#!/usr/bin/env bash
# ============================================================
#  اختبار تكامل واجهة أفاقي — تشغيل واحد يثبت إن الشغل تمام
#  الاستخدام:   bash afaqy-login-test.sh
#  ملاحظة: اليوزر والباسورد بيفضلوا على جهازك، مش بيتبعتوا لحد.
# ============================================================

BASE="https://api.afaqy.sa"        # غيّرها لو بتشتغل على بيئة تانية
USERNAME="ضع_اليوزر_هنا"
PASSWORD="ضع_الباسورد_هنا"

# ------------------------------------------------------------
echo "==============================================="
echo " 1) تسجيل الدخول"
echo "==============================================="
echo "POST $BASE/auth/login"
echo

LOGIN_BODY=$(printf '{"data":{"username":"%s","password":"%s"}}' "$USERNAME" "$PASSWORD")

LOGIN_RESP=$(curl -sS -X POST "$BASE/auth/login" \
  -H "Content-Type: application/json" \
  -H "Accept: application/json" \
  -w $'\n__HTTP__%{http_code}' \
  -d "$LOGIN_BODY")

HTTP_CODE=$(printf '%s' "$LOGIN_RESP" | sed -n 's/.*__HTTP__//p')
LOGIN_JSON=$(printf '%s' "$LOGIN_RESP" | sed 's/__HTTP__[0-9]*$//')

echo "كود الرد: $HTTP_CODE"
echo "$LOGIN_JSON" | head -c 1200
echo; echo

TOKEN=$(printf '%s' "$LOGIN_JSON" | sed -n 's/.*"token"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p')

if [ -z "$TOKEN" ]; then
  echo "-----------------------------------------------"
  echo " ما رجعش توكن. الأسباب المحتملة:"
  echo "   - اليوزر أو الباسورد غلط"
  echo "   - الحساب مفعّل عليه تحقق بخطوتين"
  echo "     (لازم /auth/send_login_otp ثم /auth/verify_login_otp)"
  echo "   - البيئة غلط — جرّب BASE تاني"
  echo " ابعت الرد اللي فوق زي ما هو لتيم مصر."
  echo "-----------------------------------------------"
  exit 1
fi

echo "تمام — التوكن رجع. أول ١٢ حرف منه: ${TOKEN:0:12}..."
echo

# ------------------------------------------------------------
echo "==============================================="
echo " 2) نداء حقيقي بالتوكن — لستة العربيات"
echo "==============================================="
echo "POST $BASE/units/lists?token=***"
echo

UNITS_RESP=$(curl -sS -X POST "$BASE/units/lists?token=$TOKEN" \
  -H "Content-Type: application/json" \
  -H "Accept: application/json" \
  -w $'\n__HTTP__%{http_code}' \
  -d '{"data":{"offset":0,"limit":3,"projection":["basic","last_update"]}}')

U_CODE=$(printf '%s' "$UNITS_RESP" | sed -n 's/.*__HTTP__//p')
U_JSON=$(printf '%s' "$UNITS_RESP" | sed 's/__HTTP__[0-9]*$//')

echo "كود الرد: $U_CODE"
if command -v python3 >/dev/null 2>&1; then
  printf '%s' "$U_JSON" | python3 -m json.tool 2>/dev/null | head -60 || printf '%s' "$U_JSON" | head -c 2000
else
  printf '%s' "$U_JSON" | head -c 2000
fi
echo; echo

# ------------------------------------------------------------
echo "==============================================="
echo " 3) الـ curl الكامل الجاهز للنسخ"
echo "==============================================="
cat <<EOF

# --- تسجيل الدخول ---
curl -X POST "$BASE/auth/login" \\
  -H "Content-Type: application/json" \\
  -d '{"data":{"username":"$USERNAME","password":"***"}}'

# --- أي نداء بعد كده (التوكن في الرابط مش في الهيدر) ---
curl -X POST "$BASE/units/lists?token=\$TOKEN" \\
  -H "Content-Type: application/json" \\
  -d '{"data":{"offset":0,"limit":3,"projection":["basic","last_update"]}}'

EOF
echo "خلص. لو الاتنين رجعوا 200، التكامل شغال والعميل يقدر يمشي على نفس النمط."
