# ============================================================
#  اختبار تكامل واجهة أفاقي — نسخة ويندوز
#  الاستخدام: افتح PowerShell في نفس الفولدر واكتب
#      .\afaqy-login-test.ps1
#  اليوزر والباسورد بيفضلوا على جهازك، مش بيتبعتوا لحد.
# ============================================================

$Base     = "https://api.afaqy.sa"     # غيّرها لو بتشتغل على بيئة تانية
$Username = "ضع_اليوزر_هنا"
$Password = "ضع_الباسورد_هنا"

Write-Host "=== 1) تسجيل الدخول ===" -ForegroundColor Cyan
Write-Host "POST $Base/auth/login`n"

$loginBody = @{ data = @{ username = $Username; password = $Password } } | ConvertTo-Json -Depth 5

try {
    $login = Invoke-RestMethod -Uri "$Base/auth/login" -Method Post `
                -ContentType "application/json" -Body $loginBody -ErrorAction Stop
} catch {
    Write-Host "فشل تسجيل الدخول:" -ForegroundColor Red
    Write-Host $_.Exception.Message
    if ($_.ErrorDetails.Message) { Write-Host $_.ErrorDetails.Message }
    Write-Host "`nابعت الرسالة دي زي ما هي لتيم مصر." -ForegroundColor Yellow
    exit 1
}

$token = $login.data.token
if (-not $token) {
    Write-Host "ما رجعش توكن. غالبًا الحساب عليه تحقق بخطوتين، أو البيانات غلط." -ForegroundColor Yellow
    $login | ConvertTo-Json -Depth 6
    exit 1
}
Write-Host ("تمام — التوكن رجع. أول ١٢ حرف: " + $token.Substring(0,12) + "...") -ForegroundColor Green

Write-Host "`n=== 2) نداء حقيقي بالتوكن — لستة العربيات ===" -ForegroundColor Cyan
Write-Host "POST $Base/units/lists?token=***`n"

$unitsBody = @{ data = @{ offset = 0; limit = 3; projection = @("basic","last_update") } } | ConvertTo-Json -Depth 5

try {
    $units = Invoke-RestMethod -Uri "$Base/units/lists?token=$token" -Method Post `
                -ContentType "application/json" -Body $unitsBody -ErrorAction Stop
    ($units | ConvertTo-Json -Depth 6) -split "`n" | Select-Object -First 60
    Write-Host "`nالنداء رجع بنجاح." -ForegroundColor Green
} catch {
    Write-Host "النداء فشل:" -ForegroundColor Red
    Write-Host $_.Exception.Message
    if ($_.ErrorDetails.Message) { Write-Host $_.ErrorDetails.Message }
}

Write-Host "`n=== 3) الـ curl الجاهز للنسخ ===" -ForegroundColor Cyan
@"

curl -X POST "$Base/auth/login" \
  -H "Content-Type: application/json" \
  -d '{"data":{"username":"$Username","password":"***"}}'

curl -X POST "$Base/units/lists?token=`$TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"data":{"offset":0,"limit":3,"projection":["basic","last_update"]}}'

"@
