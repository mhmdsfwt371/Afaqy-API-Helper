#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""يبني قاعدة معرفة الـ API التاني (afaqy.in v1.6) من التوثيق الرسمي.

الفرق الجوهري عن كولكشن AVL:
  - كل النداءات GET، والمسار بيتحط في باراميتر r
  - المصادقة بـ apiKey جوه الداتا، مش توكن في الرابط
  - الداتا JSON بيتشفّر في الرابط
  - العربية بتتحدد بالـ IMEI مباشرة — مفيش تحويل لـ UID
"""
import json

def ep(i, g, n, path, data, sensitive=0, note=''):
    """i=رقم، g=موديول، n=اسم، path=قيمة r، data=بودي الداتا"""
    d = dict(data) if data else {}
    body = json.dumps({'r': path, 'data': d}, ensure_ascii=False, indent=4)
    e = {'i': 900 + i, 'g': g, 'n': n, 'm': 'GET', 'p': '/?r=' + path,
         't': 0, 'b': body, 'sys': 'in'}
    if sensitive: e['s'] = sensitive
    if note: e['d'] = note
    return e

K = '<API_KEY>'
IMEI = '<IMEI>'
DF = '2015-11-23 00:00:00'
DT = '2015-11-23 23:59:59'

EPS = [
 # ---------- الدخول والحساب ----------
 ep(1, 'Auth (IN)', 'Login', 'users/login',
    {'username': '<USERNAME>', 'password': '<PASSWORD>',
     'device': {'token': '<DEVICE_TOKEN>', 'type': 'Android'}},
    note='بيرجّع api_key — ده اللي بيتحط في كل نداء تاني. وبيرجّع كمان server وtimezone.'),
 ep(19, 'Auth (IN)', 'Change Password', 'users/changePassword',
    {'apiKey': K, 'password': '<OLD_PASSWORD>', 'newPassword': '<NEW_PASSWORD>'},
    sensitive=1,
    note='بيغيّر كلمة السر، والـ api_key بيتغيّر معاها فبيرجع بيانات الحساب من جديد.'),
 ep(20, 'Auth (IN)', 'Update Profile', 'users/updateProfile',
    {'apiKey': K, 'email': '<EMAIL>', 'fname': '<FIRST_NAME>', 'lname': '<LAST_NAME>'}),
 ep(21, 'Auth (IN)', 'Update Settings', 'users/updateSettings',
    {'apiKey': K, 'unites': 'km,l,c', 'timezone': '+ 3 hour',
     'mapIcon': 'arrow', 'rememberMapPosition': False}),

 # ---------- الأجهزة ----------
 ep(2, 'Trackers (IN)', 'Last Update', 'userTrackers/lastUpdate',
    {'apiKey': K, 'imei': IMEI, 'dateFrom': DF, 'dateTo': DT},
    note='آخر تحديث للجهاز. من غير تواريخ بيرجّع العداد من أول ما الجهاز اتضاف.'),
 ep(3, 'Trackers (IN)', 'Events', 'userTrackers/events',
    {'apiKey': K, 'imei': IMEI, 'dateFrom': DF, 'dateTo': DT},
    note='أحداث جهاز واحد في فترة. التواريخ مطلوبة هنا.'),
 ep(4, 'Trackers (IN)', 'List', 'userTrackers/list',
    {'apiKey': K, 'offset': 0, 'limit': 10},
    note='لستة الأجهزة. بترجّع imei وsimNumber وlastUpdate وonAcc (حالة الكونتاكت).'),
 ep(5, 'Trackers (IN)', 'Search', 'userTrackers/search',
    {'apiKey': K, 'offset': 0, 'limit': 10, 'searchKey': '<SEARCH>'},
    note='بحث بالاسم أو الـ IMEI أو رقم الشريحة.'),
 ep(8, 'Trackers (IN)', 'History', 'userTrackers/history',
    {'apiKey': K, 'imei': IMEI, 'dateFrom': DF, 'dateTo': DT, 'minStop': 1},
    note='مسار الجهاز: route وstops وevents وطول المسار.'),
 ep(16, 'Trackers (IN)', 'Update', 'userTrackers/update',
    {'apiKey': K, 'imei': IMEI, 'name': '<NAME>', 'groupIds': [1, 2, 3]},
    sensitive=1, note='بيغيّر اسم الجهاز والمجموعات بتاعته.'),
 ep(9, 'Trackers (IN)', 'Groups List', 'userTrackerGroups/list', {'apiKey': K}),
 ep(10, 'Trackers (IN)', 'List Icons', 'trackers/listIcons', {'apiKey': K}),
 ep(38, 'Trackers (IN)', 'Statuses List', 'trackerStatuses/list', {'apiKey': K},
    note='حالات الجهاز لحل الخرسانة: At Plant / Charging / Left Site …'),

 # ---------- الحساسات ----------
 ep(12, 'Sensors (IN)', 'List', 'trackerSensors/list', {'apiKey': K}),
 ep(22, 'Sensors (IN)', 'Get Value', 'trackerSensors/getValue',
    {'apiKey': K, 'imei': IMEI, 'sensorId': 233, 'min': 5,
     'dateFrom': DF, 'dateTo': DT},
    note='من غير min والتواريخ بيرجّع قيمة آخر إشارة بس.'),

 # ---------- الأحداث ----------
 ep(6, 'Events (IN)', 'Data List', 'userEventsData/list',
    {'apiKey': K, 'serverId': 1, 'eventId': 157, 'imeis': [], 'offset': 0, 'limit': 10}),
 ep(7, 'Events (IN)', 'Data Search', 'userEventsData/search',
    {'apiKey': K, 'offset': 0, 'limit': 10, 'searchKey': '<SEARCH>'}),
 ep(13, 'Events (IN)', 'User Events List', 'userEvents/list', {'apiKey': K},
    note='إعدادات الأحداث: التفعيل والإشعارات بالإيميل والرسايل والأجهزة المرتبطة.'),

 # ---------- المناطق ----------
 ep(14, 'Zones (IN)', 'List', 'userZones/list', {'apiKey': K}),
 ep(23, 'Zones (IN)', 'Add', 'userZones/add',
    {'apiKey': K, 'name': '<ZONE_NAME>', 'color': '#4D4DFF', 'visible': True,
     'visibleName': True,
     'vertices': [[24.694468, 45.685586], [24.694468, 45.685586], [24.694468, 45.685586]],
     'type': 'polygon', 'diagonal': 0, 'plant': 0},
    sensitive=1,
    note='plant: 0 عادية · 1 مصنع · 2 محطة خلط · 3 غسيل · 4 ورشة · 5 موقف. الدايرة محتاجة diagonal.'),
 ep(24, 'Zones (IN)', 'Update', 'userZones/update',
    {'apiKey': K, 'id': 93, 'name': '<ZONE_NAME>', 'color': '#4D4DFF',
     'visible': True, 'visibleName': True,
     'vertices': [[24.694468, 45.685586], [24.694468, 45.685586], [24.694468, 45.685586]],
     'type': 'polygon', 'diagonal': 0, 'plant': 0},
    sensitive=1),
 ep(25, 'Zones (IN)', 'Delete', 'userZones/delete', {'apiKey': K, 'id': 93}, sensitive=2),

 # ---------- المسارات ----------
 ep(26, 'Routes (IN)', 'List', 'userRoutes/list', {'apiKey': K}),
 ep(27, 'Routes (IN)', 'View', 'userRoutes/view', {'apiKey': K, 'id': 136}),
 ep(28, 'Routes (IN)', 'Add', 'userRoutes/add',
    {'apiKey': K, 'name': '<ROUTE_NAME>', 'imei': IMEI, 'provider': 'osm',
     'optimized': True, 'desc': '<DESC>', 'startTime': '2016-08-01 08:00:00',
     'points': [{'name': 'Node1', 'lat': '24.659042', 'lng': '46.812979', 'diagonal': 50},
                {'name': 'Node2', 'lat': '24.6768', 'lng': '46.7777', 'diagonal': 50}]},
    sensitive=1, note='provider: osm الافتراضي أو google. optimized بيرتّب النقط لأحسن مسار.'),
 ep(29, 'Routes (IN)', 'Update', 'userRoutes/update',
    {'apiKey': K, 'id': 93, 'name': '<ROUTE_NAME>', 'imei': IMEI,
     'desc': '<DESC>', 'startTime': '2016-08-01 08:00:00'}, sensitive=1),
 ep(30, 'Routes (IN)', 'Delete', 'userRoutes/delete', {'apiKey': K, 'id': 93}, sensitive=2),
 ep(11, 'Routes (IN)', 'Generate Route', 'trackers/generateRoute',
    {'apiKey': K, 'serverId': 1,
     'points': ['24.6938715,46.6857516', '24.599928,46.822208']},
    note='بيرجّع المسافة بالمتر والمدة بالثواني وpolyline بين نقطتين.'),

 # ---------- العملاء والطلبات ----------
 ep(15, 'Customers (IN)', 'List', 'customers/list', {'apiKey': K}),
 ep(31, 'Orders (IN)', 'List', 'customerOrders/list', {'apiKey': K}),
 ep(32, 'Orders (IN)', 'Add', 'customerOrders/add',
    {'apiKey': K, 'customerId': 196, 'addressId': 37, 'zoneId': 357,
     'lat': '24.6249026', 'lng': '46.6970698', 'diagonal': 50, 'capacity': 17,
     'comments': '<COMMENTS>', 'imei': IMEI, 'driverId': 5,
     'ticket': '<TICKET>', 'jobOrder': '<JOB_ORDER>',
     'requestDate': '2018-05-13 15:40:22', 'extraData': {}},
    sensitive=1,
    note='addressId مطلوب، أو ابعت lat/lng عشان يتعمل عنوان جديد.'),
 ep(33, 'Orders (IN)', 'Update', 'customerOrders/update',
    {'apiKey': K, 'id': 93, 'addressId': 37, 'capacity': 17,
     'comments': '<COMMENTS>', 'imei': IMEI, 'driverId': 5,
     'requestDate': '2018-05-13 15:40:22'}, sensitive=1),
 ep(34, 'Orders (IN)', 'Change Status', 'customerOrders/changeStatus',
    {'apiKey': K, 'id': 93, 'status': 37}, sensitive=1),
 ep(35, 'Orders (IN)', 'Delete', 'customerOrders/delete', {'apiKey': K, 'id': 29}, sensitive=2),

 # ---------- التقارير ----------
 ep(17, 'Reports (IN)', 'Get Settings', 'reports/getSettings',
    {'apiKey': K, 'lang': 'english'},
    note='بيرجّع التقارير المتاحة وحقول كل تقرير — منها بتبني نداء التوليد.'),
 ep(18, 'Reports (IN)', 'Generate', 'reports/generate',
    {'apiKey': K, 'serverId': 1,
     'reportCriteria': {'sdt': '2016-02-06 00:00:00', 'edt': '2016-02-06 23:59:59',
                        'events': [], 'objects': [IMEI], 'sensors': [], 'zones': [],
                        'customers': 0, 'fillingsOption': 0, 'sensorsPeriod': 0, 'speed': 0},
     'reportFields': ['Last_update', 'Object', 'Name', 'loc'],
     'reportName': 'latest_update'},
    note='التقرير بيتبعت على إيميل الحساب — مش بيرجع في الرد.'),
 ep(37, 'Reports (IN)', 'Concrete Trips Report', 'reports/getConcreteTripsReport',
    {'apiKey': K, 'serverId': 1, 'imei': IMEI, 'dateFrom': '2018-01-13 00:00:00',
     'dateTo': '2018-01-13 23:59:59'}),
]

if __name__ == '__main__':
    out = {'endpoints': EPS}
    json.dump(out, open('kb_in.json', 'w', encoding='utf-8'),
              ensure_ascii=False, separators=(',', ':'))
    paths = [e['p'] for e in EPS]
    assert len(paths) == len(set(paths)), 'فيه مسار مكرر'
    print(f'اتبنى: {len(EPS)} إندبوينت')
    from collections import Counter
    for g, c in sorted(Counter(e['g'] for e in EPS).items()):
        print(f'  {g:18s} {c}')
    print('حساس:', sum(1 for e in EPS if e.get('s')))
