/* v6.11 — محرك تشخيص الردود.
   الاختبار ده بيطعّم المحرك رد العميل الحقيقي من حالة دعم فعلية:
   «الحقول موجودة بس القيم مش موجودة» في تقرير — والرد اللي معاه كان
   تعريف التقرير مش نتيجته. ولازم يتأكد إنه ما بيتسرّعش على ردود سليمة. */
global.setInterval=()=>0;global.clearInterval=()=>{};
const fs = require('fs');
const R = {};
function el(id){return{id,hidden:false,innerHTML:'',value:'',textContent:'',className:'',dataset:{},style:{},files:[],disabled:false,
 options:[],classList:{toggle(){},add(){},remove(){}},querySelectorAll(){return[]},addEventListener(){},focus(){},select(){},click(){},
 setAttribute(){},getAttribute(){return null},dispatchEvent(){},appendChild(){},remove(){},scrollIntoView(){},title:''}}
global.document={documentElement:el('html'),body:el('body'),addEventListener(){},querySelectorAll(){return[]},
 querySelector(){return null},createElement(){return el()},getElementById:i=>R[i]||(R[i]=el(i))};
global.history={pushState(){},replaceState(){}};global.location={hash:'',pathname:'/',replace(){}};
global.navigator={userAgent:'node',language:'ar',clipboard:{writeText(){return Promise.resolve()}}};
global.window={scrollTo(){},addEventListener(){},matchMedia:()=>({matches:false}),navigator:{}};
global.fetch=()=>Promise.reject(0);global.Blob=function(){};global.URL={createObjectURL(){return''}};global.FileReader=function(){};
global.btoa=x=>Buffer.from(x,'binary').toString('base64');global.atob=x=>Buffer.from(x,'base64').toString('binary');
const D={};global.localStorage={getItem:k=>(k in D?D[k]:null),setItem:(k,v)=>{D[k]=String(v);},removeItem(){}};
global.sessionStorage={getItem:()=>null,setItem(){},removeItem(){}};global.confirm=()=>false;

let js = fs.readFileSync('app_template.html','utf8').split('<script>')[1].split('</script>')[0]
  .replace('/*__KB__*/', fs.readFileSync('kb_slim.json','utf8'))
  .replace('/*__KBIN__*/', fs.readFileSync('kb_in.json','utf8'))
  .replace('/*__DOCS__*/', fs.readFileSync('docs.json','utf8'));
const m={};
new Function('module', js + "\nmodule.exports={diagPanel,PATTERNS,EPS,setLang,depsOf,RESOLVERS,analyzeCase,caseReply,jsonBlocks,blockKind,isReportEp,RSCOPE,prepBody,bodyOf};")(m);
const A = m.exports;
const fail = msg => { console.error('فشل: ' + msg); process.exit(1); };

/* ============ رد العميل الحقيقي من الحالة ============ */
const CASE = {
  data: [{
    summary_beta: {
      fields: [
        {name:'Date', code:'date', format:'label', order:'1', selected:true, active:true},
        {name:'Route Length', code:'route_length', format:'label', order:'2', selected:true, active:true, aggregate:'Sum'},
        {name:'Engine Work Duration', code:'engine_work', format:'label', order:'3', selected:true, active:true},
        {name:'Engine Work Percentage', code:'engine_work_percentage', format:'label', order:'4', selected:true, active:true},
        {name:'Stop Duration', code:'stop_duration', format:'label', order:'5', selected:true, active:true}
      ]
    }
  }],
  status_code: 200, message: 'success'
};

const got = A.diagPanel(CASE, JSON.stringify(CASE));
if(!got) fail('المحرك ما شخّصش حالة العميل الحقيقية خالص');
if(got.indexOf('تعريف التقرير') < 0) fail('التشخيص مش بيقول إنه تعريف مش نتيجة');
if(got.indexOf('reports/generate') < 0) fail('التشخيص ما دلّش على إندبوينت التنفيذ');
if(got.indexOf('REPORT_ID') < 0) fail('التشخيص ما وضّحش الباراميترات المطلوبة');
if(got.indexOf('data-goep') < 0) fail('مفيش زرار بيفتح الريكوست الصح');
console.log('حالة العميل        : اتشخّصت صح مع الخطوة الجاية والريكوست ✓');

/* الريكوست اللي بيوديله لازم يكون موجود فعلًا */
const idm = /data-goep="(\d+)"/.exec(got);
const target = A.EPS.find(e => String(e.i) === idm[1]);
if(!target) fail('الزرار بيوصّل لريكوست مش موجود');
if(target.p.indexOf('reports/generate') < 0) fail('الزرار بيوصّل لريكوست غلط: ' + target.p);
console.log('الوجهة             : ' + target.n + ' → ' + target.p.slice(0,52) + '… ✓');

/* ============ ما يتسرّعش على ردود سليمة ============ */
const REAL_RESULT = { data:[{ date:'2026-08-10', route_length:125.5, engine_work:'08:20:15' }],
                      status_code:200, message:'success' };
if(A.diagPanel(REAL_RESULT, JSON.stringify(REAL_RESULT)))
  fail('المحرك شخّص رد نتايج حقيقي كأنه تعريف — إنذار كاذب');

const WITH_VALUES = { data:{ fields:[{name:'Date', code:'date', value:'2026-08-10', selected:true, active:true, format:'label'}] } };
if(A.diagPanel(WITH_VALUES, JSON.stringify(WITH_VALUES)))
  fail('حقول فيها value اتشخّصت كتعريف');

const UNITS = { data:[{name:'LSR-8031', imei:'869487062749717'}], status_code:200 };
if(A.diagPanel(UNITS, JSON.stringify(UNITS))) fail('رد عربيات عادي اتشخّص بالغلط');
console.log('الإنذار الكاذب     : ولا واحد على تلات ردود سليمة ✓');

/* ============ نمط الفلتر الفاضي ============ */
const FILTERED = { data:[], pagination:{allCount:1200, filtersCount:0, resultCount:0}, status_code:200 };
const f = A.diagPanel(FILTERED, JSON.stringify(FILTERED));
if(!f) fail('رد الفلتر الفاضي ما اتشخّصش');
if(f.indexOf('الفلتر') < 0) fail('تشخيص الفلتر مش واضح');
const EMPTY_ACC = { data:[], pagination:{allCount:0, resultCount:0}, status_code:200 };
if(A.diagPanel(EMPTY_ACC, JSON.stringify(EMPTY_ACC)))
  fail('حساب فاضي فعلًا اتشخّص كأنه فلتر ضيّق — ده تشخيص غلط');
console.log('نمط الفلتر         : بيفرّق بين فلتر ضيّق وحساب فاضي ✓');

/* ============ التشخيص بيشتغل باللغتين ============ */
A.setLang('en');
const en = A.diagPanel(CASE, JSON.stringify(CASE));
if(/[\u0600-\u06FF]/.test(en.replace(/<[^>]*>/g,'').replace(/reports\/generate|REPORT_ID|USER_ID|code|id/g,'')))
  fail('التشخيص فيه عربي في الوضع الإنجليزي');
if(en.indexOf('report definition') < 0) fail('التشخيص الإنجليزي مش مترجم');
A.setLang('ar');
console.log('اللغتين            : التشخيص بيتترجم ✓');

/* v6.12 — ريكوستات تقارير المستخدم لازم تطلب رقم التقرير من حساب العميل.
   من حالة حقيقية: /user_reports/data-summary اتبعت بالـ id بتاع العينة
   فرجع 405 · id: not_found — لأن الرقم تبع حساب تاني. */
(function(){
  const need = ['/user_reports/data-summary','/user_reports/data','/user_reports/data-new'];
  for(const p of need){
    const e = A.EPS.find(x => x.p === p && x.sys === 'avl');
    if(!e) continue;
    const keys = A.depsOf(e).map(r => r.key);
    if(keys.indexOf('userReport') < 0)
      fail('ريكوست تقرير من غير اعتمادية — هيتبعت برقم عينة ويرجع not_found: ' + p);
  }
  const r = A.RESOLVERS.find(x => x.key === 'userReport');
  if(!r) fail('قاعدة تقارير المستخدم اتشالت');
  if(!r.prefer || !r.prefer.test('Summary')) fail('التفضيل مش على تقرير Summary');
  if(r.prefer.test('Summary By Driver')) fail('التفضيل واسع — بيمسك By Driver كمان');
  console.log('اعتمادية التقارير  : 3 ريكوستات، والتفضيل على Summary بالظبط ✓');
})();

/* ============ تحليل رسالة العميل ============
   الموظف بيوصله إيميل مخلوط: الرد اللي اشتكى منه، والمثال اللي عايزه،
   وأسئلة مرقّمة. لزقه في «افحص رد» كان بياخد آخر بلوك — يعني المثال
   المرغوب بدل الرد الفعلي، وده تشخيص غلط من أوله. */
const MSG = [
 'We are integrating the Report API but we are facing an issue with the response data.',
 'each object appears to contain only the field definition/metadata, rather than the actual value.',
 '{ "name": "Date", "code": "date", "format": "label", "order": "1", "selected": true, "active": true }',
 'Similarly, for the Route Length field:',
 '{ "name": "Route Length", "code": "route_length", "format": "label", "order": "2", "selected": true, "active": true, "aggregate": "Sum" }',
 'we cannot display the actual report data because the response does not contain the corresponding values.',
 'Could you please clarify the following:',
 '1. Is this API endpoint only returning the report field configuration/metadata, rather than the actual results?',
 '2. If so, which API endpoint should we call to retrieve the actual values for these fields?',
 '3. What parameters are required to retrieve the report data, such as date range, vehicle, or other filters?',
 '4. Could you please provide an example response containing actual values, for example:',
 '{ "date": "2026-08-10", "route_length": 125.5, "engine_work": "08:20:15", "stop_duration": "00:24:25" }'
].join('\n');

const an = A.analyzeCase(MSG);
if(!an.isMsg) fail('ما عرفش إن دي رسالة مش رد خام');
if(an.blocks.length !== 3) fail('عدد البلوكات غلط: ' + an.blocks.length);

/* أهم فحص: التفرقة بين الرد اللي اشتكى منه والمثال اللي عايزه */
if(an.defs.length !== 2) fail('ما فصلش تعريفات الحقول: ' + an.defs.length);
if(an.wanted.length !== 1) fail('ما ميّزش الشكل المرغوب: ' + an.wanted.length);
if(an.wanted[0].at < an.defs[0].at) fail('رتّب البلوكات غلط');
if(A.blockKind(an.wanted[0].json) === A.blockKind(an.defs[0].json))
  fail('التعريف والشكل المرغوب اتصنّفوا نفس النوع — دي المشكلة الأصلية');
console.log('فصل البلوكات       : 2 تعريف + 1 شكل مرغوب، متفرّقين ✓');

if(an.qs.length !== 4) fail('أسئلة العميل الأربعة ما اتلقطتش: ' + an.qs.length);
if(!an.reportCase) fail('حالة التقارير ما اتحددتش');
console.log('الأسئلة والحالة    : 4 أسئلة، والحالة اتحددت ✓');

/* الرد الجاهز لازم يرد على الأربعة ويدل على إندبوينت حقيقي */
const rep = A.caseReply(an);
if(!rep) fail('ما طلّعش رد');
for(const n of ['1)','2)','3)','4)']) if(rep.indexOf(n) < 0) fail('الرد ما ردّش على سؤال ' + n);
if(/[\u0600-\u06FF]/.test(rep)) fail('الرد فيه عربي والعميل كاتب إنجليزي');

/* الدليل اللي صحّح الإجابة: حقول العميل موجودة بالحرف في قالب code:"summary".
   يبقى المطلوب تشغيل تقرير الـ Summary، مش إندبوينت تنفيذ على دومين تاني. */
const tpl2 = A.EPS.find(e => e.p === '/user_report_templates/add' && e.sys === 'avl');
if(!tpl2) fail('قالب التقارير مش موجود في الكولكشن');
for(const code of ['route_length','engine_work','engine_idle','move_duration','stop_duration'])
  if(tpl2.b.indexOf(code) < 0) fail('حقل من حقول العميل مش في القالب: ' + code);
if(tpl2.b.indexOf('"code":"summary"') < 0) fail('القالب مش متعلّم كـ summary');

const dataEp3 = A.EPS.find(e => e.p === '/user_reports/data-summary' && e.sys === 'avl');
if(rep.indexOf(dataEp3.p) < 0) fail('الرد مش بيدل على إندبوينت داتا الـ Summary');
if(rep.indexOf('/user_reports/lists') < 0) fail('الرد ما قالش إزاي يجيب رقم تقريره');
if(rep.indexOf('not_found') < 0) fail('الرد ما فسّرش سبب not_found');
if(rep.indexOf('reports.afaqy-fleet.site') >= 0)
  fail('الرد رجع يدل على دومين التنفيذ التاني — دي كانت الإجابة الغلط');
console.log('الرد الجاهز        : بيدل على داتا الـ Summary بدليل من القالب ✓');

/* ما يتسرّعش: رسالة عادية من غير الحالة دي */
const PLAIN = 'Hello, the vehicle LSR-8031 shows offline since yesterday. Could you check?';
const a2 = A.analyzeCase(PLAIN);
if(a2.reportCase) fail('شخّص رسالة عادية كحالة تقارير');
if(A.caseReply(a2)) fail('طلّع رد جاهز لرسالة مالهاش قاعدة');
console.log('الإنذار الكاذب     : رسالة عادية عدّت من غير رد جاهز ✓');

/* ============ نطاق التقرير ============
   من تجربة حية على حساب فيه 3700 عربية: التقرير محتاج نطاق —
   كل العربيات أو IMEIs محددة تتحوّل لـ UIDs. */
const rep2 = A.EPS.find(e => e.p === '/user_reports/data-summary' && e.sys === 'avl');
if(!A.isReportEp(rep2)) fail('ريكوست التقرير ما اتعرفش');
if(A.isReportEp(A.EPS.find(e => e.p === '/units/lists' && e.sys === 'avl')))
  fail('ريكوست عادي اتحسب تقرير');

/* المعروض = المتبعت: النطاق لازم يبان في البودي المجهّز نفسه،
   مش يتحط في السر وقت الإرسال. */
A.RSCOPE.mode = 'all'; A.RSCOPE.uids = []; A.RSCOPE.names = [];
let out2 = JSON.parse(A.bodyOf(rep2));
if('units' in out2.data) fail('وضع «الكل» المفروض من غير حقل units');

A.RSCOPE.mode = 'imeis'; A.RSCOPE.uids = ['uid-1','uid-2','uid-3']; A.RSCOPE.names = ['3285','3286','3287'];
const pr2 = A.prepBody(rep2);
out2 = JSON.parse(pr2.text);
if(!Array.isArray(out2.data.units) || out2.data.units.length !== 3)
  fail('الـ UIDs ما بانتش في البودي المعروض');
if(out2.data.units[0] !== 'uid-1') fail('ترتيب الـ UIDs اتغيّر');
if(!out2.data.id) fail('رقم التقرير ضاع من البودي');
if(!pr2.applied) fail('البودي المفروض يتعلّم إنه اتظبط للتجربة');
if(!pr2.changes.some(c => /3285|عربية|vehicles/.test(c))) fail('التغيير مش متقال للموظف');

/* اللي بيتبعت فعلًا = نفس اللي معروض */
if(A.bodyOf(rep2) !== pr2.text) fail('المتبعت مختلف عن المعروض');
const twice = JSON.parse(A.bodyOf(rep2));
if(twice.data.units.length !== 3) fail('النطاق اتحط مرتين');

A.RSCOPE.mode = 'all'; A.RSCOPE.uids = []; A.RSCOPE.names = [];
out2 = JSON.parse(A.bodyOf(rep2));
if('units' in out2.data) fail('الرجوع للكل ما شالش الـ UIDs');
console.log('نطاق التقرير       : بيبان في البودي المعروض، والمتبعت نفسه ✓');

/* بودي لستة التقارير لازم يكون الشكل اللي في الكولكشن */
/* الفحص ده اتشال: كان بيفرض شكل data المصفوفة، وطلع إنه مش موجود في
   الكولكشن أصلًا — الشكلين الحقيقيين {data:{limit}} و{data:{data:[{filters}]}}.
   الفحص الصح بقى تحت: كل شكل لازم يكون واحد من اللي في الكولكشن. */

/* ============ لستة التقارير: الشكل الصح + بدائل ============
   من تجربة حية: النافذة قالت «ما قدرناش نجيب اللستة — خطأ من السيرفر».
   السبب إن بودي اللستة اتكتب بشكل مش موجود في الكولكشن أصلًا. */
const rr2 = A.RESOLVERS.find(x => x.key === 'userReport');
const shapes = [rr2.list.body].concat(rr2.list.alts || []);
if(shapes.length < 2) fail('مفيش بدائل — أي رفض من السيرفر هيوقف الاعتمادية');

/* كل شكل لازم يكون واحد من الأشكال الموجودة فعلًا في الكولكشن */
const known = A.EPS.filter(e => e.p === '/user_reports/lists' && e.sys === 'avl')
                   .map(e => { try{ return JSON.stringify(JSON.parse(e.b)); }catch(_){ return ''; } });
const used = JSON.stringify(shapes[0]);
if(known.indexOf(used) < 0)
  fail('الشكل الأساسي مش من الكولكشن: ' + used);
console.log('بودي لستة التقارير : الأساسي من الكولكشن و' + (shapes.length-1) + ' بدائل ✓');

/* قسم العربيات جوه نافذة الاعتمادية */
const tpl3 = fs.readFileSync('app_template.html','utf8');
if(tpl3.indexOf('id="depImeis"') < 0) fail('خانة الـ IMEIs مش في نافذة الاعتمادية');
if(tpl3.indexOf('isReportEp(e) ?') < 0) fail('القسم بيظهر على كل الريكوستات مش التقارير بس');
if(tpl3.indexOf('resolveImeis(txt)') < 0) fail('الخانة مش موصّلة بمحوّل الـ IMEIs');
console.log('العربيات في النافذة: ظاهرة لريكوستات التقارير وموصّلة ✓');
