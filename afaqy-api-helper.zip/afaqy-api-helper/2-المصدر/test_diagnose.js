/* v6.11 — محرك تشخيص الردود.
   الاختبار ده بيطعّم المحرك رد العميل الحقيقي من حالة دعم فعلية:
   «الحقول موجودة بس القيم مش موجودة» في تقرير — والرد اللي معاه كان
   تعريف التقرير مش نتيجته. ولازم يتأكد إنه ما بيتسرّعش على ردود سليمة. */
global.setInterval=()=>0;global.clearInterval=()=>{};
const fs = require('fs');
const R = {};
function el(id){return{id,hidden:false,innerHTML:'',value:'',textContent:'',className:'',dataset:{},style:{},files:[],disabled:false,
 options:[],classList:{toggle(){},add(){},remove(){}},querySelectorAll(){return[]},addEventListener(){},focus(){},select(){},click(){},
 setAttribute(){},getAttribute(){return null},dispatchEvent(){},appendChild(){},remove(){},scrollIntoView(){},title:''}}
global.document={documentElement:el('html'),body:el('body'),addEventListener(){},querySelectorAll(){return[]},
 querySelector(){return null},createElement(){return el()},getElementById:i=>R[i]||(R[i]=el(i))};
global.history={pushState(){},replaceState(){}};global.location={hash:'',pathname:'/',replace(){}};
global.navigator={userAgent:'node',language:'ar',clipboard:{writeText(){return Promise.resolve()}}};
global.window={scrollTo(){},addEventListener(){},matchMedia:()=>({matches:false}),navigator:{}};
global.fetch=()=>Promise.reject(0);global.Blob=function(){};global.URL={createObjectURL(){return''}};global.FileReader=function(){};
global.btoa=x=>Buffer.from(x,'binary').toString('base64');global.atob=x=>Buffer.from(x,'base64').toString('binary');
const D={};global.localStorage={getItem:k=>(k in D?D[k]:null),setItem:(k,v)=>{D[k]=String(v);},removeItem(){}};
global.sessionStorage={getItem:()=>null,setItem(){},removeItem(){}};global.confirm=()=>false;

let js = fs.readFileSync('app_template.html','utf8').split('<script>')[1].split('</script>')[0]
  .replace('/*__KB__*/', fs.readFileSync('kb_slim.json','utf8'))
  .replace('/*__KBIN__*/', fs.readFileSync('kb_in.json','utf8'))
  .replace('/*__DOCS__*/', fs.readFileSync('docs.json','utf8'));
const m={};
new Function('module', js + "\nmodule.exports={diagPanel,PATTERNS,EPS,setLang,depsOf,RESOLVERS,analyzeCase,caseReply,jsonBlocks,blockKind};")(m);
const A = m.exports;
const fail = msg => { console.error('فشل: ' + msg); process.exit(1); };

/* ============ رد العميل الحقيقي من الحالة ============ */
const CASE = {
  data: [{
    summary_beta: {
      fields: [
        {name:'Date', code:'date', format:'label', order:'1', selected:true, active:true},
        {name:'Route Length', code:'route_length', format:'label', order:'2', selected:true, active:true, aggregate:'Sum'},
        {name:'Engine Work Duration', code:'engine_work', format:'label', order:'3', selected:true, active:true},
        {name:'Engine Work Percentage', code:'engine_work_percentage', format:'label', order:'4', selected:true, active:true},
        {name:'Stop Duration', code:'stop_duration', format:'label', order:'5', selected:true, active:true}
      ]
    }
  }],
  status_code: 200, message: 'success'
};

const got = A.diagPanel(CASE, JSON.stringify(CASE));
if(!got) fail('المحرك ما شخّصش حالة العميل الحقيقية خالص');
if(got.indexOf('تعريف التقرير') < 0) fail('التشخيص مش بيقول إنه تعريف مش نتيجة');
if(got.indexOf('reports/generate') < 0) fail('التشخيص ما دلّش على إندبوينت التنفيذ');
if(got.indexOf('REPORT_ID') < 0) fail('التشخيص ما وضّحش الباراميترات المطلوبة');
if(got.indexOf('data-goep') < 0) fail('مفيش زرار بيفتح الريكوست الصح');
console.log('حالة العميل        : اتشخّصت صح مع الخطوة الجاية والريكوست ✓');

/* الريكوست اللي بيوديله لازم يكون موجود فعلًا */
const idm = /data-goep="(\d+)"/.exec(got);
const target = A.EPS.find(e => String(e.i) === idm[1]);
if(!target) fail('الزرار بيوصّل لريكوست مش موجود');
if(target.p.indexOf('reports/generate') < 0) fail('الزرار بيوصّل لريكوست غلط: ' + target.p);
console.log('الوجهة             : ' + target.n + ' → ' + target.p.slice(0,52) + '… ✓');

/* ============ ما يتسرّعش على ردود سليمة ============ */
const REAL_RESULT = { data:[{ date:'2026-08-10', route_length:125.5, engine_work:'08:20:15' }],
                      status_code:200, message:'success' };
if(A.diagPanel(REAL_RESULT, JSON.stringify(REAL_RESULT)))
  fail('المحرك شخّص رد نتايج حقيقي كأنه تعريف — إنذار كاذب');

const WITH_VALUES = { data:{ fields:[{name:'Date', code:'date', value:'2026-08-10', selected:true, active:true, format:'label'}] } };
if(A.diagPanel(WITH_VALUES, JSON.stringify(WITH_VALUES)))
  fail('حقول فيها value اتشخّصت كتعريف');

const UNITS = { data:[{name:'LSR-8031', imei:'869487062749717'}], status_code:200 };
if(A.diagPanel(UNITS, JSON.stringify(UNITS))) fail('رد عربيات عادي اتشخّص بالغلط');
console.log('الإنذار الكاذب     : ولا واحد على تلات ردود سليمة ✓');

/* ============ نمط الفلتر الفاضي ============ */
const FILTERED = { data:[], pagination:{allCount:1200, filtersCount:0, resultCount:0}, status_code:200 };
const f = A.diagPanel(FILTERED, JSON.stringify(FILTERED));
if(!f) fail('رد الفلتر الفاضي ما اتشخّصش');
if(f.indexOf('الفلتر') < 0) fail('تشخيص الفلتر مش واضح');
const EMPTY_ACC = { data:[], pagination:{allCount:0, resultCount:0}, status_code:200 };
if(A.diagPanel(EMPTY_ACC, JSON.stringify(EMPTY_ACC)))
  fail('حساب فاضي فعلًا اتشخّص كأنه فلتر ضيّق — ده تشخيص غلط');
console.log('نمط الفلتر         : بيفرّق بين فلتر ضيّق وحساب فاضي ✓');

/* ============ التشخيص بيشتغل باللغتين ============ */
A.setLang('en');
const en = A.diagPanel(CASE, JSON.stringify(CASE));
if(/[\u0600-\u06FF]/.test(en.replace(/<[^>]*>/g,'').replace(/reports\/generate|REPORT_ID|USER_ID|code|id/g,'')))
  fail('التشخيص فيه عربي في الوضع الإنجليزي');
if(en.indexOf('report definition') < 0) fail('التشخيص الإنجليزي مش مترجم');
A.setLang('ar');
console.log('اللغتين            : التشخيص بيتترجم ✓');

/* v6.12 — ريكوستات تقارير المستخدم لازم تطلب رقم التقرير من حساب العميل.
   من حالة حقيقية: /user_reports/data-summary اتبعت بالـ id بتاع العينة
   فرجع 405 · id: not_found — لأن الرقم تبع حساب تاني. */
(function(){
  const need = ['/user_reports/data-summary','/user_reports/data','/user_reports/data-new'];
  for(const p of need){
    const e = A.EPS.find(x => x.p === p && x.sys === 'avl');
    if(!e) continue;
    const keys = A.depsOf(e).map(r => r.key);
    if(keys.indexOf('userReport') < 0)
      fail('ريكوست تقرير من غير اعتمادية — هيتبعت برقم عينة ويرجع not_found: ' + p);
  }
  const r = A.RESOLVERS.find(x => x.key === 'userReport');
  if(!r) fail('قاعدة تقارير المستخدم اتشالت');
  if(!r.prefer || !r.prefer.test('Summary')) fail('التفضيل مش على تقرير Summary');
  if(r.prefer.test('Summary By Driver')) fail('التفضيل واسع — بيمسك By Driver كمان');
  console.log('اعتمادية التقارير  : 3 ريكوستات، والتفضيل على Summary بالظبط ✓');
})();

/* ============ تحليل رسالة العميل ============
   الموظف بيوصله إيميل مخلوط: الرد اللي اشتكى منه، والمثال اللي عايزه،
   وأسئلة مرقّمة. لزقه في «افحص رد» كان بياخد آخر بلوك — يعني المثال
   المرغوب بدل الرد الفعلي، وده تشخيص غلط من أوله. */
const MSG = [
 'We are integrating the Report API but we are facing an issue with the response data.',
 'each object appears to contain only the field definition/metadata, rather than the actual value.',
 '{ "name": "Date", "code": "date", "format": "label", "order": "1", "selected": true, "active": true }',
 'Similarly, for the Route Length field:',
 '{ "name": "Route Length", "code": "route_length", "format": "label", "order": "2", "selected": true, "active": true, "aggregate": "Sum" }',
 'we cannot display the actual report data because the response does not contain the corresponding values.',
 'Could you please clarify the following:',
 '1. Is this API endpoint only returning the report field configuration/metadata, rather than the actual results?',
 '2. If so, which API endpoint should we call to retrieve the actual values for these fields?',
 '3. What parameters are required to retrieve the report data, such as date range, vehicle, or other filters?',
 '4. Could you please provide an example response containing actual values, for example:',
 '{ "date": "2026-08-10", "route_length": 125.5, "engine_work": "08:20:15", "stop_duration": "00:24:25" }'
].join('\n');

const an = A.analyzeCase(MSG);
if(!an.isMsg) fail('ما عرفش إن دي رسالة مش رد خام');
if(an.blocks.length !== 3) fail('عدد البلوكات غلط: ' + an.blocks.length);

/* أهم فحص: التفرقة بين الرد اللي اشتكى منه والمثال اللي عايزه */
if(an.defs.length !== 2) fail('ما فصلش تعريفات الحقول: ' + an.defs.length);
if(an.wanted.length !== 1) fail('ما ميّزش الشكل المرغوب: ' + an.wanted.length);
if(an.wanted[0].at < an.defs[0].at) fail('رتّب البلوكات غلط');
if(A.blockKind(an.wanted[0].json) === A.blockKind(an.defs[0].json))
  fail('التعريف والشكل المرغوب اتصنّفوا نفس النوع — دي المشكلة الأصلية');
console.log('فصل البلوكات       : 2 تعريف + 1 شكل مرغوب، متفرّقين ✓');

if(an.qs.length !== 4) fail('أسئلة العميل الأربعة ما اتلقطتش: ' + an.qs.length);
if(!an.reportCase) fail('حالة التقارير ما اتحددتش');
console.log('الأسئلة والحالة    : 4 أسئلة، والحالة اتحددت ✓');

/* الرد الجاهز لازم يرد على الأربعة ويدل على إندبوينت حقيقي */
const rep = A.caseReply(an);
if(!rep) fail('ما طلّعش رد');
for(const n of ['1)','2)','3)','4)']) if(rep.indexOf(n) < 0) fail('الرد ما ردّش على سؤال ' + n);
if(rep.indexOf('reports/generate') < 0) fail('الرد ما دلّش على إندبوينت التنفيذ');
if(rep.indexOf('REPORT_ID') < 0 || rep.indexOf('USER_ID') < 0) fail('الرد ما وضّحش الباراميترات');
if(/[\u0600-\u06FF]/.test(rep)) fail('الرد فيه عربي والعميل كاتب إنجليزي');
const gen = A.EPS.find(e => e.n === 'EXCE BETA REPORTS');
if(!gen || rep.indexOf(gen.p) < 0) fail('الرد مش بياخد المسار من الكولكشن');
console.log('الرد الجاهز        : بيرد على الأربعة، ومساره من الكولكشن ✓');

/* ما يتسرّعش: رسالة عادية من غير الحالة دي */
const PLAIN = 'Hello, the vehicle LSR-8031 shows offline since yesterday. Could you check?';
const a2 = A.analyzeCase(PLAIN);
if(a2.reportCase) fail('شخّص رسالة عادية كحالة تقارير');
if(A.caseReply(a2)) fail('طلّع رد جاهز لرسالة مالهاش قاعدة');
console.log('الإنذار الكاذب     : رسالة عادية عدّت من غير رد جاهز ✓');
