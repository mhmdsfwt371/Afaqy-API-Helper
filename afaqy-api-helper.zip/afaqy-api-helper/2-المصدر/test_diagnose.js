/* v6.11 — محرك تشخيص الردود.
   الاختبار ده بيطعّم المحرك رد العميل الحقيقي من حالة دعم فعلية:
   «الحقول موجودة بس القيم مش موجودة» في تقرير — والرد اللي معاه كان
   تعريف التقرير مش نتيجته. ولازم يتأكد إنه ما بيتسرّعش على ردود سليمة. */
global.setInterval=()=>0;global.clearInterval=()=>{};
const fs = require('fs');
const R = {};
function el(id){return{id,hidden:false,innerHTML:'',value:'',textContent:'',className:'',dataset:{},style:{},files:[],disabled:false,
 options:[],classList:{toggle(){},add(){},remove(){}},querySelectorAll(){return[]},addEventListener(){},focus(){},select(){},click(){},
 setAttribute(){},getAttribute(){return null},dispatchEvent(){},appendChild(){},remove(){},scrollIntoView(){},title:''}}
global.document={documentElement:el('html'),body:el('body'),addEventListener(){},querySelectorAll(){return[]},
 querySelector(){return null},createElement(){return el()},getElementById:i=>R[i]||(R[i]=el(i))};
global.history={pushState(){},replaceState(){}};global.location={hash:'',pathname:'/',replace(){}};
global.navigator={userAgent:'node',language:'ar',clipboard:{writeText(){return Promise.resolve()}}};
global.window={scrollTo(){},addEventListener(){},matchMedia:()=>({matches:false}),navigator:{}};
global.fetch=()=>Promise.reject(0);global.Blob=function(){};global.URL={createObjectURL(){return''}};global.FileReader=function(){};
global.btoa=x=>Buffer.from(x,'binary').toString('base64');global.atob=x=>Buffer.from(x,'base64').toString('binary');
const D={};global.localStorage={getItem:k=>(k in D?D[k]:null),setItem:(k,v)=>{D[k]=String(v);},removeItem(){}};
global.sessionStorage={getItem:()=>null,setItem(){},removeItem(){}};global.confirm=()=>false;

let js = fs.readFileSync('app_template.html','utf8').split('<script>')[1].split('</script>')[0]
  .replace('/*__KB__*/', fs.readFileSync('kb_slim.json','utf8'))
  .replace('/*__KBIN__*/', fs.readFileSync('kb_in.json','utf8'))
  .replace('/*__DOCS__*/', fs.readFileSync('docs.json','utf8'));
const m={};
new Function('module', js + "\nmodule.exports={diagPanel,PATTERNS,EPS,setLang};")(m);
const A = m.exports;
const fail = msg => { console.error('فشل: ' + msg); process.exit(1); };

/* ============ رد العميل الحقيقي من الحالة ============ */
const CASE = {
  data: [{
    summary_beta: {
      fields: [
        {name:'Date', code:'date', format:'label', order:'1', selected:true, active:true},
        {name:'Route Length', code:'route_length', format:'label', order:'2', selected:true, active:true, aggregate:'Sum'},
        {name:'Engine Work Duration', code:'engine_work', format:'label', order:'3', selected:true, active:true},
        {name:'Engine Work Percentage', code:'engine_work_percentage', format:'label', order:'4', selected:true, active:true},
        {name:'Stop Duration', code:'stop_duration', format:'label', order:'5', selected:true, active:true}
      ]
    }
  }],
  status_code: 200, message: 'success'
};

const got = A.diagPanel(CASE, JSON.stringify(CASE));
if(!got) fail('المحرك ما شخّصش حالة العميل الحقيقية خالص');
if(got.indexOf('تعريف التقرير') < 0) fail('التشخيص مش بيقول إنه تعريف مش نتيجة');
if(got.indexOf('reports/generate') < 0) fail('التشخيص ما دلّش على إندبوينت التنفيذ');
if(got.indexOf('REPORT_ID') < 0) fail('التشخيص ما وضّحش الباراميترات المطلوبة');
if(got.indexOf('data-goep') < 0) fail('مفيش زرار بيفتح الريكوست الصح');
console.log('حالة العميل        : اتشخّصت صح مع الخطوة الجاية والريكوست ✓');

/* الريكوست اللي بيوديله لازم يكون موجود فعلًا */
const idm = /data-goep="(\d+)"/.exec(got);
const target = A.EPS.find(e => String(e.i) === idm[1]);
if(!target) fail('الزرار بيوصّل لريكوست مش موجود');
if(target.p.indexOf('reports/generate') < 0) fail('الزرار بيوصّل لريكوست غلط: ' + target.p);
console.log('الوجهة             : ' + target.n + ' → ' + target.p.slice(0,52) + '… ✓');

/* ============ ما يتسرّعش على ردود سليمة ============ */
const REAL_RESULT = { data:[{ date:'2026-08-10', route_length:125.5, engine_work:'08:20:15' }],
                      status_code:200, message:'success' };
if(A.diagPanel(REAL_RESULT, JSON.stringify(REAL_RESULT)))
  fail('المحرك شخّص رد نتايج حقيقي كأنه تعريف — إنذار كاذب');

const WITH_VALUES = { data:{ fields:[{name:'Date', code:'date', value:'2026-08-10', selected:true, active:true, format:'label'}] } };
if(A.diagPanel(WITH_VALUES, JSON.stringify(WITH_VALUES)))
  fail('حقول فيها value اتشخّصت كتعريف');

const UNITS = { data:[{name:'LSR-8031', imei:'869487062749717'}], status_code:200 };
if(A.diagPanel(UNITS, JSON.stringify(UNITS))) fail('رد عربيات عادي اتشخّص بالغلط');
console.log('الإنذار الكاذب     : ولا واحد على تلات ردود سليمة ✓');

/* ============ نمط الفلتر الفاضي ============ */
const FILTERED = { data:[], pagination:{allCount:1200, filtersCount:0, resultCount:0}, status_code:200 };
const f = A.diagPanel(FILTERED, JSON.stringify(FILTERED));
if(!f) fail('رد الفلتر الفاضي ما اتشخّصش');
if(f.indexOf('الفلتر') < 0) fail('تشخيص الفلتر مش واضح');
const EMPTY_ACC = { data:[], pagination:{allCount:0, resultCount:0}, status_code:200 };
if(A.diagPanel(EMPTY_ACC, JSON.stringify(EMPTY_ACC)))
  fail('حساب فاضي فعلًا اتشخّص كأنه فلتر ضيّق — ده تشخيص غلط');
console.log('نمط الفلتر         : بيفرّق بين فلتر ضيّق وحساب فاضي ✓');

/* ============ التشخيص بيشتغل باللغتين ============ */
A.setLang('en');
const en = A.diagPanel(CASE, JSON.stringify(CASE));
if(/[\u0600-\u06FF]/.test(en.replace(/<[^>]*>/g,'').replace(/reports\/generate|REPORT_ID|USER_ID|code|id/g,'')))
  fail('التشخيص فيه عربي في الوضع الإنجليزي');
if(en.indexOf('report definition') < 0) fail('التشخيص الإنجليزي مش مترجم');
A.setLang('ar');
console.log('اللغتين            : التشخيص بيتترجم ✓');
