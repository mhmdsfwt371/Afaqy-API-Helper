/* v6.11 — محرك تشخيص الردود.
   الاختبار ده بيطعّم المحرك رد العميل الحقيقي من حالة دعم فعلية:
   «الحقول موجودة بس القيم مش موجودة» في تقرير — والرد اللي معاه كان
   تعريف التقرير مش نتيجته. ولازم يتأكد إنه ما بيتسرّعش على ردود سليمة. */
global.setInterval=()=>0;global.clearInterval=()=>{};
const fs = require('fs');
const R = {};
function el(id){return{id,hidden:false,innerHTML:'',value:'',textContent:'',className:'',dataset:{},style:{},files:[],disabled:false,
 options:[],classList:{toggle(){},add(){},remove(){}},querySelectorAll(){return[]},addEventListener(){},focus(){},select(){},click(){},
 setAttribute(){},getAttribute(){return null},dispatchEvent(){},appendChild(){},remove(){},scrollIntoView(){},title:''}}
global.document={documentElement:el('html'),body:el('body'),addEventListener(){},querySelectorAll(){return[]},
 querySelector(){return null},createElement(){return el()},getElementById:i=>R[i]||(R[i]=el(i))};
global.history={pushState(){},replaceState(){}};global.location={hash:'',pathname:'/',replace(){}};
global.navigator={userAgent:'node',language:'ar',clipboard:{writeText(){return Promise.resolve()}}};
global.window={scrollTo(){},addEventListener(){},matchMedia:()=>({matches:false}),navigator:{}};
global.fetch=()=>Promise.reject(0);global.Blob=function(){};global.URL={createObjectURL(){return''}};global.FileReader=function(){};
global.btoa=x=>Buffer.from(x,'binary').toString('base64');global.atob=x=>Buffer.from(x,'base64').toString('binary');
const D={};global.localStorage={getItem:k=>(k in D?D[k]:null),setItem:(k,v)=>{D[k]=String(v);},removeItem(){}};
global.sessionStorage={getItem:()=>null,setItem(){},removeItem(){}};global.confirm=()=>false;

let js = fs.readFileSync('app_template.html','utf8').split('<script>')[1].split('</script>')[0]
  .replace('/*__KB__*/', fs.readFileSync('kb_slim.json','utf8'))
  .replace('/*__KBIN__*/', fs.readFileSync('kb_in.json','utf8'))
  .replace('/*__DOCS__*/', fs.readFileSync('docs.json','utf8'));
const m={};
new Function('module', js + "\nmodule.exports={diagPanel,PATTERNS,EPS,setLang,depsOf,RESOLVERS,analyzeCase,caseReply,jsonBlocks,blockKind,isReportEp,RSCOPE,prepBody,bodyOf,unitLastSeen,lastSeenMissing,summaryBody,bodyTruncated,bodyBroken,buildReportBody,RPT_KINDS,userIdFrom,SESSION,missingDeps};")(m);
const A = m.exports;
const fail = msg => { console.error('فشل: ' + msg); process.exit(1); };

/* ============ رد العميل الحقيقي من الحالة ============ */
const CASE = {
  data: [{
    summary_beta: {
      fields: [
        {name:'Date', code:'date', format:'label', order:'1', selected:true, active:true},
        {name:'Route Length', code:'route_length', format:'label', order:'2', selected:true, active:true, aggregate:'Sum'},
        {name:'Engine Work Duration', code:'engine_work', format:'label', order:'3', selected:true, active:true},
        {name:'Engine Work Percentage', code:'engine_work_percentage', format:'label', order:'4', selected:true, active:true},
        {name:'Stop Duration', code:'stop_duration', format:'label', order:'5', selected:true, active:true}
      ]
    }
  }],
  status_code: 200, message: 'success'
};

const got = A.diagPanel(CASE, JSON.stringify(CASE));
if(!got) fail('المحرك ما شخّصش حالة العميل الحقيقية خالص');
if(got.indexOf('تعريف التقرير') < 0) fail('التشخيص مش بيقول إنه تعريف مش نتيجة');
if(got.indexOf('reports/generate') < 0) fail('التشخيص ما دلّش على إندبوينت التنفيذ');
if(got.indexOf('REPORT_ID') < 0) fail('التشخيص ما وضّحش الباراميترات المطلوبة');
if(got.indexOf('data-goep') < 0) fail('مفيش زرار بيفتح الريكوست الصح');
console.log('حالة العميل        : اتشخّصت صح مع الخطوة الجاية والريكوست ✓');

/* الريكوست اللي بيوديله لازم يكون موجود فعلًا */
const idm = /data-goep="(\d+)"/.exec(got);
const target = A.EPS.find(e => String(e.i) === idm[1]);
if(!target) fail('الزرار بيوصّل لريكوست مش موجود');
if(target.p.indexOf('reports/generate') < 0) fail('الزرار بيوصّل لريكوست غلط: ' + target.p);
console.log('الوجهة             : ' + target.n + ' → ' + target.p.slice(0,52) + '… ✓');

/* ============ ما يتسرّعش على ردود سليمة ============ */
const REAL_RESULT = { data:[{ date:'2026-08-10', route_length:125.5, engine_work:'08:20:15' }],
                      status_code:200, message:'success' };
if(A.diagPanel(REAL_RESULT, JSON.stringify(REAL_RESULT)))
  fail('المحرك شخّص رد نتايج حقيقي كأنه تعريف — إنذار كاذب');

const WITH_VALUES = { data:{ fields:[{name:'Date', code:'date', value:'2026-08-10', selected:true, active:true, format:'label'}] } };
if(A.diagPanel(WITH_VALUES, JSON.stringify(WITH_VALUES)))
  fail('حقول فيها value اتشخّصت كتعريف');

const UNITS = { data:[{name:'LSR-8031', imei:'869487062749717'}], status_code:200 };
if(A.diagPanel(UNITS, JSON.stringify(UNITS))) fail('رد عربيات عادي اتشخّص بالغلط');
console.log('الإنذار الكاذب     : ولا واحد على تلات ردود سليمة ✓');

/* ============ نمط الفلتر الفاضي ============ */
const FILTERED = { data:[], pagination:{allCount:1200, filtersCount:0, resultCount:0}, status_code:200 };
const f = A.diagPanel(FILTERED, JSON.stringify(FILTERED));
if(!f) fail('رد الفلتر الفاضي ما اتشخّصش');
if(f.indexOf('الفلتر') < 0) fail('تشخيص الفلتر مش واضح');
const EMPTY_ACC = { data:[], pagination:{allCount:0, resultCount:0}, status_code:200 };
if(A.diagPanel(EMPTY_ACC, JSON.stringify(EMPTY_ACC)))
  fail('حساب فاضي فعلًا اتشخّص كأنه فلتر ضيّق — ده تشخيص غلط');
console.log('نمط الفلتر         : بيفرّق بين فلتر ضيّق وحساب فاضي ✓');

/* ============ التشخيص بيشتغل باللغتين ============ */
A.setLang('en');
const en = A.diagPanel(CASE, JSON.stringify(CASE));
if(/[\u0600-\u06FF]/.test(en.replace(/<[^>]*>/g,'').replace(/reports\/generate|REPORT_ID|USER_ID|code|id/g,'')))
  fail('التشخيص فيه عربي في الوضع الإنجليزي');
if(en.indexOf('report definition') < 0) fail('التشخيص الإنجليزي مش مترجم');
A.setLang('ar');
console.log('اللغتين            : التشخيص بيتترجم ✓');

/* اعتمادية رقم التقرير اتشالت في 6.22: كانت بتوقف الموظف وتطلب اسم،
   وتجيب رقم، والسيرفر يرفضه — بوابة بتعطّل من غير ما تحل. */
(function(){
  const rp = A.EPS.find(x => x.p === '/user_reports/data-summary' && x.sys === 'avl');
  if(A.depsOf(rp).some(r => r.key === 'userReport'))
    fail('اعتمادية التقرير رجعت — هتوقف الموظف من غير ما تحل');
  console.log('بوابة التقرير      : اتشالت، مفيش حاجة توقف الموظف ✓');
})();

/* ============ تحليل رسالة العميل ============
   الموظف بيوصله إيميل مخلوط: الرد اللي اشتكى منه، والمثال اللي عايزه،
   وأسئلة مرقّمة. لزقه في «افحص رد» كان بياخد آخر بلوك — يعني المثال
   المرغوب بدل الرد الفعلي، وده تشخيص غلط من أوله. */
const MSG = [
 'We are integrating the Report API but we are facing an issue with the response data.',
 'each object appears to contain only the field definition/metadata, rather than the actual value.',
 '{ "name": "Date", "code": "date", "format": "label", "order": "1", "selected": true, "active": true }',
 'Similarly, for the Route Length field:',
 '{ "name": "Route Length", "code": "route_length", "format": "label", "order": "2", "selected": true, "active": true, "aggregate": "Sum" }',
 'we cannot display the actual report data because the response does not contain the corresponding values.',
 'Could you please clarify the following:',
 '1. Is this API endpoint only returning the report field configuration/metadata, rather than the actual results?',
 '2. If so, which API endpoint should we call to retrieve the actual values for these fields?',
 '3. What parameters are required to retrieve the report data, such as date range, vehicle, or other filters?',
 '4. Could you please provide an example response containing actual values, for example:',
 '{ "date": "2026-08-10", "route_length": 125.5, "engine_work": "08:20:15", "stop_duration": "00:24:25" }'
].join('\n');

const an = A.analyzeCase(MSG);
if(!an.isMsg) fail('ما عرفش إن دي رسالة مش رد خام');
if(an.blocks.length !== 3) fail('عدد البلوكات غلط: ' + an.blocks.length);

/* أهم فحص: التفرقة بين الرد اللي اشتكى منه والمثال اللي عايزه */
if(an.defs.length !== 2) fail('ما فصلش تعريفات الحقول: ' + an.defs.length);
if(an.wanted.length !== 1) fail('ما ميّزش الشكل المرغوب: ' + an.wanted.length);
if(an.wanted[0].at < an.defs[0].at) fail('رتّب البلوكات غلط');
if(A.blockKind(an.wanted[0].json) === A.blockKind(an.defs[0].json))
  fail('التعريف والشكل المرغوب اتصنّفوا نفس النوع — دي المشكلة الأصلية');
console.log('فصل البلوكات       : 2 تعريف + 1 شكل مرغوب، متفرّقين ✓');

if(an.qs.length !== 4) fail('أسئلة العميل الأربعة ما اتلقطتش: ' + an.qs.length);
if(!an.reportCase) fail('حالة التقارير ما اتحددتش');
console.log('الأسئلة والحالة    : 4 أسئلة، والحالة اتحددت ✓');

/* الرد الجاهز لازم يرد على الأربعة ويدل على إندبوينت حقيقي */
const rep = A.caseReply(an);
if(!rep) fail('ما طلّعش رد');
for(const n of ['1)','2)','3)','4)']) if(rep.indexOf(n) < 0) fail('الرد ما ردّش على سؤال ' + n);
if(/[\u0600-\u06FF]/.test(rep)) fail('الرد فيه عربي والعميل كاتب إنجليزي');

/* الدليل اللي صحّح الإجابة: حقول العميل موجودة بالحرف في قالب code:"summary".
   يبقى المطلوب تشغيل تقرير الـ Summary، مش إندبوينت تنفيذ على دومين تاني. */
const tpl2 = A.EPS.find(e => e.p === '/user_report_templates/add' && e.sys === 'avl');
if(!tpl2) fail('قالب التقارير مش موجود في الكولكشن');
for(const code of ['route_length','engine_work','engine_idle','move_duration','stop_duration'])
  if(tpl2.b.indexOf(code) < 0) fail('حقل من حقول العميل مش في القالب: ' + code);
if(tpl2.b.indexOf('"code":"summary"') < 0) fail('القالب مش متعلّم كـ summary');

const dataEp3 = A.EPS.find(e => e.p === '/user_reports/data-summary' && e.sys === 'avl');
if(rep.indexOf(dataEp3.p) < 0) fail('الرد مش بيدل على إندبوينت داتا الـ Summary');
if(rep.indexOf('/user_reports/lists') < 0) fail('الرد ما قالش إزاي يجيب رقم تقريره');
if(rep.indexOf('not_found') < 0) fail('الرد ما فسّرش سبب not_found');
if(rep.indexOf('reports.afaqy-fleet.site') >= 0)
  fail('الرد رجع يدل على دومين التنفيذ التاني — دي كانت الإجابة الغلط');
console.log('الرد الجاهز        : بيدل على داتا الـ Summary بدليل من القالب ✓');

/* ما يتسرّعش: رسالة عادية من غير الحالة دي */
const PLAIN = 'Hello, the vehicle LSR-8031 shows offline since yesterday. Could you check?';
const a2 = A.analyzeCase(PLAIN);
if(a2.reportCase) fail('شخّص رسالة عادية كحالة تقارير');
if(A.caseReply(a2)) fail('طلّع رد جاهز لرسالة مالهاش قاعدة');
console.log('الإنذار الكاذب     : رسالة عادية عدّت من غير رد جاهز ✓');

/* ============ نطاق التقرير ============ */
const rep2 = A.EPS.find(e => e.p === '/user_reports/data-summary' && e.sys === 'avl');
if(!A.isReportEp(rep2)) fail('ريكوست التقرير ما اتعرفش');
if(A.isReportEp(A.EPS.find(e => e.p === '/units/lists' && e.sys === 'avl')))
  fail('ريكوست عادي اتحسب تقرير');

/* المعروض = المتبعت: النطاق لازم يبان في البودي المجهّز نفسه،
   مش يتحط في السر وقت الإرسال. */
A.RSCOPE.mode = 'all'; A.RSCOPE.uids = []; A.RSCOPE.names = [];
let out2 = JSON.parse(A.bodyOf(rep2));
if('units' in out2.data) fail('وضع «الكل» المفروض من غير حقل units');

A.RSCOPE.mode = 'imeis'; A.RSCOPE.uids = ['uid-1','uid-2','uid-3']; A.RSCOPE.names = ['3285','3286','3287'];
const pr2 = A.prepBody(rep2);
out2 = JSON.parse(pr2.text);
if(!Array.isArray(out2.data.units) || out2.data.units.length !== 3)
  fail('الـ UIDs ما بانتش في البودي المعروض');
if(out2.data.units[0] !== 'uid-1') fail('ترتيب الـ UIDs اتغيّر');
if(!out2.data.id) fail('رقم التقرير ضاع من البودي');
if(!pr2.applied) fail('البودي المفروض يتعلّم إنه اتظبط للتجربة');
if(!pr2.changes.some(c => /3285|عربية|vehicles/.test(c))) fail('التغيير مش متقال للموظف');

/* اللي بيتبعت فعلًا = نفس اللي معروض */
if(A.bodyOf(rep2) !== pr2.text) fail('المتبعت مختلف عن المعروض');
const twice = JSON.parse(A.bodyOf(rep2));
if(twice.data.units.length !== 3) fail('النطاق اتحط مرتين');

A.RSCOPE.mode = 'all'; A.RSCOPE.uids = []; A.RSCOPE.names = [];
out2 = JSON.parse(A.bodyOf(rep2));
if('units' in out2.data) fail('الرجوع للكل ما شالش الـ UIDs');
console.log('نطاق التقرير       : بيبان في البودي المعروض، والمتبعت نفسه ✓');

/* بودي لستة التقارير لازم يكون الشكل اللي في الكولكشن */
/* الفحص ده اتشال: كان بيفرض شكل data المصفوفة، وطلع إنه مش موجود في
   الكولكشن أصلًا — الشكلين الحقيقيين {data:{limit}} و{data:{data:[{filters}]}}.
   الفحص الصح بقى تحت: كل شكل لازم يكون واحد من اللي في الكولكشن. */

/* ============ لستة التقارير: الشكل الصح + بدائل ============
   من تجربة حية: النافذة قالت «ما قدرناش نجيب اللستة — خطأ من السيرفر».
   السبب إن بودي اللستة اتكتب بشكل مش موجود في الكولكشن أصلًا. */

/* قسم العربيات جوه نافذة الاعتمادية */
const tpl3 = fs.readFileSync('app_template.html','utf8');
if(tpl3.indexOf('id="depImeis"') < 0) fail('خانة الـ IMEIs مش في نافذة الاعتمادية');
if(tpl3.indexOf('isReportEp(e) ?') < 0) fail('القسم بيظهر على كل الريكوستات مش التقارير بس');
if(tpl3.indexOf('resolveImeis(txt)') < 0) fail('الخانة مش موصّلة بمحوّل الـ IMEIs');
console.log('العربيات في النافذة: ظاهرة لريكوستات التقارير وموصّلة ✓');

/* ============ الحسابات الكبيرة ============
   من تجربة حية: حساب فيه 3700 عربية واللوحة وقفت عند 1500 —
   والموظف شايف أرقام وفاكرها الكل. */
const tpl4 = fs.readFileSync('app_template.html','utf8');
if(tpl4.indexOf('async function fetchAllUnits') < 0) fail('مفيش جلب على دفعات');
if(!/PAGE\s*=\s*\d+/.test(tpl4)) fail('حجم الدفعة مش محدد');
if(tpl4.indexOf('all.length >= total') < 0) fail('الجلب مش بيقف عند العدد الحقيقي');
if(tpl4.indexOf('CAP') < 0) fail('مفيش حد أمان — لوب لا نهائي محتمل');
if(tpl4.indexOf('limit:1500') >= 0) fail('لسه فيه سقف ثابت 1500');
if(tpl4.indexOf('out.length>4000') >= 0) fail('سقف قراءة السجلات لسه 4000 — هيقص الحسابات الكبيرة');
if(tpl4.indexOf('DASH.units.length < DASH.total') < 0) fail('مفيش تنبيه لما اللي اتجاب أقل من الكل');
console.log('الحسابات الكبيرة   : جلب على دفعات بحد أمان وتنبيه لو ناقص ✓');

/* ============ مسبار التقارير ============
   من تجربة حية: الرقم بيرجع not_found حتى وهو من الحساب.
   بدل التخمين، الأداة بتجرّب كل مصادر الرقم وتقول أنهي واحد ردّ ببيانات. */
const tpl5 = fs.readFileSync('app_template.html','utf8');
if(tpl5.indexOf('async function reportIdCandidates') < 0) fail('مفيش جامع لمرشحي رقم التقرير');
if(tpl5.indexOf('async function reportProbe') < 0) fail('مفيش مسبار للتقارير');
for(const src of ['/user_reports/lists','/user_report_templates/lists'])
  if(tpl5.slice(tpl5.indexOf('reportIdCandidates')).indexOf(src) < 0)
    fail('مصدر رقم ناقص من المسبار: ' + src);
if(tpl5.slice(tpl5.indexOf('async function reportProbe')).indexOf("'/user_reports/data-summary','/user_reports/data'") < 0)
  fail('المسبار مش بيجرّب المسارين');
if(tpl5.indexOf('if(isReportEp(e)) return reportProbe(e);') < 0)
  fail('زرار «جرّب وصحّح» مش موصّل بالمسبار على ريكوستات التقارير');
if(tpl5.slice(tpl5.indexOf('async function reportProbe')).indexOf('cands.slice(0, TRY)') < 0)
  fail('مفيش سقف لعدد المحاولات — ممكن يفضل يجرّب للأبد');
console.log('مسبار التقارير     : بيجرّب كل المصادر والمسارين بحد أقصى ✓');

/* ============ خانتين جنب بعض ============
   من تجربة حية: الموظف كتب IMEI في خانة اسم التقرير، والأداة راحت
   تدوّر عليه بين 325 تقرير وقالت مش موجود. غلطة تصميم مش غلطة استخدام. */
const tpl6 = fs.readFileSync('app_template.html','utf8');
if(!/\/\^\\\\d\{14,17\}\$\/\.test\(key\)/.test(tpl6.replace(/\\\\/g,'\\\\')))
  if(tpl6.indexOf('{14,17}') < 0) fail('مفيش كشف للـ IMEI المكتوب في خانة الاسم');
if(tpl6.indexOf('ده رقم جهاز، مش اسم تقرير') < 0) fail('مفيش رسالة توضّح الغلط');
if(tpl6.indexOf('انقله لخانة العربيات') < 0) fail('مفيش زرار بينقله للخانة الصح');
console.log('الخانة الغلط       : بتتكشف وبتتنقل بضغطة ✓');

/* لستة طويلة لازم يكون ليها فلتر */
if(tpl6.indexOf('items.length > 25') < 0) fail('مفيش تمييز للستة الطويلة');
if(tpl6.indexOf('depFind_') < 0) fail('مفيش خانة فلترة للستة الطويلة');
console.log('اللستة الطويلة     : ليها فلتر بحث ✓');

/* ترتيب مرشحي التقرير بقرب الاسم */
const probe = tpl6.slice(tpl6.indexOf('async function reportIdCandidates'));
if(probe.indexOf('/^summary$/i') < 0 || probe.indexOf('/summary/i') < 0)
  fail('الترتيب مش بيفضّل الأقرب لـ Summary');
if(tpl6.indexOf('cands.slice(0, TRY)') < 0) fail('سقف المحاولات مش مستخدم');
if(tpl6.indexOf('skipped ?') < 0) fail('الأداة مش بتقول جرّبت كام من كام');
console.log('ترتيب المرشحين     : الأقرب لـ Summary الأول، والعدد متقال ✓');

/* ============ ترتيب التعريفات ============
   RSCOPE كانت متعرّفة بـ const بعد أول استخدام لها في السلّم — يعني
   نداء المسبار كان بيرمي ReferenceError صامت والسلّم القديم يشتغل مكانه. */
const tpl7 = fs.readFileSync('app_template.html','utf8');
const iScope = tpl7.indexOf('const RSCOPE');
const iLadder = tpl7.indexOf('async function labRunLadder');
const iProbe = tpl7.indexOf('async function reportProbe');
if(iScope < 0 || iLadder < 0 || iProbe < 0) fail('حاجة من التلاتة مش موجودة');
if(iScope > iLadder) fail('RSCOPE متعرّفة بعد السلّم — المسبار هيرمي خطأ صامت');
if(iProbe > iLadder) fail('المسبار متعرّف بعد السلّم');
console.log('ترتيب التعريفات    : النطاق والمسبار قبل السلّم ✓');

/* الوضعين منفصلين: كل العربيات صراحة، أو عربيات محددة */
if(tpl7.indexOf("'allExplicit'") < 0) fail('مفيش وضع «كل العربيات صراحة»');
if(tpl7.indexOf('id="rsAllGo"') < 0) fail('مفيش زرار يجيب كل عربيات الحساب');
if(tpl7.indexOf("RSCOPE.mode === 'imeis' || RSCOPE.mode === 'allExplicit'") < 0)
  fail('البودي مش بياخد الوضعين');
console.log('وضعا النطاق        : الكل صراحة ومحدد، كل واحد لوحده ✓');

/* زرار الريسيت */
if(tpl7.indexOf('id="tryReset"') < 0) fail('مفيش زرار ريسيت');
if(tpl7.indexOf("delete SESSION.deps.userReport") < 0) fail('الريسيت مش بيمسح رقم التقرير');
if(tpl7.indexOf("RSCOPE.mode='all'; RSCOPE.uids=[]; RSCOPE.names=[]; RSCOPE.imeis=[]") < 0)
  fail('الريسيت مش بيمسح النطاق');
console.log('الريسيت            : بيمسح الرقم والنطاق والنتيجة ✓');

/* ============ زرار واحد يعمل السلسلة ============
   الموظف بيدّي IMEI وبس. الأداة بتحوّله لرقم عربية، وتدوّر على رقم
   التقرير الشغّال، وتشغّل — من غير ما يعرف ولا رقم. */
const tpl8 = fs.readFileSync('app_template.html','utf8');
if(tpl8.indexOf('id="rsRun"') < 0) fail('مفيش زرار تشغيل واحد');
const wire = tpl8.slice(tpl8.indexOf('function wireScope'), tpl8.indexOf('async function reportIdCandidates'));
if(wire.indexOf('resolveImeis(txt)') < 0) fail('الزرار مش بيحوّل الـ IMEIs');
if(wire.indexOf('await reportProbe(e)') < 0) fail('الزرار مش بيشغّل المسبار بعد التحويل');
if(wire.indexOf('ولا واحد من الـ IMEIs دول في الحساب') < 0)
  fail('مفيش رسالة لما الـ IMEIs مش في الحساب');
console.log('السلسلة            : IMEI → رقم → تقرير → تشغيل بضغطة ✓');

/* ============ آخر إشارة ============
   من تجربة حية: اللوحة قالت 3700 أوفلاين و0 أونلاين، والمنصة بتقول
   838 متحركة. السبب إن القارئ كان بيفهم شكل واحد بس، وأي شكل تاني
   بيتقرا null — والأداة تفسّره «ما رسلتش ولا مرة». */
const seen = [
  ['نص مباشر',   {id:'1',name:'v',last_update:'2026-08-10 10:00:00'}],
  ['object.time',{id:'1',name:'v',last_update:{time:'2026-08-10 10:00:00'}}],
  ['lastUpdate', {id:'1',name:'v',lastUpdate:{time:'2026-08-10 10:00:00'}}],
  ['pos.time',   {id:'1',name:'v',pos:{time:'2026-08-10 10:00:00'}}],
  ['ثواني',      {id:'1',name:'v',last_time:1786353600}]
];
for(const [label, u] of seen)
  if(!A.unitLastSeen(u)) fail('شكل آخر إشارة مش متقروء: ' + label);
if(A.unitLastSeen({id:'1',name:'v'})) fail('قرأ وقت من سجل مفيهوش الحقل');
console.log('أشكال آخر إشارة    : ' + seen.length + ' أشكال كلها متقروءة ✓');

/* الفرق الحاسم: الحقل غايب ≠ الجهاز ساكت */
if(!A.lastSeenMissing({id:'1',name:'v'})) fail('الحقل الغايب ما اتحسبش غايب');
if(A.lastSeenMissing({id:'1',name:'v',last_update:null}))
  fail('الحقل موجود وفاضي اتحسب غايب — ده جهاز ما رسلش فعلًا');
for(const [, u] of seen) if(A.lastSeenMissing(u)) fail('سجل فيه وقت اتحسب ناقص الحقل');
const tpl9 = fs.readFileSync('app_template.html','utf8');
if(tpl9.indexOf("k:'noField'") < 0) fail('مفيش بند بيقول إن الحقل مش راجع في الرد');
if(tpl9.indexOf('دي عن الرد نفسه') < 0) fail('البند مش بيوضّح إن الأرقام عن الرد مش عن الأجهزة');
console.log('الحقل الغايب       : متفصول عن «ما رسلتش» وبند صريح للموظف ✓');

/* ============ الرقم المقبول والتقرير الفاضي ============
   الجدول في التجربة الحية كان فيه صفوف «رد فاضي» — يعني الرقم اتقبل
   والمسار صح. الأداة كانت بتحسبها فشل وتقول «ولا رقم اشتغل»،
   وده كان بيضيّع الإجابة الحقيقية. */
const tpl10 = fs.readFileSync('app_template.html','utf8');
const pr3 = tpl10.slice(tpl10.indexOf('async function reportProbe'));
if(pr3.indexOf('const accepted = rows.filter(x => x.ok)') < 0)
  fail('المسبار مش بيميّز الرقم المقبول بلا سجلات');
if(pr3.indexOf('الرقم مظبوط والمسار مظبوط — التقرير فاضي') < 0)
  fail('مفيش حكم منفصل للتقرير الفاضي');
if(pr3.indexOf("'/user_reports/add'") < 0)
  fail('مفيش تحويل لريكوست إنشاء التقرير');

/* دورة حياة التقرير: إنشاء ≠ قراءة */
if(tpl10.indexOf('function reportLifecycle') < 0) fail('مفيش خريطة لدورة حياة التقرير');
const lc = tpl10.slice(tpl10.indexOf('function reportLifecycle'), tpl10.indexOf('function scopeBox'));
for(const p of ['/user_reports/add','/user_reports/lists','/user_reports/data-summary','/user_reports/export'])
  if(lc.indexOf(p) < 0) fail('خطوة ناقصة من دورة الحياة: ' + p);
if(lc.indexOf('مش بتعمل تقرير جديد') < 0) fail('مش موضّح إن القراءة مش إنشاء');
console.log('دورة حياة التقرير  : الأربع خطوات، وإنشاء ≠ قراءة ✓');

/* ============ بودي مقصوص في الكولكشن ============
   عينة /user_report_templates/add مكتوب فيها «مختصر» — يعني اتقصت وقت
   التصدير. الموظف ينسخها للعميل وتفشل، وهو مش عارف ليه. */
/* v6.26: القص اتصلح من الكولكشن الأصلي — 28,667 حرف رجعوا.
   الفحص بقى يتأكد إن القص ما يرجعش، مش إنه موجود. */
const cutEps = A.EPS.filter(e => e.sys === 'avl' && A.bodyTruncated(e));
if(cutEps.length > 2) fail('القص رجع: ' + cutEps.length + ' ريكوست مقصوص');
const big = A.EPS.find(e => e.p === '/user_reports/add' && e.n === 'Add' && e.sys === 'avl');
if(A.bodyTruncated(big)) fail('بودي إنشاء التقرير رجع مقصوص');
if((big.b || '').length < 8000) fail('بودي إنشاء التقرير قصير: ' + (big.b||'').length);
const bigData = JSON.parse(big.b).data;
if(!bigData.resources || !bigData.date) fail('المفاتيح اللي رجعت ضاعت تاني');
if((bigData.fields||[]).length < 19) fail('حقول إنشاء التقرير ناقصة: ' + (bigData.fields||[]).length);
/* الكاشف نفسه لازم يفضل شغّال */
if(!A.bodyTruncated({b:'{"a":1} ... (مختصر)'})) fail('كاشف القص بايظ');
if(A.bodyTruncated({b:'{"a":1}'})) fail('كاشف القص بيدّي إنذار كاذب');
console.log('سلامة البوديز      : بودي الإنشاء كامل (' + (big.b||'').length + ' حرف، ' + bigData.fields.length + ' حقل) ✓');

/* ============ بناء تقرير من الـ API ============
   البودي المبني لازم يطابق شكل /user_reports/add الحقيقي بالحرف —
   نفس المفاتيح ونفس شكل الحقل. وأي نقص هنا معناه ريكوست هيترفض. */
const realAdd = JSON.parse(A.EPS.find(x => x.p === '/user_reports/add' && x.n === 'Add' && x.sys === 'avl').b).data;
if(!A.RPT_KINDS.length) fail('مفيش أنواع تقارير');
for(const K of A.RPT_KINDS){
  let b;
  try{ b = JSON.parse(A.buildReportBody(K.k)).data; }catch(_){ fail('بودي مش صالح للنوع: ' + K.k); }
  for(const key of Object.keys(realAdd))
    if(!(key in b)) fail(`مفتاح ناقص في ${K.k}: ${key}`);
  for(const key of Object.keys(realAdd.fields[0]))
    if(!(key in b.fields[0])) fail(`مفتاح ناقص من شكل الحقل في ${K.k}: ${key}`);
  if(!b.fields.length) fail('مفيش أعمدة في ' + K.k);
  if(b.selected_resource_type !== K.res) fail(`نوع المورد غلط في ${K.k}`);
  if(!Array.isArray(b.resources) || !b.resources.length) fail('resources فاضية في ' + K.k);
  if(!b.date || !b.date.from || !b.date.to) fail('الفترة ناقصة في ' + K.k);
}
/* تقرير السواقين ما ياخدش أرقام عربيات */
A.RSCOPE.mode = 'imeis'; A.RSCOPE.uids = ['UID-1','UID-2'];
const byDrv = JSON.parse(A.buildReportBody('summary_by_driver')).data;
if(byDrv.resources.some(r => /^UID-/.test(r)))
  fail('تقرير السواقين اتحطت فيه أرقام عربيات — نوع المورد مختلف');
const byUnit = JSON.parse(A.buildReportBody('summary')).data;
if(byUnit.resources[0] !== 'UID-1') fail('تقرير العربيات ما اخدش العربيات اللي اتحددت');
A.RSCOPE.uids = [];
/* أكواد التقارير لازم تكون من الكولكشن */
const kbCodes = new Set();
for(const ep of A.EPS) for(const mm of String(ep.b||'').matchAll(/"code"\s*:\s*"(summary[a-z_]*)"/g)) kbCodes.add(mm[1]);
for(const K of A.RPT_KINDS)
  if(!kbCodes.has(K.code)) fail('كود تقرير مش من الكولكشن: ' + K.code);
console.log('بناء التقارير      : ' + A.RPT_KINDS.length + ' أنواع، كلهم مطابقين للكولكشن ✓');

/* ============ الفحص الشامل ============
   الأداة مبتقدرش تتصل بسيرفر أفاقي من بيئة التطوير، فالفحص بيشتغل من
   متصفح الموظف. المهم إنه يفرّق بين «السيرفر ردّ» و«الرد فيه اللي المفروض». */
const tpl12 = fs.readFileSync('app_template.html','utf8');
if(tpl12.indexOf('async function healthRun') < 0) fail('مفيش فحص شامل');
const hr = tpl12.slice(tpl12.indexOf('async function healthRun'), tpl12.indexOf('function healthTable'));
for(const p of ['/units/lists','/units/signals','/user_reports/lists','/user_reports/data-summary','/user_reports/add'])
  if(hr.indexOf(p) < 0) fail('إندبوينت ناقص من الفحص: ' + p);
/* التسلسل: كل خطوة بتاخد من اللي قبلها */
if(hr.indexOf('firstUnit.id') < 0) fail('الإشارات مش بتاخد رقم عربية من لستة العربيات');
if(hr.indexOf('firstReport.id') < 0) fail('قراءة التقرير مش بتاخد رقم من لستة التقارير');
/* الكتابة لا تتنفذ من غير إذن */
if(hr.indexOf('needs permission') < 0 && hr.indexOf('محتاج إذن') < 0)
  fail('إنشاء التقرير بيتنفّذ من غير إذن — ده بيغيّر داتا العميل');
if(tpl12.indexOf('async function healthCreateReport') < 0) fail('مفيش تنفيذ منفصل للكتابة');
if(tpl12.slice(tpl12.indexOf('async function healthCreateReport')).indexOf('confirm(') < 0)
  fail('الكتابة من غير تأكيد');
/* الحكم على المحتوى مش على وصول الرد */
if(hr.indexOf('lastSeenMissing') < 0) fail('الفحص مش بيتأكد إن وقت آخر إشارة راجع');
if(hr.indexOf('warn:true') < 0) fail('مفيش حالة «ردّ بس ناقص»');
if(tpl12.indexOf('ردّ بس ناقص') < 0 && tpl12.indexOf('answered but incomplete') < 0)
  fail('العدّاد مش بيفصل الناقص عن المظبوط');
console.log('الفحص الشامل       : 5 إندبوينتس متسلسلة، والكتابة بإذن، وبيحكم على المحتوى ✓');

/* ============ رقم المستخدم ============
   الأداة كانت بتسأل الموظف «محتاج: المستخدم» وهي معاها الرقم أصلًا من
   رد الدخول — وبتروح تدوّر في /user/lists وترجع من غير سجلات. */
if(A.userIdFrom({data:{user:{id:'X1'}}}) !== 'X1') fail('ما استخرجش user.id');
if(A.userIdFrom({data:{user:{_id:'X2'}}}) !== 'X2') fail('ما استخرجش user._id');
if(A.userIdFrom({data:{id:'X3'}}) !== 'X3') fail('ما استخرجش data.id');
if(A.userIdFrom({data:{user:{}}}) !== '') fail('اخترع رقم من رد فاضي');
if(A.userIdFrom(null) !== '') fail('وقع على رد فاضي');

const addEp2 = A.EPS.find(x => x.p === '/user_reports/add' && x.n === 'Add' && x.sys === 'avl');
A.SESSION.userId = 'UID-FROM-LOGIN';
if(A.missingDeps(addEp2).some(r => r.key === 'user'))
  fail('لسه بيسأل عن المستخدم وهو معاه الرقم');
const filled = JSON.parse(A.bodyOf(addEp2));
if(filled.data.user_id !== 'UID-FROM-LOGIN') fail('user_id ما اتعبّاش في البودي');
const gen2 = JSON.parse(A.buildReportBody('summary'));
if(gen2.data.user_id !== 'UID-FROM-LOGIN') fail('المولّد ما اخدش رقم المستخدم');
A.SESSION.userId = '';
const gen3 = JSON.parse(A.buildReportBody('summary'));
if(gen3.data.user_id !== '<USER_ID>') fail('من غير اتصال المفروض يفضل علامة مكان');
const tpl13 = fs.readFileSync('app_template.html','utf8');
if(tpl13.indexOf('SESSION.userId=\'\'') < 0 && tpl13.indexOf("SESSION.userId='';") < 0)
  fail('القطع مش بيمسح رقم المستخدم — هيفضل رقم عميل بعد ما تقطع');
console.log('رقم المستخدم       : بيتلقط من الدخول، ومبقاش يتسأل عنه ✓');
