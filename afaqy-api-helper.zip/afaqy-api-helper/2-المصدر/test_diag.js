const fs=require('fs');
function el(id){return{id,hidden:false,innerHTML:'',value:'',textContent:'',className:'',dataset:{},style:{},files:[],disabled:false,
 classList:{toggle(){},add(){},remove(){}},querySelectorAll(){return[]},addEventListener(){},focus(){},select(){},click(){},
 setAttribute(){},getAttribute(){return null},dispatchEvent(){},appendChild(){},remove(){},scrollIntoView(){}}}
const R={};global.document={documentElement:el(),body:el(),addEventListener(){},querySelectorAll(){return[]},
 querySelector(){return null},createElement(){return el()},getElementById(i){return R[i]||(R[i]=el(i))}};
global.history={pushState(){},replaceState(){}};global.location={hash:''};
global.navigator={clipboard:{writeText(){return Promise.resolve()}}};
global.window={scrollTo(){},addEventListener(){}};
global.fetch=()=>Promise.reject(0);global.Blob=function(){};global.URL={createObjectURL(){return''}};global.FileReader=function(){};
let js=fs.readFileSync('app_template.html','utf8').split('<script>')[1].split('</script>')[0]
 .replace('/*__KB__*/',fs.readFileSync('kb_slim.json','utf8'))
 .replace('/*__DOCS__*/',fs.readFileSync('docs.json','utf8'));
const m={};new Function('module',js+'\nmodule.exports={diagnose,SESSION,prepBody,needsUnit,EPS,setL:(l)=>{LANG=l}};')(m);
const A=m.exports;
const strip=h=>String(h).replace(/<[^>]+>/g,'').replace(/\s+/g,' ').trim();

// الرد الحقيقي من الصورة
const real='{"message":"validation_error","status_code":405,"errors":{"unit_id":["not_found","invalid_resource"]},"extra":[]}';

console.log('=== الرد الحقيقي، ومحدش حدّد عربية ===');
console.log(strip(A.diagnose(405, real)));

console.log('\n=== نفس الرد بس بعد ما حدّد عربية ===');
A.SESSION.unit={uid:'5fb0e2e7',name:'NB YD',imei:'357454075086551'};
console.log(strip(A.diagnose(405, real)));
A.SESSION.unit=null;

console.log('\n=== حقول تانية ===');
console.log(strip(A.diagnose(405,'{"message":"validation_error","errors":{"from":["invalid_format"],"limit":["required"]}}')));

console.log('\n=== لسه بيمسك القديم ===');
console.log('401 body  : '+strip(A.diagnose(200,'{"message":"invalid_credentials","status_code":401}')).slice(0,80));
console.log('500       : '+strip(A.diagnose(500,'{}')).slice(0,70));
console.log('404       : '+strip(A.diagnose(404,'{}')).slice(0,70));

console.log('\n=== فخاخ العينات ===');
const sig=A.EPS.find(e=>e.p==='/units/signals');
const pr=A.prepBody(sig);
console.log('اتغيّر: '+pr.changes.join('  |  '));
console.log('offset دلوقتي: '+(JSON.parse(pr.text).data.offset));
console.log('from دلوقتي  : '+(JSON.parse(pr.text).data.date.from));

console.log('\n=== محتاج عربية؟ ===');
[['/units/signals'],['/units/lists'],['/auth/login'],['/zones/lists']].forEach(([p])=>{
  const e=A.EPS.find(x=>x.p===p); if(e) console.log('  '+(A.needsUnit(e)?'أيوه ':'لأ   ')+p);
});
