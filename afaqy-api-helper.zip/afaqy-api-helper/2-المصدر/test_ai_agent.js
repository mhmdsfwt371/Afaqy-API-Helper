/* v7.3 — Claude بيجرّب قبل ما يجاوب (قراءة بس، بموافقة الموظف) + مقياس الدقة. الـ API وهمي. */
const fs=require('fs'); const {JSDOM}=require('jsdom');
let F=0; const ok=(m,c,x)=>{ console.log((c?'  \u2713 ':'  \u2717 ')+m+(c||!x?'':'  \u2014 '+String(x).slice(0,180))); if(!c) F++; };
const html=fs.readFileSync(process.argv[2]||'app_template.html','utf8')
  .replace('/*__KB__*/',()=>fs.readFileSync('kb_slim.json','utf8'))
  .replace('/*__DOCS__*/',()=>fs.readFileSync('docs.json','utf8'))
  .replace('/*__KBIN__*/',()=>fs.readFileSync('kb_in.json','utf8'));
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
function boot(){ const w=new JSDOM(html,{runScripts:'dangerously',pretendToBeVisual:true,url:'https://localhost/'}).window;
  w.alert=()=>{}; w.scrollTo=()=>{}; w.showView('inspect'); w.eval("INSPVIEW='case'"); w.paintInspect();
  w.eval("AI.key='sk-ant-test-key-0123456789abcdef'; AI.remember=false;"); return w; }
const ANSWER={kind:'troubleshoot', summary_ar:'الـ IMEI مكان الـ UID', diagnosis_ar:'جرّبنا', evidence_ar:'ريكوست العميل رجّع not_allowed، وبالـ UID رجّع رسائل.',
  steps:[{method:'POST', path:'/units/lists', body:'{"data":{"limit":1}}'}, {method:'POST', path:'/units/signals', body:'{"data":{"unit_id":"5e67"}}'}],
  reply_en:'Dear team, use the UID.', reply_ar:'السادة المحترمين، استخدموا الـ UID.', unverified:[], confidence:0.95};
/* Claude وهمي: بيطلب ريكوستات بالترتيب، وبعدين بيجاوب */
function scripted(w, asks){
  w.__turns=[]; let n=0;
  w.fetch=async (url,opt)=>{ const b=JSON.parse(opt.body); w.__turns.push(b);
    const usage={input_tokens:1000,output_tokens:100};
    if(n<asks.length){ const a=asks[n++]; return {ok:true,status:200,json:async()=>({model:'claude-sonnet-5',usage,content:[{type:'tool_use',id:'tu'+n,name:'call_api',input:a}]})}; }
    return {ok:true,status:200,json:async()=>({model:'claude-sonnet-5',usage,content:[{type:'tool_use',id:'fin',name:'answer',input:ANSWER}]})}; };
}
(async()=>{
/* ١) قايمة المسموح */
{ const w=boot(); const A=p=>w.aiCallAllowed(p);
  ok('/units/lists مسموح', A('/units/lists').ok);
  ok('/units/signals مسموح', A('/units/signals').ok);
  ok('/units/locations (محفوظ من غير توثيق، قراءة) مسموح للتشخيص', A('/units/locations').ok);
  ok('/auth/login ممنوع', !A('/auth/login').ok);
  ok('/units/edit ممنوع (كتابة)', !A('/units/edit').ok);
  ok('/user_reports/send ممنوع (بيبعت)', !A('/user_reports/send').ok);
  ok('/user_reports/export ممنوع (بيصدّر)', !A('/user_reports/export').ok);
  ok('/reports/completed/… ممنوع (إشعار رغم إن epKind بيقول قراءة)', !A('/reports/completed/68ad76564da4c536c2031765').ok && w.epKind({p:'/reports/completed/68ad76564da4c536c2031765'})==='read');
  ok('مسار مخترع ممنوع', !A('/units/last_position').ok);
  const docsRead=w.eval("EPS.filter(e=>sysOf(e)==='avl' && aiCallAllowed(e.p).ok).length");
  ok('عدد المسموح معقول (قراءة بس)', docsRead>20 && docsRead<120, docsRead);
}
/* ٢) من غير اتصال: مفيش أداة تجربة، والجواب مباشر */
{ const w=boot(); w.eval('SESSION.token=null'); scripted(w, []);
  w.document.getElementById('caseText').value='hi'; await w.aiRun('hi'); await sleep(30);
  const b=w.__turns[0];
  ok('مش متصل: أداة answer بس، ومفروضة', b.tools.length===1 && b.tools[0].name==='answer' && b.tool_choice && b.tool_choice.name==='answer');
}
/* ٣) متصل: Claude بيطلب → الموظف بيوافق → الأداة بتنفّذ → Claude بيكمّل */
{ const w=boot(); w.__api=[];
  w.eval(`SESSION.token='TOKSECRET123'; apiFetch = async (p,b,o)=>{ window.__api.push({p,b,m:o&&o.method});
     return p==='/units/locations' ? {ok:true,status:200,json:{status_code:401,message:'not_allowed',data:[]}}
          : {ok:true,status:200,json:{status_code:200,data:Array.from({length:40},(x,i)=>({id:'u'+i,imei:'86123004493402'+(i%10),name:'V'+i,note:'x'.repeat(500)}))}}; };`);
  scripted(w, [{method:'POST',path:'/units/locations',body:'{"data":{"unit_id":"861230044934025"}}',reason:'reproduce the customer request'},
               {method:'POST',path:'/units/lists',body:'{"data":{"limit":1,"filters":{"imei":{"value":["861230044934025"],"op":"in"}}}}',reason:'get the UID'}]);
  w.document.getElementById('caseText').value='locations fails with not_allowed'; const run=w.aiRun('locations fails with not_allowed');
  await sleep(40);
  ok('الموظف شاف الطلب الأول قبل التنفيذ', /Claude عايز يجرّب على الحساب/.test(w.document.getElementById('caseOut').textContent) && /reproduce the customer request/.test(w.document.getElementById('caseOut').textContent) && w.__api.length===0);
  ok('الأداة متاحة لـ Claude لما متصل', w.__turns[0].tools.some(t=>t.name==='call_api'));
  w.document.querySelector('[data-a="yes"]').click(); await sleep(40);
  ok('اتنفّذ بعد الموافقة بس، بالمسار والبودي', w.__api.length===1 && w.__api[0].p==='/units/locations' && w.__api[0].b.data.unit_id==='861230044934025');
  w.document.querySelector('[data-a="yes"]').click(); await run; await sleep(30);
  ok('الطلب التاني اتنفّذ', w.__api.length===2 && w.__api[1].p==='/units/lists');
  const tr=w.__turns[1].messages[2].content[0].content, tr2=w.__turns[2].messages[4].content[0].content;
  ok('رد الحساب راح لـ Claude: not_allowed و status_code', /not_allowed/.test(tr) && /"status_code":401/.test(tr));
  ok('الرد اتقص: 3 عناصر + «… more»، والنصوص اتقصت', /… 37 more/.test(tr2) && !/x{400}/.test(tr2));
  ok('التوكن عمره ما راح لـ Claude', !JSON.stringify(w.__turns).includes('TOKSECRET123'));
  const out=w.document.getElementById('caseOut').textContent, a=w.eval('AI.last');
  ok('لوحة «اتجرّب على الحساب» بالريكوستين وحالتهم', /اتجرّب على الحساب/.test(out) && /رجع خطأ/.test(out) && /رجع سليم/.test(out) && a._calls.length===2);
  ok('الدليل من Claude ظاهر', /ريكوست العميل رجّع not_allowed/.test(out));
  ok('الخطوة اللي اتجربت ونجحت متعلّمة «اتجرّب ✓»', a.steps[0].tested===true && !a.steps[1].tested && /اتجرّب ✓/.test(out));
}
/* ٤) رفض وتخطّي */
{ const w=boot(); w.__api=[]; w.eval(`SESSION.token='T'; apiFetch = async (p)=>{ window.__api.push(p); return {ok:true,status:200,json:{status_code:200,data:[]}}; };`);
  scripted(w, [{method:'POST',path:'/units/edit',body:'{}',reason:'try editing'}, {method:'POST',path:'/units/signals',body:'{}',reason:'read signals'}]);
  const run=w.aiRun('x'); await sleep(40);
  ok('طلب كتابة اترفض من غير ما يتسأل', w.__api.length===0 && /Not allowed: not a read-only request/.test(JSON.stringify(w.__turns[1].messages[2])));
  w.document.querySelector('[data-a="no"]').click(); await run; await sleep(30);
  ok('اللي اتخطّى ما اتنفّذش وClaude عرف', w.__api.length===0 && /The engineer skipped this call/.test(JSON.stringify(w.__turns[2].messages)));
  const a=w.eval('AI.last'); ok('اللوحة بتقول اترفض واتخطّى', a._calls.map(c=>c.st).join(',')==='refused,skipped');
}
/* ٥) «نفّذ الكل» وحد الـ 4 ريكوستات */
{ const w=boot(); w.__api=[]; w.eval(`SESSION.token='T'; apiFetch = async (p)=>{ window.__api.push(p); return {ok:true,status:200,json:{status_code:200,data:[]}}; };`);
  const many=Array.from({length:6},()=>({method:'POST',path:'/units/lists',body:'{}',reason:'r'}));
  scripted(w, many); const run=w.aiRun('x'); await sleep(40);
  w.document.querySelector('[data-a="all"]').click(); await run; await sleep(30);
  ok('«نفّذ الكل» بيكمّل من غير سؤال', w.__api.length>=2);
  ok('مش أكتر من 4 ريكوستات، وبعدها answer مفروض', w.__api.length<=4 && w.__turns[w.__turns.length-1].tool_choice && w.__turns[w.__turns.length-1].tool_choice.name==='answer', w.__api.length);
  ok('«نفّذ الكل» بيتصفّر بعد الحالة', w.eval('AI_APPROVE_ALL')===false);
}
/* ٦) مقياس الدقة */
{ const w=boot(); const E=w.eval('AI_EVAL');
  /* الأسماء نفسها مكانها private_names.json بس — الاختبار بيدوّر على الشكل: مفيش إيميلات ولا دومينات شركات */
  ok('المقياس فيه 8 حالات متنضّفة (مفيش إيميلات ولا دومينات)', E.length===8 && !/[\w.-]+@[\w-]+\.\w+|\bwww\.|\.com\.sa\b/i.test(JSON.stringify(E.map(c=>c.text))));
  const good={kind:'troubleshoot', steps:[{path:'/units/lists'},{path:'/units/signals'}], reply_en:'Use the UID instead of the IMEI.', reply_ar:'استخدموا الـ UID بدل الـ IMEI.', unverified:[], blocked:false};
  ok('رد سليم على حالة الـ IMEI بيعدّي', w.aiEvalScore(E[0], good).length===0, w.aiEvalScore(E[0], good).join('|'));
  const bad=Object.assign({}, good, {steps:[{path:'/units/locations'}], reply_en:'A role is missing, we will add the role.'});
  const f=w.aiEvalScore(E[0], bad);
  ok('رد غلط بيتمسك: ناقص lists، بيقترح locations، وبيقول رول ناقص', f.length===3, f.join('|'));
  const ret=Object.assign({}, good, {reply_en:'We keep data for 90 days.', unverified:[]});
  ok('مدة احتفاظ مخترعة بتتمسك', w.aiEvalScore(E[5], ret).length===2, w.aiEvalScore(E[5], ret).join('|'));
  /* تشغيل كامل بـ Claude وهمي */
  w.eval('SESSION.token=null'); w.fetch=async()=>({ok:true,status:200,json:async()=>({model:'claude-sonnet-5',usage:{input_tokens:1000,output_tokens:100},content:[{type:'tool_use',id:'a',name:'answer',input:{kind:'question',summary_ar:'x',steps:[{method:'POST',path:'/units/lists',body:'{}'}],reply_en:'Use the UID and IMEI via /units/signals; status_code; Bearer; dtt dts last_update.',reply_ar:'x',unverified:['rate limit'],confidence:0.8}}]})});
  w.document.getElementById('aiEval').click(); await sleep(200);
  const out=w.document.getElementById('aiEvalOut').textContent;
  ok('المقياس بيشتغل ويطلّع النسبة والتكلفة', /الدقة: \d\/8 \(\d+%\)/.test(out) && /\$0\.\d{3}/.test(out), out.slice(0,140));
  ok('المقياس من غير تجربة على الحساب', w.eval('true'));
}
console.log(F?`\nفشل ${F}`:'\nClaude بيجرّب + المقياس: تمام'); process.exit(F?1:0);
})();
