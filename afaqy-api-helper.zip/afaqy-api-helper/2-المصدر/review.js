/* مراجعة كود: حقائق مش انطباعات.
   بتمشي على القالب وتطلّع: دوال ميتة، ونداءات على حاجة مش موجودة،
   وتعريفات مكررة، ودوال طويلة أوي، وanawait من غير حماية. */
const fs = require('fs');

const tpl = fs.readFileSync('app_template.html', 'utf8');
const js  = tpl.split('<script>')[1].split('</script>')[0];
const lines = js.split('\n');

// ---------- الدوال المعرّفة ----------
const defs = new Map();                       // اسم -> [أسطر]
const reDef = /^(?:async\s+)?function\s+([A-Za-z_$][\w$]*)\s*\(/;   // المستوى الأعلى بس
lines.forEach((l, i) => {
  const m = l.match(reDef);
  if (m) { if (!defs.has(m[1])) defs.set(m[1], []); defs.get(m[1]).push(i + 1); }
});

// دوال متعرّفة كـ const/let
const reConst = /^(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=\s*(?:async\s*)?(?:\([^)]*\)|[A-Za-z_$][\w$]*)\s*=>/;
lines.forEach((l, i) => {
  const m = l.match(reConst);
  if (m) { if (!defs.has(m[1])) defs.set(m[1], []); defs.get(m[1]).push(i + 1); }
});

// ---------- النداءات ----------
/* بنشيل تعليقات CSS وقيم var(--x) عشان ما تتحسبش نداءات */
const scan = js.replace(/var\(--[\w-]+\)/g, '')
               .replace(/\/\*[\s\S]*?\*\//g, '');
const calls = new Map();
const reUse = /\b([A-Za-z_$][\w$]*)\b/g;
let m2;
while ((m2 = reUse.exec(scan))) {
  const n = m2[1];
  calls.set(n, (calls.get(n) || 0) + 1);
}

// ---------- الدوال المستخدمة من الـ HTML ----------
const htmlOnly = new Set();
for (const mm of tpl.matchAll(/on\w+="([A-Za-z_$][\w$]*)\(/g)) htmlOnly.add(mm[1]);

/* إيجابيات كاذبة معروفة: كلمات جوه نصوص مثال أو كود بايثون داخل قالب */
const FALSE_POSITIVE = new Set(['nprint','responses','template','customer','$','sim_']);  // sim_ جوه ريجيكس شرح الحقول مش نداء
const BUILTIN = new Set(['if','for','while','switch','catch','function','return','typeof','new','await',
  'String','Number','Boolean','Array','Object','JSON','Math','Date','RegExp','Promise','Set','Map','Error',
  'parseInt','parseFloat','isNaN','isFinite','encodeURIComponent','decodeURIComponent','fetch','setTimeout',
  'setInterval','clearTimeout','clearInterval','require','console','alert','confirm','caches','FileReader',
  'Blob','URL','AbortController','Request','Intl','Symbol','WeakMap','structuredClone','queueMicrotask',
  'btoa','atob','escape','unescape','localStorage','sessionStorage','prompt']);   // مبنيّات المتصفح — مش دوال بتاعتنا

const problems = { dup: [], dead: [], missing: [], big: [], unguarded: [] };

// تعريفات مكررة
for (const [n, ls] of defs) if (ls.length > 1) problems.dup.push(`${n} (أسطر ${ls.join(', ')})`);

// دوال ميتة: متعرّفة والنداءات عليها = مرة واحدة (التعريف نفسه)
for (const [n, ls] of defs) {
  const c = calls.get(n) || 0;
  const usedInHtml = htmlOnly.has(n) || new RegExp('id="' + n + '"').test(tpl);
  if (c <= 1 && !usedInHtml && !FALSE_POSITIVE.has(n)) problems.dead.push(`${n} (سطر ${ls[0]}، اتذكر ${c} مرة)`);
}

// نداءات بأقواس على حاجة مش معرّفة في أي مكان
const KEYWORD = new Set(['async','await','var','let','const','return','typeof','function','if','for','while',
  'switch','catch','try','finally','new','delete','in','of','do','else','case','break','continue','yield','void']);
const invoked = new Map();
let m3; const reInv = /\b([A-Za-z_$][\w$]*)\s*\(/g;
while ((m3 = reInv.exec(scan))) invoked.set(m3[1], (invoked.get(m3[1]) || 0) + 1);
for (const [n, c] of invoked) {
  if (defs.has(n) || BUILTIN.has(n) || KEYWORD.has(n) || FALSE_POSITIVE.has(n)) continue;
  if (/^[A-Z]/.test(n)) continue;
  const declared = new RegExp('(?:const|let|var|function)\\s+' + n + '\\b').test(js) ||
                   new RegExp('[.?]' + n + '\\s*\\(').test(js) ||
                   new RegExp('\\b' + n + '\\s*[:=]').test(js) ||
                   new RegExp('\\(\\s*[^)]*\\b' + n + '\\b[^)]*\\)\\s*(?:=>|\\{)').test(js);
  if (!declared) problems.missing.push(`${n} (${c} نداء)`);
}

// دوال طويلة
for (const [n, ls] of defs) {
  const start = ls[0] - 1;
  let depth = 0, end = start, started = false;
  for (let i = start; i < lines.length && i < start + 400; i++) {
    for (const ch of lines[i]) { if (ch === '{') { depth++; started = true; } else if (ch === '}') depth--; }
    if (started && depth <= 0) { end = i; break; }
  }
  const len = end - start + 1;
  if (len > 90) problems.big.push(`${n}: ${len} سطر (${ls[0]})`);
}

// await من غير try
for (const [n, ls] of defs) {
  const start = ls[0] - 1;
  let depth = 0, end = start, started = false;
  for (let i = start; i < lines.length && i < start + 400; i++) {
    for (const ch of lines[i]) { if (ch === '{') { depth++; started = true; } else if (ch === '}') depth--; }
    if (started && depth <= 0) { end = i; break; }
  }
  const body = lines.slice(start, end + 1).join('\n');
  if (/\bawait\b/.test(body) && !/\btry\s*\{/.test(body) && !/\.catch\(/.test(body))
    problems.unguarded.push(`${n} (سطر ${ls[0]})`);
}

// ---------- التقرير ----------
const P = (title, arr, note) => {
  console.log('\n' + title + ': ' + (arr.length || 'مفيش'));
  arr.slice(0, 25).forEach(x => console.log('   ' + x));
  if (arr.length > 25) console.log('   … و' + (arr.length - 25) + ' غيرهم');
  if (note && arr.length) console.log('   ← ' + note);
};

console.log('حجم الكود      : ' + lines.length.toLocaleString() + ' سطر');
console.log('دوال معرّفة     : ' + defs.size);

P('تعريفات مكررة', problems.dup, 'الجافاسكريبت بياخد الأخير — ده اللي كسر الأداة قبل كده');
P('نداءات على حاجة مش موجودة', problems.missing, 'هتقع وقت التشغيل');
P('دوال ميتة (متعرّفة وما بتتندهش)', problems.dead, 'شيلها أو استخدمها');
P('دوال أطول من 90 سطر', problems.big, 'صعبة الصيانة والاختبار');
P('await من غير حماية', problems.unguarded, 'فشل الشبكة هيرمي خطأ مش متمسك');

const fatal = problems.dup.length + problems.missing.length;
console.log('\n' + (fatal ? '!! ' + fatal + ' مشكلة تستاهل وقفة' : 'مفيش مشاكل قاتلة'));
process.exit(fatal ? 1 : 0);
