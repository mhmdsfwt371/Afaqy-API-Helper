#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v6.34b — الرد الجاهز على إيميل تقرير الـ summary.

رد الدعم الحقيقي بعت ريكوستين: data-summary للملخص المجمّع، وdata-new
بـ resource_id لتفاصيل كل عربية. الأداة كانت بتدي data-summary بس،
وبتقول على data-new إنها «نفس الصفوف بشكل أوسع» — وده غلط.

وكمان الاتنين محتاجين رقم تقرير، والعميل مش معاه واحد. فالرد لازم يبدأ
من الأول: add ثم percentage ثم القراءة."""
import sys, io

PATH = sys.argv[1] if len(sys.argv) > 1 else 'app_template.html'
src = io.open(PATH, encoding='utf-8').read()
orig = len(src)

def rep(old, new, n=1, tag=''):
    global src
    c = src.count(old)
    if c != n:
        raise SystemExit('MISMATCH [%s]: expected %d found %d\n---\n%s' % (tag, n, c, old[:240]))
    src = src.replace(old, new, n)
    print('  ok  %s' % tag)

# ── ١) السؤال الأول: السلسلة الأربعة بدل اتنين ────────────────
rep(
"""    '   The values live in a different family — /user_reports/… rather than /reports/… — and they take two calls:',
    '     a. POST /user_reports/add            → creates the report, returns the report id',
    '     b. POST /user_reports/data-summary   → returns the rows for that id',
    '   /user_reports/data and /user_reports/data-new return the same rows in fuller shapes, and /user_reports/export returns the same result as a file.',""",
"""    '   The values live in a different family — /user_reports/… rather than /reports/… — and reading them is a chain of four calls:',
    '     a. POST /user_reports/add           → creates the report, returns the report id',
    '     b. POST /user_reports/percentage    → generation progress for that id; repeat until it reaches 100',
    '     c. POST /user_reports/data-summary  → the aggregated summary: one row per vehicle',
    '     d. POST /user_reports/data-new      → the detailed rows for a single vehicle, keyed by resource_id',
    '   Steps c and d serve different needs. Use c for the summary table you described, and d when you need the breakdown behind one vehicle. /user_reports/export returns the same result as a file.',
    '   Step b is the one that is easy to miss. The report is generated asynchronously, so immediately after step a the rows do not exist yet. Reading them at that moment returns an empty data array with status_code 200 and message success — a valid response that looks like a failure. Poll until the percentage is 100, then read.',""",
    1, 'reply: four-call chain')

# ── ٢) السؤال التالت ──────────────────────────────────────────
rep(
"""    '3) Is another call needed after /reports/lists',
    '   Yes — the two above. /reports/lists on its own can never return values, however the parameters are varied.',""",
"""    '3) Is another call needed after /reports/lists',
    '   Yes — the chain above. /reports/lists on its own can never return values, however the parameters are varied. Keep it for the column headers and for letting your user pick a report type.',""",
    1, 'reply: q3')

# ── ٣) العينات: نضيف المتابعة وتفاصيل العربية ─────────────────
rep(
"""    '   Step 2 — read its rows:',
    '   POST https://api.afaqy.sa/user_reports/data-summary?token=<YOUR_TOKEN>',
    '   { "data": { "id": "<REPORT_ID>" } }',
    ''
  ];""",
"""    '   Step 2 — wait for it to finish generating:',
    '   POST https://api.afaqy.sa/user_reports/percentage?token=<YOUR_TOKEN>',
    '   { "data": { "ids": ["<REPORT_ID>"] } }',
    '',
    '   → { "data": [ { "reportId": "<REPORT_ID>", "percentage": 100 } ] }',
    '   Repeat this call every few seconds until percentage reaches 100. Only then do the rows exist.',
    '',
    '   Step 3 — read the aggregated summary (one row per vehicle):',
    '   POST https://api.afaqy.sa/user_reports/data-summary?token=<YOUR_TOKEN>',
    '   { "data": { "id": "<REPORT_ID>" } }',
    '',
    '   Step 4 — read the detail behind a single vehicle:',
    '   POST https://api.afaqy.sa/user_reports/data-new?token=<YOUR_TOKEN>',
    '   { "data": { "id": "<REPORT_ID>", "resource_id": "<UNIT_ID>" } }',
    '   The resource_id here is the unit id, the same value you passed in resources when creating the report.',
    ''
  ];""",
    1, 'reply: samples')

# ── ٤) الخاتمة تعكس الاتنين ───────────────────────────────────
rep(
"""  L.push('So: keep /reports/lists for building the column headers and letting the user pick a report type, and add the create-then-read pair for the data itself.');""",
"""  L.push('In short: /reports/lists gives you the column headers, /user_reports/add plus /user_reports/percentage produce the run, /user_reports/data-summary gives the summary table, and /user_reports/data-new gives the per-vehicle detail. If a read comes back empty, check the percentage before anything else — nine times out of ten the report simply had not finished.');""",
    1, 'reply: closing')

# ── ٥) لوحة التشخيص: السلسلة الظاهرة للموظف ──────────────────
rep(
"""        <code>POST /user_reports/add</code> → ${t('بيرجّع رقم التقرير','returns the report id')} →
        <code>POST /user_reports/data-summary</code> → ${t('بيرجّع الصفوف','returns the rows')} →
        <code>POST /user_reports/delete</code> ${t('للتنضيف بعد التجربة','to clean up after testing')}.<br>""",
"""        <code>POST /user_reports/add</code> → ${t('بيرجّع رقم التقرير','returns the report id')} →
        <code>POST /user_reports/percentage</code> → ${t('استنى لحد ١٠٠٪','wait until it reaches 100%')} →
        <code>POST /user_reports/data-summary</code> → ${t('الملخص المجمّع','the aggregated summary')} →
        <code>POST /user_reports/data-new</code> → ${t('تفاصيل عربية واحدة بـ resource_id','one vehicle in detail, by resource_id')} →
        <code>POST /user_reports/delete</code> ${t('للتنضيف بعد التجربة','to clean up after testing')}.<br>
        ${t('لو قريت الصفوف قبل ما النسبة توصل ١٠٠٪ بترجع فاضية والرد سليم — ده أشهر سبب للبلاغ ده. جرّب السلسلة كاملة من تبويب «سيناريوهات جاهزة».',
            'Reading the rows before the percentage reaches 100 returns an empty result with a valid response — the most common cause of this complaint. Run the whole chain from the ready-scenarios tab.')}<br>""",
    1, 'diagnosis: chain')

io.open(PATH, 'w', encoding='utf-8').write(src)
print('\ndone: %s (%d -> %d, +%d)' % (PATH, orig, len(src), len(src) - orig))
