/* v6.44 — طلب إنتجريشن: إيميل فيه لستة بيانات بيتحوّل لرد نقطة بنقطة.
   المحك إيميل حقيقي من عميل (٢٧ سبتمبر ٢٠٢٦): ١٤ نقطة بيانات و٨ أسئلة فنية.
   القاعدة اللي بتتقفل هنا: مفيش بند بيتقال «متاح» غير لو الريكوست في الكولكشن،
   واللي مش فيها بيتقال «يحتاج تأكيد» — مش بيتخمّن. */
const fs=require('fs'); const {JSDOM}=require('jsdom');
let F=0; const pass=m=>console.log('  \u2713 '+m); const fail=m=>{console.log('  \u2717 '+m);F++;};
const ok=(m,c,x)=>c?pass(m):fail(m+(x?'  \u2014 '+String(x).slice(0,160):''));
const build=()=>fs.readFileSync(process.argv[2]||'app_template.html','utf8')
  .replace('/*__KB__*/',()=>fs.readFileSync('kb_slim.json','utf8'))
  .replace('/*__DOCS__*/',()=>fs.readFileSync('docs.json','utf8'))
  .replace('/*__KBIN__*/',()=>fs.readFileSync('kb_in.json','utf8'));
function boot(){
  const w=new JSDOM(build(),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://localhost/'}).window;
  w.alert=()=>{}; w.confirm=()=>true; w.scrollTo=()=>{}; w.URL.createObjectURL=()=>'blob:x';
  w.HTMLAnchorElement.prototype.click=function(){};
  return w;
}
const EMAIL_AR = `السادة/ فريق آفاقي المحترمين،

نرغب في الاستفادة من خدمة API الخاصة بنظام آفاقي لحساب الشركة، ونأمل تزويدنا بإمكانية الوصول إلى البيانات التالية للمركبات المسجلة لدينا:

1. رقم اللوحة ومعرّف المركبة (Vehicle ID).
2. المسافة المقطوعة لكل رحلة ولكل يوم.
3. تاريخ ووقت بداية ونهاية كل رحلة ومدة الرحلة.
4. حالة تشغيل وإيقاف المحرك (Ignition ON/OFF).
5. إجمالي ساعات تشغيل المحرك (Engine Hours).
6. مدة وقوف المركبة والمحرك في حالة تشغيل (Idling Duration)، مع وقت بداية ونهاية الحالة.
7. بيانات التوقفات (Stops/Parking)، وتشمل وقت البداية والنهاية والمدة والموقع.
8. بيانات الموقع GPS والمسارات التاريخية للمركبة، مع التاريخ والوقت.
9. بيانات السرعة.
10. إمكانية استخراج حركة المركبة حسب التاريخ والوقت.
11. بالنسبة للمركبات المبردة، نرجو توضيح إمكانية الحصول على حالة تشغيل وحدة التبريد أو الـ PTO، وساعات تشغيل وحدة التبريد وأوقات بداية ونهاية التشغيل.
12. بيانات مستوى الوقود أو استهلاك الوقود (Fuel Level / Fuel Consumption) في حال كانت متاحة من الأجهزة أو CAN Bus.
13. بيانات السائق (Driver ID) المرتبط بالمركبة، إن كانت متاحة.
14. إمكانية الوصول إلى البيانات التاريخية (Historical Data)، مع توضيح أقصى مدة تاريخية متاحة من خلال الـ API.

كما نرجو تزويدنا بالمعلومات الفنية الخاصة بالـ API، وتشمل:
• API Documentation.
• طريقة المصادقة (Authentication).
• إمكانية توفير API Key أو Token بصلاحية Read Only.
• قائمة الـ Endpoints المتاحة.
• حدود الاستخدام (Rate Limits).
• إمكانية استخدام Webhooks إن كانت متاحة.
• إمكانية توفير بيئة تجريبية أو بيانات تجريبية (Sandbox/Test).
• توضيح ما إذا كانت خدمة الـ API تتطلب رسومًا إضافية.

ونأمل أيضًا توضيح أي من البيانات المذكورة أعلاه غير متاح حاليًا من خلال الـ API، وأي بدائل متاحة للحصول عليه.

شاكرين لكم تعاونكم، وننتظر إفادتكم.`;

const EMAIL_EN = `Hello AFAQY team,

We would like to integrate with your API and need access to the following for our fleet:
1) Vehicle ID and plate number
2) Distance per day
3) Ignition ON/OFF status
4) Fuel level if available from CAN bus
5) Driver ID linked to each vehicle
- API documentation
- Rate limits

Thanks`;

const TICKET = `Hi, our integration is failing:
1. We call POST /units/lists with the token
2. The response is 200 but the body says unauthorized
3. We tried again and got the same
{"message":"unauthorized","status_code":401,"extra":[]}
Please advise.`;

(async()=>{
/* ═════ ١) الكتالوج نفسه: كل ريكوست فيه موجود في الكولكشن ═════ */
{
  const w=boot();
  const cat=w.eval('REQ_CATALOG'), EPS=w.eval('EPS'), ST=w.eval('REQ_ST');
  const missing=[];
  cat.forEach(c=>c.eps.forEach(p=>{ if(!EPS.some(e=>e.p===p && w.sysOf(e)==='avl')) missing.push(c.id+':'+p); }));
  ok('كل ريكوست في الكتالوج موجود في كولكشن AVL — مفيش مسار مخترع', missing.length===0, missing.join(' '));
  const gaps=cat.filter(c=>!(c.t&&c.t.ar&&c.t.en&&c.note&&c.note.ar&&c.note.en&&c.reply&&c.reply.ar&&c.reply.en)).map(c=>c.id);
  ok('كل بند بالعربي والإنجليزي: عنوان وملاحظة ورد', gaps.length===0, gaps.join(' '));
  const badSt=cat.filter(c=>!ST[c.st]).map(c=>c.id);
  ok('كل بند بحالة معروفة', badSt.length===0, badSt.join(' '));
  ok('البند اللي حالته «متاح» وراه ريكوست فعلًا (إلا التوثيق والقايمة)',
     cat.filter(c=>c.st==='ok' && !c.eps.length).every(c=>['docs','endpoints-list'].includes(c.id)));
}
/* ═════ ٢) الإيميل الحقيقي: بيتعرف عليه وكل بند بياخد حالته ═════ */
{
  const w=boot();
  const a=w.analyzeCase(EMAIL_AR);
  ok('الإيميل اتعرف عليه كطلب إنتجريشن مش تذكرة', a.reqCase===true && a.reportCase===false);
  ok('٢٢ بند: ١٤ رقم و٨ نقطة', a.req.items.length===22 && a.req.items.filter(x=>x.num).length===14, a.req.items.length);
  const st=id=>a.req.items[id-1].st;
  ok('١) اللوحة والمعرّف → متاح', st(1)==='ok', st(1));
  ok('٣) الرحلات → يحتاج تأكيد (مفيش قالب رحلات في الكولكشن)', st(3)==='confirm', st(3));
  ok('٤) الإشعال → متاح ومش متلخبط مع الخمول', st(4)==='ok' && a.req.items[3].hits.map(h=>h.id).join()==='ignition', a.req.items[3].hits.map(h=>h.id));
  ok('٥) ساعات المحرك → متاح', st(5)==='ok');
  ok('٦) الخمول → جزئي، ومش بيطلّع التوقفات', st(6)==='part' && !a.req.items[5].hits.some(h=>h.id==='stops'));
  ok('٧) التوقفات → جزئي، ومش بيطلّع المواقع', st(7)==='part' && !a.req.items[6].hits.some(h=>h.id==='gps-history'));
  ok('٨) و١٠) المواقع والحركة → متاح', st(8)==='ok' && st(10)==='ok');
  ok('١١) التبريد → حسب الجهاز', st(11)==='sensor');
  ok('١٢) الوقود → حسب الجهاز', st(12)==='sensor');
  ok('١٣) السائق → متاح', st(13)==='ok');
  ok('١٤) أقصى مدة تاريخية → يحتاج تأكيد، مش مواقع', st(14)==='confirm' && a.req.items[13].hits.map(h=>h.id).join()==='retention', a.req.items[13].hits.map(h=>h.id));
  const b=i=>a.req.items[14+i];
  ok('التوثيق والمصادقة → متاح', b(0).st==='ok' && b(1).st==='ok');
  ok('توكن قراءة فقط → يحتاج تأكيد', b(2).st==='confirm');
  ok('حدود الاستخدام → يحتاج تأكيد (ما نقولش مفيش حد)', b(4).st==='confirm');
  ok('Webhooks → جزئي', b(5).st==='part');
  ok('البيئة التجريبية → يحتاج تأكيد', b(6).st==='confirm');
  ok('الرسوم → تجاري', b(7).st==='sales');
  ok('العدّاد: ١٠ متاحة · ٣ جزئي · ٢ جهاز · ٦ تأكيد · ١ تجاري · ٠ من غير مقابل',
     JSON.stringify(a.req.count)===JSON.stringify({ok:10,part:3,sensor:2,confirm:6,sales:1,none:0}), JSON.stringify(a.req.count));
}
/* ═════ ٣) الرد: بلغة إيميله، بترقيمه، ومن غير تخمين ═════ */
{
  const w=boot();
  const a=w.analyzeCase(EMAIL_AR);
  const ar=w.reqReply(a,'ar'), en=w.reqReply(a,'en');
  ok('الرد العربي بيبدأ بالبند ١ بنص العميل نفسه', /1\) رقم اللوحة ومعرّف المركبة/.test(ar));
  ok('البنود بنقطة بتفضل بنقطة مش بترقيم مخترع', /• API Documentation/.test(ar) && !/15\)/.test(ar));
  ok('الرد العربي بيقول «قيد التأكيد» على الرحلات', /3\)[^\n]*\n\s+قيد التأكيد/.test(ar));
  ok('الرد العربي مش بيوعد برقم لحدود الاستخدام', !/طلب في (الدقيقة|الثانية)|requests per/i.test(ar+en));
  ok('ساعات المحرك بالثواني ÷ 3600 موجودة في الرد', /3600/.test(ar) && /3600/.test(en));
  ok('الرد الإنجليزي عناوينه من الكتالوج مش نص العميل العربي', /1\) Vehicle id and plate/.test(en) && !/رقم اللوحة/.test(en));
  ok('الرد الإنجليزي بيلخّص اللي هيتأكد لاحقًا', /Points we will come back to in a follow-up: 2, 3, 6, 7, 14/.test(en));
  ok('لينك التوثيق في الاتنين', /api\.afaqy\.sa\/docs/.test(ar) && /api\.afaqy\.sa\/docs/.test(en));
  ok('caseReply بيرجّع نفس الرد للطلب', w.caseReply(a)===w.reqReply(a,'ar'));
}
/* ═════ ٤) الشاشة: الرد فوق، زرار اللغة، الجدول، الكولكشن ═════ */
{
  const w=boot();
  w.showView('inspect'); w.eval("INSPVIEW='case'"); w.paintInspSwitch(); w.paintCase();
  w.document.getElementById('caseText').value=EMAIL_AR;
  w.document.getElementById('caseGo').click();
  const out=w.document.getElementById('caseOut');
  ok('الشاشة بتقول طلب إنتجريشن', /طلب إنتجريشن: 22 بند/.test(out.textContent));
  const pre=w.document.getElementById('caseReplyTxt');
  ok('الرد ظاهر بالعربي واتجاهه يمين', pre && pre.style.direction==='rtl' && /1\) رقم اللوحة/.test(pre.textContent));
  w.document.getElementById('reqEn').click();
  const pre2=w.document.getElementById('caseReplyTxt');
  ok('زرار الإنجليزي بيقلب الرد واتجاهه', pre2.style.direction==='ltr' && /Dear team/.test(pre2.textContent));
  const rows=out.querySelectorAll('table.kv tr');
  ok('الجدول فيه ٢٢ صف', rows.length===22, rows.length);
  ok('صف السائق فيه زرار يفتح الريكوست', !!out.querySelector('[data-goep] code') && /get_unit_driver/.test(out.textContent));
  /* الكولكشن: من غير توكن، بعلامات مكان، وبالريكوستات المتاحة بس */
  const a=w.analyzeCase(EMAIL_AR);
  const col=w.pmFromReq(a); const txt=JSON.stringify(col);
  const paths=col.item.map(it=>String(it.request.url.raw).replace('{{base_url}}','').replace(/\?.*$/,''));
  ok('الكولكشن بيبدأ بالدخول', paths[0]==='/auth/login', paths[0]);
  ok('فيه المواقع والإشارات والحساسات والسائق', ['/units/locations','/units/signals','/unit_sensors/lists','/drivers/get_unit_driver','/drivers/lists'].every(p=>paths.includes(p)), paths.join(' '));
  ok('مفيش ريكوست مكرر', new Set(paths).size===paths.length);
  ok('مفيش توكن ولا معرّف حقيقي جوه الملف', !/eyJ[A-Za-z0-9\-_]{15,}/.test(txt) && !/"[0-9a-f]{24}"/.test(txt));
  ok('علامات المكان مستخدمة', /\{\{unit_id\}\}/.test(txt) && /\{\{date_from\}\} 00:00:00/.test(txt));
  ok('offset الخمسين اتصلّح لصفر', !/"offset": ?"?50"?/.test(txt));
  ok('متغيّر التوكن فاضي (mine=false)', col.variable.find(v=>v.key==='token').value==='');
}
/* ═════ ٥) إيميل إنجليزي: الرد إنجليزي افتراضيًا بنص العميل ═════ */
{
  const w=boot();
  const a=w.analyzeCase(EMAIL_EN);
  ok('الإيميل الإنجليزي اتعرف عليه', a.reqCase===true && a.req.items.length===7, a.req && a.req.items.length);
  const en=w.reqReply(a, a.arabic?'ar':'en');
  ok('الافتراضي إنجليزي وعناوينه نص العميل', /1\) Vehicle ID and plate number/.test(en) && /Dear team/.test(en));
  ok('الوقود حسب الجهاز والحدود تحتاج تأكيد', a.req.items[3].st==='sensor' && a.req.items[6].st==='confirm');
  const ar=w.reqReply(a,'ar');
  ok('العربي لإيميل إنجليزي بياخد عناوين الكتالوج', /1\) رقم اللوحة ومعرّف المركبة/.test(ar));
}
/* ═════ ٦) تذكرة عادية فيها خطوات مرقّمة: ما تتحوّلش لطلب ═════ */
{
  /* إيميل تقرير الـ Summary الحقيقي — فيه لستة حقول وأسئلة مرقّمة، وكان هيتقرأ كطلب بيانات */
  const w=boot();
  const SUMMARY=`Dear team,\n\nI am currently integrating the following Report API:\nhttps://api.afaqy.sa/reports/lists?token={{afaqy_token}}\n\nThe API is returning a successful response, but the data section appears to contain the report configuration rather than the actual report values.\nFor example, under summary_beta, the response provides fields such as:\n\n  - Date — code: date\n  - Route Length — code: route_length\n  - Engine Work Duration — code: engine_work\n  - Stop Duration — code: stop_duration\n\nQuestions:\n1. Which API endpoint should be used to retrieve the actual report data/records for summary_beta?\n2. What parameters are required, such as vehicle ID, date range, report code, etc.?\n3. Is there another API that needs to be called after /reports/lists?\n4. Could you please provide a sample request and response containing actual values, for example Date: 10-08-2026 and Route Length: 70 km?`;
  const a=w.analyzeCase(SUMMARY);
  ok('إيميل تقرير الـ Summary فضل حالة تقرير مش طلب بيانات', a.reportCase===true && a.reqCase===false, JSON.stringify({rep:a.reportCase, req:a.reqCase}));
}
{
  const w=boot();
  const a=w.analyzeCase(TICKET);
  ok('التذكرة اللي فيها رد خطأ فضلت تذكرة', a.reqCase===false, JSON.stringify(a.req && a.req.count));
  const a2=w.analyzeCase('1) list vehicles\n2) speed');
  ok('لستة من بندين مش طلب', a2.reqCase===false);
}

console.log(F ? `\nفشل ${F}` : '\nطلب الإنتجريشن: تمام');
process.exit(F?1:0);
})();
