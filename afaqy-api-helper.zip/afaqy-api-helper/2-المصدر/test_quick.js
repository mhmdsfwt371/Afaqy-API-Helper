const fs=require('fs');
function el(id){return{id,hidden:false,innerHTML:'',value:'',textContent:'',dataset:{},style:{},files:[],disabled:false,
 classList:{toggle(){},add(){},remove(){}},querySelectorAll(){return[]},addEventListener(){},focus(){},select(){},click(){},
 setAttribute(){},getAttribute(){return null},dispatchEvent(){},appendChild(){},remove(){},scrollIntoView(){},oninput:null,onchange:null,onclick:null}}
const R={};global.document={documentElement:el(),body:el(),addEventListener(){},querySelectorAll(){return[]},
 querySelector(){return null},createElement(){return el()},getElementById(i){return R[i]||(R[i]=el(i))}};
global.history={pushState(){},replaceState(){}};
global.location={hash:''};
global.navigator={clipboard:{writeText(){return Promise.resolve()}}};global.window={scrollTo(){},addEventListener(){}};
global.fetch=()=>Promise.reject(0);global.Blob=function(){};global.URL={createObjectURL(){return''}};global.FileReader=function(){};
let js=fs.readFileSync('app_template.html','utf8').split('<script>')[1].split('</script>')[0]
  .replace('/*__KB__*/',fs.readFileSync('kb_slim.json','utf8')).replace('/*__DOCS__*/',fs.readFileSync('docs.json','utf8'));
const m={};new Function('module',js+`
module.exports={EPS,injectUid,quickCandidates,quickCurl,quickBundle,labVariants,matchByName,DESTRUCTIVE,setL:(l)=>{LANG=l}};`)(m);
const A=m.exports;
const UID='5fb0e2e703ed529bb30f9af3';

console.log('١) الإندبوينتس اللي بتتعرض للموظف (قراءة بس، ومرتبطة بعربية):');
['اشارات','موقع','عدادات','تقرير'].forEach(q=>{
  const r=A.quickCandidates(q);
  console.log('   "'+q+'" → '+(r.length?r.map(x=>x.e.p).slice(0,3).join(' , '):'مفيش'));
});

console.log('\n٢) مفيش أي إندبوينت بيمسح أو بيعدّل في القايمة:');
const all=['اشارات','موقع','عدادات','تقرير','حذف','تعديل','اضافة'].flatMap(q=>A.quickCandidates(q));
const bad=all.filter(x=>A.DESTRUCTIVE.test(x.e.n)||A.DESTRUCTIVE.test(x.e.p));
console.log('   '+(bad.length?'خطر! '+bad.map(b=>b.e.p).join(','):'نضيفة ✓'));

console.log('\n٣) حقن الـ UID والتواريخ في بودي الإشارات:');
const sig=A.EPS.find(e=>e.p==='/units/signals');
const body=A.injectUid(JSON.parse(sig.b), UID, '2026-08-01 00:00:00', '2026-08-03 23:59:59', true);
console.log(JSON.stringify(body,null,1));

console.log('\n٤) حقن في بودي المواقع:');
const loc=A.EPS.find(e=>e.p==='/units/locations');
console.log(JSON.stringify(A.injectUid(JSON.parse(loc.b), UID, '2026-08-01 00:00:00','2026-08-01 23:59:59', true)));

console.log('\n٥) حقن في filters.id (لستة العربيات بالعدادات):');
console.log(JSON.stringify(A.injectUid({data:{limit:1,projection:['basic','counters'],filters:{id:'OLD'}}}, UID,'','',false)));

console.log('\n٦) الـ curl الناتج:');
console.log(A.quickCurl(sig, body).split('\n').slice(0,4).join('\n')+'\n  ...');
console.log('\n   التوكن ظاهر؟ '+(A.quickCurl(sig,body).includes('<YOUR_TOKEN>')?'لأ — متبدل ✓':'أيوه ✗'));

console.log('\n٧) الرد الجاهز للعميل فيه الـ UID والتحذيرات:');
const b=A.quickBundle(sig,{name:'NB YD',id:UID,imei:'357454075086551'},'CURL','{"ok":true}');
['UID: '+UID,'IMEI: 357454075086551','returns HTTP 200 even when a call fails','not accepted by these endpoints'].forEach(k=>
  console.log('   '+(b.includes(k)?'✓':'✗')+'  '+k));
