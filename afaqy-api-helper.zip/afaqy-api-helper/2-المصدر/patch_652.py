#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v6.52 — الـ UID بيتجاب لوحده من الـ IMEI اللي في التذكرة.

طلب صفوت (١٢ أكتوبر): طالما التذكرة فيها IMEI، الرد يطلّع للعميل الـ UID
اللي يستخدمه جاهز — أوتوماتيك، من غير ما الموظف يحدّد الجهاز من الشريط.

- لما الحالة تتشخّص «IMEI مكان رقم العربية» والأداة متصلة بحساب، بتنده
  نفس الريكوست الموثّق اللي الرد بيقترحه: /units/lists مفلتر بالـ IMEI.
  لو الفلتر ما اشتغلش (السيرفر رجّع لستة عادية) بتدوّر جوه اللستة، ولو
  لسه مش لاقية بتجيب لستة الحساب كلها مرة واحدة (نفس كاش «حدّد الجهاز»).
- بتقبل التطابق على الـ IMEI بس — مش الاسم ولا السيريال.
- بتتعمل مرة واحدة لكل IMEI لكل حساب متصل؛ لو اتصلت بحساب تاني، الكاش بيتمسح.
- الرد والكولكشن بياخدوا الـ UID، وتحت عنوان الرد ملاحظة بتقول حصل إيه:
  اتجاب (واسم العربية)، أو بيتجاب، أو العربية مش على الحساب ده، أو مش متصل.
- الشريط فوق ما بيتغيّرش — العربية المحددة فيه بتفضل زي ما هي.
"""
import sys, io, os
HERE = os.path.dirname(os.path.abspath(__file__))
PATH = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, 'app_template.html')
src = io.open(PATH, encoding='utf-8').read(); orig = len(src)
def rep(old, new, n=1, tag=''):
    global src
    c = src.count(old)
    if c != n: raise SystemExit('MISMATCH [%s]: expected %d found %d\n---\n%s' % (tag, n, c, old[:200]))
    src = src.replace(old, new, n); print('  ok  %s' % tag)

# ── ١) الكاش والبحث ─────────────────────────────────────────────
rep("""/* الـ UID الحقيقي لو الموظف حدّد نفس الـ IMEI من الشريط فوق */
function _uidFor(im){
  return (im && typeof SESSION !== 'undefined' && SESSION.unit && String(SESSION.unit.imei) === String(im) && SESSION.unit.uid) ? String(SESSION.unit.uid) : '';
}""",
"""/* v6.52: الـ UID اللي اتجاب أوتوماتيك لكل IMEI — مربوط بالحساب المتصل، ويتمسح لو الحساب اتغيّر */
const IMEI_UID = { tok:null, map:{}, state:{} };
function _imeiCacheFresh(){
  const tok = (typeof SESSION !== 'undefined' && SESSION.token) || null;
  if(IMEI_UID.tok !== tok){ IMEI_UID.tok = tok; IMEI_UID.map = {}; IMEI_UID.state = {}; }
}
/* الـ UID الحقيقي: من الشريط فوق لو نفس الـ IMEI، أو اللي اتجاب أوتوماتيك */
function _uidFor(im){
  if(!im) return '';
  if(typeof SESSION !== 'undefined' && SESSION.unit && String(SESSION.unit.imei) === String(im) && SESSION.unit.uid) return String(SESSION.unit.uid);
  _imeiCacheFresh();
  const hit = IMEI_UID.map[digitsOnly(String(im))];
  return hit ? hit.uid : '';
}
/* بيجيب الـ UID لـ IMEI من الحساب المتصل — بنفس الريكوست الموثّق اللي الرد بيقترحه.
   بيرجّع: 'ok' | 'none' (مش على الحساب) | 'err' | 'nosession' */
async function autoUid(im){
  _imeiCacheFresh();
  const key = digitsOnly(String(im || ''));
  if(!key) return 'none';
  if(!SESSION.token) return 'nosession';
  if(IMEI_UID.map[key]) return 'ok';
  if(IMEI_UID.state[key] && IMEI_UID.state[key] !== 'busy') return IMEI_UID.state[key];
  IMEI_UID.state[key] = 'busy';
  const take = resp => { const m = matchByName(resp, key); return (m.hit && m.by === 'IMEI') ? m.hit : null; };
  try{
    let hit = null;
    const r = await apiFetch('/units/lists', {data:{offset:0, limit:1, projection:['basic'], filters:{imei:{value:[key], op:'in'}}}}, {method:'POST'});
    if(r && r.ok) hit = take(r.json);
    if(!hit){
      /* الفلتر ما رجّعش العربية — نفس لستة «حدّد الجهاز» (مرة واحدة للحساب) */
      if(!UNITS_CACHE){
        const r2 = await apiFetch('/units/lists', {data:{offset:0, limit:1000, simplify:0, projection:['basic']}}, {method:'POST'});
        if(r2 && r2.ok) UNITS_CACHE = r2.json;
      }
      if(UNITS_CACHE) hit = take(UNITS_CACHE);
    }
    if(hit){ IMEI_UID.map[key] = {uid:String(hit.id), name:String(hit.name || '')}; IMEI_UID.state[key] = 'ok'; return 'ok'; }
    IMEI_UID.state[key] = 'none'; return 'none';
  }catch(_){ IMEI_UID.state[key] = 'err'; return 'err'; }
}""", tag='كاش الـ UID والبحث')

# ── ٢) شاشة الحالة: بتنده البحث وبتقول حصل إيه ────────────────────
rep("""  /* ٥) رد جاهز */
  const reply = caseReply(a);
  if(reply){""",
"""  /* v6.52: الـ IMEI اللي في التذكرة ← الـ UID من الحساب المتصل، أوتوماتيك */
  let uidNote = '';
  { const m0 = caseMatch(a), im = _imeis(a)[0];
    if(im && m0 && m0.r && m0.r.id === 'imei-vs-uid'){
      _imeiCacheFresh();
      const key = digitsOnly(String(im)), st = IMEI_UID.state[key], got = _uidFor(im), hit = IMEI_UID.map[key];
      if(got){
        uidNote = `<div class="note sig" style="margin-bottom:8px"><b>${t('الـ UID مكتوب في الرد:','The UID is in the reply:')}</b> <code>${esc(got)}</code>${hit && hit.name ? ' — ' + esc(hit.name) : ''}.
          ${hit ? t('اتجاب أوتوماتيك من الحساب المتصل بالـ IMEI اللي في التذكرة.','Fetched automatically from the connected account using the IMEI in the ticket.') : t('من الجهاز المحدد فوق.','From the device set in the top bar.')}</div>`;
      } else if(!SESSION.token){
        uidNote = `<div class="note warn" style="margin-bottom:8px">${t(`اتصل بحساب العميل (أو أي حساب شايف العربية) والأداة هتجيب الـ UID بتاع ${im} وتكتبه في الرد لوحدها.`, `Connect to the customer account (or any account that sees the vehicle) and the tool fetches the UID for ${im} and writes it into the reply.`)}</div>`;
      } else if(st === 'none'){
        uidNote = `<div class="note warn" style="margin-bottom:8px">${t(`العربية اللي الـ IMEI بتاعها ${im} مش على الحساب المتصل — اتصل بحساب العميل والـ UID هيتكتب لوحده.`, `The vehicle with IMEI ${im} is not on the connected account — connect to the customer account and the UID is written automatically.`)}</div>`;
      } else if(st === 'err'){
        uidNote = `<div class="note warn" style="margin-bottom:8px">${t('ما وصلناش للسيرفر عشان نجيب الـ UID — الرد تحت فيه الخطوة اللي العميل يجيبه بيها.','Could not reach the server to fetch the UID — the reply below carries the step the customer uses to get it.')}</div>`;
      } else {
        uidNote = `<div class="note" style="margin-bottom:8px">${t(`بنجيب الـ UID بتاع ${im} من الحساب المتصل…`, `Fetching the UID for ${im} from the connected account…`)}</div>`;
        if(st !== 'busy'){
          const again = text;
          autoUid(im).then(() => { const box = $('caseText'); if(!box || box.value === again || !box.value) renderCase(again); });
        }
      }
    }
  }

  /* ٥) رد جاهز */
  const reply = caseReply(a);
  if(reply){""", tag='البحث الأوتوماتيك في شاشة الحالة')
rep("""          'Written in the language of their message. Read it before sending, and adjust the execution-body part once the reports team confirms its shape.')}</div>
      <pre id="caseReplyTxt\"""",
"""          'Written in the language of their message. Read it before sending, and adjust the execution-body part once the reports team confirms its shape.')}</div>
      ${uidNote}
      <pre id="caseReplyTxt\"""", tag='الملاحظة فوق الرد')

io.open(PATH, 'w', encoding='utf-8').write(src)
print('القالب: %d → %d بايت' % (orig, len(src)))
