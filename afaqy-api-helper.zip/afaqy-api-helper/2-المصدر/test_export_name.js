/* اسم ملف الإكسل: المستخدم - الحاجة - التاريخ - الوقت، في كل التصديرات */
const fs=require('fs');
const R={}; let LAST=null;
function el(id){return{id,hidden:false,innerHTML:'',value:'',textContent:'',dataset:{},style:{},href:'',
 get download(){return this._d}, set download(v){this._d=v; LAST=v;},
 classList:{toggle(){},add(){},remove(){}},querySelectorAll(){return[]},addEventListener(){},focus(){},select(){},
 click(){},setAttribute(){},getAttribute(){return null},dispatchEvent(){},appendChild(){},remove(){},scrollIntoView(){},onclick:null}}
global.document={documentElement:el(),body:el(),addEventListener(){},querySelectorAll(){return[]},
 querySelector(){return null},createElement(){return el()},getElementById(i){return R[i]||(R[i]=el(i))}};
global.history={pushState(){},replaceState(){}};global.location={hash:'',pathname:'/',replace(){},reload(){}};
global.setInterval=()=>0;global.navigator={clipboard:{writeText(){return Promise.resolve()}}};
global.window={scrollTo(){},addEventListener(){}};global.fetch=()=>Promise.reject(0);
global.TextEncoder=require('util').TextEncoder;global.Blob=function(){};
global.URL={createObjectURL(){return''}};global.FileReader=function(){};global.AbortController=function(){};
let js=fs.readFileSync('app_template.html','utf8').split('<script>')[1].split('</script>')[0]
 .replace('/*__KB__*/',fs.readFileSync('kb_slim.json','utf8')).replace('/*__KBIN__*/', fs.readFileSync('kb_in.json','utf8'))
 .replace('/*__DOCS__*/',fs.readFileSync('docs.json','utf8'));
const m={};new Function('module',js+
 "\nmodule.exports={exportName,SESSION,DASH,WASL,dashExport,waslExport,dashRender};")(m);
const A=m.exports;
const fail=s=>{console.error('فشل: '+s);process.exit(1)};
/* المستخدم - التاريخ - الموديول - الوقت */
const RE=/^[^-]+ - \d{4}-\d{2}-\d{2} - [^-]+ - (0[1-9]|1[0-2])-[0-5]\d (AM|PM)\.xlsx$/;

A.SESSION.user='safwat@afaqy.com';
const n1=A.exportName('كل العربيات');
if(!RE.test(n1)) fail('الشكل غلط: '+n1);
if(n1.indexOf('safwat@afaqy.com')!==0) fail('اسم المستخدم مش في الأول');
const parts=n1.replace(/\.xlsx$/,'').split(' - ');
if(parts.length!==4) fail('الأجزاء '+parts.length+' مش ٤: '+n1);
if(!/^\d{4}-\d{2}-\d{2}$/.test(parts[1])) fail('التاريخ مش في المكان التاني');
if(!/^(0[1-9]|1[0-2])-[0-5]\d (AM|PM)$/.test(parts[3])) fail('الوقت مش ١٢ ساعة بـ AM/PM: '+parts[3]);
console.log('الشكل           : '+n1+' ✓');

// الرموز الممنوعة في أسماء الملفات بتتشال
A.SESSION.user='a/b:c*d?e"f<g>h|i';
if(/[\\/:*?"<>|]/.test(A.exportName('x'))) fail('رموز ممنوعة فضلت في الاسم');
console.log('رموز الملفات    : اتشالت ✓');

// من غير اتصال
A.SESSION.user='';
if(A.exportName('x').indexOf('no-account')!==0) fail('ما تعاملش مع عدم الاتصال');
console.log('من غير اتصال    : no-account ✓');

/* الاسم لازم يبقى إنجليزي بالكامل — الخلط بيتعرض معكوس في ويندوز */
A.SESSION.user='agm';
const AR=/[\u0600-\u06FF]/;
if(AR.test(A.exportName('Devices all'))) fail('في عربي في اسم الملف');

// التصدير الفعلي من اللوحتين
A.SESSION.user='agm';
A.DASH.units=[{name:'V',imei:'1',device_type:'gps'}]; A.DASH.filter='gps'; A.DASH.flag=null;
LAST=null; A.dashExport();
if(!RE.test(LAST||'')) fail('اسم تصدير الأجهزة غلط: '+LAST);
if(LAST.indexOf('GPS')<0) fail('نوع الجهاز مش في الاسم: '+LAST);
if(AR.test(LAST)) fail('اسم تصدير الأجهزة فيه عربي: '+LAST);
if(LAST.replace(/\.xlsx$/,'').split(' - ').length!==4) fail('أجزاء تصدير الأجهزة مش ٤: '+LAST);
console.log('لوحة الأجهزة    : '+LAST+' ✓');

A.WASL.rows=[{id:'W1',name:'x',imei:'2'}]; A.WASL.q=''; A.WASL.inq={};
LAST=null; A.waslExport();
if(!RE.test(LAST||'')) fail('اسم تصدير وصل غلط: '+LAST);
if(LAST.indexOf('WASL')<0) fail('WASL مش في الاسم: '+LAST);
if(AR.test(LAST)) fail('اسم تصدير وصل فيه عربي: '+LAST);
if(LAST.replace(/\.xlsx$/,'').split(' - ').length!==4) fail('أجزاء تصدير وصل مش ٤: '+LAST);
console.log('لوحة وصل        : '+LAST+' ✓');


// الوقت ١٢ ساعة صح في كل الحالات
const check=(h,mi,want)=>{
  const RD=Date; global.Date=class extends RD{ constructor(){ super(2026,7,4,h,mi); } };
  const n=A.exportName('x').replace(/\.xlsx$/,'').split(' - ')[3];
  global.Date=RD;
  if(n!==want) fail('الساعة '+h+':'+mi+' طلعت '+n+' والمفروض '+want);
};
check(0,5,'12-05 AM');    // نص الليل
check(9,30,'09-30 AM');
check(12,0,'12-00 PM');   // الظهر
check(13,45,'01-45 PM');
check(23,59,'11-59 PM');
console.log('نظام ١٢ ساعة    : نص الليل والظهر والصبح والمسا كلهم صح ✓');
