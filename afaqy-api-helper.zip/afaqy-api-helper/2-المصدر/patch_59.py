#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v5.9 — الوضع الليلي + إصلاح زراير الشريط المخفية."""
import sys
P='app_template.html'; s=open(P,encoding='utf-8').read()
miss=[]; done=[]
def rep(old,new,label,cnt=1):
    global s
    c=s.count(old)
    if c!=cnt: miss.append(f'{label} (لقيت {c})'); return
    s=s.replace(old,new); done.append(label)

# ===== ١) خلفية الحبر تتفصل عن لون النص =====
rep("  --code-bg:#0E1A22; --code-ink:#D8E6EA;",
    "  --code-bg:#0E1A22; --code-ink:#D8E6EA;\n  --ink-bg:#101A24;        /* خلفية الهيدر والزراير — منفصلة عن لون النص عشان الوضع الليلي */",
    '١أ) متغير --ink-bg')
rep(".top{background:var(--ink); color:#E8EFF3; padding:12px 18px 0}",
    ".top{background:var(--ink-bg); color:#E8EFF3; padding:12px 18px 0}", '١ب) الهيدر')
rep(".btn{\n  background:var(--ink); color:#fff; border:1px solid var(--ink); border-radius:var(--r);",
    ".btn{\n  background:var(--ink-bg); color:#fff; border:1px solid var(--ink-bg); border-radius:var(--r);", '١ج) الزراير')
rep(".toast{position:fixed; bottom:22px; inset-inline-start:22px; background:var(--ink); color:#fff;",
    ".toast{position:fixed; bottom:22px; inset-inline-start:22px; background:var(--ink-bg); color:#fff;", '١د) التوست')
rep('id="topCopy" style="background:var(--ink); border-color:var(--ink)"',
    'id="topCopy" style="background:var(--ink-bg); border-color:var(--ink-bg)"', '١هـ) زرار النسخ فوق')

# ===== ٢) زراير الشريط الشبح: نص غامق على خلفية غامقة =====
rep(".btn.ghost{background:transparent; color:var(--ink); border-color:var(--line)}",
    """.btn.ghost{background:transparent; color:var(--ink); border-color:var(--line)}
/* الشريط العلوي غامق دايمًا — فأي زرار ghost جواه لازم يبقى نصه فاتح.
   من غير القاعدة دي الزرار بيتكتب بلون الحبر على خلفية الحبر ويختفي خالص. */
.conn .btn.ghost{color:#C7D6DF; border-color:#33475C}
.conn .btn.ghost:hover{background:#1C2A36; border-color:#4A6舒}""".replace('4A6舒','4A6275'),
    '٢) قاعدة زراير الشريط')

# ===== ٣) لوحة الوضع الليلي =====
rep("*{box-sizing:border-box}",
    """/* ============ الوضع الليلي ============
   نفس المتغيرات بقيم تانية — فأي حاجة في الأداة (اللوحات، النوافذ، الكروت،
   الجداول، النتايج) بتتحوّل معاها لوحدها من غير ما نلمس كل عنصر. */
html[data-theme="dark"]{
  --ink:#E7EDF2; --ink-2:#B7C6D2; --muted:#8CA0B0;
  --surface:#0F171E; --panel:#16212B; --panel-2:#1C2934;
  --line:#2E4050; --line-soft:#243441;
  --signal:#2AA5B3; --signal-deep:#6FD9C9; --signal-soft:#123840;
  --alert:#E8A06A; --alert-soft:#3A2416;
  --ok:#6FCB9B; --ok-soft:#12321F;
  --code-bg:#0A1116; --code-ink:#D8E6EA;
  --ink-bg:#0A1218;
}
html[data-theme="dark"] .btn{color:#EAF2F6}
html[data-theme="dark"] .btn.warn{border-color:#6A4A2E}
html[data-theme="dark"] .btn.sig{color:#04222A}
html[data-theme="dark"] .ct[aria-selected="true"]{color:#DCE9EE}
html[data-theme="dark"] .toast{color:#EAF2F6}
*{box-sizing:border-box}""", '٣) لوحة الوضع الليلي')

# ===== ٤) زرار التبديل في الشريط =====
rep('<button class="btn ghost" id="langBtn"',
    '<button class="btn ghost" id="themeBtn" style="padding:6px 12px; font-size:13px" title="الوضع الليلي / النهاري">\u263e</button>\n      <button class="btn ghost" id="langBtn"',
    '٤) زرار الثيم')

# ===== ٥) المنطق =====
rep("$('acctSel').onchange = acctPick;",
    """/* ============ v5.9 — الوضع الليلي ============
   أول فتحة بتمشي على إعداد الجهاز نفسه. أول ما تدوس الزرار، اختيارك
   بيتحفظ على الجهاز ده وبيفضل معاك في كل التبويبات والنوافذ. */
const THEME_KEY = 'afaqy.theme';
function themeStored(){
  try{ const v = localStorage.getItem(THEME_KEY); return (v === 'dark' || v === 'light') ? v : 'auto'; }
  catch(_){ return 'auto'; }
}
function themeIsDark(mode){
  if(mode === 'dark') return true;
  if(mode === 'light') return false;
  try{ return !!(window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches); }
  catch(_){ return false; }
}
function themeApply(mode){
  const dark = themeIsDark(mode);
  document.documentElement.setAttribute('data-theme', dark ? 'dark' : 'light');
  const mt = document.querySelector('meta[name="theme-color"]');
  if(mt) mt.setAttribute('content', dark ? '#0A1218' : '#101A24');
  const b = $('themeBtn');
  if(b){
    b.textContent = dark ? '\u2600' : '\u263e';
    b.title = dark ? t('رجّع الوضع النهاري','Switch to light') : t('الوضع الليلي','Switch to dark');
  }
  return dark;
}
function themeToggle(){
  const next = document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
  try{ localStorage.setItem(THEME_KEY, next); }catch(_){}
  themeApply(next);
}
$('themeBtn').onclick = themeToggle;
themeApply(themeStored());
$('acctSel').onchange = acctPick;""", '٥) منطق الثيم')

for d in done: print('تمام:',d)
if miss:
    print('!! MISS:'); [print('  ',x) for x in miss]; sys.exit(1)
open(P,'w',encoding='utf-8').write(s)
print(f'اتكتب — {len(done)} تعديل')
