const fs=require('fs');
function el(){return{hidden:false,innerHTML:'',value:'',textContent:'',dataset:{},style:{},classList:{toggle(){},add(){},remove(){}},querySelectorAll(){return[]},addEventListener(){},focus(){},select(){},click(){},setAttribute(){},getAttribute(){return null},dispatchEvent(){},appendChild(){},remove(){},scrollIntoView(){}}}
const R={};global.document={documentElement:el(),body:el(),addEventListener(){},querySelectorAll(){return[]},querySelector(){return null},createElement(){return el()},getElementById(i){return R[i]||(R[i]=el(i))}};
global.history={pushState(){},replaceState(){}};global.location={hash:''};
global.setInterval=()=>0;   // المؤقت بيخلي الاختبار ما يخلصش في Node
global.navigator={userAgent:'node',clipboard:{writeText(){return Promise.resolve()}}};global.window={scrollTo(){},addEventListener(){},matchMedia:()=>({matches:false}),navigator:{}};
global.fetch=()=>Promise.reject(0);global.Blob=function(){};global.URL={createObjectURL(){return''}};global.FileReader=function(){};
let js=fs.readFileSync('app_template.html','utf8').split('<script>')[1].split('</script>')[0]
 .replace('/*__KB__*/',fs.readFileSync('kb_slim.json','utf8'))
 .replace('/*__DOCS__*/',fs.readFileSync('docs.json','utf8'));
const m={};new Function('module',js+'\nmodule.exports={search,norm};')(m);const A=m.exports;

const cases=[['تسجيل دخول','/auth/login'],['عاوز اعمل لوجين','/auth/login'],['سرعة العربية','/units/signals'],
 ['اشارات','/units/signals'],['عاوز اشارات جهاز معين','/units/signals'],['عدادات العربية','/units/lists'],
 ['ساعات التشغيل','/units/lists'],['آخر موقع','/units/locations'],['فين العربية','/units/locations'],
 ['بيانات حدث معين','/events/view'],['مين عدل الصلاحيات','/audit/lists'],['لستة العربيات','/units/lists'],
 ['تشغيل تقرير','/user_reports/data'],['مخالفات','/traffic-tickets/lists'],['قائمة السواقين','/drivers/lists'],
 ['اضافة منطقة','/zones/add'],['حاويات النفايات','/waste/containers'],
 ['رقم الشريحة','/units/lists'],['امتى اتضاف الجهاز','/units/lists']];
let bad=[];
cases.forEach(([q,want])=>{ const r=A.search(q); const top=r.length?r[0].e.p:'—';
  if(top.indexOf(want)!==0) bad.push(q+' → '+top+' (متوقع '+want+')'); });
if(bad.length){ console.error('فشل:\n  '+bad.join('\n  ')); process.exit(1); }
console.log('البحث: '+cases.length+' من '+cases.length+' صح');

// التطبيع
const N=[['قائمة','قايمة'],['إشارات','اشارات'],['مؤشر','موشر'],['٣٥٧','357']];
N.forEach(([a,b])=>{ if(A.norm(a)!==A.norm(b)){ console.error('تطبيع فشل: '+a+' ≠ '+b); process.exit(1);} });
console.log('التطبيع: تمام');

// البادئة وانت بتكتب
if(!A.search('عاوز قائ').length){ console.error('البادئة فشلت'); process.exit(1); }
console.log('البادئة: تمام');

// نداءات بروتوكول الجهاز ما تتصدرش
const sig=A.search('اشارات');
if(!sig[0].e.p.startsWith('/')){ console.error('نداء بروتوكول اتصدّر'); process.exit(1); }
console.log('ترتيب البروتوكول: تمام');
