/* v6.9 — بوابة التنفيذ الحي وتسجيل الدخول لكل نظام.
   المراجعة النهائية لقت إن المسارات الحية كلها مبنية على AVL: توكن في
   الرابط وبودي POST. لو الموظف على النظام التاني وضغط «جرّب دلوقتي»،
   كان هيتبعت شكل غلط لسيرفر بيفهم شكل تاني — ويفشل بطريقة غامضة. */
global.setInterval=()=>0;global.clearInterval=()=>{};
const fs = require('fs');
const R = {};
function el(id){return{id,hidden:false,innerHTML:'',value:'',textContent:'',className:'',dataset:{},style:{},files:[],disabled:false,
 options:[],classList:{toggle(){},add(){},remove(){}},querySelectorAll(){return[]},addEventListener(){},focus(){},select(){},click(){},
 setAttribute(){},getAttribute(){return null},dispatchEvent(){},appendChild(){},remove(){},scrollIntoView(){},title:''}}
global.document={documentElement:el('html'),body:el('body'),addEventListener(){},querySelectorAll(){return[]},
 querySelector(){return null},createElement(){return el()},getElementById:i=>R[i]||(R[i]=el(i))};
global.history={pushState(){},replaceState(){}};global.location={hash:'',pathname:'/',replace(){}};
global.navigator={userAgent:'node',language:'ar',clipboard:{writeText(){return Promise.resolve()}}};
global.window={scrollTo(){},addEventListener(){},matchMedia:()=>({matches:false}),navigator:{}};
global.Blob=function(){};global.URL={createObjectURL(){return''}};global.FileReader=function(){};
global.btoa=x=>Buffer.from(x,'binary').toString('base64');global.atob=x=>Buffer.from(x,'base64').toString('binary');
const D={};global.localStorage={getItem:k=>(k in D?D[k]:null),setItem:(k,v)=>{D[k]=String(v);},removeItem(){}};
global.sessionStorage={getItem:()=>null,setItem(){},removeItem(){}};global.confirm=()=>false;

/* بنسجّل كل نداء شبكة عشان نثبت إن ولا واحد اتبعت */
const SENT = [];
global.fetch = (url, opt) => {
  /* fetch('docs.pdf') بيحصل عند التحميل عشان يتأكد إن الدليل جنب الصفحة —
     مش نداء API، فبنستبعده من العدّ. */
  if(!/docs\.pdf|version\.json|sw\.js/.test(String(url)))
    SENT.push({url:String(url), method:(opt&&opt.method)||'GET'});
  return Promise.resolve({
    ok:true, status:200,
    text:()=>Promise.resolve(JSON.stringify({message:'success', data:{username:'u', api_key:'KEY-FROM-SERVER'}}))
  });
};

let js = fs.readFileSync('app_template.html','utf8').split('<script>')[1].split('</script>')[0]
  .replace('/*__KB__*/', fs.readFileSync('kb_slim.json','utf8'))
  .replace('/*__KBIN__*/', fs.readFileSync('kb_in.json','utf8'))
  .replace('/*__DOCS__*/', fs.readFileSync('docs.json','utf8'));
const m={};
new Function('module', js + "\nmodule.exports={EPS,sysOf,tryItRun,connect,SESSION,fullUrl,curSys,epKind};")(m);
const A = m.exports;
const $ = i => R[i] || (R[i] = el(i));
const fail = msg => { console.error('فشل: ' + msg); process.exit(1); };

(async () => {
  /* ============ ١) التنفيذ الحي مقفول على النظام التاني ============ */
  $('baseUrl').value = 'http://afaqy.in/api';
  const inRead = A.EPS.find(e => A.sysOf(e)==='in' && A.epKind(e)==='read');
  if(!inRead) fail('مفيش ريكوست قراءة في النظام التاني للاختبار');
  const out = el('out');
  SENT.length = 0;
  await A.tryItRun(inRead, out);
  if(SENT.length) fail('اتبعت نداء شبكة للنظام التاني رغم إن التنفيذ مقفول: ' + SENT[0].url);
  if(out.innerHTML.indexOf('مش متاح') < 0) fail('ما اتقالش للموظف إن التنفيذ مش متاح');
  console.log('بوابة التنفيذ      : صفر نداءات، والسبب متقال للموظف ✓');

  /* الكتابة والحساس في النظام التاني مقفولين برضه */
  for(const kind of ['write','danger']){
    const e = A.EPS.find(x => A.sysOf(x)==='in' && A.epKind(x)===kind);
    if(!e) continue;
    SENT.length = 0;
    await A.tryItRun(e, out, true);          // armed = كأن الموظف أكّد
    if(SENT.length) fail(`ريكوست ${kind} في النظام التاني اتنفّذ فعلًا!`);
  }
  console.log('الكتابة والحساس    : مقفولين حتى مع التأكيد ✓');

  /* ============ ٢) AVL لسه بينفّذ عادي — البوابة ما كسرتوش ============ */
  $('baseUrl').value = 'https://api.afaqy.sa';
  A.SESSION.user='u'; A.SESSION.pass='p'; A.SESSION.token='TOK'; A.SESSION.at=Date.now();
  const avlRead = A.EPS.find(e => A.sysOf(e)==='avl' && A.epKind(e)==='read' && e.t);
  SENT.length = 0;
  await A.tryItRun(avlRead, out);
  if(!SENT.length) fail('AVL بقى مقفول كمان — البوابة واسعة زيادة');
  if(SENT[0].url.indexOf('afaqy.in') >= 0) fail('نداء AVL راح لدومين النظام التاني');
  console.log('تنفيذ AVL          : لسه شغّال وبيروح لدومينه ✓');

  /* ============ ٣) دخول النظام التاني بيجيب apiKey مش توكن ============ */
  A.SESSION.token=''; A.SESSION.apiKey=''; A.SESSION.user='';
  $('baseUrl').value = 'http://afaqy.in/api';
  $('sesU').value='user@afaqy.com'; $('sesP').value='pass';
  SENT.length = 0;
  const ok = await A.connect(false);
  if(!ok) fail('دخول النظام التاني فشل رغم إن السيرفر رجّع api_key');
  if(A.SESSION.apiKey !== 'KEY-FROM-SERVER') fail('الـ apiKey ما اتخزّنش: ' + A.SESSION.apiKey);
  if(A.SESSION.token) fail('توكن AVL اتخزّن في جلسة النظام التاني');
  if(!SENT.length || SENT[0].method !== 'GET') fail('دخول النظام التاني اتبعت بغير GET');
  if(SENT[0].url.indexOf('?r=users/login') < 0) fail('مسار دخول النظام التاني غلط: ' + SENT[0].url);
  console.log('دخول النظام التاني : GET، وapiKey اتخزّن، وصفر توكن ✓');

  /* ============ ٤) الرابط بيتعبّى بالـ apiKey الحقيقي بعد الاتصال ============ */
  /* الدخول نفسه مالوش apiKey (بتسجّل دخول عشان تجيبه) — فبنختار ريكوست
     تاني فيه المفتاح فعلًا. */
  const keyed = A.EPS.find(e => A.sysOf(e)==='in' && e.b.indexOf('apiKey') >= 0);
  if(!keyed) fail('مفيش ريكوست فيه apiKey للاختبار');
  const u = A.fullUrl(keyed, true);
  if(u.indexOf(encodeURIComponent('KEY-FROM-SERVER')) < 0 && u.indexOf('KEY-FROM-SERVER') < 0)
    fail('الرابط ما اتعبّاش بالـ apiKey بعد الاتصال');
  const sample = A.fullUrl(keyed, false);
  if(sample.indexOf('KEY-FROM-SERVER') >= 0) fail('مفتاح العميل الحقيقي اتسرّب في المثال المعروض!');
  console.log('تعبئة المفتاح      : الحقيقي في التنفيذ، والعلامة في المثال ✓');

  /* ============ ٥) القطع بيمسح المفتاح ============ */
  const dis = js.indexOf("SESSION.apiKey=''");
  if(dis < 0) fail('القطع مش بيمسح الـ apiKey — هيفضل في الذاكرة بعد تبديل العميل');
  console.log('القطع              : بيمسح الـ apiKey ✓');
})().catch(e => { console.error('فشل: ' + (e && e.message || e)); process.exit(1); });
