#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v6.40 — الكولكشن بقى نسختين.

الكولكشن كان دايمًا بيطلع نظيف: كل قيمة بتتحوّل {{placeholder}} والمتغيّرات
بتنزل فاضية. ده صح للعميل — بس لما الموظف عايز يجرّب هو بنفسه، بيبقى
لازم يقعد يملا التوكن ورقم العربية بإيده وهو متصل بالحساب أصلاً.

بقى فيه اختيار: نسخة للعميل زي ما هي، ونسخة ليه هو معبّاة من الجلسة
المتصلة. النسخة المعبّاة اسمها ووصفها بيقولوا إنها مش للإرسال.
"""
import sys, io

PATH = sys.argv[1] if len(sys.argv) > 1 else 'app_template.html'
src = io.open(PATH, encoding='utf-8').read()
orig = len(src)

def rep(old, new, n=1, tag=''):
    global src
    c = src.count(old)
    if c != n: raise SystemExit('MISMATCH [%s]: expected %d found %d\n---\n%s' % (tag, n, c, old[:220]))
    src = src.replace(old, new, n); print('  ok  %s' % tag)

# ── ١) pmWrap بياخد وضع: نظيف أو معبّى ───────────────────────
rep("""function pmWrap(name, desc, items, extraVars){
  const v = [
    {key:'base_url',    value:baseUrl(),      type:'string'},
    {key:'username',    value:'',             type:'string'},
    {key:'password',    value:'',             type:'string'},
    {key:'token',       value:'',             type:'string'},
    {key:'user_id',     value:'',             type:'string'},
    {key:'imei',        value:'',             type:'string'},
    {key:'unit_id',     value:'',             type:'string'},
    {key:'date_from',   value:today(),        type:'string'},
    {key:'date_to',     value:today(),        type:'string'}
  ].concat(extraVars || []);""",
"""/* mine=true يعني الكولكشن ليّا أنا: بيتعبّى من الجلسة المتصلة عشان
   يشتغل من أول Send. mine=false يعني للعميل: كل حاجة فاضية.
   الفرق ده لازم يفضل صريح — ملف فيه توكن ما يتبعتش لحد. */
function pmWrap(name, desc, items, extraVars, mine){
  const F = mine ? (x=>x||'') : (()=>'');
  const v = [
    {key:'base_url',    value:baseUrl(),      type:'string'},
    {key:'username',    value:F(SESSION.user), type:'string'},
    {key:'password',    value:'',             type:'string'},   /* الباسورد ما بيتكتبش في ملف أبدًا */
    {key:'token',       value:F(SESSION.token), type:'string'},
    {key:'user_id',     value:F(SESSION.userId), type:'string'},
    {key:'imei',        value:'',             type:'string'},
    {key:'unit_id',     value:'',             type:'string'},
    {key:'date_from',   value:today(),        type:'string'},
    {key:'date_to',     value:today(),        type:'string'}
  ].concat(extraVars || []);""",
    1, 'pmWrap بوضعين')

# ── ٢) pmFromRecipe بيمرّر الوضع ────────────────────────────
rep("function pmFromRecipe(r){", "function pmFromRecipe(r, mine){", 1, 'توقيع pmFromRecipe')

# ── ٣) الزرار بقى اتنين ─────────────────────────────────────
rep("""      <button class="btn ghost" id="rcPm">${t('نزّل كولكشن Postman','Download Postman collection')}</button>""",
"""      <button class="btn ghost" id="rcPm">${t('كولكشن للعميل','Collection for the customer')}</button>
      <button class="btn ghost" id="rcPmMine" ${SESSION.token?'':'disabled'}>${t('كولكشن ليّا — بالتوكين','Collection for me — with the token')}</button>""",
    1, 'زرارين')

rep("""  $('rcPm').onclick = ()=>pmSave(pmFromRecipe(r),""",
"""  const _pmMine = $('rcPmMine');
  if(_pmMine) _pmMine.onclick = ()=>{
    if(!SESSION.token){ toast(t('اتصل بحساب الأول عشان يبقى في توكن يتحط.',
                                'Connect to an account first so there is a token to fill in.')); return; }
    if(!confirm(t('الملف ده هيخرج وفيه توكن الحساب المتصل. لك إنت عشان تجرّب — ما يتبعتش لعميل ولا يترفع في مكان مشترك. تكمّل؟',
                  'This file will carry the connected account token. It is for you to test with — do not send it to a customer or upload it anywhere shared. Continue?'))) return;
    pmSave(pmFromRecipe(r, true), (r.id || 'recipe') + '-mine');
  };
  $('rcPm').onclick = ()=>pmSave(pmFromRecipe(r),""",
    1, 'توصيل الزرار الجديد')


# ── ٤) نهاية pmFromRecipe: الاسم والوصف يقولوا نوع النسخة ────
rep("""  return pmWrap('AFAQY \u2014 ' + ((r.title && r.title.en) || dual(r.title)), desc, items,
    [{key:'report_code', value:'summary', type:'string'},""",
"""  return pmWrap('AFAQY \u2014 ' + ((r.title && r.title.en) || dual(r.title))
                  + (mine ? '  [MY SESSION \u2014 DO NOT SHARE]' : ''),
    (mine ? 'THIS FILE CARRIES A LIVE ACCESS TOKEN FOR THE CONNECTED ACCOUNT.\\n'
          + 'It is filled in so you can run it yourself immediately. Do not send it to a\\n'
          + 'customer and do not upload it anywhere shared. Use the customer version for that.\\n\\n'
          : '') + desc, items,
    [{key:'report_code', value:'summary', type:'string'},""",
    1, 'اسم ووصف النسخة المعبّاة')

io.open(PATH, 'w', encoding='utf-8').write(src)
print('\ndone (%d -> %d, +%d)' % (orig, len(src), len(src) - orig))
