/* v5.9 — الوضع الليلي وزراير الشريط.
   الاختبار ده اتكتب بعد ما زرارين اتنشروا ومحدش شافهم: نصّهم كان بلون
   الحبر على خلفية الحبر. القاعدة دلوقتي محروسة — وكذلك تحوّل الثيم كله. */
global.setInterval=()=>0;global.clearInterval=()=>{};
const fs = require('fs');
const ATTRS = {};
function el(id){return{id,hidden:false,innerHTML:'',value:'',textContent:'',className:'',dataset:{},style:{},files:[],disabled:false,
 options:[],classList:{toggle(){},add(){},remove(){}},querySelectorAll(){return[]},addEventListener(){},focus(){},select(){},click(){},
 setAttribute(k,v){ATTRS[(this.id||'?')+':'+k]=v;},getAttribute(k){return ATTRS[(this.id||'?')+':'+k]||null;},
 dispatchEvent(){},appendChild(){},remove(){},scrollIntoView(){},title:''}}
const HTML = el('html');
const R={};global.document={documentElement:HTML,body:el('body'),addEventListener(){},querySelectorAll(){return[]},
 querySelector(sel){ return sel.indexOf('theme-color')>=0 ? el('meta') : null; },
 createElement(){return el()},getElementById(i){return R[i]||(R[i]=el(i))}};
global.history={pushState(){},replaceState(){}};global.location={hash:'',pathname:'/',replace(){}};
global.navigator={userAgent:'node',clipboard:{writeText(){return Promise.resolve()}}};
let SYS_DARK = false;
global.window={scrollTo(){},addEventListener(){},matchMedia:q=>({matches:/dark/.test(q)&&SYS_DARK}),navigator:{}};
global.fetch=()=>Promise.reject(0);global.Blob=function(){};global.URL={createObjectURL(){return''}};global.FileReader=function(){};
global.btoa=x=>Buffer.from(x,'binary').toString('base64');global.atob=x=>Buffer.from(x,'base64').toString('binary');
const DISK={};
global.localStorage={getItem:k=>(k in DISK?DISK[k]:null),setItem:(k,v)=>{DISK[k]=String(v);},removeItem:k=>{delete DISK[k];}};
global.sessionStorage={getItem:()=>null,setItem(){},removeItem(){}};
global.confirm=()=>false;

const tpl = fs.readFileSync('app_template.html','utf8');
let js = tpl.split('<script>')[1].split('</script>')[0]
  .replace('/*__KB__*/', fs.readFileSync('kb_slim.json','utf8')).replace('/*__KBIN__*/', fs.readFileSync('kb_in.json','utf8'))
  .replace('/*__DOCS__*/', fs.readFileSync('docs.json','utf8'));
const m={};
new Function('module', js + "\nmodule.exports={themeApply,themeToggle,themeStored,THEME_KEY};")(m);
const A = m.exports;
const fail = msg => { console.error('فشل: ' + msg); process.exit(1); };
const themeNow = () => global.document.documentElement.getAttribute('data-theme');

/* ١) الأوضاع التلاتة */
if(A.themeApply('dark') !== true || themeNow() !== 'dark') fail('الليلي ما اتطبقش');
if(A.themeApply('light') !== false || themeNow() !== 'light') fail('النهاري ما اتطبقش');
SYS_DARK = true;  if(A.themeApply('auto') !== true)  fail('التلقائي ما تبعش الجهاز الغامق');
SYS_DARK = false; if(A.themeApply('auto') !== false) fail('التلقائي ما تبعش الجهاز الفاتح');
console.log('الأوضاع            : ليلي ونهاري وتلقائي حسب الجهاز ✓');

/* ٢) التبديل بيتحفظ ويرجع بعد إعادة الفتح */
A.themeApply('light'); A.themeToggle();
if(themeNow() !== 'dark') fail('التبديل ما غيّرش');
if(DISK[A.THEME_KEY] !== 'dark') fail('الاختيار ما اتحفظش');
if(A.themeStored() !== 'dark') fail('الاختيار ما رجعش بعد الفتح');
A.themeToggle();
if(themeNow() !== 'light' || DISK[A.THEME_KEY] !== 'light') fail('التبديل الراجع غلط');
console.log('التبديل والحفظ     : بيتحفظ وبيرجع ✓');

/* ٣) الزرار بيقول للناس هو هيعمل إيه */
A.themeApply('dark');
if(!R.themeBtn || !R.themeBtn.textContent) fail('زرار الثيم من غير علامة');
const darkLabel = R.themeBtn.textContent;
A.themeApply('light');
if(R.themeBtn.textContent === darkLabel) fail('العلامة ما بتتغيرش بين الوضعين');
console.log('زرار الثيم         : علامته بتتغير مع الوضع ✓');

/* ٤) الحارس: أي زرار ghost جوه الشريط لازم يبقى نصه فاتح */
const css = tpl.slice(tpl.indexOf('<style>'), tpl.indexOf('</style>'));
if(css.indexOf('.conn .btn.ghost{color:#C7D6DF') < 0) fail('قاعدة زراير الشريط اتشالت — الزراير هتختفي تاني');
const bar = tpl.slice(tpl.indexOf('<div class="conn">'), tpl.indexOf('</header>'));
const ghosts = (bar.match(/class="btn ghost"/g) || []).length;
if(ghosts < 4) fail('عدد زراير الشريط أقل من المتوقع: ' + ghosts);
if(/color:var\(--ink\)[^}]*}\s*$/.test(bar)) fail('زرار في الشريط بلون الحبر');
console.log('زراير الشريط       : ' + ghosts + ' زرار، كلهم مغطيين بالقاعدة ✓');

/* ٥) خلفية الحبر منفصلة عن لون النص — أساس الوضع الليلي */
if(css.indexOf('--ink-bg:') < 0) fail('متغير خلفية الحبر ناقص');
if(css.indexOf('.top{background:var(--ink)}') >= 0 || css.indexOf('.top{background:var(--ink);') >= 0)
  fail('الهيدر لسه بياخد لون النص كخلفية');
if(css.indexOf('html[data-theme="dark"]') < 0) fail('لوحة الوضع الليلي ناقصة');
for(const v of ['--panel:', '--surface:', '--line:', '--code-bg:']){
  const dark = css.slice(css.indexOf('html[data-theme="dark"]'));
  if(dark.indexOf(v) < 0) fail('متغير ناقص من الوضع الليلي: ' + v);
}
console.log('المتغيرات          : الخلفية منفصلة واللوحة كاملة ✓');

/* ٦) النوافذ والكروت بتتبع المتغيرات — يعني بتتحوّل لوحدها */
for(const rule of ['.modal{background:var(--panel)', '.card{background:var(--panel)', '.panel{background:var(--panel)'])
  if(css.indexOf(rule) < 0) fail('عنصر مش بياخد لونه من المتغيرات: ' + rule);
console.log('النوافذ والكروت    : بتاخد ألوانها من المتغيرات ✓');
