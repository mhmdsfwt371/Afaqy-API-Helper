#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v5.8 — الحسابات المحفوظة. أنكورات حرفية، وأي MISS بيوقّف الترقيعة."""
import sys
P='app_template.html'; s=open(P,encoding='utf-8').read()
miss=[]; done=[]
def rep(old,new,label,cnt=1):
    global s
    c=s.count(old)
    if c!=cnt: miss.append(f'{label} (لقيت {c})'); return
    s=s.replace(old,new); done.append(label)

# ===== ١) لستة الحسابات في الشريط =====
old='      <input id="sesU" data-arph="اسم المستخدم"'
new='''      <select id="acctSel" style="max-width:170px" title="الحسابات المحفوظة على الجهاز ده"><option value="">— حسابات محفوظة —</option></select>
      <input id="sesU" data-arph="اسم المستخدم"'''
rep(old,new,'١) لستة الحسابات')

# ===== ٢) زرار الحفظ والمسح بعد زرار الاتصال =====
old='<span id="sesState" class="pill">غير متصل</span>'
new='''<button class="btn ghost" id="acctSave" style="padding:6px 10px; font-size:13px" data-ar="احفظ الحساب" data-en="Save account">احفظ الحساب</button>
      <button class="btn ghost" id="acctDel" hidden style="padding:6px 10px; font-size:13px" data-ar="امسح" data-en="Delete">امسح</button>
      ''' + old
rep(old,new,'٢) زراير الحفظ والمسح')

# ===== ٣) المنطق قبل ربط زرار الاتصال =====
old="$('sesGo').onclick  = ()=>connect(false);"
new='''/* ============ v5.8 — الحسابات المحفوظة ============
   محفوظة على الجهاز ده بس، في المتصفح — مش على سيرفر ولا بتتبعت لحد.
   الاسم والبيئة بيتحفظوا دايمًا. كلمة السر اختيارية وبتتخزّن بس لو اخترت،
   وبتتكتب مموّهة عشان ما تظهرش لأول عين تفتح إعدادات المتصفح —
   والتمويه ده إخفاء مش تشفير: أي حد قدامه الجهاز مفتوح يقدر يوصلها.
   عشان كده: ما تحفظش باسورد على جهاز مشترك، والمسح بضغطة. */
const ACCT_KEY = 'afaqy.accounts.v1';
function acctMask(txt, key){
  let out = '';
  for(let i=0;i<txt.length;i++) out += String.fromCharCode(txt.charCodeAt(i) ^ (key.charCodeAt(i % key.length) + 41) % 256);
  try{ return btoa(unescape(encodeURIComponent(out))); }catch(_){ return ''; }
}
function acctUnmask(b64, key){
  let raw;
  try{ raw = decodeURIComponent(escape(atob(b64))); }catch(_){ return ''; }
  let out = '';
  for(let i=0;i<raw.length;i++) out += String.fromCharCode(raw.charCodeAt(i) ^ (key.charCodeAt(i % key.length) + 41) % 256);
  return out;
}
function acctLoad(){
  try{ const a = JSON.parse(localStorage.getItem(ACCT_KEY) || '[]'); return Array.isArray(a) ? a : []; }
  catch(_){ return []; }
}
function acctStore(list){
  try{ localStorage.setItem(ACCT_KEY, JSON.stringify(list.slice(0, 40))); return true; }
  catch(_){ return false; }
}
function acctPaint(){
  const sel = $('acctSel'); if(!sel) return;
  const list = acctLoad(), keep = sel.value;
  sel.innerHTML = `<option value="">${t('— حسابات محفوظة —','— saved accounts —')}</option>`
    + list.map((a,i)=>`<option value="${i}">${esc(a.u)}${a.pw ? '' : ' ' + t('(من غير باسورد)','(no password)')}</option>`).join('');
  sel.value = keep && Number(keep) < list.length ? keep : '';
  $('acctDel').hidden = sel.value === '';
}
function acctPick(){
  const sel = $('acctSel'), list = acctLoad();
  $('acctDel').hidden = sel.value === '';
  if(sel.value === '') return;
  const a = list[Number(sel.value)]; if(!a) return;
  $('sesU').value = a.u || '';
  $('sesP').value = a.pw ? acctUnmask(a.pw, a.u) : '';
  if(a.base){
    const opts = [...$('baseUrl').options].map(o=>o.value);
    if(opts.indexOf(a.base) >= 0){ $('baseUrl').value = a.base; $('baseCustom').hidden = true; }
    else { $('baseUrl').value = '__custom'; $('baseCustom').hidden = false; $('baseCustom').value = a.base; }
  }
  sesPaint(a.pw ? t('اتعبّى — دوس اتصال','Filled in — press connect')
                : t('اتعبّى الاسم — اكتب كلمة السر','Username filled — type the password'));
  (a.pw ? $('sesGo') : $('sesP')).focus();
}
function acctSave(){
  const u = $('sesU').value.trim(), pw = $('sesP').value;
  if(!u){ sesPaint(t('اكتب اسم المستخدم الأول','Enter the username first'), true); return; }
  const withPw = pw ? confirm(t(
    'أحفظ كلمة السر كمان؟\\n\\nهتتخزّن على الجهاز ده مموّهة — التمويه إخفاء مش تشفير، وأي حد قدامه الجهاز مفتوح يقدر يوصلها.\\n\\nموافق = يتحفظ الاسم وكلمة السر. إلغاء = الاسم بس.',
    'Save the password too?\\n\\nIt is stored on this device obfuscated — that is hiding, not encryption, and anyone at this unlocked device can recover it.\\n\\nOK = save both. Cancel = username only.')) : false;
  const list = acctLoad();
  const rec = {u, base: baseUrl(), pw: withPw ? acctMask(pw, u) : ''};
  const at = list.findIndex(a => a.u === u && a.base === rec.base);
  if(at >= 0) list[at] = rec; else list.unshift(rec);
  if(!acctStore(list)){ sesPaint(t('المتصفح رافض يحفظ','The browser refused to save'), true); return; }
  acctPaint();
  const i2 = acctLoad().findIndex(a => a.u === u && a.base === rec.base);
  $('acctSel').value = String(i2); $('acctDel').hidden = false;
  sesPaint(withPw ? t('اتحفظ بكلمة السر','Saved with the password')
                  : t('اتحفظ — من غير كلمة السر','Saved — without the password'));
}
function acctDelete(){
  const sel = $('acctSel'); if(sel.value === '') return;
  const list = acctLoad(), a = list[Number(sel.value)]; if(!a) return;
  if(!confirm(t(`أمسح «${a.u}» من الجهاز ده؟`, `Delete "${a.u}" from this device?`))) return;
  list.splice(Number(sel.value), 1); acctStore(list);
  sel.value = ''; acctPaint();
  sesPaint(t('اتمسح','Deleted'));
}
$('acctSel').onchange = acctPick;
$('acctSave').onclick = acctSave;
$('acctDel').onclick  = acctDelete;
acctPaint();
''' + old
rep(old,new,'٣) منطق الحسابات')

for d in done: print('تمام:',d)
if miss:
    print('!! MISS:'); [print('  ',x) for x in miss]; sys.exit(1)
open(P,'w',encoding='utf-8').write(s)
print(f'اتكتب — {len(done)} تعديل')
