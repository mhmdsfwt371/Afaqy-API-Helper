#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v6.50 — الأداة على التوثيق الرسمي «1- AVL Integration documentation».

المصدر بقى التوثيق الرسمي (documenter.getpostman.com/view/50854881/2sBYB2qnL3):
193 ريكوست في 18 موديول، بدل كولكشن AVL PROOOO (529). الـ KB بيتبني من
الكولكشن بـ build_kb_from_collection.py (كان ناقص من الريبو).

- 12 ريكوست مش في التوثيق فضلوا لأن الأداة نفسها بتستخدمهم أو بتشرحهم
  (/units/locations، قوالب التقارير، لوحة وصل، OTP…) — بعلامة «مش في التوثيق»
  في النتايج، وتحذير في صفحة الريكوست بالسبب. الباقي (~313) اتشال.
- وصف التوثيق الرسمي لكل ريكوست (الغرض، الاستخدام، النجاح، الخطأ) بقى يظهر
  في صفحة الريكوست.
- مفردات البحث: الموديولات اللي اتشالت اتشالت من المفردات (وإلا البحث كان
  بيوجّه لحاجة مش موجودة)، واللي اتغيّر اسمها اتنقلت.
- الأرقام اللي الأداة بتقولها عن الكولكشن اتحسبت تاني من التوثيق.
"""
import sys, io, os, re

HERE = os.path.dirname(os.path.abspath(__file__))
PATH = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, 'app_template.html')
src = io.open(PATH, encoding='utf-8').read(); orig = len(src)
def rep(old, new, n=1, tag=''):
    global src
    c = src.count(old)
    if c != n: raise SystemExit('MISMATCH [%s]: expected %d found %d\n---\n%s' % (tag, n, c, old[:200]))
    src = src.replace(old, new, n); print('  ok  %s' % tag)

# ── ١) مفردات البحث ─────────────────────────────────────────────
GONE = ['Driver Groups','Roles and Permissions','User Report Schedules','EventStatus','EventComment','Unit Shipments',
        'Unit Shared Group','CustomerType','Traffic','WASL Driver','Waste','Warehouses groups','Markers','Charts','Chat',
        'Audit Log','CustomFields','Status','Home','Madinati Integration','Report Categories','Others']
RENAME = {'Tailers':'Trailers', 'Unit DriverBehavior':'Unit Driver Behavior'}
i = src.find('const VOCAB = {'); j = src.find('\n};', i)
blk = src[i:j]; lines = blk.split('\n'); kept = []; dropped = 0
for l in lines:
    m = re.match(r"^\s*'([^']+)'\s*:", l)
    if m and m.group(1) in GONE: dropped += 1; continue
    if m and m.group(1) in RENAME: l = l.replace("'%s':" % m.group(1), "'%s':" % RENAME[m.group(1)], 1)
    kept.append(l)
if dropped != len(GONE): raise SystemExit('VOCAB: expected to drop %d, dropped %d' % (len(GONE), dropped))
src = src[:i] + '\n'.join(kept) + src[j:]; print('  ok  مفردات البحث: %d موديول اتشال، 2 اتغيّر اسمهم' % dropped)
rep("""/* ---------------- Arabic → module vocabulary ----------------
   كل مدخل هنا مربوط بموديول حقيقي موجود في الكولكشن. مفيش اختراع. */""",
"""/* ---------------- Arabic → module vocabulary ----------------
   كل مدخل هنا مربوط بموديول حقيقي موجود في الكولكشن. مفيش اختراع.
   v6.50: الكولكشن = التوثيق الرسمي. موديول اتشال من التوثيق = اتشال من هنا (اختبار بيقفل ده). */""", tag='تعليق المفردات')

# ── ٢) علامة «مش في التوثيق» + وصف التوثيق ───────────────────────
rep("""      <span class="rp">${esc(r.e.p)}</span> ${sysChip(r.e)} ${kindChip(r.e)}""",
    """      <span class="rp">${esc(r.e.p)}</span> ${sysChip(r.e)} ${kindChip(r.e)} ${undocChip(r.e)}""", tag='علامة في النتايج')
rep("""function renderResults(list){""",
"""/* v6.50: ريكوست مش في التوثيق الرسمي — الأداة محتفظة بيه لسبب مكتوب، بس ما يتبعتش للعميل كحل من غير تأكيد */
function undocChip(e){
  return e && e.x ? `<span class="pill bad" style="font-size:11px; padding:1px 7px" title="${esc(t('مش في التوثيق الرسمي','Not in the official documentation'))}">${t('مش في التوثيق','undocumented')}</span>` : '';
}
/* وصف التوثيق (Markdown بسيط بالإنجليزي) → HTML آمن: **عريض** و`كود` وسطور */
function docHtml(d){
  let h = esc(String(d || '').trim()).replace(/\\r/g, '');
  h = h.replace(/\\*\\*([^*]+)\\*\\*/g, '<b>$1</b>').replace(/`([^`]+)`/g, '<code>$1</code>')
       .replace(/^#{1,4}\\s*(.+)$/gm, '<b>$1</b>').replace(/^\\s*[-*]\\s+/gm, '• ').replace(/\\n{2,}/g, '<br><br>').replace(/\\n/g, '<br>');
  return h;
}
function renderResults(list){""", tag='دوال العلامة والوصف')
rep("""      ${why && why.length ? `<div class="why"><b>${t('ظهر لأن سؤالك فيه:','Matched because your question contains:')}</b>${why.map(w=>`<span>${esc(w)}</span>`).join('')}</div>` : ''}""",
"""      ${why && why.length ? `<div class="why"><b>${t('ظهر لأن سؤالك فيه:','Matched because your question contains:')}</b>${why.map(w=>`<span>${esc(w)}</span>`).join('')}</div>` : ''}
      ${e.x ? `<div class="note warn" style="margin-top:10px"><b>${t('الريكوست ده مش في التوثيق الرسمي','This request is not in the official documentation')}</b> (1- AVL Integration documentation).
        ${t('الأداة محتفظة بيه عشان:','The tool keeps it because:')} ${esc(e.xr || '')}.<br>
        ${t('السيرفر ممكن يكون لسه بيرد عليه — بس ما تبعتهوش للعميل كحل قبل ما تتأكد إنه لسه مدعوم.','The server may still answer it — but do not send it to a customer as the solution before confirming it is still supported.')}</div>` : ''}
      ${e.d && !e.x ? `<details style="margin-top:10px" open><summary style="cursor:pointer; font-size:13px; color:var(--muted)">${t('من التوثيق الرسمي','From the official documentation')}</summary>
        <div dir="ltr" style="text-align:left; font-size:13px; line-height:1.6; margin-top:6px; padding:10px 12px; background:var(--panel-2); border:1px solid var(--line); border-radius:var(--r)">${docHtml(e.d)}</div></details>` : ''}""",
    tag='تحذير ووصف في صفحة الريكوست')

# ── ٣) الأرقام والمصدر ──────────────────────────────────────────
rep("""   AVL PROOOO: POST، توكن في الرابط، العربية بالـ UID.""",
    """   AVL — التوثيق الرسمي «1- AVL Integration documentation»: POST، توكن في الرابط أو هيدر Bearer، العربية بالـ UID.""", tag='اسم المصدر')
rep("""<p>ده الحال في <b>504</b> ريكوست من أصل <b>534</b> في الكولكشن.</p>""",
    """<p>ده الحال في <b>164</b> ريكوست من <b>193</b> في التوثيق الرسمي — الباقي بياخد التوكن هيدر Bearer من إعداد الكولكشن.</p>""", tag='إحصائية التوكن بالعربي')
rep("""<p>This holds for <b>504</b> of the <b>534</b> requests in the collection.""",
    """<p>This holds for <b>164</b> of the <b>193</b> requests in the official documentation — the rest take the token as a Bearer header from the collection settings.""", tag='إحصائية التوكن بالإنجليزي')
rep("""— <b>460</b> من <b>475</b> ريكوست ليهم بودي:""", """— <b>168</b> من <b>171</b> ريكوست ليهم بودي في التوثيق:""", tag='إحصائية data بالعربي')
rep("""— <b>460</b> of the <b>475</b> requests that carry one:""", """— <b>168</b> of the <b>171</b> documented requests that carry one:""", tag='إحصائية data بالإنجليزي')
rep("""<p><b>514</b> من <b>534</b> ريكوست بـ <code>POST</code>""", """<p><b>187</b> من <b>193</b> ريكوست في التوثيق بـ <code>POST</code>""", tag='إحصائية POST بالعربي')
rep("""<p><b>514</b> of <b>534</b> requests use <code>POST</code>""", """<p><b>187</b> of the <b>193</b> documented requests use <code>POST</code>""", tag='إحصائية POST بالإنجليزي')
rep("""<p>الكولكشن مفيهوش نماذج ردود محفوظة (نموذج واحد بس من 534)، فمفيش عندنا قائمة أخطاء موثّقة.</p>""",
    """<p>التوثيق الرسمي فيه 30 رد محفوظ على 15 ريكوست بس من 193، فلسه مفيش عندنا قائمة أخطاء موثّقة كاملة.</p>""", tag='الردود المحفوظة بالعربي')
rep("""<p>The collection carries almost no saved responses (one out of 534), so there is no documented """,
    """<p>The official documentation carries 30 saved responses on only 15 of its 193 requests, so there is still no complete documented """, tag='الردود المحفوظة بالإنجليزي')
rep("""(504 ريكوست من 534)""", """(164 ريكوست من 193 في التوثيق)""", tag='ملاحظة المصادقة بالعربي')
rep("""(504 of 534 requests)""", """(164 of the 193 documented requests)""", tag='ملاحظة المصادقة بالإنجليزي')

io.open(PATH, 'w', encoding='utf-8').write(src)
print('القالب: %d → %d بايت' % (orig, len(src)))

# ── ٤) علامة البناء ─────────────────────────────────────────────
bp = os.path.join(HERE, 'build.py'); bb = io.open(bp, encoding='utf-8').read()
old = "    ('function ocrTicket',           'لقطة الإيميل بتتحوّل لتذكرة'),\n]"
new = "    ('function ocrTicket',           'لقطة الإيميل بتتحوّل لتذكرة'),\n    ('function undocChip',           'الريكوستات اللي مش في التوثيق الرسمي متعلّمة'),\n]"
if 'function undocChip' in bb: print('  --  علامة البناء موجودة')
elif bb.count(old) != 1: raise SystemExit('MISMATCH build.py markers')
else: io.open(bp, 'w', encoding='utf-8').write(bb.replace(old, new)); print('  ok  علامة البناء')
