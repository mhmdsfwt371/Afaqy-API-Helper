/* اختبارات v6.35 — الأداة بتطلّع كولكشن Postman بنفسها.
   الفحص هنا هو نفس الفحص اللي اتعمل يدوي على الكولكشن اللي اتبعت:
   الأشكال مطابقة للـ KB، السلسلة مربوطة، حلقة الانتظار بتقف عند ١٠٠،
   ومفيش أي بيانات من الحساب المتصل بتتسرّب في الملف. */
const fs = require('fs');
const { JSDOM } = require('jsdom');

let FAILED = 0;
const pass = m => console.log('  \u2713 ' + m);
const fail = m => { console.log('  \u2717 ' + m); FAILED++; };
const ok = (m, c, x) => c ? pass(m) : fail(m + (x ? '  \u2014 ' + x : ''));

const FILE = process.argv[2] || 'app_template.html';
function boot(){
  const html = fs.readFileSync(FILE, 'utf8')
    .replace('/*__KB__*/',   () => fs.readFileSync('kb_slim.json', 'utf8'))
    .replace('/*__DOCS__*/', () => fs.readFileSync('docs.json', 'utf8'))
    .replace('/*__KBIN__*/', () => fs.readFileSync('kb_in.json', 'utf8'));
  const dom = new JSDOM(html, { runScripts:'dangerously', pretendToBeVisual:true, url:'https://localhost/' });
  const w = dom.window;
  w.alert = () => {}; w.confirm = () => true; w.scrollTo = () => {};
  return w;
}

/* الحساب المتصل: قيم حقيقية عشان نتأكد إنها ما بتتسربش في الملف */
const SECRET = { token:'SECRET_TOKEN_XYZ', user:'Opp', userId:'SECRET_USER_9',
                 unit:'SECRET_UNIT_7' };
function connect(w){
  w.eval(`SESSION.token='${SECRET.token}'; SESSION.user='${SECRET.user}';
          SESSION.userId='${SECRET.userId}'; SESSION.unit='${SECRET.unit}';`);
}

const KB = JSON.parse(fs.readFileSync('kb_slim.json', 'utf8'));
const kbBody = {};
KB.endpoints.forEach(e => {
  if (!(e.b || '').trim() || kbBody[e.p]) return;
  try { kbBody[e.p] = JSON.parse(e.b); } catch (_) { /* عينات فيها تعليقات — بنتخطاها */ }
});

function byPath(col, p){
  return col.item.find(i => i.request.url.raw.indexOf(p + '?') > -1);
}
function bodyOf(it){ return JSON.parse(it.request.body.raw); }

/* ═════ ١) السيناريو بيطلّع كولكشن مكتمل ═════ */
console.log('\n\u0661) كولكشن من السيناريو');
let COL;
{
  const w = boot(); connect(w);
  COL = w.eval("JSON.stringify(pmFromRecipe(RECIPES.find(r=>r.id==='summary-report')))");
  COL = JSON.parse(COL);
  ok('سكيمة Postman v2.1', COL.info.schema.indexOf('v2.1.0/collection.json') > 0);
  ok('فيه اسم ووصف', COL.info.name.length > 5 && COL.info.description.length > 60);
  ok('كل ريكوست POST', COL.item.every(i => i.request.method === 'POST'));
  ok('كل ريكوست له URL كامل', COL.item.every(i => /^\{\{base_url\}\}\/.+\?token=\{\{token\}\}$/.test(i.request.url.raw)));
  ok('كل ريكوست له بودي JSON سليم', COL.item.every(i => { try { JSON.parse(i.request.body.raw); return true; } catch(_) { return false; } }));
  ok('كل ريكوست له شرح', COL.item.every(i => (i.request.description || '').length > 20),
     COL.item.filter(i => (i.request.description||'').length <= 20).map(i=>i.name).join(', '));
  w.close();
}

/* ═════ ٢) السلسلة كاملة وبالترتيب ═════ */
console.log('\n\u0662) السلسلة والترتيب');
{
  const paths = COL.item.map(i => i.request.url.raw.split('?')[0].replace('{{base_url}}',''));
  ['/auth/login','/units/lists','/user_reports/add','/user_reports/percentage',
   '/user_reports/data-summary','/user_reports/data-new','/user_reports/export',
   '/user_reports/delete'].forEach(p => ok('فيه ' + p, paths.indexOf(p) > -1, paths.join(' ')));
  const iPct = paths.indexOf('/user_reports/percentage');
  const iSum = paths.indexOf('/user_reports/data-summary');
  const iAdd = paths.indexOf('/user_reports/add');
  ok('الإنشاء قبل الانتظار', iAdd > -1 && iAdd < iPct, paths.join(' '));
  ok('الانتظار قبل القراءة', iPct > -1 && iPct < iSum, paths.join(' '));
  ok('الدخول أول حاجة', paths[0] === '/auth/login');
  ok('التنضيف آخر حاجة', paths[paths.length-1] === '/user_reports/delete');
}

/* ═════ ٣) الأشكال مطابقة لقاعدة المعرفة ═════ */
console.log('\n\u0663) الأشكال مطابقة للـ KB');
{
  [['/user_reports/percentage'], ['/user_reports/data-summary'],
   ['/user_reports/export'], ['/user_reports/delete'], ['/auth/login']].forEach(([p]) => {
    const mine = bodyOf(byPath(COL, p)).data;
    const ref  = kbBody[p].data;
    ok(p + ' مفاتيح data زي الـ KB',
       JSON.stringify(Object.keys(mine).sort()) === JSON.stringify(Object.keys(ref).sort()),
       'انا=' + Object.keys(mine).sort() + ' KB=' + Object.keys(ref).sort());
  });
  const add = bodyOf(byPath(COL, '/user_reports/add')).data;
  const ref = kbBody['/user_reports/add'].data;
  ok('/user_reports/add مفاتيح data زي الـ KB (+ user_id)',
     Object.keys(ref).every(k => k in add), Object.keys(ref).filter(k => !(k in add)).join(','));
  const dn = bodyOf(byPath(COL, '/user_reports/data-new')).data;
  ok('data-new فيه id و resource_id زي كولكشن الدعم',
     'id' in dn && 'resource_id' in dn, Object.keys(dn).join(','));
}

/* ═════ ٤) سلسلة الالتقاط مربوطة ═════ */
console.log('\n\u0664) الالتقاط بين الخطوات');
{
  const scr = (p, kind) => {
    const it = byPath(COL, p);
    const ev = (it.event || []).find(e => e.listen === (kind || 'test'));
    return ev ? ev.script.exec.join('\n') : '';
  };
  ok('login بيلتقط token', scr('/auth/login').indexOf('set("token"') > -1);
  ok('login بيلتقط user_id', scr('/auth/login').indexOf('set("user_id"') > -1);
  ok('units/lists بيلتقط unit_id', scr('/units/lists').indexOf('set("unit_id"') > -1);
  ok('add بيلتقط report_id', scr('/user_reports/add').indexOf('set("report_id"') > -1);
  ok('add بيستهلك user_id', byPath(COL,'/user_reports/add').request.body.raw.indexOf('{{user_id}}') > -1);
  ok('add بيستهلك unit_id', byPath(COL,'/user_reports/add').request.body.raw.indexOf('{{unit_id}}') > -1);
  ok('percentage بيستهلك report_id', byPath(COL,'/user_reports/percentage').request.body.raw.indexOf('{{report_id}}') > -1);
  ok('data-new بيستهلك report_id و unit_id',
     byPath(COL,'/user_reports/data-new').request.body.raw.indexOf('{{report_id}}') > -1 &&
     byPath(COL,'/user_reports/data-new').request.body.raw.indexOf('{{unit_id}}') > -1);
}

/* ═════ ٥) حلقة الانتظار ═════ */
console.log('\n\u0665) حلقة الانتظار');
{
  const it = byPath(COL, '/user_reports/percentage');
  const test = (it.event.find(e => e.listen === 'test') || {script:{exec:[]}}).script.exec.join('\n');
  const pre  = (it.event.find(e => e.listen === 'prerequest') || {script:{exec:[]}}).script.exec.join('\n');
  ok('فيه رجوع لنفس الريكوست', test.indexOf('setNextRequest') > -1);
  ok('الاسم في الحلقة مطابق لاسم الريكوست الفعلي', test.indexOf(it.name) > -1, it.name);
  ok('فيه سقف للمحاولات', /n\s*<\s*\d+/.test(test));
  ok('فيه تأخير قبل المحاولة', pre.indexOf('3000') > -1);
  ok('بيتعامل مع رد من غير حقل percentage', test.indexOf('pct === null') > -1);
}

/* ═════ ٦) المتغيّرات ═════ */
console.log('\n\u0666) المتغيّرات');
{
  const declared = COL.variable.map(v => v.key);
  const raw = JSON.stringify(COL);
  const used = Array.from(new Set((raw.match(/\{\{(\w+)\}\}/g) || []).map(s => s.slice(2,-2))));
  ok('كل متغيّر بيتنده معرّف', used.every(u => declared.indexOf(u) > -1),
     used.filter(u => declared.indexOf(u) < 0).join(','));
  ok('مفيش متغيّر معرّف وما بيتندهش (غير poll_count)',
     declared.every(d => used.indexOf(d) > -1 || ['poll_count','username','password'].indexOf(d) > -1),
     declared.filter(d => used.indexOf(d) < 0).join(','));
  ok('base_url متعبّى', (COL.variable.find(v=>v.key==='base_url')||{}).value.indexOf('http') === 0);
  ok('التوكن واليوزر والباسورد فاضيين',
     ['token','username','password'].every(k => (COL.variable.find(v=>v.key===k)||{}).value === ''));
}

/* ═════ ٧) الأهم: مفيش تسريب من الحساب المتصل ═════ */
console.log('\n\u0667) نظافة الملف — مفيش بيانات الحساب المتصل');
{
  const raw = JSON.stringify(COL);
  ok('مفيش توكن الحساب', raw.indexOf(SECRET.token) < 0);
  ok('مفيش رقم مستخدم الحساب', raw.indexOf(SECRET.userId) < 0);
  ok('مفيش رقم عربية الحساب', raw.indexOf(SECRET.unit) < 0);
  ok('مفيش اسم الحساب', raw.indexOf(SECRET.user) < 0);
  ok('مفيش JWT', !/eyJ[A-Za-z0-9\-_]{20,}/.test(raw));
  ok('مفيش ID من عينات الـ KB',
     raw.indexOf('66fd1abe') < 0 && raw.indexOf('63f223f9') < 0 && raw.indexOf('5d35a75c') < 0);
}

/* ═════ ٨) كولكشن من تحليل رسالة العميل ═════ */
console.log('\n\u0668) كولكشن من رسالة العميل');
{
  const w = boot(); connect(w);
  const EMAIL = fs.readFileSync('test_case.js','utf8').match(/const EMAIL = `([\s\S]*?)`;/)[1];
  w.showView('inspect');
  w.document.getElementById('ivCase').click();
  w.document.getElementById('caseText').value = EMAIL;
  w.document.getElementById('caseGo').click();

  ok('زرار تنزيل الكولكشن ظهر تحت الرد', !!w.document.getElementById('casePm'));

  w.URL.createObjectURL = () => 'blob:x';
  w.URL.revokeObjectURL = () => {};
  const col = JSON.parse(w.eval(
    'JSON.stringify(pmFromCase(analyzeCase(' + JSON.stringify(EMAIL) + ')))'));
  ok('الكولكشن اتبنى من الرسالة', !!col && Array.isArray(col.item) && col.item.length > 5,
     col ? col.item.length : 'null');

  if (col) {
    const addRaw = byPath(col, '/user_reports/add').request.body.raw;
    const add = JSON.parse(addRaw);
    const codes = (add.data.fields || []).map(f => f.code);
    ['route_length','engine_work','move_duration','engine_idle','stop_duration']
      .forEach(c => ok('عمود العميل ' + c + ' في بودي الإنشاء', codes.indexOf(c) > -1, codes.join(',')));
    ok('resources علامة مكان مش عربية حقيقية',
       JSON.stringify(add.data.resources) === JSON.stringify(['{{unit_id}}']),
       JSON.stringify(add.data.resources));
    ok('user_id علامة مكان', add.data.user_id === '{{user_id}}', String(add.data.user_id));
    const raw = JSON.stringify(col);
    ok('مفيش توكن الحساب في كولكشن الحالة', raw.indexOf(SECRET.token) < 0);
    ok('مفيش رقم مستخدم الحساب', raw.indexOf(SECRET.userId) < 0);
    ok('الوصف بيشرح فخ الرد الفاضي',
       /looks like a failure/.test(col.info.description));
    ok('الوصف فيه السلسلة الأربعة',
       /data-summary/.test(col.info.description) && /data-new/.test(col.info.description) &&
       /percentage/.test(col.info.description));
  }
  w.close();
}


/* ═════ ٩) الملف بيروح لعميل: كله إنجليزي مهما كانت لغة الواجهة ═════ */
console.log('\n\u0669) لغة الملف');
{
  const w = boot(); connect(w);
  w.eval("setLang('ar');");
  const col = JSON.parse(w.eval("JSON.stringify(pmFromRecipe(RECIPES.find(r=>r.id==='summary-report')))"));
  const ar = /[\u0600-\u06FF]/;
  ok('مفيش اسم ريكوست بالعربي', !col.item.some(i => ar.test(i.name)),
     col.item.filter(i => ar.test(i.name)).map(i=>i.name).join(' | '));
  ok('مفيش شرح بالعربي', !col.item.some(i => ar.test(i.request.description || '')),
     col.item.filter(i => ar.test(i.request.description||'')).map(i=>i.name).join(' | '));
  ok('اسم الكولكشن إنجليزي', !ar.test(col.info.name), col.info.name);
  ok('وصف الكولكشن إنجليزي', !ar.test(col.info.description));
  ok('التعليقات في السكربتات إنجليزي',
     !col.item.some(i => (i.event||[]).some(e => ar.test(e.script.exec.join('')))));
  w.close();
}
console.log('\n' + (FAILED ? '\u2717 فشل نهائي: ' + FAILED : '\u2713 كله عدّى'));
process.exit(FAILED ? 1 : 0);
