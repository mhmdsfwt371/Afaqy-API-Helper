#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v6.45 — العميل بعت الرد صورة: الأداة بتقراها.

المحك: إيميل حقيقي (١١ أكتوبر) — «Postman Response:» وبعدها صورة.
الموظف كان بيقف: الأداة بتاخد نص بس.

اللي بيتعمل:
- في «افحص رد» و«حلّل رسالة عميل»: ارفع صورة، أو الصقها (Ctrl+V)، أو اسحبها
  على الخانة. الأداة بتقرا الكلام اللي فيها وتحطه في الخانة وتفحصه زي أي رد.
- القراءة بتتعمل على الجهاز نفسه في المتصفح (Tesseract مترجم لـ WebAssembly)
  — الصورة ما بتتبعتش لأي سيرفر. المحرك بينزل من jsDelivr أول مرة بس
  (حوالي ٦ ميجا، بنسخة مثبّتة) وبيتحفظ: في كاش خدمة الخلفية وفي IndexedDB
  بتاع المحرك نفسه، فالمرات الجاية بتشتغل أوفلاين.
- قبل القراءة: الصورة بتتكبّر وتتحوّل رمادي وتتعكس لو خلفيتها غامقة
  (بوستمان بالوضع الليلي) — من غير كده القراءة بتبقى نص صح نص غلط.
- بعد القراءة: تنضيف للي الـ OCR بيغلط فيه في الـ JSON: أرقام السطور بتاعة
  بوستمان، علامات التنصيص المعوجة، المفاتيح اللي اتقطعت بمسافة
  (status code → status_code)، والصفر اللي بيتقرى 6 أو 8 في status_code
  لما يطلع رقم مش موجود أصلًا — وكل تصليح بيتقال للموظف.
- الأرقام الطويلة (معرّفات، IMEI) ممكن تتقرى غلط: الأداة بتقول «راجع
  الأرقام قبل الفحص» ومش بتلعب فيها.
"""
import sys, io, os

HERE = os.path.dirname(os.path.abspath(__file__))
PATH = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, 'app_template.html')
src = io.open(PATH, encoding='utf-8').read()
orig = len(src)

def rep(old, new, n=1, tag=''):
    global src
    c = src.count(old)
    if c != n: raise SystemExit('MISMATCH [%s]: expected %d found %d\n---\n%s' % (tag, n, c, old[:240]))
    src = src.replace(old, new, n); print('  ok  %s' % tag)

OCR_JS = r"""
/* ============ صورة الرد — قراءة على الجهاز ============
   العميل كتير بيبعت رد بوستمان صورة. القراءة بتتعمل هنا في المتصفح
   (Tesseract مترجم WebAssembly) — الصورة ما بتسيبش الجهاز. المحرك بينزل
   من jsDelivr أول مرة بنسخة مثبّتة، وبعدها بيشتغل من الكاش أوفلاين. */
const OCR = { lib:'tesseract.js@5.1.1', core:'tesseract.js-core@5.1.1',
              lang:'@tesseract.js-data/eng@1.0.0/4.0.0_best_int', worker:null, loading:null };
/* الاختبار بيوجّه المحرك لسيرفر محلي — الإنتاج دايمًا jsDelivr */
function ocrCdn(){ return (typeof window !== 'undefined' && window.OCR_CDN_OVERRIDE) || 'https://cdn.jsdelivr.net/npm/'; }
function loadScript(url){
  return new Promise((res, rej)=>{
    const s = document.createElement('script'); s.src = url; s.async = true;
    s.onload = res; s.onerror = ()=>rej(new Error('load ' + url));
    document.head.appendChild(s);
  });
}
/* حالة المحرك بكلام الموظف — مش status بتاع المكتبة */
function ocrStage(m){
  const st = String((m && m.status) || ''), pc = Math.round(((m && m.progress) || 0) * 100);
  const name = /core/.test(st)        ? t('بنزّل محرك القراءة — مرة واحدة بس','Downloading the reader — first time only')
             : /traineddata/.test(st) ? t('بنزّل قاموس الحروف — مرة واحدة بس','Downloading the character data — first time only')
             : /recogniz/.test(st)    ? t('بنقرا الصورة','Reading the image')
             : t('بنجهّز','Preparing');
  return name + (pc > 0 && pc < 100 ? ' ' + pc + '%' : '');
}
async function ocrEngine(progress){
  if(OCR.worker) return OCR.worker;
  if(OCR.loading) return OCR.loading;
  OCR.loading = (async()=>{
    try{
      if(typeof Tesseract === 'undefined') await loadScript(ocrCdn() + OCR.lib + '/dist/tesseract.min.js');
      const w = await Tesseract.createWorker('eng', 1, {
        workerPath: ocrCdn() + OCR.lib + '/dist/worker.min.js',
        corePath:   ocrCdn() + OCR.core,
        langPath:   ocrCdn() + OCR.lang,
        gzip: true,
        logger: m => { try{ progress && progress(ocrStage(m)); }catch(_){} }
      });
      /* بلوك واحد متساوي الأسطر — ده شكل رد بوستمان، ومسافات الأعمدة بتتحفظ */
      await w.setParameters({ tessedit_pageseg_mode: '6', preserve_interword_spaces: '1' });
      OCR.worker = w; return w;
    } finally { OCR.loading = null; }
  })();
  return OCR.loading;
}
function ocrLoadImage(file){
  return new Promise((res, rej)=>{
    const url = URL.createObjectURL(file), img = new Image();
    img.onload = ()=>res({img, url}); img.onerror = ()=>rej(new Error('bad image'));
    img.src = url;
  });
}
/* تكبير ×٢ للصور الصغيرة، رمادي، عكس لو الخلفية غامقة، وشدّ تباين —
   بوستمان بالوضع الليلي من غير كده بيطلع نص صح نص غلط. */
function ocrPrepare(img){
  const scale = (img.naturalWidth || img.width) < 1400 ? 2 : 1;
  const c = document.createElement('canvas');
  c.width = (img.naturalWidth || img.width) * scale; c.height = (img.naturalHeight || img.height) * scale;
  const x = c.getContext('2d', {willReadFrequently:true});
  x.imageSmoothingEnabled = true; x.imageSmoothingQuality = 'high';
  x.drawImage(img, 0, 0, c.width, c.height);
  const d = x.getImageData(0, 0, c.width, c.height), p = d.data, n = p.length / 4;
  const hist = new Uint32Array(256); let sum = 0;
  for(let i = 0; i < p.length; i += 4){
    const g = (p[i]*299 + p[i+1]*587 + p[i+2]*114) / 1000 | 0;
    p[i] = g; sum += g; hist[g]++;
  }
  const dark = (sum / n) < 110;
  /* قصّ ٠٫٥٪ من الطرفين عشان بيكسل واحد ما يبوّظش الشدّ */
  let lo = 0, hi = 255, acc = 0, cut = n * 0.005;
  for(let i = 0; i < 256; i++){ acc += hist[i]; if(acc > cut){ lo = i; break; } }
  acc = 0; for(let i = 255; i >= 0; i--){ acc += hist[i]; if(acc > cut){ hi = i; break; } }
  const rng = Math.max(1, hi - lo);
  for(let i = 0; i < p.length; i += 4){
    let v = Math.max(0, Math.min(255, Math.round((p[i] - lo) * 255 / rng)));
    if(dark) v = 255 - v;
    p[i] = p[i+1] = p[i+2] = v; p[i+3] = 255;
  }
  x.putImageData(d, 0, 0);
  return {canvas:c, dark, scale};
}
/* الأكواد اللي بنعرفها — لو status_code طلع رقم مش منهم والصفر اتقرى 6 أو 8، بنرجّعه */
const OCR_CODES = new Set(['200','201','204','400','401','402','403','404','405','406','408','409','410','415','422','429','500','501','502','503','504']);
/* تنضيف اللي الـ OCR بيغلط فيه في JSON — كل تصليح بيتقال للموظف */
function ocrClean(txt){
  const fixes = []; let s = String(txt || '').replace(/\r/g, '');
  const q = (s.match(/[“”„‟″‘’‚‛′]/g) || []).length;
  s = s.replace(/[“”„‟″]/g, '"').replace(/[‘’‚‛′]/g, "'");
  if(q) fixes.push(t('علامات تنصيص معوجة اتظبطت','Curly quotes straightened'));
  /* أرقام السطور بتاعة بوستمان في أول كل سطر — ساعات لازقة في القوس: «5}» */
  const lines = s.split('\n'), nonEmpty = lines.filter(l => l.trim()).length;
  const LN = /^\s*\d{1,4}(?=\s+\S|[{}\[\]])/;
  const numbered = lines.filter(l => LN.test(l)).length;
  if(numbered >= 3 && numbered >= nonEmpty * 0.6){
    s = lines.map(l => l.replace(/^\s*\d{1,4}\s*/, '')).join('\n');
    fixes.push(t('أرقام السطور اتشالت','Line numbers removed'));
  }
  /* قوس إغلاق على سطر لوحده اتقرى حروف («Is» أو «L» أو «¥»): لو إحنا جوه كائن أو مصفوفة،
     السطر ده هو القوس اللي بيقفلها. بنتتبّع الأقواس من بره النصوص المقتبسة. */
  {
    const L2 = s.split('\n'), stack = []; let fixed = 0;
    const walk = line => { let q = false;
      for(const ch of line){ if(ch === '"'){ q = !q; continue; } if(q) continue;
        if(ch === '{' || ch === '[') stack.push(ch);
        else if((ch === '}' || ch === ']') && stack.length) stack.pop(); } };
    for(let i = 0; i < L2.length; i++){
      const tr = L2[i].trim();
      if(stack.length && /^[A-Za-z¥£§†‡¢]{1,3}[.,]?$/.test(tr)){
        const next = (L2.slice(i + 1).find(x => x.trim()) || '').trim();
        const close = stack[stack.length - 1] === '{' ? '}' : ']';
        L2[i] = close + (next.startsWith('"') ? ',' : ''); fixed++;
      }
      walk(L2[i]);
    }
    if(fixed){ s = L2.join('\n'); fixes.push(t(`${fixed} قوس إغلاق اتقرى حروف واترجّع`, `${fixed} closing bracket read as letters restored`)); }
  }
  /* مفتاح اتقطع بمسافة: "status code": → "status_code": */
  let k = 0;
  s = s.replace(/"([a-z][a-z0-9]*(?: [a-z][a-z0-9_]*)+)"\s*:/gi, (m, key)=>{ k++; return '"' + key.replace(/ /g, '_') + '":'; });
  if(k) fixes.push(t('مفاتيح اتقطعت بمسافة اتلمّت','Keys split by a space rejoined'));
  /* علامة تنصيص اتقرت نجمة أو فاصلة في أول المفتاح: *message" → "message" */
  s = s.replace(/^(\s*)[*'`´]([a-z_][a-z0-9_]*)"/gmi, '$1"$2"');
  /* صفر اتقرى حرف في مكان رقم */
  s = s.replace(/:\s*[@oO]\s*(?=[,\n}\]])/g, ': 0')
       .replace(/(?<=\d)[oO](?=\d)/g, '0').replace(/(?<=\d)[lI](?=\d)/g, '1');
  /* status_code بيقول رقم مش موجود أصلًا — الصفر اتقرى 6 أو 8 */
  s = s.replace(/("status_code"\s*:\s*)(\d{3})\b/g, (m, a, num)=>{
    if(OCR_CODES.has(num)) return m;
    const alt = num.replace(/[68]/g, '0');
    if(alt !== num && OCR_CODES.has(alt)){ fixes.push(t(`status_code اتقرى ${num} واتصلّح لـ ${alt} — اتأكد من الصورة`, `status_code read as ${num}, corrected to ${alt} — check the image`)); return a + alt; }
    return m;
  });
  return {text: s.trim(), fixes};
}
/* الصورة → نص منضّف. progress(نص) بيتنده مع كل مرحلة. */
async function ocrImage(file, progress){
  const {img, url} = await ocrLoadImage(file);
  try{
    const prep = ocrPrepare(img);
    const w = await ocrEngine(progress);
    progress && progress(t('بنقرا الصورة','Reading the image'));
    const {data} = await w.recognize(prep.canvas);
    const out = ocrClean(data.text);
    out.dark = prep.dark; out.confidence = Math.round(data.confidence || 0);
    return out;
  } finally { URL.revokeObjectURL(url); }
}
/* صندوق الصورة تحت الخانة: الصورة نفسها + الحالة + اللي اتصلّح */
function ocrBox(boxId, html, thumb){
  const b = $(boxId); if(!b) return;
  b.hidden = false;
  b.innerHTML = `<div style="display:flex; gap:12px; align-items:flex-start; flex-wrap:wrap">
    ${thumb ? `<img src="${thumb}" alt="" style="max-height:120px; max-width:220px; border:1px solid var(--line); border-radius:var(--r); background:#fff">` : ''}
    <div style="flex:1 1 240px; font-size:13px">${html}</div></div>`;
}
/* بتوصّل الصورة بالخانة: رفع، أو لصق Ctrl+V، أو سحب. after() بتتنده بعد ما النص يتحط. */
function ocrAttach(textId, boxId, fileId, after){
  const ta = $(textId); if(!ta) return;
  const run = async file => {
    if(!file || !/^image\//.test(file.type || '')){ toast(t('ده مش ملف صورة','That is not an image file')); return; }
    const thumb = URL.createObjectURL(file);
    ocrBox(boxId, `<div class="note">${esc(t('بنجهّز','Preparing'))}</div>`, thumb);
    try{
      const r = await ocrImage(file, stage => ocrBox(boxId, `<div class="note">${esc(stage)}</div>`, thumb));
      if(!r.text){
        ocrBox(boxId, `<div class="note warn">${t('ما طلعش كلام من الصورة. جرّب صورة أوضح أو أكبر — أو اطلب من العميل النص نفسه.','No text came out of the image. Try a clearer or larger one — or ask the customer for the text itself.')}</div>`, thumb);
        return;
      }
      const cur = ta.value.trim();
      ta.value = cur ? cur + '\n\n' + r.text : r.text;
      ocrBox(boxId, `<div class="note sig"><b>${t('اتقرت من الصورة','Read from the image')}</b>${r.dark ? ' — ' + esc(t('خلفية غامقة اتعكست قبل القراءة','dark background inverted before reading')) : ''}.
          ${t('راجع الأرقام الطويلة (المعرّفات والـ IMEI) قبل ما تعتمد عليها — الصفر ساعات بيتقرى 6 أو 8.','Check long numbers (ids and IMEIs) before relying on them — a zero sometimes reads as 6 or 8.')}
          ${r.fixes.length ? `<ul style="margin:6px 0 0; padding-inline-start:20px">${r.fixes.map(f=>`<li>${esc(f)}</li>`).join('')}</ul>` : ''}</div>`, thumb);
      after && after(r);
    }catch(err){
      const off = !navigator.onLine || /load |Failed to fetch|NetworkError/i.test(String(err && err.message || err));
      ocrBox(boxId, `<div class="note warn"><b>${t('ما قدرناش نقرا الصورة.','Could not read the image.')}</b> ${off
        ? t('قراءة الصور محتاجة نت أول مرة بس عشان تنزّل المحرك (حوالي ٦ ميجا) — بعدها بتشتغل أوفلاين.','Reading images needs the internet the first time only, to download the reader (about 6 MB) — after that it works offline.')
        : esc(String(err && err.message || err).slice(0, 160))}</div>`, thumb);
    }
  };
  const fi = $(fileId);
  if(fi) fi.addEventListener('change', ev => { const f = ev.target.files && ev.target.files[0]; if(f && /^image\//.test(f.type)) { run(f); ev.target.value = ''; } });
  ta.addEventListener('paste', ev => {
    const items = (ev.clipboardData && ev.clipboardData.items) || [];
    const it = [...items].find(i => /^image\//.test(i.type));
    if(it){ ev.preventDefault(); run(it.getAsFile()); }
  });
  ta.addEventListener('dragover', ev => { ev.preventDefault(); });
  ta.addEventListener('drop', ev => {
    const f = ev.dataTransfer && ev.dataTransfer.files && ev.dataTransfer.files[0];
    if(f && /^image\//.test(f.type)){ ev.preventDefault(); run(f); }
  });
}
"""

# ── ١) الكود قبل renderInspect ────────────────────────────────
rep("function renderInspect(){\n  const raw = ($('inText').value||'').trim();",
    OCR_JS + "\nfunction renderInspect(){\n  const raw = ($('inText').value||'').trim();", tag='محرك قراءة الصورة')

# ── ٢) خانة الرد: الملف بيقبل صور + صندوق الصورة ─────────────
rep("""        <input type="file" id="inFile" accept="application/json,.json,.txt" hidden></label>
      <button class="btn ghost" id="inClear"></button>
    </div>
  </div></div>
  <div id="inOut"></div>""",
"""        <input type="file" id="inFile" accept="application/json,.json,.txt,image/*" hidden></label>
      <button class="btn ghost" id="inClear"></button>
    </div>
    <div id="inImgBox" style="margin-top:10px" hidden></div>
  </div></div>
  <div id="inOut"></div>""", tag='خانة الرد بتقبل صور')

# الملف النصي زي ما هو، والصورة بتروح للقارئ
rep("""$('inFile').onchange = ev=>{ const f=ev.target.files[0]; if(!f) return;
  const rd=new FileReader(); rd.onload=()=>{ $('inText').value=String(rd.result||''); renderInspect(); };
  rd.readAsText(f); };""",
"""$('inFile').onchange = ev=>{ const f=ev.target.files[0]; if(!f || /^image\\//.test(f.type||'')) return;
  const rd=new FileReader(); rd.onload=()=>{ $('inText').value=String(rd.result||''); renderInspect(); };
  rd.readAsText(f); };
/* v6.45: صورة الرد — رفع أو لصق أو سحب، وبعد القراءة بتتفحص على طول */
ocrAttach('inText', 'inImgBox', 'inFile', ()=>renderInspect());
$('inClear').addEventListener('click', ()=>{ const b=$('inImgBox'); if(b){ b.hidden=true; b.innerHTML=''; } });""", tag='الصورة بتتقرا وتتفحص')

rep("""  $('inFileLbl').textContent = t('أو ارفع ملف','or upload a file');""",
    """  $('inFileLbl').textContent = t('أو ارفع ملف أو صورة','or upload a file or image');
  $('inText').placeholder = t('الصق الرد هنا — أو الصق صورة الرد (Ctrl+V) أو اسحبها على الخانة','Paste the response here — or paste a screenshot of it (Ctrl+V) or drop it on the box');""", tag='تسمية الرفع والتلميح')

rep("""    'الصق أي رد من الـ API — بتاعك أو اللي العميل بعتهولك — والأداة تحوّله لجدول مقروء: أسماء وأرقام وعدادات محوّلة. لو الرد فيه خطأ، بتقولك السبب.',
    'Paste any API response — yours or one a customer sent you — and the tool turns it into a readable table: names, ids, converted counters. If the response carries an error, it explains it.');""",
"""    'الصق أي رد من الـ API — بتاعك أو اللي العميل بعتهولك — والأداة تحوّله لجدول مقروء: أسماء وأرقام وعدادات محوّلة. لو الرد فيه خطأ، بتقولك السبب. والعميل لو بعته صورة، الصقها زي ما هي والأداة تقراها.',
    'Paste any API response — yours or one a customer sent you — and the tool turns it into a readable table: names, ids, converted counters. If the response carries an error, it explains it. If the customer sent a screenshot, paste it as it is and the tool reads it.');""", tag='مقدمة الفحص')

# ── ٣) خانة رسالة العميل: نفس الحاجة ─────────────────────────
rep("""      <div class="row" style="margin-top:10px">
        <button class="btn sig" id="caseGo">${t('حلّل','Analyse')}</button>
        <button class="btn ghost" id="caseClear">${t('مسح','Clear')}</button>
      </div>
    </div></div>
    <div id="caseOut"></div>`;
  $('caseGo').onclick = ()=>renderCase($('caseText').value);
  $('caseClear').onclick = ()=>{ $('caseText').value=''; $('caseOut').innerHTML=''; CASE_LIVE = null; };""",
"""      <div class="row" style="margin-top:10px">
        <button class="btn sig" id="caseGo">${t('حلّل','Analyse')}</button>
        <label class="btn ghost" style="cursor:pointer">${t('أو ارفع صورة الرد','or upload the response image')}
          <input type="file" id="caseImg" accept="image/*" hidden></label>
        <button class="btn ghost" id="caseClear">${t('مسح','Clear')}</button>
      </div>
      <div id="caseImgBox" style="margin-top:10px" hidden></div>
    </div></div>
    <div id="caseOut"></div>`;
  $('caseGo').onclick = ()=>renderCase($('caseText').value);
  $('caseClear').onclick = ()=>{ $('caseText').value=''; $('caseOut').innerHTML=''; CASE_LIVE = null;
    const b=$('caseImgBox'); if(b){ b.hidden=true; b.innerHTML=''; } };
  /* v6.45: «Postman Response:» وبعدها صورة — بتتقرا وتتحط تحت كلام العميل وتتحلّل */
  ocrAttach('caseText', 'caseImgBox', 'caseImg', ()=>renderCase($('caseText').value));""", tag='خانة الرسالة بتقرا الصورة')

rep("""        placeholder="${t('الصق الإيميل كامل — الكلام والأكواد والأسئلة','Paste the full email — prose, code blocks and questions')}"></textarea>""",
    """        placeholder="${t('الصق الإيميل كامل — الكلام والأكواد والأسئلة. ولو الرد جه صورة، الصقها هنا (Ctrl+V)','Paste the full email — prose, code blocks and questions. If the response came as a screenshot, paste it here (Ctrl+V)')}"></textarea>""", tag='تلميح خانة الرسالة')

io.open(PATH, 'w', encoding='utf-8').write(src)
print('القالب: %d → %d بايت' % (orig, len(src)))

# ── ٤) خدمة الخلفية: محرك القراءة بيتخزّن في كاش ثابت ─────────
bp = os.path.join(HERE, 'build.py')
bb = io.open(bp, encoding='utf-8').read()
def rep3(old, new, tag):
    global bb
    if bb.count(old) != 1: raise SystemExit('MISMATCH build.py [%s]' % tag)
    bb = bb.replace(old, new); print('  ok  %s' % tag)
rep3("""const CACHE = 'afaqy-helper-' + VERSION;""",
"""const CACHE = 'afaqy-helper-' + VERSION;
/* محرك قراءة الصور (Tesseract من jsDelivr، ~٦ ميجا) في كاش مستقل مش مربوط
   بالنسخة — عشان ما ينزلش تاني مع كل نشر. بيتمسح بس مع «flush». */
const OCR_CACHE = 'afaqy-ocr-v1';""", 'كاش المحرك')
rep3("""      .then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k))))""",
     """      .then(keys => Promise.all(keys.filter(k => k !== CACHE && k !== OCR_CACHE).map(k => caches.delete(k))))""", 'التفعيل بيسيب كاش المحرك')
rep3("""  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;           // سيرفر أفاقي يعدي على طول""",
"""  const url = new URL(req.url);
  /* ملفات محرك القراءة: الكاش الأول، والشبكة لو مش موجودة — وبتتحفظ */
  if (url.hostname === 'cdn.jsdelivr.net' && /tesseract/.test(url.pathname)) {
    ev.respondWith(
      caches.match(req).then(hit => hit || fetch(req).then(res => {
        if (res && res.ok) { const copy = res.clone(); caches.open(OCR_CACHE).then(c => c.put(req, copy)); }
        return res;
      }))
    );
    return;
  }
  if (url.origin !== self.location.origin) return;           // سيرفر أفاقي يعدي على طول""", 'المحرك بيتخزّن')
rep3("""    ('const REQ_CATALOG',            'طلب إنتجريشن نقطة بنقطة'),\n]""",
     """    ('const REQ_CATALOG',            'طلب إنتجريشن نقطة بنقطة'),\n    ('function ocrImage',            'قراءة صورة الرد على الجهاز'),\n]""", 'علامة البناء')
io.open(bp, 'w', encoding='utf-8').write(bb)

# ── ٥) package.json: المحرك للاختبار المحلي بس (مش في الزيب ولا الأداة) ──
pp = os.path.join(HERE, 'package.json')
import json
pj = json.load(io.open(pp, encoding='utf-8'))
pj.setdefault('devDependencies', {})
pj['devDependencies']['tesseract.js'] = '5.1.1'
pj['devDependencies']['@tesseract.js-data/eng'] = '1.0.0'
pj['description'] = 'مصدر مساعد الإنتجريشن — الاختبارات بتشتغل بـ jsdom، والبناء بـ python3 build.py. محرك القراءة (tesseract) محتاجه اختبار المتصفح بس؛ الأداة نفسها بتحمّله من jsDelivr.'
json.dump(pj, io.open(pp, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)
print('  ok  package.json')
print('تمام — شغّل الاختبارات وبعدين build.py')
