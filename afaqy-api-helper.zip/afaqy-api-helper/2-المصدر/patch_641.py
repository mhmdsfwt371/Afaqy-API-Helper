#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v6.41 — «شغّل كل الخطوات» بقى يمشي لوحده فعلًا.

كان بيقف عند أول خطوة فيها اختيار ويقول «اختار وكمّل». وسيناريو التقرير
فيه تلات اختيارات، فكان بيقف تلات مرات — يعني مش تشغيل تلقائي أصلًا.

دلوقتي: تحط IMEI واحد، وتدوس، والأداة تمشي السلسلة كاملة لوحدها —
تجيب رقم العربية، تختار قالب الـ summary، تعمل التقرير، تستنى التوليد،
تقرا الصفوف — وفي الآخر تطلّعلك الأرقام ورد جاهز للعميل يشرح السلسلة.
"""
import sys, io

PATH = sys.argv[1] if len(sys.argv) > 1 else 'app_template.html'
src = io.open(PATH, encoding='utf-8').read()
orig = len(src)

def rep(old, new, n=1, tag=''):
    global src
    c = src.count(old)
    if c != n: raise SystemExit('MISMATCH [%s]: expected %d found %d\n---\n%s' % (tag, n, c, old[:220]))
    src = src.replace(old, new, n); print('  ok  %s' % tag)

# ── ١) خانة IMEI في مدخلات السيناريو ────────────────────────
rep("""  inputs:[{k:'from',t:'date',l:{ar:'من يوم', en:'From'}},
          {k:'to',t:'date',l:{ar:'لحد يوم', en:'To'}}],
  steps:[
   { t:{ar:'جلب مجموعات العربيات', en:'Fetch vehicle groups'}, kind:'call', m:'POST', path:'/unit_groups/lists',""",
"""  inputs:[{k:'from',t:'date',l:{ar:'من يوم', en:'From'}},
          {k:'to',t:'date',l:{ar:'لحد يوم', en:'To'}},
          {k:'imei',t:'text',l:{ar:'IMEI عربية واحدة — للتشغيل التلقائي', en:'One vehicle IMEI — for the automatic run'}}],
  steps:[
   { t:{ar:'جلب مجموعات العربيات', en:'Fetch vehicle groups'}, kind:'call', m:'POST', path:'/unit_groups/lists',""",
    1, 'خانة IMEI')

# ── ٢) rcAll بقى يكمّل بدل ما يقف ───────────────────────────
rep("""  $('rcAll').onclick = async ()=>{
    const b=$('rcAll'), old=b.textContent; b.disabled=true;
    for(let i=0;i<r.steps.length;i++){
      const st=r.steps[i];
      if(st.kind==='choose'){ b.disabled=false; b.textContent=old;
        toast(t('وقفت عند خطوة الاختيار — اختار وكمّل','Stopped at a choice step — pick one and continue')); return; }
      b.textContent = t(`الخطوة ${i+1} من ${r.steps.length}…`,`Step ${i+1} of ${r.steps.length}…`);
      await runStep(i);
      if(!RC.results[i] || !RC.results[i].ok){ b.disabled=false; b.textContent=old;
        toast(t('وقفت عند خطوة فشلت','Stopped at a failed step')); return; }
    }
    b.disabled=false; b.textContent=old; toast(t('خلصت كل الخطوات','All steps completed'));
  };""",
"""  $('rcAll').onclick = async ()=>{
    const b=$('rcAll'), old=b.textContent; b.disabled=true;
    /* الوضع التلقائي: الخطوات اللي فيها اختيار بتختار لوحدها بدل ما توقف.
       من غيره كان بيقف تلات مرات في سيناريو التقرير — يعني مش تلقائي. */
    RC.auto = true;
    try{
      for(let i=0;i<r.steps.length;i++){
        const st=r.steps[i];
        if(st.kind==='rexport'){                 /* التصدير بينزّل ملف — مش من حق التلقائي */
          RC.results[i] = {ok:true, msg:t('التصدير اتساب ليك — دوس عليه لو محتاجه.',
                                          'The export is left to you — press it if you need the file.')};
          renderSteps(); continue;
        }
        b.textContent = t(`الخطوة ${i+1} من ${r.steps.length}…`,`Step ${i+1} of ${r.steps.length}…`);
        await runStep(i);
        /* الخطوات اللي بتختار لوحدها بترجّع الوعد ده عشان نستناها */
        if(RC.autoWait){ await RC.autoWait; RC.autoWait = null; }
        if(!RC.results[i] || !RC.results[i].ok){
          toast(t(`وقفت عند الخطوة ${i+1}`, `Stopped at step ${i+1}`));
          return;
        }
      }
      toast(t('خلصت كل الخطوات','All steps completed'));
      summaryWrap(r);
    } finally {
      RC.auto = false; b.disabled=false; b.textContent=old;
    }
  };""", 1, 'rcAll تلقائي')

# ── ٣) اختيار القالب لوحده ──────────────────────────────────
rep("""  RC.results[i]={ok:false, msg:t(`اختار القالب (${items.length} متاح):`,`Choose a template (${items.length} available):`),""",
"""  /* تلقائي: بندوّر على القالب اللي كوده summary. لو مش لاقيينه بناخد
     الأول ونقول للموظف إحنا اخترنا إيه — مش بنسكت. */
  if(RC.auto && st.into === 'tplId'){
    const pick = items.find(x => /summary/i.test(String((x.raw && x.raw.code) || ''))) ||
                 items.find(x => /summary/i.test(String(x.name || ''))) || items[0];
    RC.vars[st.into] = pick.id; RC.vars._tplRaw = pick.raw;
    RC.results[i] = {ok:true,
      msg:`${t('القالب','Template')}: <b>${esc(pick.name)}</b> — <code>${esc(pick.raw && pick.raw.code || '—')}</code>`,
      html:`<div class="note" style="margin-top:8px">${t(
        `اتخد لوحده من ${items.length} قالب في الحساب. لو ده مش المطلوب، ارجع ونفّذ الخطوة دي بإيدك.`,
        `Chosen automatically from ${items.length} templates on the account. If it is the wrong one, run this step by hand.`)}</div>`,
      vars:{[st.into]:pick.id, code:(pick.raw && pick.raw.code) || '—'}};
    return renderSteps();
  }
  RC.results[i]={ok:false, msg:t(`اختار القالب (${items.length} متاح):`,`Choose a template (${items.length} available):`),""",
    1, 'اختيار القالب تلقائي')

# ── ٤) النطاق لوحده: بالـ IMEI أو الحساب كله ────────────────
rep("""async function doRScope(i){
  const prev = RC.results[i-1];
  const groups = (prev && prev.json) ? deepItems(prev.json) : [];""",
"""async function doRScope(i){
  const prev = RC.results[i-1];
  const groups = (prev && prev.json) ? deepItems(prev.json) : [];
  /* تلقائي: لو الموظف حط IMEI بنشتغل على العربية دي لوحدها — أسرع
     في التوليد وأدق في الإثبات. من غير IMEI بنجيب الحساب كله. */
  if(RC.auto){
    RC.autoWait = (async ()=>{
      const box = $('out_'+i);
      const im = String(RC.vars.imei || '').trim();
      try{
        if(box) box.innerHTML = `<div class="note">${t('بيجيب عربيات الحساب…','Fetching the account vehicles…')}</div>`;
        const got = await fetchAllUnits(['basic'], (n)=>{
          if(box) box.innerHTML = `<div class="note">${t(`بيجيب… ${n}`,`Fetching… ${n}`)}</div>`; });
        const all = got.units || [];
        RC.vars._unitNames = {};
        all.forEach(u=>{ const k=String(u.id||u._id||''); if(k) RC.vars._unitNames[k]=String(u.name||k); });
        if(im){
          const hit = all.find(u => String(u.imei||'') === im);
          if(!hit){
            RC.results[i] = {ok:false,
              msg: t(`الـ IMEI ده مش في الحساب المتصل: ${esc(im)}`, `This IMEI is not on the connected account: ${esc(im)}`),
              html:`<div class="note warn" style="margin-top:8px">${t(
                `الحساب فيه ${all.length} عربية ومفيهمش الرقم ده. اتأكد من الرقم، أو سيب الخانة فاضية عشان يشتغل على الحساب كله.`,
                `The account holds ${all.length} vehicles and none carries this number. Check it, or leave the field empty to run on the whole account.`)}</div>`};
            return renderSteps();
          }
          RC.vars.resources = [String(hit.id || hit._id)];
          RC.vars.scopeLabel = String(hit.name || im);
          RC.results[i] = {ok:true,
            msg:`${t('العربية','Vehicle')}: <b>${esc(hit.name||im)}</b> — <code>${esc(String(hit.id||hit._id))}</code>`,
            html:`<div class="note sig" style="margin-top:8px">${t(
              'الـ IMEI اتحوّل لرقم العربية — ده اللي بيتحط في resources، مش الـ IMEI.',
              'The IMEI was resolved to the unit id — that is what goes into resources, not the IMEI.')}</div>`,
            vars:{scope: String(hit.name||im)}};
          return renderSteps();
        }
        RC.vars.resources = all.map(u=>String(u.id||u._id||'')).filter(Boolean);
        RC.vars.scopeLabel = t('كل الحساب','the whole account');
        RC.results[i] = {ok: RC.vars.resources.length > 0,
          msg: RC.vars.resources.length
            ? `${t('النطاق','Scope')}: <b>${t('كل الحساب','the whole account')}</b> — ${RC.vars.resources.length} ${t('عربية','vehicles')}`
            : t('الحساب مفيهوش عربيات ظاهرة.','No vehicles are visible on this account.'),
          vars:{scope: RC.vars.resources.length + ' ' + t('عربية','vehicles')}};
        return renderSteps();
      }catch(err){
        RC.results[i] = {ok:false, msg:t('ما قدرناش نجيب العربيات: ','Could not fetch the vehicles: ')
          + esc(String(err && err.message || err).slice(0,140))};
        return renderSteps();
      }
    })();
    return;
  }""", 1, 'النطاق تلقائي')

# ── ٥) الخلاصة والرد الجاهز في الآخر ────────────────────────
HELPER = r"""
/* بعد ما السلسلة تخلص لوحدها: الأرقام اللي طلعت، ورد جاهز للعميل
   مبني على اللي حصل فعلًا مش على كلام عام. */
function summaryWrap(r){
  const rowsStep = r.steps.findIndex(s => s.kind === 'rows');
  const res = RC.results[rowsStep];
  const rows = (res && res.json) ? reportRows(res.json) : [];
  const host = $('rcSteps');
  if(!host) return;
  const old = document.getElementById('rcWrap'); if(old) old.remove();

  const box = document.createElement('div');
  box.id = 'rcWrap';
  box.className = 'panel';
  box.style.marginTop = '14px';
  box.innerHTML = `<div class="sec" style="border-top:0">
      <div class="crumb">${t('الخلاصة','The outcome')}</div>
      <div style="font-size:15px; font-weight:600; margin-top:5px; line-height:1.7">${
        rows.length
          ? t(`السلسلة مشيت لآخرها ورجعت ${rows.length} صف من الحساب المتصل.`,
              `The chain ran to the end and returned ${rows.length} rows from the connected account.`)
          : t('السلسلة مشيت لآخرها والصفوف رجعت فاضية — العربية ما تحركتش في الفترة دي.',
              'The chain ran to the end and the rows came back empty — the vehicle did not move in this period.')}</div>
      <div class="note" style="margin-top:8px">${t('النطاق','Scope')}: <b>${esc(RC.vars.scopeLabel||'—')}</b>
        · ${t('الفترة','Period')}: <code>${esc(RC.vars.from||'—')}</code> → <code>${esc(RC.vars.to||'—')}</code>
        · ${t('رقم التقرير','Report id')}: <code>${esc(RC.vars.reportId||'—')}</code></div>
      <div class="row" style="margin-top:12px">
        <button class="btn sig" id="rcReplyCopy">${t('انسخ رد للعميل','Copy the customer reply')}</button>
        <button class="btn ghost" id="rcWrapPm">${t('كولكشن للعميل','Collection for the customer')}</button>
      </div>
      <pre class="pre" id="rcReplyTxt" style="white-space:pre-wrap; direction:ltr; text-align:left; margin-top:10px">${esc(summaryReply(rows))}</pre>
    </div>`;
  host.parentNode.appendChild(box);
  clipBlocks(box);
  const cp = document.getElementById('rcReplyCopy');
  if(cp) cp.onclick = ()=>copyText(document.getElementById('rcReplyTxt').textContent,
                                   t('الرد اتنسخ','Reply copied'));
  const pb = document.getElementById('rcWrapPm');
  if(pb) pb.onclick = ()=>pmSave(pmFromRecipe(RC.r), (RC.r.id||'recipe'));
  box.scrollIntoView({behavior:'smooth', block:'start'});
}

/* الرد بيتكتب من اللي حصل فعلًا: عدد الصفوف، والأعمدة اللي رجعت */
function summaryReply(rows){
  const cols = rows.length ? Object.keys(rows[0]).filter(k=>typeof rows[0][k]!=='object').slice(0,8) : [];
  const L = [];
  L.push('Hello,');
  L.push('');
  L.push('Report values do not come from the catalog endpoints. /reports/lists and');
  L.push('/user_report_templates/lists return report definitions — column names, codes and');
  L.push('aggregation. They describe a report; they never run one.');
  L.push('');
  L.push('Retrieving the values is a chain of four calls, in this order:');
  L.push('');
  L.push('  1. POST /user_reports/add          creates and runs the report, returns its id');
  L.push('  2. POST /user_reports/percentage   generation progress; repeat until it is 100');
  L.push('  3. POST /user_reports/data-summary the aggregated summary, one row per vehicle');
  L.push('  4. POST /user_reports/data-new     the detail behind one vehicle, by resource_id');
  L.push('');
  L.push('Step 2 is the one that is easy to miss and it is where most integrations stall.');
  L.push('The report is generated asynchronously, so straight after step 1 the rows do not');
  L.push('exist yet. Reading them at that moment returns an empty data array with');
  L.push('status_code 200 and message success — a valid response that looks like a failure.');
  L.push('');
  L.push('Two details worth stating plainly:');
  L.push('');
  L.push('  · resources takes vehicle ids, not IMEIs. If you hold IMEIs, resolve them first');
  L.push('    with POST /units/lists and take the id of each matching unit.');
  L.push('  · /user_reports/lists returns the ids of reports that already exist, but their');
  L.push('    data belongs to the period and vehicles they were created with. For a');
  L.push('    different period you need a new /user_reports/add rather than a lookup.');
  L.push('');
  if(rows.length){
    L.push('We ran this chain end to end on the account and it returned ' + rows.length + ' row(s).');
    if(cols.length) L.push('The keys in the response are: ' + cols.join(', ') + '.');
  } else {
    L.push('We ran this chain end to end on the account. It completed and returned no rows,');
    L.push('which means the vehicles did not move during the period requested rather than');
    L.push('that anything failed.');
  }
  L.push('');
  L.push('A Postman collection with the whole sequence is attached. Fill in the collection');
  L.push('variables and run the requests in order, or use the Runner — the token, user id,');
  L.push('unit id and report id are carried between the requests automatically, and the');
  L.push('progress request loops on its own until generation completes.');
  L.push('');
  L.push('Please try it and tell us what comes back if anything differs.');
  L.push('');
  L.push('Best regards,');
  return L.join('\n');
}
"""
rep("async function doRScope(i){", HELPER.lstrip('\n') + "\nasync function doRScope(i){", 1, 'الخلاصة والرد')

io.open(PATH, 'w', encoding='utf-8').write(src)
print('\ndone (%d -> %d, +%d)' % (orig, len(src), len(src) - orig))
