#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v6.0 — إنهاء الترجمة: كل نص المستخدم بيشوفه له مقابل، والكسور اتصلحت."""
import sys
P='app_template.html'; s=open(P,encoding='utf-8').read()
miss=[]; done=[]
def rep(old,new,label,cnt=1):
    global s
    c=s.count(old)
    if c!=cnt: miss.append(f'{label} (لقيت {c})'); return
    s=s.replace(old,new); done.append(label)

# ===== ١) الفاصلة العليا المكسورة في خانة البحث =====
rep('data-enph="Type the customer\\u0027s question… e.g. how do I list vehicles"',
    'data-enph="Type the customer&#39;s question — e.g. how do I list vehicles"',
    '١) الفاصلة العليا في خانة البحث')

# ===== ٢) نصوص ثابتة في الصفحة من غير مقابل =====
for lbl,(old,ar,en) in {
 '٢أ) زرار التثبيت':   ('id="instGo" style="background:#00707F; border-color:#00707F; padding:6px 16px">تثبيت</button>','تثبيت','Install'),
 '٢ب) رفض التثبيت':   ('id="instSkip" style="color:#8FA6B4; border-color:#33475C; padding:6px 12px">لأ شكرًا</button>','لأ شكرًا','No thanks'),
 '٢ج) زرار التحديث':  ('id="updGo" style="background:#fff; color:#00707F; border-color:#fff; padding:6px 16px">تحديث</button>','تحديث','Update'),
 '٢د) تأجيل التحديث': ('id="updSkip" style="color:#CFF0F2; border-color:#4E9AA3; padding:6px 12px">بعدين</button>','بعدين','Later'),
}.items():
    rep(old, old.replace('>'+ar+'</button>', f' data-ar="{ar}" data-en="{en}">{ar}</button>'), lbl)

rep('<option value="__custom">أخرى…</option>',
    '<option value="__custom" data-ar="أخرى…" data-en="Other…">أخرى…</option>', '٢هـ) خيار بيئة أخرى')
rep('<option value="">— حسابات محفوظة —</option>',
    '<option value="" data-ar="— حسابات محفوظة —" data-en="— saved accounts —">— حسابات محفوظة —</option>',
    '٢و) عنوان لستة الحسابات')
rep('<span id="sesState" class="pill">غير متصل</span>',
    '<span id="sesState" class="pill" data-ar="غير متصل" data-en="Not connected">غير متصل</span>',
    '٢ز) حالة الاتصال')

# ===== ٣) أسماء صيغ التصحيح التلقائي — كانت عربي في الوضع الإنجليزي =====
VAR = {
 'الشكل المرصود من المنصة':'The shape observed from the platform',
 'زي ما هو في الكولكشن':'Exactly as in the collection',
 'مع هيدر القبول':'With the Accept header',
 'تغليف البودي في data':'Body wrapped in data',
 'فك التغليف المزدوج':'Double wrapping removed',
 'من غير projection':'Without projection',
 'الأرقام كنصوص':'Numbers sent as strings',
 'أقل بودي ممكن':'Smallest possible body',
 'data كنص JSON':'data as a JSON string',
 'form-encoded زي المنصة':'form-encoded like the platform',
 'بودي فاضي':'Empty body',
}
i0=s.find('function labVariants'); i1=s.find('\n}', s.find('return out;', i0))
if i0<0 or i1<0: miss.append('٣) مكان labVariants')
else:
    seg=s[i0:i1]; n=0
    for ar,en in VAR.items():
        old=f"n:'{ar}'"; new=f"n:t('{ar}','{en}')"
        n+=seg.count(old); seg=seg.replace(old,new)
    s=s[:i0]+seg+s[i1:]; done.append(f'٣) أسماء الصيغ ({n} موضع)')

# ===== ٤) رسايل تشغيل المجموعة =====
rep("msg: r.ok?'':((r.json&&r.json.message)||('حالة '+r.code))});",
    "msg: r.ok?'':((r.json&&r.json.message)||(t('حالة ','Status ')+r.code))});", '٤أ) حالة الرد')
rep("msg:'المتصفح ما وصلش للسيرفر'}); }",
    "msg:t('المتصفح ما وصلش للسيرفر','The browser could not reach the server')}); }", '٤ب) فشل الشبكة')

# ===== ٥) كلمة التأكيد بالإنجليزي =====
rep("<b>نفّذ</b> ${t('في الخانة ودوس تأكيد.','in the box, then press confirm.')}",
    "<b>${t('نفّذ','RUN')}</b> ${t('في الخانة ودوس تأكيد.','in the box, then press confirm.')}",
    '٥أ) كلمة التأكيد المعروضة')
rep("if(v === 'نفّذ' || v === 'نفذ') tryItRun(e, out, true);",
    "if(v === 'نفّذ' || v === 'نفذ' || v.toUpperCase() === 'RUN') tryItRun(e, out, true);",
    '٥ب) قبول RUN')

# ===== ٦) بوابة الدخول (مطفية افتراضيًا) بلغة الجهاز =====
rep("function authGate(done){\n  if(!AUTH.enabled) return done();",
    """function authGate(done){
  if(!AUTH.enabled) return done();
  /* البوابة بتظهر قبل ما الأداة تحمّل، فمفيش زرار لغة لسه — بنمشي على لغة المتصفح */
  const gEn = String((navigator.language || navigator.userLanguage || 'ar')).slice(0,2) !== 'ar';
  const g = (ar, en) => gEn ? en : ar;""",
    '٦أ) لغة البوابة')
# البوابة: استبدالات صريحة بعدّاد — الشرط المرن قبل كده كان بيعدّي على استبدال فاضي ويقول تمام
rep(">مساعد الإنتجريشن</div>'+", ">'+g('مساعد الإنتجريشن','Integration Helper')+'</div>'+", '٦ب) عنوان البوابة')
rep(">دعم أفاقي — استخدام داخلي</div>'+", ">'+g('دعم أفاقي — استخدام داخلي','Afaqy support — internal use')+'</div>'+", '٦ج) سطر البوابة')
rep('<input id="gEmail" placeholder="إيميل الشغل"', '<input id="gEmail" placeholder=\'+g(\'إيميل الشغل\',\'Work email\')+\'', '٦د) خانة الإيميل')
rep('<input id="gPass" type="password" placeholder="كلمة السر"', '<input id="gPass" type="password" placeholder=\'+g(\'كلمة السر\',\'Password\')+\'', '٦هـ) خانة كلمة السر')
rep(">دخول</button>", ">'+g('دخول','Sign in')+'</button>", '٦و) زرار الدخول')
rep("\"Segoe UI\",Tahoma,Arial,sans-serif; direction:rtl'", "\"Segoe UI\",Tahoma,Arial,sans-serif; direction:'+(gEn?'ltr':'rtl')", '٦ز) اتجاه البوابة')
for lbl,old,en in [
 ('٦ز) بيتأكد',"err.textContent='بيتأكد…';","Checking…"),
 ('٦ح) الدومين',"err.textContent='الإيميل لازم يكون على '+AUTH.allowedDomain; return;","The email must be on "),
 ('٦ط) بيانات غلط',"? 'البيانات غلط، أو الحساب مش متعمل لسه.' : 'ما قدرناش نتحقق: '+(e.code||e.message); });","x"),
 ('٦ي) مكتبة',"document.getElementById('gErr').textContent='ما قدرناش نحمّل مكتبة الدخول — اتأكد من النت.';","x"),
]:
    if lbl.startswith('٦ز'): new="err.textContent=g('بيتأكد…','Checking…');"
    elif lbl.startswith('٦ح'): new="err.textContent=g('الإيميل لازم يكون على ','The email must be on ')+AUTH.allowedDomain; return;"
    elif lbl.startswith('٦ط'): new="? g('البيانات غلط، أو الحساب مش متعمل لسه.','Wrong credentials, or the account is not set up yet.') : g('ما قدرناش نتحقق: ','Could not verify: ')+(e.code||e.message); });"
    else: new="document.getElementById('gErr').textContent=g('ما قدرناش نحمّل مكتبة الدخول — اتأكد من النت.','Could not load the sign-in library — check the network.');"
    rep(old,new,lbl)

for d in done: print('تمام:',d)
if miss:
    print('!! MISS:'); [print('  ',x) for x in miss]; sys.exit(1)
open(P,'w',encoding='utf-8').write(s)
print(f'اتكتب — {len(done)} تعديل')
