/* اختبارات بانل «حساسات الجهاز» — يتصل بـ /unit_sensors/lists مفلتر
   بـ unit_id بس، ويوري بس اللي رجع فعلًا، مش قايمة عامة. */
const fs = require('fs');
const { JSDOM } = require('jsdom');

let FAILED = 0;
const fail = m => { console.log('  ✗ ' + m); FAILED++; };
const pass = m => console.log('  ✓ ' + m);
const strip = h => String(h || '').replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ');

function buildHtml(){
  return fs.readFileSync('app_template.html', 'utf8')
    .replace('/*__KB__*/',   fs.readFileSync('kb_slim.json', 'utf8'))
    .replace('/*__DOCS__*/', fs.readFileSync('docs.json', 'utf8'))
    .replace('/*__KBIN__*/', fs.readFileSync('kb_in.json', 'utf8'));
}

function boot(fetchImpl){
  const dom = new JSDOM(buildHtml(), { runScripts: 'dangerously', pretendToBeVisual: true, url: 'https://localhost/' });
  const w = dom.window;
  w.alert = () => {}; w.confirm = () => true; w.scrollTo = () => {};
  if (fetchImpl) w.fetch = fetchImpl;
  w.eval(`SESSION.token='TOK'; SESSION.user='Opp'; SESSION.userId='000000000000000000000001';`);
  return w;
}

function seedUnits(w, units){
  w.eval(`DASH.units = ${JSON.stringify(units)}; DASH.filter=null; DASH.flag=null;
          DASH.scope=null; DASH.state=null; DASH.sensorUnit=null; DASH.sensorResult={};
          DASH.at = new Date();`);
  w.showView('dash');
  w.dashRender();
}

const GPS_UNIT = { id: 'unitA1', name: 'GPS Truck 1', device_type: 'gps', imei: '111111111111111' };
const STAT_UNIT = { id: 'unitB2', name: 'Cold Room Sensor', device_type: 'stationary', imei: '222222222222222' };

/* ═════ ١) دوسة على صف تفتح البانل، وتاني دوسة تقفله ═════ */
console.log('\n١) دوسة الصف بتفتح البانل وتقفله');
{
  const w = boot();
  seedUnits(w, [GPS_UNIT, STAT_UNIT]);
  const d = w.document;
  let row = d.querySelector('[data-unit="unitA1"]');
  if (!row) fail('صف الجهاز مش موجود في الجدول');
  else pass('صف الجهاز موجود وقابل للدوسة');

  row.click();
  if (w.eval('DASH.sensorUnit') !== 'unitA1') fail('الدوسة ما اختارتش الجهاز');
  else pass('الدوسة اختارت الجهاز');
  if (!d.querySelector('#sensorGo')) fail('زرار التحقق ما ظهرش بعد الاختيار');
  else pass('زرار التحقق ظهر');

  row = d.querySelector('[data-unit="unitA1"]');
  row.click();
  if (w.eval('DASH.sensorUnit') !== null) fail('الدوسة التانية ما قفلتش البانل');
  else pass('الدوسة التانية قفلت البانل (toggle)');
}

/* ═════ ٢) جهاز مفيهوش حساسات — رد فاضي واضح مش خطأ ═════ */
console.log('\n٢) جهاز GPS بسيط من غير حساسات — رد فاضي مفهوم');
{
  const calls = [];
  const fetchMock = (url, opt) => {
    calls.push({ url: String(url), body: opt && opt.body ? JSON.parse(opt.body) : {} });
    return Promise.resolve({ ok: true, status: 200, text: () => Promise.resolve('{"data":[]}') });
  };
  const w = boot(fetchMock);
  seedUnits(w, [GPS_UNIT]);
  const d = w.document;
  d.querySelector('[data-unit="unitA1"]').click();
  d.querySelector('#sensorGo').click();

  setTimeout(() => {
    const call = calls.find(c => /\/unit_sensors\/lists/.test(c.url));
    if (!call) fail('ما نادتش /unit_sensors/lists خالص');
    else pass('نادى /unit_sensors/lists');
    if (!call || !call.body.data || !call.body.data.filters || call.body.data.filters.unit_id !== 'unitA1')
      fail('البودي ما فيهوش unit_id الجهاز المختار');
    else pass('البودي مفلتر بـ unit_id بتاع الجهاز ده بالظبط');

    const txt = strip(d.getElementById('dashOut').innerHTML);
    if (txt.indexOf('مفيش حساسات مسجّلة') < 0) fail('الرد الفاضي ما اتفسّرش بوضوح إنه صحيح مش خطأ');
    else pass('وضّح إن الرد الفاضي صحيح ومش نقص في الأداة');
    if (/فشل|error/i.test(txt)) fail('عامل الرد الفاضي كأنه خطأ');
    else pass('ما عاملش الرد الفاضي كخطأ');

    run3();
  }, 300);
}

/* ═════ ٣) جهاز عليه حساسات حقيقية — بتتعرض بالاسم والنوع، مش قايمة عامة ═════ */
function run3(){
  console.log('\n٣) جهاز وحدة ثابتة عليه حساسات فعلية');
  const calls = [];
  const fetchMock = (url, opt) => {
    calls.push({ url: String(url), body: opt && opt.body ? JSON.parse(opt.body) : {} });
    if (/\/unit_sensors\/lists/.test(url)) {
      return Promise.resolve({ ok: true, status: 200, text: () => Promise.resolve(JSON.stringify({
        data: [
          { id: 's1', name: 'Cold Room Temp', type: 'temp', param: 'ain1', unit_id: 'unitB2' },
          { id: 's2', name: 'Door Sensor', type: 'door', param: 'di3', unit_id: 'unitB2' }
        ]
      })) });
    }
    return Promise.resolve({ ok: true, status: 200, text: () => Promise.resolve('{"data":{}}') });
  };
  const w = boot(fetchMock);
  seedUnits(w, [STAT_UNIT]);
  const d = w.document;
  d.querySelector('[data-unit="unitB2"]').click();
  d.querySelector('#sensorGo').click();

  setTimeout(() => {
    const txt = strip(d.getElementById('dashOut').innerHTML);
    ['Cold Room Temp', 'Door Sensor', 'temp', 'door', 'ain1', 'di3'].forEach(k => {
      if (txt.indexOf(k) < 0) fail('البانل ما وريش ' + k);
    });
    pass('البانل وري الحساسين الحقيقيين بالاسم والنوع والباراميتر');
    if (txt.indexOf('2 حساس') < 0 && txt.indexOf('2 sensor') < 0)
      fail('العداد ما قالش إن دول حساسين بالظبط');
    else pass('العداد وضّح العدد الحقيقي');
    /* الكلمات دي بتظهر في المنصة الحقيقية للأجهزة كلها — ما ينفعش تفضل هنا
       كقايمة عامة، لازم تكون بس اللي رجع فعلًا للجهاز ده */
    ['بطارية السيارة', 'الاستغاثة', 'الوزن', 'المجموعة'].forEach(generic => {
      if (txt.indexOf(generic) >= 0) fail('ظهرت كلمة من القايمة العامة القديمة: ' + generic);
    });
    pass('مفيش أثر لقايمة تشيك بوكس عامة — البانل حقيقي بس');
    run4();
  }, 300);
}

/* ═════ ٤) إعادة تحميل العربيات بتصفّر الاختيار ═════ */
function run4(){
  console.log('\n٤) تحميل العربيات من جديد يصفّر اختيار الجهاز');
  const w = boot();
  seedUnits(w, [GPS_UNIT]);
  w.document.querySelector('[data-unit="unitA1"]').click();
  if (w.eval('DASH.sensorUnit') !== 'unitA1') fail('الإعداد الأولي فشل'); 
  w.eval(`DASH.sensorUnit=null; DASH.sensorResult={}; DASH.sensorBusy=null;`); // نفس اللي بيحصل جوه dashLoadUnits
  if (w.eval('DASH.sensorUnit') !== null) fail('التصفير ما شتغلش');
  else pass('اختيار الجهاز اتصفّر مع إعادة التحميل');

  console.log(FAILED ? `\n✗ ${FAILED} اختبار وقع` : '\n✓ كل الاختبارات عدّت');
  process.exit(FAILED ? 1 : 0);
}
