/* فحوصات المتانة: سباق الردود، وحقن HTML من ملف مستورد، وعنوان البيئة */
const fs=require('fs');
const R={};
function el(id){return{id,hidden:false,innerHTML:'',value:'',textContent:'',className:'',dataset:{},style:{},files:[],disabled:false,
 classList:{toggle(){},add(){},remove(){}},querySelectorAll(){return[]},addEventListener(){},focus(){},select(){},click(){},
 setAttribute(){},getAttribute(){return null},dispatchEvent(){},appendChild(){},remove(){},scrollIntoView(){},onclick:null}}
global.document={documentElement:el(),body:el(),addEventListener(){},querySelectorAll(){return[]},
 querySelector(){return null},createElement(){return el()},getElementById(i){return R[i]||(R[i]=el(i))}};
global.history={pushState(){},replaceState(){}};global.location={hash:'',pathname:'/',replace(){},reload(){}};
global.setInterval=()=>0;global.navigator={clipboard:{writeText(){return Promise.resolve()}}};
global.window={scrollTo(){},addEventListener(){}};
global.AbortController=function(){this.signal={};this.abort=()=>{}};
global.Blob=function(){};global.URL={createObjectURL(){return''}};global.FileReader=function(){};

let DELAY=0, BODY={message:'success',status_code:200,data:{n:1}};
global.fetch=()=>new Promise(res=>setTimeout(()=>res({ok:true,status:200,
  text:()=>Promise.resolve(JSON.stringify(BODY))}), DELAY));

let js=fs.readFileSync('app_template.html','utf8').split('<script>')[1].split('</script>')[0]
 .replace('/*__KB__*/',fs.readFileSync('kb_slim.json','utf8')).replace('/*__KBIN__*/', fs.readFileSync('kb_in.json','utf8'))
 .replace('/*__DOCS__*/',fs.readFileSync('docs.json','utf8'));
const m={};new Function('module',js+
 "\nmodule.exports={EPS,SESSION,tryItRun,esc,baseUrlOk,LEARNED,seq:()=>RUN_SEQ,bump:()=>{RUN_SEQ++}};")(m);
const A=m.exports;
const fail=s=>{console.error('فشل: '+s);process.exit(1)};

(async()=>{
  A.SESSION.token='T'; A.SESSION.user='u'; A.SESSION.pass='p';
  const e1=A.EPS.find(x=>x.p==='/units/lists');
  const out=document.getElementById('tryout');

  // رد بطيء لريكوست قديم ما يكتبش فوق الجديد
  DELAY=60; BODY={message:'OLD_RESPONSE',status_code:200};
  const slow = A.tryItRun(e1, out);
  A.bump();                                  // المستخدم فتح ريكوست تاني
  out.innerHTML = 'الشاشة الجديدة';
  await slow;
  if(out.innerHTML.indexOf('OLD_RESPONSE')>=0) fail('رد قديم كتب فوق الشاشة الجديدة');
  if(out.innerHTML !== 'الشاشة الجديدة') fail('الشاشة الجديدة اتغيّرت');
  console.log('سباق الردود           : الرد القديم اتجاهل ✓');

  // حقن HTML من ملف معرفة مستورد
  const evil = '<img src=x onerror=alert(1)>';
  if(A.esc(evil).indexOf('<img')>=0) fail('esc مش بيشيل الوسوم');
  console.log('حقن HTML              : esc بيشيل الوسوم ✓');

  // عنوان البيئة
  document.getElementById('baseUrl').value='__custom';
  const cases=[['https://api.afaqy.sa',true],['http://1.2.3.4:8080',true],
               ['api.afaqy.sa',false],['https://a.com/path',false],['مش لينك',false]];
  cases.forEach(([u,want])=>{
    document.getElementById('baseCustom').value=u;
    if(A.baseUrlOk()!==want) fail('عنوان البيئة: '+u+' المفروض '+(want?'مقبول':'مرفوض'));
  });
  console.log('فحص عنوان البيئة      : '+cases.length+' حالات ✓');
})();
