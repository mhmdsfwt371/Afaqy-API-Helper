/* v7.4 — إيميل Outlook (.msg/.eml) من غير لقطة شاشة، وحالات شبيهة محلية من غير ما نص العميل يتحفظ. */
const fs=require('fs'); const {JSDOM}=require('jsdom');
let F=0; const ok=(m,c,x)=>{ console.log((c?'  \u2713 ':'  \u2717 ')+m+(c||!x?'':'  \u2014 '+String(x).slice(0,180))); if(!c) F++; };
const html=fs.readFileSync(process.argv[2]||'app_template.html','utf8')
  .replace('/*__KB__*/',()=>fs.readFileSync('kb_slim.json','utf8'))
  .replace('/*__DOCS__*/',()=>fs.readFileSync('docs.json','utf8'))
  .replace('/*__KBIN__*/',()=>fs.readFileSync('kb_in.json','utf8'))
  .replace('/*__MSGREADER__*/',()=>fs.readFileSync('vendor_msgreader.min.js','utf8'));
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
function boot(){ const w=new JSDOM(html,{runScripts:'dangerously',pretendToBeVisual:true,url:'https://localhost/'}).window;
  w.alert=()=>{}; w.scrollTo=()=>{}; w.TextDecoder=require('util').TextDecoder; w.TextEncoder=require('util').TextEncoder;
  w.showView('inspect'); w.eval("INSPVIEW='case'"); w.paintInspect(); return w; }
const fileOf=(w,buf,name,type)=>{ const u8=new Uint8Array(buf); const f=new w.File([u8],name,{type:type||''}); f.arrayBuffer=async()=>u8.buffer.slice(u8.byteOffset,u8.byteOffset+u8.byteLength); return f; };
(async()=>{
/* ١) .msg حقيقي من Outlook */
{ const w=boot();
  ok('قارئ .msg موجود جوه الأداة', typeof w.AfaqyMsgReader==='function');
  const m=await w.mailParse(fileOf(w, fs.readFileSync('testdata/Hello__CJK.msg'), 'Hello +CJK.msg'));
  ok('.msg: الموضوع والنص بالحرف (يونيكود)', m.subject==='Hello +CJK' && /你好/.test(m.body) && /안녕하세요/.test(m.body), JSON.stringify(m).slice(0,160));
  const m2=await w.mailParse(fileOf(w, fs.readFileSync('testdata/attachAndInline.msg'), 'a.msg'));
  ok('.msg: المرفقات بأسماءها ومحتواها', m2.atts.length===2 && m2.atts.some(a=>a.name==='attach.png' && a.data.length===1558) && m2.atts.some(a=>a.type==='image/png'));
}
/* ٢) .eml بعربي ومرفق صورة كبيرة */
{ const w=boot();
  const png=Buffer.alloc(20000, 7); png.write('\x89PNG\r\n\x1a\n', 0, 'binary');
  const bodyAr=Buffer.from('السادة المحترمين،\nلما بنستخدم /units/locations بالـ unit_id 861230044934025 بيرجع not_allowed.\n','utf8').toString('base64');
  const eml=['From: =?utf-8?B?'+Buffer.from('فريق التكامل','utf8').toString('base64')+'?= <it@example.com>','Subject: =?utf-8?Q?API_error_=E2=80=94_last_location?=','MIME-Version: 1.0',
    'Content-Type: multipart/mixed; boundary="B1"','','--B1','Content-Type: text/plain; charset=utf-8','Content-Transfer-Encoding: base64','',bodyAr,'--B1',
    'Content-Type: image/png; name="shot.png"','Content-Disposition: attachment; filename="shot.png"','Content-Transfer-Encoding: base64','',png.toString('base64'),'--B1--',''].join('\r\n');
  const m=await w.mailParse(fileOf(w, Buffer.from(eml,'binary'), 'x.eml'));
  ok('.eml: الموضوع والمرسل بعد فك =?utf-8?…?=', m.subject==='API error — last location' && /فريق التكامل/.test(m.from), m.subject+' | '+m.from);
  ok('.eml: النص العربي (base64) بالحرف', /السادة المحترمين/.test(m.body) && /861230044934025/.test(m.body));
  ok('.eml: المرفق اتفك بحجمه', m.atts.length===1 && m.atts[0].name==='shot.png' && m.atts[0].data.length===20000);
  /* الإدخال الكامل: النص في الخانة، والصورة بتتقري، والتحليل بيشتغل */
  w.ocrImage=async()=>({isTicket:false, text:'{"message":"not_allowed","status_code":401}'});
  await w.mailIngest(fileOf(w, Buffer.from(eml,'binary'), 'x.eml')); await sleep(40);
  const v=w.document.getElementById('caseText').value;
  ok('الخانة فيها الموضوع والنص والمرفق المقروء', /^Subject: API error/.test(v) && /السادة المحترمين/.test(v) && /\[shot\.png\]\n\{"message":"not_allowed"/.test(v), v.slice(0,200));
  ok('التحليل اشتغل (IMEI مكان رقم العربية)', /IMEI/.test(w.document.getElementById('caseOut').textContent));
  ok('الصندوق بيقول اتقرا الإيميل والصورة', /اتقرا الإيميل/.test(w.document.getElementById('caseImgBox').textContent) && /shot\.png/.test(w.document.getElementById('caseImgBox').textContent));
}
/* ٣) ملف مش إيميل */
{ const w=boot(); await w.mailIngest(fileOf(w, Buffer.from('just text'), 'x.eml')); await sleep(20);
  ok('ملف مش إيميل: رسالة واضحة من غير ما يقع', /اتقرا الإيميل|ما قدرناش نقرا الملف/.test(w.document.getElementById('caseImgBox').textContent)); }
/* ٤) حالات شبيهة: الحفظ والظهور */
{ const w=boot();
  const T1='Dear team, Acme Logistics here (contact: Ahmed). POST /units/locations {"data":{"unit_id":"861230044934025"}} returns {"message":"not_allowed","status_code":401}';
  w.document.getElementById('caseText').value=T1; w.document.getElementById('caseGo').click(); await sleep(40);
  ok('تحت الرد: «احفظ الحالة دي للفريق»', !!w.document.getElementById('caseKeep'));
  w.document.getElementById('caseKeep').click();
  const k=w.eval("ADDED[ADDED.length-1]");
  ok('اتحفظت كحالة بالرد والبصمة', k.kind==='case' && /UID/.test(k.reply) && k.sig.paths.includes('/units/locations') && k.sig.errs.includes('not_allowed') && k.sig.mk.includes('imei15'));
  const blob=JSON.stringify(k);
  ok('نص رسالة العميل ما اتحفظش (مفيش اسم الشركة ولا الشخص)', !/acme|logistics|ahmed/i.test(blob), k.sig.tok.join(','));
  ok('البصمة كلمات تقنية بس', k.sig.tok.every(x=>w.eval('caseVocab()').has(x)));
  /* بعد إعادة التحميل البصمة والرد فاضلين */
  const raw=w.localStorage.getItem('afaqy.added.v1');
  const w2=new JSDOM(html,{runScripts:'dangerously',pretendToBeVisual:true,url:'https://localhost/',beforeParse(win){ win.localStorage.setItem('afaqy.added.v1', raw); }}).window;
  w2.alert=()=>{}; w2.scrollTo=()=>{};
  const k2=w2.eval("ADDED.find(x=>x.kind==='case')");
  ok('بعد الفتح تاني: الحالة بالبصمة والرد', k2 && k2.reply===k.reply && k2.sig.paths[0]==='/units/locations');
  /* رسالة شبيهة من عميل تاني */
  w2.showView('inspect'); w2.eval("INSPVIEW='case'"); w2.paintInspect();
  const T2='Hello, our developers call /units/locations with unit_id 357454075086551 and get not_allowed (status_code 401). Please advise.';
  w2.document.getElementById('caseText').value=T2; w2.document.getElementById('caseGo').click(); await sleep(40);
  ok('رسالة شبيهة: «حالة شبيهة اتحلّت قبل كده» فوق بالرد', /حالة شبيهة اتحلّت قبل كده/.test(w2.document.getElementById('caseOut').textContent) && !!w2.document.querySelector('[data-simcopy]'));
  /* رسالة مختلفة */
  w2.document.getElementById('caseText').value='Can we send the token in an Authorization header?'; w2.document.getElementById('caseGo').click(); await sleep(40);
  ok('رسالة مختلفة: مفيش حالة شبيهة', !/حالة شبيهة اتحلّت/.test(w2.document.getElementById('caseOut').textContent));
  ok('نفس الرد مرتين ما يتحفظش', w.caseKeep(T1,'x')==='dup');
}
/* ٥) Claude ما بيزحمش من غير مفتاح */
{ const w=boot();
  ok('من غير مفتاح: زرار Claude مستخبي والإعدادات مقفولة', w.document.getElementById('aiGo').hidden && w.document.getElementById('aiSet').hidden);
  w.document.getElementById('caseText').value='How long do you keep historical data?'; w.document.getElementById('caseGo').click(); await sleep(30);
  const o=w.document.getElementById('caseOut').textContent;
  ok('القواعد ما عرفتش: الاقتراح بيوجّه للريكوستات والتصعيد والحفظ — مش لمفتاح', /صعّدها/.test(o) && !/مفتاح Anthropic/.test(o));
  w.showView('search'); w.eval("lastQ='webhook callbacks for alarms'"); w.emptyState('x');
  ok('البحث من غير مفتاح: «اسأل Claude» مستخبي والتصعيد موجود', w.document.getElementById('aiAsk0').hidden && !!w.document.getElementById('escal0'));
}
console.log(F?`\nفشل ${F}`:'\nالإيميل والحالات الشبيهة: تمام'); process.exit(F?1:0);
})();
