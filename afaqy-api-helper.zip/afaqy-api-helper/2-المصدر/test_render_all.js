/* v6.2 — اختبار «ارسم كل حاجة باللغتين».
   بيقلّب الأداة كلها عربي ثم إنجليزي، ويلمّ كل اللي اترسم، ويدوّر على:
   عربي مندسّ في الوضع الإنجليزي، قيم مكسورة، وسوم متنفذة من بيانات السيرفر،
   وأي {ar} في بيانات السيناريوهات والفرز من غير {en}. */
global.setInterval=()=>0;global.clearInterval=()=>{};
const fs = require('fs');
const R = {};
function el(id){return{id,hidden:false,innerHTML:'',value:'',textContent:'',className:'',dataset:{},style:{},files:[],disabled:false,
 options:[],classList:{toggle(){},add(){},remove(){}},querySelectorAll(){return[]},addEventListener(){},focus(){},select(){},click(){},
 setAttribute(){},getAttribute(){return null},dispatchEvent(){},appendChild(){},remove(){},scrollIntoView(){},title:''}}
global.document={documentElement:el('html'),body:el('body'),addEventListener(){},querySelectorAll(){return[]},
 querySelector(){return null},createElement(){return el()},getElementById:i=>R[i]||(R[i]=el(i))};
global.history={pushState(){},replaceState(){}};global.location={hash:'',pathname:'/',replace(){}};
global.navigator={userAgent:'node',language:'ar',clipboard:{writeText(){return Promise.resolve()}}};
global.window={scrollTo(){},addEventListener(){},matchMedia:()=>({matches:false}),navigator:{}};
global.fetch=()=>Promise.reject(0);global.Blob=function(){};global.URL={createObjectURL(){return''}};global.FileReader=function(){};
global.btoa=x=>Buffer.from(x,'binary').toString('base64');global.atob=x=>Buffer.from(x,'base64').toString('binary');
const DISK={};global.localStorage={getItem:k=>(k in DISK?DISK[k]:null),setItem:(k,v)=>{DISK[k]=String(v);},removeItem:k=>{delete DISK[k];}};
global.sessionStorage={getItem:()=>null,setItem(){},removeItem(){}};
global.confirm=()=>false;

let js = fs.readFileSync('app_template.html','utf8').split('<script>')[1].split('</script>')[0]
  .replace('/*__KB__*/', fs.readFileSync('kb_slim.json','utf8')).replace('/*__KBIN__*/', fs.readFileSync('kb_in.json','utf8'))
  .replace('/*__DOCS__*/', fs.readFileSync('docs.json','utf8'));
const m={};
new Function('module', js + "\nmodule.exports={setLang,renderDetail,userCard,openEscalation,EPS,RECIPES,TRIAGE,SESSION};")(m);
const A = m.exports;
const fail = msg => { console.error('فشل: ' + msg); process.exit(1); };
const AR = /[\u0600-\u06FF]/g;

function snapshot(){
  return Object.values(R).map(e => [e.innerHTML, e.textContent, e.value].join(' ')).join('\n');
}
function renderEverything(lang){
  for(const k in R) { R[k].innerHTML=''; R[k].textContent=''; }
  A.setLang(lang);                                   // بيعيد رسم كل التبويبات لأن كلها «ظاهرة» في الاختبار
  const ep = A.EPS.find(e=>e.p==='/units/lists' && e.n==='List');
  A.renderDetail(ep, []);                            // صفحة ريكوست كاملة
  const card = A.userCard({name:'LSR-8031', imei:'869', id:'x1', device_serial:'869',
    sim_number:'0100', created_at:'2020-02-13 13:57:19', last_update:{time:'2026-08-05 10:00:00'},
    counters:{engine_hours:7200, odometer:1234}, groups:[{name: lang==='en'?'Fleet A':'أسطول جدة'}]});
  A.openEscalation('POST /units/lists');             // نص التصعيد باللغة الحالية
  return snapshot() + '\n' + card;
}

/* ١) العربي: يترسم من غير قيم مكسورة */
const arOut = renderEverything('ar');
for(const badTok of ['undefined','[object Object]','NaN','\\u0'])
  if(arOut.indexOf(badTok) >= 0) fail('قيمة مكسورة في العربي: ' + badTok);
console.log('الرسم بالعربي      : ' + arOut.length + ' حرف، من غير قيم مكسورة ✓');

/* ٢) الإنجليزي: نفس الرسم، ومفيش عربي مندسّ */
const enOut = renderEverything('en');
for(const badTok of ['undefined','[object Object]','NaN','\\u0'])
  if(enOut.indexOf(badTok) >= 0) fail('قيمة مكسورة في الإنجليزي: ' + badTok);
const textOnly = enOut.replace(/<[^>]*>/g,' ')
  .replace(/data-ar="[^"]*"/g,' ').replace(/data-arph="[^"]*"/g,' ')
  .replace(/(^|\s)ع(\s|$)/g,' ')             // زرار اللغة بيعرض «ع» عمدًا في الوضع الإنجليزي
  .replace(/\/\s+[\u0600-\u06FF]+/g,' ')      // قاموس المصطلحات ثنائي عمدًا: endpoint / إندبوينت
  .replace(/[\u0600-\u06FF\u064B-\u0652]+\s+in Arabic/g,' in Arabic');  // ذكر الكلمة العربية بالاسم في شرح إنجليزي — مقصود
const runs = textOnly.match(/[\u0600-\u06FF][\u0600-\u06FF\s،؛؟]*[\u0600-\u06FF]|[\u0600-\u06FF]/g) || [];
if(runs.length){
  const ctx = runs.slice(0,4).map(r=>{
    const i = textOnly.indexOf(r);
    return '«' + textOnly.slice(Math.max(0,i-30), i+r.length+30).replace(/\s+/g,' ').trim() + '»';
  });
  fail('عربي مندسّ في الوضع الإنجليزي (' + runs.length + ' مقطع): ' + ctx.join('  ·  '));
}
console.log('الرسم بالإنجليزي   : ' + enOut.length + ' حرف، صفر عربي مندسّ ✓');

/* ٣) بيانات السيرفر الخبيثة ما تتنفذش — اسم حساس فيه وسم */
const evil = A.userCard({name:'X', sensors:[{name:'<img src=x onerror=alert(1)>', value:'<b>5</b>'}]});
if(evil.indexOf('<img') >= 0 || evil.indexOf('onerror') >= 0 && evil.indexOf('&lt;img') < 0)
  fail('وسم من رد السيرفر اتنفذ جوه الكارت!');
if(evil.indexOf('&lt;img') < 0) fail('اسم الحساس الخبيث اختفى بدل ما يتهرّب');
if(evil.indexOf('&amp;lt;') >= 0) fail('تهريب مزدوج رجع تاني');
console.log('حقن من السيرفر     : الوسوم بتتهرّب مرة واحدة صح ✓');

/* ٤) كل {ar} في بيانات السيناريوهات والفرز لازم معاه {en} بنفس الحجم */
let pairs = 0;
function walk(o, path){
  if(o == null || typeof o !== 'object') return;
  if(Array.isArray(o)){ o.forEach((x,i)=>walk(x, path+'['+i+']')); return; }
  if('ar' in o){
    pairs++;
    if(!('en' in o)) fail('من غير مقابل إنجليزي: ' + path);
    const a=o.ar, e=o.en;
    if(Array.isArray(a) !== Array.isArray(e)) fail('شكل مختلف بين اللغتين: ' + path);
    if(Array.isArray(a) && a.length !== e.length) fail('عدد مختلف بين اللغتين: ' + path);
    if(!Array.isArray(a) && typeof a === 'string' && a.trim() && !(String(e).trim())) fail('إنجليزي فاضي: ' + path);
  }
  for(const k in o) if(k!=='ar' && k!=='en') walk(o[k], path+'.'+k);
}
walk(A.RECIPES, 'RECIPES'); walk(A.TRIAGE, 'TRIAGE');
console.log('بيانات السيناريوهات: ' + pairs + ' زوج، كلهم كاملين ومتساويين ✓');
