#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""جرد الترجمة: بيدوّر على أي نص المستخدم بيشوفه ومش بيتترجم أو مكسور."""
import re, json, sys
s = open('app_template.html', encoding='utf-8').read()
AR = re.compile(r'[\u0600-\u06FF]')
head = s[:s.find('<script>')]
js   = s[s.find('<script>'):]
P = {}

P['هروب مكسور في الصفحة'] = [m.group(0) for m in re.finditer(r'\\u[0-9a-fA-F]{4}', head)]
P['هروب مكسور في الصفحة'] = [m.group(0) for m in re.finditer(r'\\u[0-9a-fA-F]{4}', head)]

# ٢) عناصر HTML فيها عربي وما فيهاش مقابل إنجليزي
bad_el = []
for m in re.finditer(r'<(button|span|option|label|h[1-6]|div|p|b|em|a)\b([^>]*)>([^<]{2,120})</\1>', head):
    tag, attrs, txt = m.group(1), m.group(2), m.group(3).strip()
    if AR.search(txt) and 'data-ar=' not in attrs:
        bad_el.append(f'<{tag}> {txt[:60]}')
P['نص عربي ثابت في الصفحة'] = bad_el

# ٣) خانات لها placeholder عربي من غير مقابل
ph = []
for m in re.finditer(r'<input\b([^>]*)>', head):
    a = m.group(1)
    mm = re.search(r'placeholder="([^"]*)"', a)
    if mm and AR.search(mm.group(1)) and 'data-arph=' not in a:
        ph.append(mm.group(1)[:50])
P['خانة من غير ترجمة'] = ph

# ٤) data-ar من غير data-en (والعكس)
for m in re.finditer(r'<[^>]*data-ar="([^"]*)"[^>]*>', head):
    if 'data-en=' not in m.group(0):
        P.setdefault('data-ar من غير data-en', []).append(m.group(1)[:40])
for m in re.finditer(r'<[^>]*data-arph="([^"]*)"[^>]*>', head):
    if 'data-enph=' not in m.group(0):
        P.setdefault('placeholder من غير مقابل', []).append(m.group(1)[:40])

# ٥) الجانب الإنجليزي في t() فيه عربي، أو فاضي
mixed, empty = [], []
for m in re.finditer(r"t\(\s*(['\"])((?:\\.|(?!\1)[^\\])*)\1\s*,\s*(['\"])((?:\\.|(?!\3)[^\\])*)\3\s*\)", js):
    ar, en = m.group(2), m.group(4)
    if AR.search(en): mixed.append(en[:60])
    elif not en.strip() and ar.strip(): empty.append(ar[:40])
P['إنجليزي فيه عربي'] = mixed
P['إنجليزي فاضي'] = empty

# ٦) نص عربي معروض للمستخدم من غير t() — جوه innerHTML/textContent
raw = []
for m in re.finditer(r'(innerHTML|textContent)\s*=\s*`([^`]{0,400})`', js):
    body = m.group(2)
    for lit in re.finditer(r'>([^<>${}]{4,90})<', body):
        txt = lit.group(1).strip()
        if AR.search(txt) and 't(' not in txt:
            raw.append(txt[:60])
P['عربي معروض من غير t()'] = raw

# ٧) الدليل: أي بند عربي من غير مقابل إنجليزي
d = json.load(open('docs.json', encoding='utf-8'))
gaps = []
for sec in d['sections']:
    if len(sec['b']['ar']) != len(sec['b']['en']):
        gaps.append(f"قسم {sec['id']}: {len(sec['b']['ar'])} عربي مقابل {len(sec['b']['en'])} إنجليزي")
    for x in sec['b']['en']:
        # كلمة عربية جوه جملة إنجليزية مقبولة لو دي كلمة الموظف بيكتبها فعلًا وبتتشرح جنبها
        if AR.search(x) and 'in Arabic' not in x: gaps.append(f"قسم {sec['id']}: إنجليزي فيه عربي — {x[:50]}")
for h in d['history']:
    if len(h['items']['ar']) != len(h['items']['en']):
        gaps.append(f"نسخة {h['v']}: عدد البنود مختلف")
P['الدليل'] = gaps

tot = 0
for k, v in P.items():
    v = [x for x in v if x]
    print(f'\n### {k}: {len(v)}')
    for x in v[:12]: print('   ', x)
    if len(v) > 12: print(f'    … و{len(v)-12} غيرهم')
    tot += len(v)
print(f'\nالمجموع: {tot}')
sys.exit(1 if tot else 0)
