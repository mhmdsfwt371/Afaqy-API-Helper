#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v6.38 — حاجتين على شاشة الإندبوينت:

١) البودي بقى يتعدّل قبل التنفيذ. limit، projection، أي حاجة.
   والمعدّل بيمشي على المثال والتجربة سوا — فاللي بتشوفه هو اللي بيتبعت.

٢) الكارت كان بيقول «أوفلاين» لما last_update مش راجع أصلاً. ده ادعاء
   مش صحيح: الجهاز ممكن يكون شغّال والـ projection هو اللي ناقص. بقى
   بيقول «مش معروف» ويوضّح السبب.
"""
import sys, io

PATH = sys.argv[1] if len(sys.argv) > 1 else 'app_template.html'
src = io.open(PATH, encoding='utf-8').read()
orig = len(src)

def rep(old, new, n=1, tag=''):
    global src
    c = src.count(old)
    if c != n: raise SystemExit('MISMATCH [%s]: expected %d found %d\n---\n%s' % (tag, n, c, old[:220]))
    src = src.replace(old, new, n); print('  ok  %s' % tag)

# ── ١) مخزن التعديلات + liveBody بيقراه ─────────────────────
rep("""function liveBody(e){""",
"""/* البودي المعدّل لكل إندبوينت. المفتاح هو المسار، فالتعديل بيفضل
   لو رحت لإندبوينت تاني ورجعت — ومش بيتخزّن على الجهاز، بيروح مع الصفحة. */
const BODY_EDIT = {};

/* البودي اللي المفروض يتبعت: المعدّل لو موجود، وإلا اللي من القاعدة */
function bodyOf2(e){
  const k = String(e && e.p || '');
  if(BODY_EDIT[k] !== undefined) return BODY_EDIT[k];
  return bodyOf(e);
}

function liveBody(e){""", 1, 'مخزن التعديلات')

rep("""  const raw = bodyOf(e);
  if(!NO_RETRY.test(e.p||'') || !SESSION.user) return raw;""",
"""  const raw = bodyOf2(e);
  if(!NO_RETRY.test(e.p||'') || !SESSION.user) return raw;""", 1, 'liveBody بياخد المعدّل')

# ── ٢) صندوق التعديل تحت المثال ──────────────────────────────
rep("""      <pre class="pre" id="codeout">${esc(gen(e, codeMode))}</pre>
      <div class="row">
        <button class="btn sig" id="cpCode">${t('نسخ المثال','Copy example')}</button>""",
"""      <pre class="pre" id="codeout">${esc(gen(e, codeMode))}</pre>
      ${(e.m||'POST')!=='GET' && bodyOf(e) ? `
      <details class="bodyEdit" id="bodyEditBox" ${BODY_EDIT[e.p]!==undefined?'open':''}>
        <summary>${t('عدّل البودي قبل ما تنفّذ','Edit the body before running')}
          <span class="cnt">— ${t('limit، projection، أي حاجة','limit, projection, anything')}</span>
          ${BODY_EDIT[e.p]!==undefined?`<span class="chip sig" style="pointer-events:none; margin-inline-start:8px">${t('معدّل','edited')}</span>`:''}</summary>
        <div style="padding:12px 14px">
          <textarea id="bodyBox" spellcheck="false" style="width:100%; min-height:190px; resize:vertical;
            font-family:var(--mono); font-size:12.5px; line-height:1.7; direction:ltr; text-align:left;
            background:var(--panel-2); color:var(--ink); border:1px solid var(--field-line, var(--line));
            border-radius:3px; padding:10px">${esc(bodyOf2(e))}</textarea>
          <div class="row" style="margin-top:8px">
            <button class="btn sig" id="bodyApply">${t('طبّق','Apply')}</button>
            <button class="btn ghost" id="bodyReset">${t('رجّع الأصلي','Reset to original')}</button>
            <span id="bodyMsg" style="font-size:12.5px; color:var(--muted); align-self:center"></span>
          </div>
          <div class="note" style="margin-top:8px">${t(
            'اللي في الصندوق ده هو اللي بيتبعت فعلًا، وهو اللي بيظهر في المثال وفي الرد الكامل للعميل. لو JSON غلط الأداة هتقولك ومش هتطبّق.',
            'What sits in this box is what actually gets sent, and it is what appears in the example and in the full customer reply. If the JSON is invalid the tool says so and applies nothing.')}</div>
        </div>
      </details>` : ''}
      <div class="row">
        <button class="btn sig" id="cpCode">${t('نسخ المثال','Copy example')}</button>""",
    1, 'صندوق التعديل')

# ── ٣) توصيل الأزرار ─────────────────────────────────────────
rep("""  $('tryIt').onclick = ()=>{ if(ensureDeps(e, ()=>tryIt(e))) tryIt(e); };""",
"""  const bBox = $('bodyBox'), bMsg = $('bodyMsg');
  if(bBox){
    const say = (txt, bad) => { if(bMsg){ bMsg.textContent = txt; bMsg.style.color = bad ? 'var(--alert)' : 'var(--ok)'; } };
    $('bodyApply').onclick = ()=>{
      const v = bBox.value;
      try{ JSON.parse(v); }
      catch(err){ say(t('JSON مش سليم: ','Invalid JSON: ') + String(err.message).slice(0,70), true); return; }
      BODY_EDIT[e.p] = v;
      say(t('اتطبّق — المثال والتنفيذ بقوا على البودي ده','Applied — the example and the run now use this body'));
      const co = $('codeout'); if(co) co.textContent = gen(e, codeMode);
    };
    $('bodyReset').onclick = ()=>{
      delete BODY_EDIT[e.p];
      bBox.value = bodyOf(e);
      say(t('رجع للأصلي','Back to the original'));
      const co = $('codeout'); if(co) co.textContent = gen(e, codeMode);
    };
  }
  $('tryIt').onclick = ()=>{ if(ensureDeps(e, ()=>tryIt(e))) tryIt(e); };""",
    1, 'توصيل أزرار التعديل')

# ── ٤) ستايل الصندوق ────────────────────────────────────────
rep(""".caseMore{border:1px solid var(--line);""",
""".bodyEdit{border:1px solid var(--line); border-radius:var(--r); background:var(--panel);
  margin-top:10px; overflow:hidden}
.bodyEdit>summary{cursor:pointer; padding:10px 14px; font-weight:600; font-size:13.5px;
  color:var(--ink); list-style:none; display:flex; align-items:center; gap:8px; flex-wrap:wrap}
.bodyEdit>summary::-webkit-details-marker{display:none}
.bodyEdit>summary::before{content:'\\25B8'; color:var(--muted); font-size:11px; transition:transform .15s}
.bodyEdit[open]>summary::before{transform:rotate(90deg)}
.bodyEdit>summary:hover{background:var(--panel-2)}
.bodyEdit>summary .cnt{color:var(--muted); font-weight:400; font-size:12.5px}
.caseMore{border:1px solid var(--line);""", 1, 'ستايل الصندوق')

# ── ٥) الكارت: مش معروف ≠ أوفلاين ───────────────────────────
rep("""  const online = hrs !== null && hrs <= 1;""",
"""  const online = hrs !== null && hrs <= 1;
  const seenUnknown = hrs === null;      /* الحقل مش راجع — مش معناه الجهاز أوفلاين */""",
    1, 'متغيّر عدم المعرفة')

rep("""        ${badge(online ? t('أونلاين','Online') : t('أوفلاين','Offline'), online?OK:BAD)}""",
"""        ${badge(seenUnknown ? t('آخر إشارة مش راجعة','Last signal not returned')
                             : online ? t('أونلاين','Online') : t('أوفلاين','Offline'),
                seenUnknown ? GREY : online ? OK : BAD)}""",
    1, 'الشارة بتقول الحقيقة')

# ── ٦) والكارت يقول ليه ─────────────────────────────────────
rep("""  const luRaw = lu.time || lu.datetime || u.last_time || '';
  if(luRaw || seen) add(t('آخر تحديث','Last update'), luRaw,""",
"""  const luRaw = lu.time || lu.datetime || u.last_time || '';
  if(!luRaw && !seen)
    add(t('آخر إشارة','Last signal'), t('مش في الرد','not in the response'),
        t('حط last_update في الـ projection عشان تشوفها — من غيرها مينفعش نحكم أونلاين ولا أوفلاين',
          'add last_update to the projection to see it — without it online/offline cannot be judged'));
  if(luRaw || seen) add(t('آخر تحديث','Last update'), luRaw,""",
    1, 'سطر آخر إشارة')

# ── ٧) الحساسات: نقول لو مش راجعة بدل ما تختفي ──────────────
rep("""  sensorsOf(u).slice(0,6).forEach(s2=>add(String(s2.name), String(s2.value)));""",
"""  const sns = sensorsOf(u);
  if(sns.length) sns.slice(0,8).forEach(s2=>add(String(s2.name), String(s2.value),
        t('قراءة حساس','sensor reading')));
  else add(t('الحساسات','Sensors'), t('مش في الرد','not in the response'),
        t('حط sensors في الـ projection — ولو حطيتها ورجعت فاضية يبقى الجهاز فعلًا مالوش حساسات',
          'add sensors to the projection — and if it still comes back empty the device genuinely has none'));""",
    1, 'سطر الحساسات')

io.open(PATH, 'w', encoding='utf-8').write(src)
print('\ndone (%d -> %d, +%d)' % (orig, len(src), len(src) - orig))
