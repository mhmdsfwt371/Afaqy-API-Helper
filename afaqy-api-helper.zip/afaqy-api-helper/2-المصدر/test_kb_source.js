/* v6.50 — مصدر الأداة هو التوثيق الرسمي «1- AVL Integration documentation».
   الاختبار ده بيقفل: الـ KB = ناتج المحوّل من ملف الكولكشن بالظبط (مفيش تعديل يدوي)،
   والمستبعد عمدًا مستبعد، والمحفوظ من غير توثيق هو اللي في القايمة بس وكل واحد بسبب،
   ومفردات البحث مربوطة بموديولات موجودة، والأرقام القديمة مش في الأداة. */
const fs=require('fs'), cp=require('child_process'), os=require('os'), path=require('path');
let F=0; const ok=(m,c,x)=>{ console.log((c?'  \u2713 ':'  \u2717 ')+m+(c||!x?'':'  \u2014 '+String(x).slice(0,160))); if(!c) F++; };
const COL='avl_integration_documentation.postman_collection.json';
ok('ملف التوثيق الرسمي موجود في المصدر', fs.existsSync(COL));
const tmp=path.join(os.tmpdir(),'kb_regen_'+process.pid+'.json');
cp.execFileSync('python3',['build_kb_from_collection.py',COL,tmp,'kb_slim.json'],{stdio:'pipe'});
ok('الـ KB = ناتج المحوّل من التوثيق بالحرف (مفيش تعديل يدوي)', fs.readFileSync(tmp,'utf8')===fs.readFileSync('kb_slim.json','utf8'));
fs.unlinkSync(tmp);
const kb=JSON.parse(fs.readFileSync('kb_slim.json','utf8')), E=kb.endpoints;
const col=JSON.parse(fs.readFileSync(COL,'utf8'));
let n=0; (function w(a){ a.forEach(it=>{ if(it.item) w(it.item); else n++; }); })(col.item);
ok('عدد ريكوستات التوثيق مطابق للملف', kb.source.documented===n && n===193, kb.source.documented+' / '+n);
ok('المصدر متسجّل بالاسم واللينك', kb.source.name==='1- AVL Integration documentation' && /50854881\/2sBYB2qnL3/.test(kb.source.url));
['/units/add','/units/delete','/units/bulk-delete'].forEach(p=>ok('مستبعد عمدًا: '+p, !E.some(e=>e.p===p)));
const KEEP=['/units/locations','/user_report_templates/lists','/user_report_templates/add','/reports/add','/customers/lists','/units/getAddress',
  '/auth/login_as','/auth/reset_expired_password','/auth/send_login_otp','/auth/verify_login_otp',
  '/wasl_integration/vehicles/lists','/wasl_integration/vehicles/inquiry','/wasl_integration/vehicles/update_imei'];
const X=E.filter(e=>e.x);
ok('المحفوظ من غير توثيق = القايمة بالظبط ('+KEEP.length+')', X.length===KEEP.length && KEEP.every(p=>X.some(e=>e.p===p)), X.map(e=>e.p).join(' '));
ok('كل محفوظ ليه سبب مكتوب', X.every(e=>e.xr && e.xr.trim().length>=5));
ok('مفيش ريكوست رسمي متعلّم «مش في التوثيق»', E.filter(e=>!e.x).length===kb.source.official);
ok('كل ريكوست رسمي ليه وصف من التوثيق', E.filter(e=>!e.x).every(e=>e.d && e.d.length>10));
const bad=E.filter(e=>e.b && (/^\s*\/\//m.test(e.b) || /\/\*/.test(e.b)));
ok('مفيش تعليقات // أو /* في البوديز', bad.length===0, bad.map(e=>e.p).join(' '));
const blob=JSON.stringify(kb)+fs.readFileSync(COL,'utf8');
/* سطر «username» متعلّق في عينة /user/lists كان فيه اسم حساب عميل — الاختبار بيدوّر على الشكل مش على الاسم
   (الأسماء نفسها مكانها private_names.json بس، مش الريبو) */
ok('مفيش سطر username متعلّق (فيه اسم حساب عميل) في التوثيق ولا الـ KB', !/\/\/\s*\\?"username\\?"\s*:/.test(blob));
const ul=E.find(e=>e.p==='/units/lists'); let ub=null; try{ ub=JSON.parse(ul.b); }catch(_){}
ok('عينة /units/lists من غير فلتر الـ IMEI الوهمي وفيها created_at', ub && !ub.data.filters && ub.data.projection.includes('created_at') && /وهمي/.test(ul.fx||''));
/* مفردات البحث مربوطة بموديولات موجودة */
const html=fs.readFileSync(process.argv[2]||'app_template.html','utf8');
const i=html.indexOf('const VOCAB = {'), j=html.indexOf('\n};',i);
const keys=[...html.slice(i,j).matchAll(/^\s*'([^']+)'\s*:/gm)].map(m=>m[1].split('/')[0]);
const G=new Set(E.map(e=>e.g)), dead=keys.filter(k=>!G.has(k));
ok('كل موديول في مفردات البحث موجود في الـ KB', dead.length===0, dead.join('، '));
/* الأرقام القديمة */
ok('مفيش أرقام الكولكشن القديم (534/514/504/475) في الأداة', !/\b(514|504)\b[^<]{0,40}\b534\b|\b460\b[^<]{0,30}\b475\b/.test(html));
const docs=JSON.parse(fs.readFileSync('docs.json','utf8'));
const secTxt=JSON.stringify(docs.sections);
ok('الدليل (الأقسام الحالية) مش بيقول 529 ريكوست', !/529 (ريكوست|requests)/.test(secTxt));
console.log(F?`\nفشل ${F}`:'\nمصدر الأداة = التوثيق الرسمي: تمام'); process.exit(F?1:0);
