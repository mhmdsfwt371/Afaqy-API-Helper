# testdata

Public sample Outlook `.msg` files from the msgreader project's own test folder
(https://github.com/HiraokaHyperTools/msgreader — Apache License 2.0), used by the
browser gate (`test_browser.py`) and `test_mail_cases.js` to prove that a real
Outlook file is read inside the tool. They contain no AFAQY or customer data.
