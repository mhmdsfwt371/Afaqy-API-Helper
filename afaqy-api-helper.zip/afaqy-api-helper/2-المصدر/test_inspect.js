/* فحص رد: بيحوّل JSON لجدول مقروء، وبيمسك الأخطاء، وبيحوّل الوحدات */
const fs=require('fs');
const R={};
function el(id){return{id,hidden:false,innerHTML:'',value:'',textContent:'',className:'',dataset:{},style:{},files:[],disabled:false,
 classList:{toggle(){},add(){},remove(){}},querySelectorAll(){return[]},addEventListener(){},focus(){},select(){},click(){},
 setAttribute(){},getAttribute(){return null},dispatchEvent(){},appendChild(){},remove(){},scrollIntoView(){},onclick:null}}
global.document={documentElement:el(),body:el(),addEventListener(){},querySelectorAll(){return[]},
 querySelector(){return null},createElement(){return el()},getElementById(i){return R[i]||(R[i]=el(i))}};
global.history={pushState(){},replaceState(){}};global.location={hash:'',pathname:'/',replace(){},reload(){}};
global.setInterval=()=>0;global.navigator={clipboard:{writeText(){return Promise.resolve()}}};
global.window={scrollTo(){},addEventListener(){}};global.fetch=()=>Promise.reject(0);
global.AbortController=function(){this.signal={};this.abort=()=>{}};
global.Blob=function(){};global.URL={createObjectURL(){return''}};global.FileReader=function(){};
let js=fs.readFileSync('app_template.html','utf8').split('<script>')[1].split('</script>')[0]
 .replace('/*__KB__*/',fs.readFileSync('kb_slim.json','utf8'))
 .replace('/*__DOCS__*/',fs.readFileSync('docs.json','utf8'));
const m={};new Function('module',js+"\nmodule.exports={pickRows,renderInspect};")(m);
const A=m.exports;
const fail=s=>{console.error('فشل: '+s);process.exit(1)};
const strip=h=>String(h).replace(/<[^>]+>/g,' ').replace(/\s+/g,' ').trim();

// رد حقيقي الشكل من units/lists
const real={message:'success',status_code:200,data:{items:[
 {_id:'5fb0e2e703ed529bb30f9af3',name:'NB YD - TH - 1129',imei:'357454075086551',
  device_serial:'861230048816917',plate_number:'ABC 1234',active:true,
  counters:{odometer:233207.232139,engine_hours:95761694},
  last_update:{time:'2026-08-04 09:12:00',pos:{speed:64}}},
 {_id:'6009324fd77b9f0552247855',name:'DP 18181',imei:'352094083043288',active:true,
  counters:{odometer:1200.5,engine_hours:3600},
  last_update:{time:'2026-08-04 08:00:00',pos:{speed:0}}}]}};

const {rows,total,path}=A.pickRows(real);
if(total!==2) fail('عدد السجلات غلط: '+total);
if(rows[0].name!=='NB YD - TH - 1129') fail('الاسم مش متقروء');
if(rows[0].imei!=='357454075086551') fail('الـ IMEI مش متقروء');
if(Math.round(rows[0].engine_hours)!==26600) fail('ساعات التشغيل ما اتحولتش: '+rows[0].engine_hours);
if(Math.round(rows[1].engine_hours)!==1) fail('التحويل التاني غلط: '+rows[1].engine_hours);
if(rows[0].speed!==64) fail('السرعة مش متقروءة');
console.log('قراءة السجلات      : '+total+' سجل، الأسماء والأرقام والسرعة ✓');
console.log('تحويل ساعات التشغيل: 95761694 ثانية → '+Math.round(rows[0].engine_hours)+' ساعة ✓');

// رد فيه خطأ
document.getElementById('inText').value=JSON.stringify({message:'validation_error',status_code:405,errors:{unit_id:['not_found']}});
A.renderInspect();
const out=strip(document.getElementById('inOut').innerHTML);
if(out.indexOf('validation_error')<0) fail('ما عرضش الخطأ');
if(out.indexOf('رقم العربية')<0) fail('ما شرحش الحقل المرفوض');
console.log('رد فيه خطأ         : اتعرض واتشرح ✓');

// JSON مكسور
document.getElementById('inText').value='{ده مش جيسون}';
A.renderInspect();
if(strip(document.getElementById('inOut').innerHTML).indexOf('ما قدرناش نقرا الرد')<0) fail('ما مسكش الـ JSON المكسور');  // الرسالة اتطورت في 5.x: بتحاول تصلّح الأول وبعدين بتقول ما قدرناش
console.log('JSON مكسور         : اتمسك برسالة واضحة ✓');

// رد فاضي
document.getElementById('inText').value=JSON.stringify({message:'success',status_code:200,data:{items:[]}});
A.renderInspect();
if(strip(document.getElementById('inOut').innerHTML).indexOf('مش لستة سجلات')<0) fail('ما قالش إنه فاضي');  // صيغة 5.x: الفاضي بيتعرض «مش لستة سجلات» مع الرد الخام
console.log('رد فاضي            : اتقال بوضوح ✓');

// شكل مختلف تمامًا
const odd={result:{payload:{records:[{id:'x1',name:'حاجة'},{id:'x2',name:'حاجة تانية'}]}}};
if(A.pickRows(odd).total!==2) fail('ما لقاش السجلات في شكل مختلف');
console.log('شكل رد مختلف       : لقى السجلات ✓');
