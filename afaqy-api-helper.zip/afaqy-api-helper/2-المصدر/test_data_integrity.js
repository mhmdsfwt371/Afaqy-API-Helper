/* v6.8 — سلامة البيانات: النظامين ما يتلخبطوش.
   المستخدم سأل «اتمنى متكونش لخبطت البيانات؟» — والرد الصح مش طمأنة،
   ده فحص بيتشغّل مع كل بناء: كل ريكوست AVL بيتقارن بالأصل حقل بحقل،
   وكل ريكوست في النظام التاني بيتأكد إنه ما أخدش حاجة من AVL والعكس. */
global.setInterval=()=>0;global.clearInterval=()=>{};
const fs=require('fs');const R={};
function el(id){return{id,hidden:false,innerHTML:'',value:'',textContent:'',className:'',dataset:{},style:{},files:[],disabled:false,
 options:[],classList:{toggle(){},add(){},remove(){}},querySelectorAll(){return[]},addEventListener(){},focus(){},select(){},click(){},
 setAttribute(){},getAttribute(){return null},dispatchEvent(){},appendChild(){},remove(){},scrollIntoView(){},title:''}}
global.document={documentElement:el('html'),body:el('body'),addEventListener(){},querySelectorAll(){return[]},
 querySelector(){return null},createElement(){return el()},getElementById:i=>R[i]||(R[i]=el(i))};
global.history={pushState(){},replaceState(){}};global.location={hash:'',pathname:'/',replace(){}};
global.navigator={userAgent:'node',language:'ar',clipboard:{writeText(){return Promise.resolve()}}};
global.window={scrollTo(){},addEventListener(){},matchMedia:()=>({matches:false}),navigator:{}};
global.fetch=()=>Promise.reject(0);global.Blob=function(){};global.URL={createObjectURL(){return''}};global.FileReader=function(){};
global.btoa=x=>Buffer.from(x,'binary').toString('base64');global.atob=x=>Buffer.from(x,'base64').toString('binary');
const D={};global.localStorage={getItem:k=>(k in D?D[k]:null),setItem:(k,v)=>{D[k]=String(v);},removeItem(){}};
global.sessionStorage={getItem:()=>null,setItem(){},removeItem(){}};global.confirm=()=>false;

const KB   = JSON.parse(fs.readFileSync('kb_slim.json','utf8'));
const KBIN = JSON.parse(fs.readFileSync('kb_in.json','utf8'));
let js=fs.readFileSync('app_template.html','utf8').split('<script>')[1].split('</script>')[0]
 .replace('/*__KB__*/',fs.readFileSync('kb_slim.json','utf8'))
 .replace('/*__KBIN__*/',fs.readFileSync('kb_in.json','utf8'))
 .replace('/*__DOCS__*/',fs.readFileSync('docs.json','utf8'));
const m={};new Function('module',js+'\nmodule.exports={EPS,sysOf,VOCAB,DUP,fullUrl,curSys,sysEps};')(m);
const A=m.exports;
let bad=0; const err=x=>{console.error('فشل: '+x); bad++;};

console.log('=== ١) كل ريكوست AVL زي ما هو بالحرف؟ ===');
const live = new Map(A.EPS.filter(e=>A.sysOf(e)==='avl').map(e=>[e.i,e]));
let checked=0, diffs=[];
for(const src of KB.endpoints){
  const got = live.get(src.i);
  if(!got){ diffs.push('ناقص: '+src.p); continue; }
  for(const k of ['g','n','m','p','t','b','q','h','fd','bm','d','s']){
    const a=JSON.stringify(src[k]), b=JSON.stringify(got[k]);
    if(a!==b) diffs.push(`${src.m} ${src.p} · الحقل ${k}: كان ${String(a).slice(0,40)} بقى ${String(b).slice(0,40)}`);
  }
  checked++;
}
console.log(`  اتفحص ${checked} من ${KB.endpoints.length} ريكوست AVL`);
if(diffs.length){ diffs.slice(0,6).forEach(d=>err(d)); } else console.log('  ✓ كلهم مطابقين للأصل حرفيًا — ولا حقل اتغيّر');

console.log('\n=== ٢) حقول النظام التاني ما تسرّبتش لـAVL؟ ===');
const leaked = A.EPS.filter(e=>A.sysOf(e)==='avl' && (String(e.p).includes('?r=') || String(e.b||'').includes('apiKey')));
if(leaked.length) err(`${leaked.length} ريكوست AVL فيه أثر من النظام التاني: ${leaked[0].p}`);
else console.log('  ✓ مفيش apiKey ولا ?r= في أي ريكوست AVL');

console.log('\n=== ٣) حقول AVL ما تسرّبتش للنظام التاني؟ ===');
/* device.token بتاع إشعارات الموبايل موجود في التوثيق الرسمي — مش توكن AVL.
   الفحص بيدوّر على توكن المصادقة: حقل t، أو token في الرابط، أو apiKey ناقص. */
const leaked2 = A.EPS.filter(e => A.sysOf(e)==='in' && (
   e.t || String(e.p||'').includes('token=') ||
   /"token"\s*:/.test(String(e.b||'').replace(/"device"[\s\S]*?\}/,''))
));
if(leaked2.length) err(`${leaked2.length} ريكوست في النظام التاني فيه توكن: ${leaked2[0].p}`);
else console.log('  ✓ مفيش توكن ولا حقول AVL في النظام التاني');

console.log('\n=== ٤) قاموس البحث: كلمات AVL ما اتبهدلتش؟ ===');
const orig = {'Units':['عربية','عربيات','مركبة'],'Zones':['منطقة'],'Drivers':['سواق']};
for(const [k,words] of Object.entries(orig)){
  if(!A.VOCAB[k]) { err('موديول اختفى من القاموس: '+k); continue; }
  const missing = words.filter(w=>!A.VOCAB[k].includes(w));
  if(missing.length) err(`${k} فقد كلمات: ${missing.join('،')}`);
}
if(A.VOCAB['Units'].some(w=>w.includes('IN')||w.includes('order'))) err('كلمات النظام التاني اتحقنت في قاموس AVL');
console.log(`  ✓ Units لسه ${A.VOCAB['Units'].length} كلمة · Trackers (IN) عنده ${(A.VOCAB['Trackers (IN)']||[]).length} — منفصلين`);

console.log('\n=== ٥) الأرقام والمسارات ما اتصادمتش؟ ===');
const ids=A.EPS.map(e=>e.i); const dupIds=ids.filter((x,i)=>ids.indexOf(x)!==i);
if(dupIds.length) err('أرقام مكررة: '+[...new Set(dupIds)].slice(0,5)); else console.log('  ✓ 566 رقم كلهم فريدين');
const avlP=new Set(A.EPS.filter(e=>A.sysOf(e)==='avl').map(e=>e.m+' '+e.p));
const inP =A.EPS.filter(e=>A.sysOf(e)==='in').map(e=>e.m+' '+e.p);
const clash=inP.filter(p=>avlP.has(p));
if(clash.length) err('مسار مشترك بين النظامين: '+clash[0]); else console.log('  ✓ مفيش مسار مشترك بين النظامين');

console.log('\n=== ٦) الروابط المولّدة صح لكل نظام؟ ===');
R['baseUrl'].value='https://api.afaqy.sa';
const a1=A.fullUrl(A.EPS.find(e=>e.p==='/units/lists'&&A.sysOf(e)==='avl'),false);
console.log('  AVL      :', a1);
R['baseUrl'].value='http://afaqy.in/api';
const i1=A.fullUrl(A.EPS.find(e=>A.sysOf(e)==='in'&&e.b.includes('userTrackers/list')),false);
console.log('  أفاقي إن  :', i1.slice(0,95));
if(a1.includes('?r=')||a1.includes('afaqy.in')) err('رابط AVL اتلوث');
if(!i1.includes('afaqy.in/api/?r=')||i1.includes('token=')) err('رابط النظام التاني غلط');
if(!bad) console.log('  ✓ كل نظام بشكله');
R['baseUrl'].value='https://api.afaqy.sa';

console.log('\n=== النتيجة ===');
console.log(bad? `  ✗ ${bad} مشكلة` : '  ✓ صفر لخبطة — البيانات منفصلة تمامًا');
if(bad) process.exit(1);
