/* اختبارات ترتيب شاشة «حلّل رسالة عميل» — v6.36.
   الفكرة: الموظف بيفتح الشاشة عشان الرد. لازم يلاقيه من غير ما يسكرول
   في ستة بلوكات تحليل. */
const fs = require('fs');
const { JSDOM } = require('jsdom');
let F = 0;
const pass = m => console.log('  \u2713 ' + m);
const fail = m => { console.log('  \u2717 ' + m); F++; };
const ok = (m, c, x) => c ? pass(m) : fail(m + (x ? '  \u2014 ' + x : ''));

const build = () => fs.readFileSync(process.argv[2] || 'app_template.html', 'utf8')
  .replace('/*__KB__*/',   () => fs.readFileSync('kb_slim.json', 'utf8'))
  .replace('/*__DOCS__*/', () => fs.readFileSync('docs.json', 'utf8'))
  .replace('/*__KBIN__*/', () => fs.readFileSync('kb_in.json', 'utf8'));

const EMAIL = `I am currently integrating the following Report API:
https://api.afaqy.sa/reports/lists?token={{afaqy_token}}
The API returns a successful response but the data section contains the report
configuration and field metadata rather than the actual report values.
Under summary_beta the response provides fields such as:
  - Date - code: date
  - Route Length - code: route_length
  - Engine Work Duration - code: engine_work
  - Engine Move Duration - code: move_duration
  - Stop Duration - code: stop_duration
What I need is actual data: Date: 10-08-2026, Route Length: 70 km.
1. Which API endpoint should be used to retrieve the actual report data for summary_beta?
2. What parameters are required, such as vehicle ID, date range, report code?
3. Is there another API that needs to be called after /reports/lists?
4. Could you provide a sample request and response containing actual values?`;

const VAGUE = `The report API is not working for our account. Please advise.`;

function analyse(txt){
  const dom = new JSDOM(build(), { runScripts:'dangerously', pretendToBeVisual:true, url:'https://localhost/' });
  const w = dom.window; w.alert = () => {}; w.scrollTo = () => {};
  w.showView('inspect');
  w.document.getElementById('ivCase').click();
  w.document.getElementById('caseText').value = txt;
  w.document.getElementById('caseGo').click();
  return { w, out: w.document.getElementById('caseOut') };
}

/* ═════ ١) الحكم فوق والرد بعده مباشرة ═════ */
console.log('\n\u0661) الترتيب: الحكم، الرد، وبعدين التحليل');
{
  const { w, out } = analyse(EMAIL);
  const html = out.innerHTML;
  const iVerdict = html.indexOf('caseVerdict');
  const iReply   = html.indexOf('caseReplyTxt');
  const iMore    = html.indexOf('caseMore');
  ok('سطر الحكم موجود', iVerdict > -1);
  ok('الرد موجود', iReply > -1);
  ok('الحكم قبل الرد', iVerdict > -1 && iVerdict < iReply, iVerdict + ' vs ' + iReply);
  ok('الرد قبل التحليل', iReply > -1 && iMore > -1 && iReply < iMore, iReply + ' vs ' + iMore);
  ok('زرار نسخ الرد ظاهر من غير فتح حاجة',
     !!out.querySelector('#caseCopy') &&
     !out.querySelector('details.caseMore #caseCopy'));
  ok('زرار الكولكشن ظاهر برضه',
     !!out.querySelector('#casePm') && !out.querySelector('details.caseMore #casePm'));
  w.close();
}

/* ═════ ٢) التحليل مطوي مش مفرود ═════ */
console.log('\n\u0662) التحليل مطوي');
{
  const { w, out } = analyse(EMAIL);
  const det = out.querySelector('details.caseMore');
  ok('التحليل جوه عنصر مطوي', !!det);
  ok('مقفول افتراضيًا', det && !det.hasAttribute('open'));
  const panelsTop = Array.from(out.children).filter(el => el.classList && el.classList.contains('panel'));
  ok('البلوكات المفرودة اتنين بس (الحكم والرد)', panelsTop.length === 2, panelsTop.length);
  const inside = det ? det.querySelectorAll('.panel').length : 0;
  ok('باقي الأقسام كلها جوه المطوي', inside >= 3, inside);
  ok('السطر بيقول فيه كام قسم', det && /\d+/.test(det.querySelector('summary').textContent));
  w.close();
}

/* ═════ ٣) الرد الطويل بيتقص ما بيمدّش الصفحة ═════ */
console.log('\u0663) الرد الطويل بيتقص');
{
  const { w, out } = analyse(EMAIL);
  const pre = out.querySelector('#caseReplyTxt');
  ok('الرد بياخد كلاس القص', pre && pre.classList.contains('pre'));
  ok('الرد فعلًا طويل ومحتاج قص', pre && pre.textContent.length > 3000, pre && pre.textContent.length);
  const body = fs.readFileSync(process.argv[2] || 'app_template.html', 'utf8')
    .split('function renderCase(text){')[1].split('\nasync function caseLiveRun')[0];
  ok('clipBlocks بتتنادى في الشاشة دي', /clipBlocks\(out\)/.test(body));
  ok('والنداء بعد ما الـ HTML يتحط',
     body.indexOf('out.innerHTML') < body.indexOf('clipBlocks(out)'));
  w.close();
}

/* ═════ ٤) الحكم بيفرّق بين محسومة وناقصة ═════ */
console.log('\n\u0664) الحكم بيقول الحقيقة');
{
  const a = analyse(EMAIL);
  const txtA = a.out.textContent;
  ok('رسالة التقرير: الحكم محسومة', /محسومة|Resolved/.test(txtA), txtA.slice(0, 80));
  ok('الحكم بيسمّي الغلطة مش بيقول «في مشكلة»',
     /كتالوج|catalog/.test(txtA.slice(0, 400)));
  a.w.close();

  const b = analyse(VAGUE);
  const txtB = b.out.textContent;
  ok('رسالة ناقصة: الحكم مش محسومة', /ناقصة أدلة|Evidence needed/.test(txtB), txtB.slice(0, 80));
  ok('وبيقول ناقص كام حاجة', /\d+\s*(حاجة|item)/.test(txtB));
  ok('ومفيش رد جاهز اتعرض', !b.out.querySelector('#caseReplyTxt'));
  b.w.close();
}

/* ═════ ٥) الأزرار لسه شغالة بعد إعادة الترتيب ═════ */
console.log('\n\u0665) التوصيل ما اتكسرش');
{
  const { w, out } = analyse(EMAIL);
  let copied = '';
  w.eval('window.__cp = null;');
  w.navigator.clipboard = { writeText: t => { copied = t; return Promise.resolve(); } };
  const cp = out.querySelector('#caseCopy');
  ok('زرار النسخ متوصّل', cp && typeof cp.onclick === 'function');
  const pm = out.querySelector('#casePm');
  ok('زرار الكولكشن متوصّل', pm && typeof pm.onclick === 'function');
  ok('الكولكشن بيتولّد فعلًا',
     (() => { try { const c = w.eval('JSON.stringify(pmFromCase(analyzeCase(document.getElementById("caseText").value)))');
                    return JSON.parse(c).item.length >= 4; } catch(e){ return false; } })());
  ok('روابط الإندبوينتس لسه متوصّلة',
     Array.from(out.querySelectorAll('[data-goep]')).every(b => typeof b.onclick === 'function'));
  w.close();
}

console.log('\n' + (F ? '\u2717 فشل: ' + F : '\u2713 كله عدّى'));
process.exit(F ? 1 : 0);
