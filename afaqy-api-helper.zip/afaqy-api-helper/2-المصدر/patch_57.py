#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ترقيعة v5.7 — وضوح الردود والتصعيد. أنكورات حرفية وأي MISS بيوقّفها."""
import sys
P='app_template.html'; s=open(P,encoding='utf-8').read()
miss=[]; done=[]
def rep(old,new,label,cnt=1):
    global s
    c=s.count(old)
    if c!=cnt: miss.append(f'{label} (لقيت {c})'); return
    s=s.replace(old,new); done.append(label)

# ===== ١) pickRows يفرّق الفاضي عن اللي مش لستة =====
rep("let best=null, path='';",
    "let best=null, path='', emptyPath=null;",'١أ) تتبع الفاضي')
ip=s.find('function pickRows'); seg=s[ip:ip+900]
oldA="if(Array.isArray(o)){ if(o.length && typeof o[0]==='object'"
if seg.count(oldA)!=1: miss.append('١ب) نمط المصفوفة جوه pickRows')
else:
    s=s[:ip]+seg.replace(oldA,"if(Array.isArray(o)){ if(!o.length && emptyPath===null) emptyPath=p2||'.';\n      if(o.length && typeof o[0]==='object'")+s[ip+900:]
    done.append('١ب) التقاط المصفوفة الفاضية (محصور)')
rep("if(!best) return {rows:[], path:''};",
    "if(!best) return {rows:[], path:'', total:0, empty: emptyPath!==null};",'١ج) رجوع الفاضي')
rep("return {rows, path, total:best.length};",
    "return {rows, path, total:best.length, empty:false};",'١د) رجوع الملي')

# ===== ٢) رسالة العرض بعد التشغيل =====
rep("const {rows, total} = pickRows(r.json);",
    "const PK = pickRows(r.json), {rows, total} = PK;",'٢أ) التقاط في العرض')
LIT="${t('الرد ده مش لستة سجلات.','This response is not a list of records.')}"
NEW1=("${PK.empty ? t('الرد سليم والاتصال شغال — بس صفر سجلات مطابقة للفلتر. وسّع التواريخ أو شيل الفلاتر وجرّب تاني.',"
      "'The response is valid and the connection works — zero records matched the filter. Widen the dates or drop the filters and retry.')"
      " : t('الرد ده مش لستة سجلات.','This response is not a list of records.')}")
i=s.find(LIT)
if i<0: miss.append('٢ب) الرسالة الأولى')
else: s=s[:i]+NEW1+s[i+len(LIT):]; done.append('٢ب) رسالة العرض بقت تفرّق')

# ===== ٣) نفس الشيء في تبويب الفحص =====
rep("const {rows, path, total} = pickRows(j);",
    "const PK2 = pickRows(j), {rows, path, total} = PK2;",'٣أ) التقاط في الفحص')
NEW2=NEW1.replace('PK.empty','PK2.empty')
i=s.find(LIT)
if i<0: miss.append('٣ب) الرسالة التانية')
else: s=s[:i]+NEW2+s[i+len(LIT):]; done.append('٣ب) رسالة الفحص بقت تفرّق')

# ===== ٤) العريض في الدليل يظهر عريض =====
rep("/* ================= الدليل ================= */",
    """/* v5.7 — **كلمة** في بنود الدليل بتظهر عريضة فعلًا بدل النجمتين */
function mdBold(h){ return h.replace(/\\*\\*([^*]+)\\*\\*/g, '<b>$1</b>'); }
/* ================= الدليل ================= */""",'٤أ) mdBold')
rep('const line = x => `<li style="margin-bottom:5px">${esc(x)}</li>`;',
    'const line = x => `<li style="margin-bottom:5px">${mdBold(esc(x))}</li>`;','٤ب) تطبيقه على البنود')

# ===== ٥) المجموعات في الكارت =====
old="add(t('الشريحة','SIM'), simOf(u), t('رقم شريحة الاتصال جوه الجهاز — مالوش علاقة بتعريف العربية','the SIM inside the device — unrelated to identifying the vehicle'));"
new=old+"""
  const grp = (Array.isArray(u.groups)?u.groups:[]).map(g=>typeof g==='string'?g:(g&&(g.name||g.title))||'').filter(Boolean);
  if(grp.length) add(t('المجموعات','Groups'), grp.slice(0,4).join('، ') + (grp.length>4?` +${grp.length-4}`:''));"""
rep(old,new,'٥) صف المجموعات')

# ===== ٦) التصعيد بياخد الحساب وعميل التذكرة =====
rep("function openEscalation(subject){",
    """/* v5.7 — سطور سياق بتتزود على نص التصعيد */
function escCtxLines(en){
  const acc = SESSION.user || (en ? '(not connected)' : '(مش متصل)');
  const tc = (($('tickCust') && $('tickCust').value) || '').trim();
  return (en ? `\\nConnected account: ${acc}` : `\\nالحساب المتصل: ${acc}`)
       + (tc ? (en ? `\\nTicket customer: ${tc}` : `\\nعميل التذكرة: ${tc}`) : '');
}
function openEscalation(subject){""",'٦أ) escCtxLines')
i0=s.find('function openEscalation(subject){')
seg=s[i0:i0+4500]; token='${baseUrl()}'
idxs=[]; j=0
while True:
    k=seg.find(token,j)
    if k<0: break
    idxs.append(k); j=k+len(token)
if len(idxs)!=2:
    miss.append(f'٦ب) مواضع البيئة (لقيت {len(idxs)})')
else:
    a,b=idxs
    seg2=seg[:a+len(token)]+'${escCtxLines(true)}'+seg[a+len(token):b+len(token)]+'${escCtxLines(false)}'+seg[b+len(token):]
    s=s[:i0]+seg2+s[i0+4500:]; done.append('٦ب) السياق في النسختين')

# ===== ٧) نوايا الشريحة وتاريخ الإضافة =====
anch='odometer|engine.?hours|counters/'
i=s.find(anch)
if i<0: miss.append('٧) سطر العدادات')
else:
    ln=s.find('\n', i)
    ins=("\n { re:/شريح[هة]|رقم الشريح[هة]|سيم كارت|sim/,                                p:/^\\/units\\/lists$/,     s:10 },"
         "\n { re:/امتي اتضاف|امتى اتضاف|تاريخ الاضاف|اتضافت عل[يى] الحساب|تاريخ اضاف[هة] الجهاز/, p:/^\\/units\\/lists$/,   s:10 },")
    s=s[:ln]+ins+s[ln:]; done.append('٧) نيتين جداد')

for d in done: print('تمام:',d)
if miss:
    print('!! MISS:'); [print('  ',x) for x in miss]; sys.exit(1)
open(P,'w',encoding='utf-8').write(s)
print(f'اتكتب — {len(done)} تعديل')
