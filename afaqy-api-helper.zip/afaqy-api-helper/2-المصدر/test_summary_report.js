/* اختبارات v6.34 — سيناريو تقرير Summary الكامل.
   اللي بنثبته: الأداة ما بتقراش الصفوف قبل ما التوليد يخلص، والرد الفاضي
   بيتشرح كحالة مش كعطل، والتفاصيل بتروح لـ data-new بـ resource_id
   مش لـ data-summary. */
const fs = require('fs');
const { JSDOM } = require('jsdom');

let FAILED = 0;
const fail = m => { console.log('  \u2717 ' + m); FAILED++; };
const pass = m => console.log('  \u2713 ' + m);
const ok = (m, cond, extra) => cond ? pass(m) : fail(m + (extra ? '  \u2014 ' + extra : ''));

const FILE = process.argv[2] || 'app_template.html';
function buildHtml(){
  return fs.readFileSync(FILE, 'utf8')
    .replace('/*__KB__*/',   () => fs.readFileSync('kb_slim.json', 'utf8'))
    .replace('/*__DOCS__*/', () => fs.readFileSync('docs.json', 'utf8'))
    .replace('/*__KBIN__*/', () => fs.readFileSync('kb_in.json', 'utf8'));
}

function boot(){
  const dom = new JSDOM(buildHtml(), { runScripts:'dangerously', pretendToBeVisual:true, url:'https://localhost/' });
  const w = dom.window;
  w.alert = () => {}; w.confirm = () => true; w.scrollTo = () => {};
  w.eval("SESSION.token='TOK'; SESSION.user='Opp'; SESSION.pass='p'; SESSION.userId='000000000000000000000001';");
  return w;
}

/* بنسجّل كل ريكوست الأداة بعتته عشان نحكم على السلوك مش على الكلام */
function stubFetch(w, plan){
  const calls = [];
  w.fetch = async (url, opt) => {
    let body = null;
    try { body = JSON.parse(opt && opt.body); } catch (_) {}
    const path = String(url).split('?')[0].replace(/^https?:\/\/[^/]+/, '');
    calls.push({ path, body });
    const hit = plan(path, body, calls);
    const txt = JSON.stringify(hit === undefined ? { message:'success', status_code:200, data:[] } : hit);
    return { ok:true, status:200, text: async () => txt };
  };
  return calls;
}
const nap = ms => new Promise(r => setTimeout(r, ms));
async function until(fn, tries, gap){
  for (let i = 0; i < (tries || 60); i++) { if (fn()) return true; await nap(gap || 100); }
  return false;
}

(async () => {

/* ═════ ١) السيناريو موجود وترتيب خطواته صح ═════ */
console.log('\n\u0661) السيناريو وترتيب خطواته');
{
  const w = boot();
  ok('السيناريو مسجّل في RECIPES', !!w.eval("RECIPES.find(x=>x.id==='summary-report')"));
  const kinds = w.eval("RECIPES.find(x=>x.id==='summary-report').steps.map(s=>s.kind).join(',')").split(',');
  ok('فيه خطوة تحديد نطاق', kinds.indexOf('rscope') > -1, kinds.join(','));
  ok('فيه خطوة متابعة توليد', kinds.indexOf('poll') > -1, kinds.join(','));
  ok('المتابعة قبل قراءة الصفوف',
     kinds.indexOf('poll') > -1 && kinds.indexOf('poll') < kinds.indexOf('rows'), kinds.join(','));
  ok('التصدير آخر خطوة', kinds[kinds.length-1] === 'rexport', kinds.join(','));
  ok('خطوة الإنشاء بتنده user_reports/add',
     w.eval("RECIPES.find(x=>x.id==='summary-report').steps.some(s=>s.path==='/user_reports/add')"));
  w.showView('recipes'); w.renderRecipeCards();
  ok('السيناريو ظاهر في كروت الشاشة', !!w.document.querySelector('[data-r="summary-report"]'));
  w.close();
}

/* ═════ ٢) بودي الإنشاء بياخد عربيات النطاق فعلاً ═════ */
console.log('\n\u0662) بودي الإنشاء');
{
  const w = boot();
  const body = JSON.parse(w.eval(`JSON.stringify((function(){
    const st = RECIPES.find(x=>x.id==='summary-report').steps.find(s=>s.path==='/user_reports/add');
    return st.body({ resources:['AAA','BBB','CCC'], scopeLabel:'group',
      _tplRaw:{code:'summary', fields:[{name:'Name', code:'name'}]},
      from:'2026-08-01', to:'2026-08-05' });
  })())`));
  ok('resources = عربيات النطاق',
     JSON.stringify(body.data.resources) === JSON.stringify(['AAA','BBB','CCC']),
     JSON.stringify(body.data.resources));
  ok('الكود متاخد من القالب', body.data.code === 'summary', String(body.data.code));
  ok('الأعمدة من القالب مش مخترعة', Array.isArray(body.data.fields) && body.data.fields.length === 1);
  ok('نوع المورد units', body.data.selected_resource_type === 'units');
  ok('الفترة من المدخلات',
     body.data.date.from === '2026-08-01 00:00:00' && body.data.date.to === '2026-08-05 23:59:59',
     JSON.stringify(body.data.date));
  ok('مفيش ID من عينة الكولكشن في البودي',
     JSON.stringify(body).indexOf('66fd1abe') < 0 && JSON.stringify(body).indexOf('63f223f9') < 0);
  w.close();
}

/* ═════ ٣) قراءة النسبة وشكل الصفوف ═════ */
console.log('\n\u0663) قراءة نسبة التوليد وشكل الصفوف');
{
  const w = boot();
  ok('نسبة من شكل reportId/percentage',
     w.pollPct({ data:[{ reportId:'R1', percentage:100 }] }, 'R1') === 100);
  ok('بتفرّق بين تقريرين في نفس الرد',
     w.pollPct({ data:[{ reportId:'R1', percentage:12 }, { reportId:'R2', percentage:99 }] }, 'R2') === 99);
  ok('رد من غير نسبة بيرجّع null', w.pollPct({ message:'success', data:[] }, 'R1') === null);
  ok('reportRows بتلاقي أكبر مصفوفة صفوف',
     w.reportRows({ data:[{a:1},{a:2}], extra:[] }).length === 2);
  ok('reportRows بترجع فاضي لو مفيش صفوف', w.reportRows({ message:'success', data:[] }).length === 0);
  ok('rowUnitId بتفضّل resource_id', w.rowUnitId({ resource_id:'R', unit_id:'U', id:'I' }) === 'R');
  ok('rowUnitId بترجع فاضي لو مفيش معرّف', w.rowUnitId({ name:'x' }) === '');
  w.close();
}

/* ═════ ٤) السلسلة اللايف: بتستنى ١٠٠٪ قبل ما تقرا ═════ */
console.log('\n\u0664) المتابعة بتسبق القراءة فعلًا');
{
  const w = boot();
  let pctCalls = 0;
  const calls = stubFetch(w, (path) => {
    if (path === '/user_reports/percentage') {
      pctCalls++;
      return { message:'success', status_code:200,
               data:[{ reportId:'RID9', percentage: pctCalls >= 3 ? 100 : pctCalls * 30 }] };
    }
    if (path === '/user_reports/data-summary')
      return { message:'success', status_code:200,
               data:[{ resource_id:'U1', name:'car-1', route_length:72.71, max_spd:108 }] };
  });
  w.showView('recipes');
  w.startRecipe('summary-report');
  w.eval(`RC.vars.reportId='RID9'; RC.vars.scopeLabel='all';
          RC.vars._unitNames={U1:'car-1'};
          RC.results[RC.r.steps.findIndex(s=>s.kind==='poll')-1] = {ok:true, msg:'x'};`);
  w.renderSteps();
  const iP = w.eval("RC.r.steps.findIndex(s=>s.kind==='poll')");
  const iR = w.eval("RC.r.steps.findIndex(s=>s.kind==='rows')");

  w.runStep(iP);
  await until(() => w.eval(`!!(RC.results[${iP}] && RC.results[${iP}].ok)`), 90, 150);
  ok('المتابعة بتنجح لما توصل ١٠٠٪', w.eval(`!!(RC.results[${iP}] && RC.results[${iP}].ok)`),
     w.eval(`RC.results[${iP}] ? String(RC.results[${iP}].msg).slice(0,80) : 'null'`));
  ok('سألت percentage أكتر من مرة مش مرة واحدة', pctCalls >= 3, 'pctCalls=' + pctCalls);
  ok('ما قرتش الصفوف وهي بتتولّد',
     calls.filter(c => c.path === '/user_reports/data-summary').length === 0);
  const pb = (calls.find(c => c.path === '/user_reports/percentage') || {}).body;
  ok('بودي المتابعة فيه رقم التقرير في ids',
     JSON.stringify(pb) === JSON.stringify({ data:{ ids:['RID9'] } }), JSON.stringify(pb));

  w.runStep(iR);
  await until(() => w.eval(`!!RC.results[${iR}]`), 60, 100);
  const okRows = w.eval(`!!(RC.results[${iR}] && RC.results[${iR}].ok)`);
  const html   = w.eval(`RC.results[${iR}] ? String(RC.results[${iR}].html||'') : ''`);
  ok('الصفوف رجعت بعد التوليد', okRows,
     w.eval(`RC.results[${iR}] ? String(RC.results[${iR}].msg).slice(0,80) : 'null'`));
  ok('الجدول فيه قيم التقرير الحقيقية', /72\.71/.test(html) && /108/.test(html));
  ok('فيه زرار تفاصيل للعربية', /data-rowdet="U1"/.test(html));
  w.close();
}

/* ═════ ٥) رد فاضي = حالة متشرحة مش عطل ═════ */
console.log('\n\u0665) الرد الفاضي بيتشرح');
{
  const w = boot();
  stubFetch(w, (path) => {
    if (path === '/user_reports/data-summary') return { message:'success', status_code:200, data:[] };
  });
  w.showView('recipes');
  w.startRecipe('summary-report');
  w.eval(`RC.vars.reportId='RID9';
          RC.results[RC.r.steps.findIndex(s=>s.kind==='rows')-1] = {ok:true, msg:'x'};`);
  w.renderSteps();
  const iR = w.eval("RC.r.steps.findIndex(s=>s.kind==='rows')");
  w.runStep(iR);
  await until(() => w.eval(`!!RC.results[${iR}]`), 60, 100);
  const html = w.eval(`String((RC.results[${iR}]||{}).html || '')`);
  ok('الفاضي متقال عليه مش خطأ', /مش خطأ|not an error/.test(html), html.slice(0, 110));
  ok('بيوجّه يرجع لخطوة المتابعة', /المتابعة|polling/.test(html));
  ok('ما ادّعاش نجاح', w.eval(`RC.results[${iR}].ok === false`));
  w.close();
}

/* ═════ ٦) التفاصيل بتروح لـ data-new بـ resource_id ═════ */
console.log('\n\u0666) تفاصيل عربية واحدة');
{
  const w = boot();
  const calls = stubFetch(w, (path) => {
    if (path === '/user_reports/data-new')
      return { message:'success', status_code:200, data:[{ dt:'2026-08-10', speed:40 }] };
  });
  w.showView('recipes');
  w.startRecipe('summary-report');
  w.eval(`RC.vars.reportId='RID9'; RC.vars._unitNames={U7:'car-7'};
          const iR = RC.r.steps.findIndex(s=>s.kind==='rows');
          RC.results[iR-1] = {ok:true, msg:'x'};
          RC.results[iR] = {ok:true, msg:'x', html:'<div id="rowDet_'+iR+'"></div>'};`);
  w.renderSteps();
  const iR = w.eval("RC.r.steps.findIndex(s=>s.kind==='rows')");
  w.rowDetail(iR, 'U7', null);
  await until(() => calls.some(c => c.path === '/user_reports/data-new'), 60, 100);
  const c = calls.find(x => x.path === '/user_reports/data-new');
  ok('التفاصيل بتنده data-new مش data-summary', !!c);
  ok('البودي فيه resource_id للعربية',
     !!(c && c.body && c.body.data && c.body.data.resource_id === 'U7'), JSON.stringify(c && c.body));
  ok('البودي فيه رقم التقرير كمان', !!(c && c.body && c.body.data && c.body.data.id === 'RID9'));
  ok('ما نداش data-summary في خطوة التفاصيل',
     !calls.some(x => x.path === '/user_reports/data-summary'));
  w.close();
}

/* ═════ ٧) التصدير بياخد نفس رقم التقرير ═════ */
console.log('\n\u0667) التصدير');
{
  const w = boot();
  const calls = stubFetch(w, (path) => {
    if (path === '/user_reports/export')
      return { message:'success', status_code:200, data:{ url:'https://x/y.pdf' } };
  });
  w.showView('recipes');
  w.startRecipe('summary-report');
  w.eval(`RC.vars.reportId='RID9';
          RC.results[RC.r.steps.findIndex(s=>s.kind==='rexport')-1] = {ok:true, msg:'x'};`);
  w.renderSteps();
  const iX = w.eval("RC.r.steps.findIndex(s=>s.kind==='rexport')");
  w.runStep(iX);
  await until(() => !!w.document.getElementById('rx_' + iX), 40, 60);
  const sel = w.document.getElementById('rx_' + iX);
  ok('بيطلع مختار نوع الملف', !!sel);
  ok('بيوضّح الفرق بين export و request-export',
     w.document.body.innerHTML.indexOf('request-export') > -1);
  if (sel) {
    sel.value = 'pdf';
    sel.dispatchEvent(new w.Event('change'));
    await until(() => calls.some(c => c.path === '/user_reports/export'), 60, 100);
    const c = calls.find(x => x.path === '/user_reports/export');
    ok('التصدير بينده user_reports/export', !!c);
    ok('بنفس رقم التقرير ونوع الملف',
       !!(c && c.body && c.body.data && c.body.data.id === 'RID9' && c.body.data.type === 'pdf'),
       JSON.stringify(c && c.body));
  }
  w.close();
}

console.log('\n' + (FAILED ? '\u2717 فشل: ' + FAILED : '\u2713 كله عدّى'));
process.exit(FAILED ? 1 : 0);
})();
