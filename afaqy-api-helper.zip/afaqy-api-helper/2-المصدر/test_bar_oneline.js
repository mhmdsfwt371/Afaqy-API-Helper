/* v6.4 — الشريط العلوي لازم يفضل سطر واحد.
   الاختبار ده اتكتب بعد ما المستخدم اشتكى إن الشريط بيلف لسطرين.
   الفحص على القواعد اللي بتضمن ده، عشان أي تعديل جاي ما يرجّعش المشكلة. */
const fs = require('fs');
const tpl = fs.readFileSync('app_template.html','utf8');
const css = tpl.slice(tpl.indexOf('<style>'), tpl.indexOf('</style>'));
const js  = tpl.slice(tpl.indexOf('<script>'));
const head = tpl.slice(0, tpl.indexOf('<script>'));
const fail = m => { console.error('فشل: ' + m); process.exit(1); };

/* ١) على الشاشات العادية الشريط ممنوع يلف */
const mq = css.slice(css.indexOf('@media(min-width:1000px)'));
if(css.indexOf('@media(min-width:1000px)') < 0) fail('قاعدة منع اللف اتشالت');
if(mq.indexOf('.conn{flex-wrap:nowrap') < 0) fail('الشريط مسموح له يلف تاني');
if(mq.indexOf('max-width:100%') < 0) fail('من غير سقف عرض العناصر مش هتنكمش — هتطلع برّه الشاشة');
console.log('منع اللف           : nowrap + سقف عرض ✓');

/* ٢) الشارات ما تتسحقش لحرف واحد */
for(const id of ['sesState','unitState']){
  const i2 = mq.indexOf('#'+id+'{');
  if(i2 < 0) fail('قاعدة الشارة مش موجودة: ' + id);
  if(mq.slice(i2, mq.indexOf('}', i2)).indexOf('min-width') < 0) fail('شارة من غير حد أدنى: ' + id);
}
console.log('حدود الشارات       : فيه حد أدنى يمنع السحق ✓');

/* ٣) البيئة تفضل مقروءة — أهم معلومة في الشريط */
if(!/#baseUrl\{[^}]*flex:0 0 auto/.test(mq)) fail('البيئة ممكن تنكمش — لازم تفضل واضحة');
console.log('البيئة             : محمية من الانكماش ✓');

/* ٤) بعد الاتصال خانات الدخول بتختفي عشان تفضي مكان */
if(js.indexOf("['sesU','sesP','sesGo','acctSel','acctSave','acctDel'].forEach") < 0)
  fail('خانات الدخول مش بتختفي بعد الاتصال — الشريط هيزحم');
if(js.indexOf('const on = !!SESSION.token;') < 0) fail('شرط الاتصال ناقص');
console.log('بعد الاتصال        : خانات الدخول بتختفي وبتفضي مكان ✓');

/* ٥) الأزرار العامة مكانها صف العنوان مش شريط الاتصال */
const brandBlock = head.slice(head.indexOf('<div class="brand">'), head.indexOf('<div class="conn">'));
for(const id of ['themeBtn','langBtn'])
  if(brandBlock.indexOf('id="'+id+'"') < 0) fail('زرار عام لسه في شريط الاتصال: ' + id);
console.log('الأزرار العامة     : في صف العنوان ✓');
