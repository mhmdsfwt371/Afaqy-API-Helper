/* v5.8 — الحسابات المحفوظة.
   الاختبار ده بيمسك أخطر حاجة ممكن تحصل هنا: كلمة سر بتتكتب صريحة على الجهاز،
   أو بتتحفظ من غير ما الموظف يوافق، أو بتتسرّب في نص التصعيد. */
global.setInterval=()=>0;global.clearInterval=()=>{};
const fs = require('fs');
function el(id){return{id,hidden:false,innerHTML:'',value:'',textContent:'',className:'',dataset:{},style:{},files:[],disabled:false,
 options:[],classList:{toggle(){},add(){},remove(){}},querySelectorAll(){return[]},addEventListener(){},focus(){},select(){},click(){},
 setAttribute(){},getAttribute(){return null},dispatchEvent(){},appendChild(){},remove(){},scrollIntoView(){}}}
const R={};global.document={documentElement:el(),body:el(),addEventListener(){},querySelectorAll(){return[]},
 querySelector(){return null},createElement(){return el()},getElementById(i){return R[i]||(R[i]=el(i))}};
global.history={pushState(){},replaceState(){}};global.location={hash:'',pathname:'/',replace(){}};
global.navigator={userAgent:'node',clipboard:{writeText(){return Promise.resolve()}}};
global.window={scrollTo(){},addEventListener(){},matchMedia:()=>({matches:false}),navigator:{}};
global.fetch=()=>Promise.reject(0);global.Blob=function(){};global.URL={createObjectURL(){return''}};global.FileReader=function(){};
global.btoa = x => Buffer.from(x,'binary').toString('base64');
global.atob = x => Buffer.from(x,'base64').toString('binary');
const DISK = {};
global.localStorage = {getItem:k=>(k in DISK?DISK[k]:null), setItem:(k,v)=>{DISK[k]=String(v);}, removeItem:k=>{delete DISK[k];}};
global.sessionStorage = {getItem:()=>null, setItem(){}, removeItem(){}};
let ASK = true; global.confirm = () => ASK;

let js = fs.readFileSync('app_template.html','utf8').split('<script>')[1].split('</script>')[0]
  .replace('/*__KB__*/', fs.readFileSync('kb_slim.json','utf8'))
  .replace('/*__DOCS__*/', fs.readFileSync('docs.json','utf8'));
const m={};
new Function('module', js + "\nmodule.exports={acctSave,acctPick,acctDelete,acctLoad,acctMask,acctUnmask,ACCT_KEY};")(m);
const A = m.exports;
const fail = msg => { console.error('فشل: ' + msg); process.exit(1); };
const $ = i => R[i] || (R[i] = el(i));
const PW = 'S3cret!باسورد';

/* ١) حفظ بكلمة السر ورجوعها صح */
$('sesU').value = 'support@abc'; $('sesP').value = PW; $('baseUrl').value = 'https://api.afaqy.sa';
ASK = true; A.acctSave();
let list = A.acctLoad();
if(list.length !== 1) fail('ما اتحفظش: ' + list.length);
if(list[0].u !== 'support@abc') fail('الاسم غلط');
$('sesU').value = ''; $('sesP').value = '';
$('acctSel').value = '0'; A.acctPick();
if($('sesU').value !== 'support@abc') fail('الاسم ما رجعش');
if($('sesP').value !== PW) fail('كلمة السر ما رجعتش صح: ' + $('sesP').value);
console.log('حفظ واسترجاع       : الاسم وكلمة السر رجعوا زي ما هما ✓');

/* ٢) كلمة السر مش صريحة على الجهاز — لا هي ولا أي جزء منها */
const raw = JSON.stringify(DISK);
if(raw.indexOf(PW) >= 0) fail('كلمة السر متخزّنة صريحة!');
if(raw.indexOf('S3cret') >= 0) fail('جزء من كلمة السر ظاهر صريح!');
console.log('على القرص          : مفيش كلمة سر صريحة ✓');

/* ٣) رفض الحفظ = الاسم يتحفظ وكلمة السر لأ */
DISK[A.ACCT_KEY] = '[]';
$('sesU').value = 'support@xyz'; $('sesP').value = PW;
ASK = false; A.acctSave();
list = A.acctLoad();
if(list[0].pw !== '') fail('كلمة السر اتحفظت رغم الرفض!');
$('sesP').value = 'حاجة تانية';
$('acctSel').value = '0'; A.acctPick();
if($('sesP').value !== '') fail('خانة كلمة السر المفروض تتفضّى');
if(JSON.stringify(DISK).indexOf('S3cret') >= 0) fail('أثر لكلمة السر بعد الرفض!');
console.log('رفض الحفظ          : الاسم بس، وصفر أثر لكلمة السر ✓');

/* ٤) نفس اليوزر على بيئتين = سجلين، والتحديث مش تكرار */
DISK[A.ACCT_KEY] = '[]';
$('sesU').value = 'ops'; $('sesP').value = 'p1'; $('baseUrl').value = 'https://api.afaqy.sa';
ASK = true; A.acctSave();
$('baseUrl').value = 'https://apibeta.afaqy.pro'; A.acctSave();
if(A.acctLoad().length !== 2) fail('البيئتين المفروض سجلين: ' + A.acctLoad().length);
A.acctSave();
if(A.acctLoad().length !== 2) fail('الحفظ المكرر عمل سجل زيادة');
console.log('البيئات            : سجل لكل بيئة، والتكرار بيحدّث ✓');

/* ٥) المسح بيشيل السجل وأثره */
$('acctSel').value = '0'; ASK = true; A.acctDelete();
if(A.acctLoad().length !== 1) fail('المسح ما اشتغلش');
console.log('المسح              : السجل اتشال ✓');

/* ٦) التمويه مربوط باليوزر — مش مفتاح واحد لكل الحسابات */
if(A.acctMask('نفس الباسورد','userA') === A.acctMask('نفس الباسورد','userB'))
  fail('نفس الناتج ليوزرين مختلفين');
if(A.acctUnmask(A.acctMask('abc','u'), 'u') !== 'abc') fail('الفك مش راجع للأصل');
if(A.acctUnmask('مش base64 خالص', 'u') !== '') fail('مدخل بايظ المفروض يرجع فاضي');
console.log('التمويه            : مربوط باليوزر وبيتحمّل المدخل البايظ ✓');

/* ٧) الحسابات ما تظهرش في نص التصعيد */
const tpl = fs.readFileSync('app_template.html','utf8');
const iEsc = tpl.indexOf('function openEscalation');
const body = tpl.slice(iEsc, iEsc + 5000);
for(const bad of ['acctLoad', 'SESSION.pass', 'ACCT_KEY'])
  if(body.indexOf(bad) >= 0) fail('التصعيد بيلمس ' + bad);
console.log('التصعيد            : مفيش حسابات ولا باسوردات فيه ✓');
