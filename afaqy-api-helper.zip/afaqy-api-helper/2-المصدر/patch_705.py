#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v7.5 — آخر موقع من /units/lists، و/units/locations نقط التراك خلال فترة.

من صفوت (٢٨ أكتوبر): آخر موقع للعربية بييجي من /units/lists نفسه في
last_update (lat و lng وآخر سيجنال). و/units/locations هو نقط التراك اللي
بتترسم خلال فترة زمنية — كان موجود، بس مش في التوثيق الرسمي.
القرار: في ردود العملاء يفضل /units/signals (الموثّق) للفترة.

- سبب الاحتفاظ بـ /units/locations اتصلّح (كان بيقول «آخر موقع» — غلط).
- معلومة ثابتة للفريق بنفس المعنى، ومصدرها صفوت.
- رد الـ IMEI: الخطوة التانية بقت بتقول صراحة إنها للفترة بس — لو العميل عايز
  آخر موقع، الخطوة الأولى كفاية.
"""
import sys, io, os
HERE = os.path.dirname(os.path.abspath(__file__))
PATH = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, 'app_template.html')
src = io.open(PATH, encoding='utf-8').read(); orig = len(src)
def rep(old, new, n=1, tag=''):
    global src
    c = src.count(old)
    if c != n: raise SystemExit('MISMATCH [%s]: expected %d found %d\n---\n%s' % (tag, n, c, old[:200]))
    src = src.replace(old, new, n); print('  ok  %s' % tag)

rep("""const LEARNED = [
""", """const LEARNED = [
 { sev:'high', src:{ar:'صفوت — أكتوبر 2026', en:'Safwat — October 2026'},
   t:{ar:'آخر موقع من /units/lists — و/units/locations نقط التراك خلال فترة', en:'Last location comes from /units/lists — /units/locations is the track points over a period'},
   body:{ar:`<p><b>آخر موقع للعربية</b> بييجي من <code>/units/lists</code> نفسه، جوه <code>last_update</code>: <code>lat</code> و<code>lng</code> ووقت آخر سيجنال. فلتر بالـ <code>IMEI</code> وبروجيكشن <code>last_update</code> — نداء واحد بيرجّع الـ <code>UID</code> وآخر موقع.</p>
   <p><b><code>/units/locations</code></b> هو نقط التراك اللي بتترسم خلال فترة زمنية. كان شغّال، بس <b>مش في التوثيق الرسمي</b> — في ردود العملاء استخدم <code>/units/signals</code> للفترة لأنه الموثّق.</p>
   <p>غلطة متكررة: العميل عايز آخر موقع، فبينادي <code>/units/locations</code> (التراك) بدل <code>/units/lists</code>.</p>`,
     en:`<p><b>The last location</b> of a vehicle comes from <code>/units/lists</code> itself, inside <code>last_update</code>: <code>lat</code>, <code>lng</code> and the time of the last signal. Filter by <code>IMEI</code> with the <code>last_update</code> projection — one call returns the <code>UID</code> and the last location.</p>
   <p><b><code>/units/locations</code></b> returns the track points drawn over a period. It has worked, but it is <b>not in the official documentation</b> — in customer replies use <code>/units/signals</code> for a period, because it is documented.</p>
   <p>A recurring mistake: the customer wants the last location and calls <code>/units/locations</code> (the track) instead of <code>/units/lists</code>.</p>`} },
""", tag='معلومة ثابتة للفريق')
rep("""        note:{ar:'المواقع خلال فترة: كل رسالة فيها الوقت والموقع والسرعة. الصفحات بـ limit و offset — زوّد offset بـ 100 لحد ما الرد يرجع فاضي.',
              en:'Positions over a period: every message carries its time, position and speed. Page through with limit and offset — increase offset by 100 until the response comes back empty.'}});""",
"""        note:{ar:'للفترة بس: لو المطلوب آخر موقع، الخطوة ١ كفاية (last_update). للمواقع خلال فترة: كل رسالة فيها الوقت والموقع والسرعة، والصفحات بـ limit و offset — زوّد offset بـ 100 لحد ما الرد يرجع فاضي.',
              en:'Only for a period: if you need the last location, step 1 is enough (last_update). For positions over a period: every message carries its time, position and speed. Page through with limit and offset — increase offset by 100 until the response comes back empty.'}});""", tag='الخطوة التانية للفترة بس')

io.open(PATH, 'w', encoding='utf-8').write(src)
print('القالب: %d → %d بايت' % (orig, len(src)))

cp = os.path.join(HERE, 'build_kb_from_collection.py'); cc = io.open(cp, encoding='utf-8').read()
o = "    ('POST', '/units/locations'):                     'سيناريو «آخر موقع لعربية» وطلب الإنتجريشن (المواقع خلال فترة) — العملاء لسه بيستخدموه',"
n = "    ('POST', '/units/locations'):                     'نقط التراك اللي بتترسم خلال فترة زمنية — العملاء بيستخدموه؛ آخر موقع بييجي من /units/lists (last_update)، وللفترة في ردود العملاء /units/signals الموثّق',"
if n in cc: print('  --  السبب متصلّح')
elif cc.count(o) != 1: raise SystemExit('MISMATCH converter reason')
else: io.open(cp, 'w', encoding='utf-8').write(cc.replace(o, n)); print('  ok  سبب الاحتفاظ اتصلّح')
