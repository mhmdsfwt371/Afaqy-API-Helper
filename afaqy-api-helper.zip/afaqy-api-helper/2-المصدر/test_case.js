/* اختبارات «حلّل رسالة عميل» — بنص إيميل العميل الحقيقي زي ما وصل.
   الفكرة: الاختبار يقرا الشاشة زي ما الموظف بيقراها، مش يستدعي دوال جوّه.
   لو رجع يطلب أدلة وهو قارى التشخيص، الاختبار بيقع. */
const fs = require('fs');
const { JSDOM } = require('jsdom');

let FAILED = 0;
const fail = m => { console.log('  ✗ ' + m); FAILED++; };
const pass = m => console.log('  ✓ ' + m);
const strip = h => String(h || '').replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ');

/* نص الإيميل زي ما وصل بالظبط — أكواد الحقول مكتوبة كلام مش JSON */
const EMAIL = `Dear Abdulrahman Alasmari,

I am currently integrating the following Report API:
https://api.afaqy.sa/reports/lists?token={{afaqy_token}}

The API is returning a successful response, but the data section appears to contain the report configuration and field metadata rather than the actual report values.
For example, under summary_beta, the response provides fields such as:

  - Date — code: date
  - Route Length — code: route_length
  - Engine Work Duration — code: engine_work
  - Engine Work Percentage — code: engine_work_percentage
  - Engine Move Duration — code: move_duration
  - Engine Idle — code: engine_idle
  - Stop Duration — code: stop_duration

Questions:
1. Which API endpoint should be used to retrieve the actual report data/records for summary_beta?
2. What parameters are required, such as vehicle ID, date range, report code, etc.?
3. Is there another API that needs to be called after retrieving the report configuration from /reports/lists?
4. Could you please provide a sample request and response containing actual values, for example Date: 10-08-2026 and Route Length: 70 km?`;

/* ريكوست غامض — لسه المفروض يطلب أدلة */
const VAGUE = `Hello team,
The integration is not working on our side. We tried again this morning and nothing came back.
Could you please check what is wrong? It used to work before and now it does not.
We are blocked on this and need it urgently for the go live next week please advise.`;

/* بنبني من القالب زي باقي اختبارات المصدر — عشان الاختبار يمشي في الخط الحقيقي */
function buildHtml(){
  return fs.readFileSync('app_template.html', 'utf8')
    .replace('/*__KB__*/',   fs.readFileSync('kb_slim.json', 'utf8'))
    .replace('/*__DOCS__*/', fs.readFileSync('docs.json', 'utf8'))
    .replace('/*__KBIN__*/', fs.readFileSync('kb_in.json', 'utf8'));
}

function boot(fetchImpl){
  const html = buildHtml();
  const dom = new JSDOM(html, { runScripts: 'dangerously', pretendToBeVisual: true, url: 'https://localhost/' });
  const w = dom.window;
  w.alert = () => {}; w.confirm = () => true; w.scrollTo = () => {};
  if (fetchImpl) w.fetch = fetchImpl;
  return w;
}

/* SESSION متعرّفة بـ const، يعني مش خاصية على window — بندخلها من نفس النطاق */
function setSession(w, token){
  w.eval(`SESSION.token=${JSON.stringify(token)}; SESSION.user='Opp';
          SESSION.userId='000000000000000000000001';`);
}

function analyse(w, text){
  w.document.getElementById('nav-inspect') ? w.document.getElementById('nav-inspect').click() : null;
  w.showView('inspect');
  w.document.getElementById('ivCase').click();
  w.document.getElementById('caseText').value = text;
  w.document.getElementById('caseGo').click();
  return w.document.getElementById('caseOut');
}

/* ═════════ ١) الرسالة المحسومة: يجاوب، ما يطلبش ═════════ */
console.log('\n١) رسالة تقرير الـ summary — المفروض تتحسم من غير طلب أدلة');
{
  const w = boot();
  const out = analyse(w, EMAIL);
  const txt = strip(out.innerHTML);
  const pre = out.querySelector('#caseReplyTxt');
  const reply = pre ? pre.textContent : '';

  if (!reply) fail('ما طلعش رد جاهز خالص');
  else pass('طلّع رد جاهز');

  if (out.querySelector('#caseAskTxt')) fail('لسه بيطلب أدلة — والتشخيص محسوم');
  else pass('ما طلبش أدلة');

  if (txt.indexOf('مش ناقص حاجة') < 0) fail('ما ظهرش بانل «مش ناقص حاجة»');
  else pass('بانل «مش ناقص حاجة» ظهر');

  ['/user_reports/add', '/user_reports/data-summary', '/user_reports/delete'].forEach(p => {
    if (reply.indexOf(p) < 0) fail('الرد ما فيهوش ' + p);
    else pass('الرد بيدل على ' + p);
  });

  if (/could you send us|send us the account|please provide the/i.test(reply))
    fail('الرد لسه بيطلب حاجة من العميل');
  else pass('الرد ما بيطلبش من العميل حاجة');

  ['route_length', 'engine_work', 'move_duration', 'engine_idle', 'stop_duration'].forEach(c => {
    if (reply.indexOf(c) < 0) fail('بودي المثال ما فيهوش الحقل ' + c);
  });
  pass('بودي المثال مبني من حقول العميل نفسها');

  if (reply.indexOf('summary_beta') < 0) fail('ما استخدمش كود التقرير اللي العميل ذكره');
  else pass('استخدم summary_beta زي ما هو');

  ['resources', 'selected_resource_type', 'user_id', 'interval_unit'].forEach(k => {
    if (reply.indexOf(k) < 0) fail('البودي ناقص ' + k);
  });
  pass('البودي فيه الباراميترات المطلوبة كلها');

  if (reply.indexOf('reports.afaqy-fleet.site') >= 0) fail('لسه بيوصّي بدومين التقارير القديم');
  else pass('ما بيوصّيش بالدومين الغلط');

  if (txt.indexOf('اسأل تيم التقارير') >= 0) fail('لسه بيقول بودي التنفيذ مش متسجّل');
  else pass('التحفّظ القديم اتشال');

  ['1)', '2)', '3)', '4)'].forEach(n => {
    if (reply.indexOf(n) < 0) fail('الرد ما بيجاوبش السؤال ' + n);
  });
  pass('الرد بيجاوب الأسئلة الأربعة بالترتيب');
}

/* ═════════ ٢) الرسالة الغامضة: لسه يطلب أدلة ═════════ */
console.log('\n٢) رسالة غامضة — المفروض لسه يطلب أدلة');
{
  const w = boot();
  const out = analyse(w, VAGUE);
  if (!out.querySelector('#caseAskTxt')) fail('بطّل يطلب أدلة في الحالة الغامضة');
  else pass('لسه بيطلب أدلة لما الرسالة فعلاً ناقصة');

  const ask = out.querySelector('#caseAskTxt').textContent;
  if (ask.indexOf('The account they are testing with') < 0)
    fail('ما طلبش الحساب وإحنا مش متصلين');
  else pass('بيطلب الحساب لما مفيش اتصال');
}

/* ═════════ ٣) وإحنا متصلين: ما يطلبش الحساب ═════════ */
console.log('\n٣) متصل بحساب — المفروض ما يطلبش اسم الحساب');
{
  const w = boot();
  setSession(w, 'TESTTOKEN');
  const out = analyse(w, VAGUE);
  const ask = out.querySelector('#caseAskTxt');
  if (!ask) fail('بطّل يطلب أي حاجة خالص');
  else if (ask.textContent.indexOf('The account they are testing with') >= 0)
    fail('لسه بيطلب اسم الحساب وهو متصل بيه');
  else pass('ما طلبش الحساب وهو متصل');
}

/* ═════════ ٤) السلسلة اللايف: إنشاء → قراءة → مسح ═════════ */
console.log('\n٤) التحقق اللايف — السلسلة كاملة والمسح مضمون');
{
  const calls = [];
  const reply = (obj) => Promise.resolve({
    ok: true, status: 200,
    text: () => Promise.resolve(JSON.stringify(obj))
  });
  const fetchMock = (url, opt) => {
    const body = opt && opt.body ? JSON.parse(opt.body) : {};
    calls.push({ url: String(url), body });
    if (/\/units\/lists/.test(url))
      return reply({ data: { items: [{ id: '5c3b1d7303ed52664c40f2c5', name: 'TRUCK-77' }] } });
    if (/\/user_reports\/add/.test(url))
      return reply({ data: { id: '62e2af6df2c6fc4f0d2031b8' } });
    if (/\/user_reports\/data-summary/.test(url))
      return reply({ data: [{ name: 'TRUCK-77', unit_id: '5c3b1d7303ed52664c40f2c5',
                              date: '10-08-2026', route_length: '70 km',
                              engine_work: '05:12:00', engine_idle: '00:48:00',
                              stop_duration: '18:00:00' }] });
    if (/\/user_reports\/delete/.test(url))
      return reply({ data: { deleted: true } });
    return reply({ data: {} });
  };

  const w = boot(fetchMock);
  setSession(w, 'SECRET-TOKEN-XYZ');
  const out = analyse(w, EMAIL);
  const btn = out.querySelector('#caseLive');
  if (!btn) { fail('زرار التحقق اللايف ما ظهرش وإحنا متصلين'); }
  else {
    pass('زرار التحقق اللايف ظهر');
    btn.click();
    setTimeout(() => {
      const paths = calls.map(c => c.url.replace(/\?.*/, ''));
      ['/units/lists', '/user_reports/add', '/user_reports/data-summary', '/user_reports/delete']
        .forEach(p => {
          if (!paths.some(u => u.indexOf(p) >= 0)) fail('السلسلة ما نادتش ' + p);
          else pass('نادى ' + p);
        });

      const add = calls.find(c => /user_reports\/add/.test(c.url));
      if (!add) fail('ما بعتش إنشاء تقرير');
      else {
        if (!add.body.data || add.body.data.resources[0] !== '5c3b1d7303ed52664c40f2c5')
          fail('ما حطّش id العربية اللي جابها في resources');
        else pass('حط id العربية في resources — مش IMEI');
        if (add.body.data.user_id !== '000000000000000000000001')
          fail('ما حطّش user_id من الحساب المتصل');
        else pass('حط user_id من رد الدخول');
        const codes = (add.body.data.fields || []).map(f => f.code);
        if (codes.indexOf('route_length') < 0 || codes.indexOf('engine_idle') < 0)
          fail('البودي اللي اتبعت ما فيهوش حقول العميل');
        else pass('البودي اتبعت بحقول العميل نفسها');
      }

      const del = calls.find(c => /user_reports\/delete/.test(c.url));
      if (!del || !del.body.data || del.body.data.id !== '62e2af6df2c6fc4f0d2031b8')
        fail('ما مسحش التقرير المؤقت برقمه');
      else pass('مسح التقرير المؤقت بعد التجربة');

      const pre = w.document.getElementById('caseReplyTxt');
      const txt = pre ? pre.textContent : '';
      if (txt.indexOf('70 km') < 0) fail('الرد الحقيقي ما اتحطّش في الرسالة');
      else pass('الرد الحقيقي اتحط في الرسالة');

      if (txt.indexOf('SECRET-TOKEN-XYZ') >= 0) fail('التوكن تسرّب في الرسالة');
      else pass('التوكن اتشال');
      if (txt.indexOf('5c3b1d7303ed52664c40f2c5') >= 0) fail('معرّف العربية تسرّب');
      else pass('المعرّفات اتشالت');
      if (txt.indexOf('TRUCK-77') >= 0) fail('اسم العربية تسرّب');
      else pass('اسم العربية اتشال');

      console.log(FAILED ? `\n✗ ${FAILED} اختبار وقع` : '\n✓ كل الاختبارات عدّت');
      process.exit(FAILED ? 1 : 0);
    }, 900);
  }
}

/* ═════════ رد الدعم الحقيقي: ريكوستين مش واحد ═════════
   عبدالرحمن بعت للعميل Report Summary و Report Data. الأداة لازم
   تطلّع الاتنين — والحلقة الناقصة اللي هو ما بعتهاش كمان. */
console.log('\nرد الدعم الحقيقي — الأداة لازم تغطّيه وتزوّد عليه');
{
  const w = boot();
  const out = analyse(w, EMAIL);
  const pre = out.querySelector('#caseReplyTxt');
  const reply = pre ? pre.textContent : '';
  const page  = strip(out.innerHTML);

  reply.indexOf('/user_reports/data-summary') > -1
    ? pass('الرد فيه data-summary (الملخص المجمّع)')
    : fail('الرد مفيهوش data-summary');

  reply.indexOf('/user_reports/data-new') > -1
    ? pass('الرد فيه data-new (تفاصيل العربية)')
    : fail('الرد مفيهوش data-new — ده نص رد الدعم');

  /resource_id/.test(reply)
    ? pass('الرد بيوضّح resource_id لتفاصيل العربية')
    : fail('الرد مفيهوش resource_id');

  reply.indexOf('/user_reports/percentage') > -1
    ? pass('الرد فيه متابعة التوليد — الحلقة اللي ناقصة من رد الدعم')
    : fail('الرد مفيهوش percentage');

  /100/.test(reply) && /empty/i.test(reply)
    ? pass('الرد بيحذّر من القراءة المبكرة اللي بترجع فاضي')
    : fail('الرد ما بيشرحش فخ الرد الفاضي');

  /* الفرق بين الاتنين لازم يبان — مش «نفس الصفوف بشكل أوسع» */
  /same rows in fuller shapes/i.test(reply)
    ? fail('لسه بيقول إن data-new نفس الصفوف — ده وصف غلط')
    : pass('وصف data-new اتصحّح');

  /aggregated summary/i.test(reply) && /single vehicle|one vehicle/i.test(reply)
    ? pass('الفرق بين المجمّع والتفصيلي مكتوب صريح')
    : fail('الفرق بين data-summary و data-new مش واضح');

  /* ولسه ما بيطلبش أدلة — الرسالة محسومة */
  !/caseAskCopy/.test(out.innerHTML)
    ? pass('ما رجعش يطلب أدلة — الرسالة فيها كل حاجة')
    : fail('رجع يطلب أدلة رغم إن التشخيص كامل');

  /percentage/.test(page)
    ? pass('لوحة التشخيص كمان بتوري المتابعة')
    : fail('التشخيص مفيهوش المتابعة');
}
