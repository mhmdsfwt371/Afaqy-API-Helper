#!/usr/bin/env bash
# النشر: البناء الأول، وأي فشل بيوقف كل حاجة.
set -euo pipefail
cd /home/claude

python3 build.py                     # الاختبارات وحارس العلامات جواه
umask 077
printf '%s' "$GH_TOKEN" > .ghtok
TOK=$(cat .ghtok)
rm -rf push && mkdir push && cd push
git -c init.defaultBranch=main init -q .
git remote add origin "https://x-access-token:${TOK}@github.com/mhmdsfwt371/Afaqy-API-Helper.git"
git -c http.version=HTTP/1.1 fetch -q origin main
git checkout -q -b main FETCH_HEAD
cp -r /mnt/user-data/outputs/repo/* .

L=$(git ls-files -o --exclude-standard -c | xargs -r grep -lao "ABS-Haj\|رواحل\|ريفيفا\|Reviva\|Kaar Technologies" 2>/dev/null | wc -l)
T=$(git ls-files -o --exclude-standard -c | xargs -r grep -lao "github_pat_" 2>/dev/null | wc -l)
echo "فحص التسريب: أسماء=$L توكنات=$T"
if [ "$L" -ne 0 ] || [ "$T" -ne 0 ]; then echo "!! تسريب — وقّفت"; exit 1; fi

git add -A
if git diff --cached --quiet; then echo "!! مفيش تغيير يترفع — البناء غالبًا ما اشتغلش"; exit 1; fi
git -c user.name="Afaqy Support Tool" -c user.email="support@afaqy.local" commit -q -F "$MSG_FILE"
git -c http.version=HTTP/1.1 push -q origin main
echo "اترفع فعلًا ✓"
cd /home/claude && rm -rf push .ghtok
