#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v6.3 — اتساق UX/UI: فصل الشريط، توحيد الحواف والخطوط، هرمية أزرار الأكشن."""
import sys
P='app_template.html'; s=open(P,encoding='utf-8').read()
miss=[]; done=[]
def rep(old,new,label,cnt=1):
    global s
    c=s.count(old)
    if c!=cnt: miss.append(f'{label} (لقيت {c})'); return
    s=s.replace(old,new); done.append(label)

# ===== ١) فاصل بصري في الشريط بين مجموعة الاتصال ومجموعة الجهاز =====
# قبل خانة الجهاز فيه unitSep — نخليه فاصل حقيقي بدل ما يكون شرطة نصية
rep('.conn{display:flex; flex-wrap:wrap; gap:8px; align-items:center; padding-bottom:12px}',
    '.conn{display:flex; flex-wrap:wrap; gap:8px; align-items:center; padding-bottom:12px}\n'
    '.conn .grp-sep{width:1px; align-self:stretch; min-height:22px; background:#33475C; margin:0 4px; opacity:.7}',
    '١أ) ستايل الفاصل')
# نحط فاصل قبل احفظ الحساب (بين الدخول وإدارة الحساب) وقبل خانة الجهاز
rep('<button class="btn ghost" id="acctSave"',
    '<span class="grp-sep" aria-hidden="true"></span>\n      <button class="btn ghost" id="acctSave"',
    '١ب) فاصل قبل إدارة الحساب')

# ===== ٢) توحيد كل الحواف على --r =====
rep('border-radius:2px; letter-spacing:.06em}',
    'border-radius:var(--r); letter-spacing:.06em}', '٢أ) حافة وسم الميثود')
rep('border-radius:2px; padding:1px 7px; font-size:11.5px; color:var(--ink-2)}',
    'border-radius:var(--r); padding:1px 7px; font-size:11.5px; color:var(--ink-2)}', '٢ب) حافة التاجف')
rep('background:var(--ok-soft); color:var(--ok); font-size:11px; padding:1px 7px; border-radius:2px',
    'background:var(--ok-soft); color:var(--ok); font-size:11px; padding:1px 7px; border-radius:var(--r)', '٢ج) حافة tagv')
rep('background:var(--alert-soft); color:var(--alert); font-size:11px; padding:1px 7px; border-radius:2',
    'background:var(--alert-soft); color:var(--alert); font-size:11px; padding:1px 7px; border-radius:var(--r);/*keep*/2', '٢د) حافة tagu')

# ===== ٣) توحيد الخطوط: مقياس واضح =====
# 13.5px و 14px المتناثرة → نثبّتهم. النص الأساسي 13.5، المتوسط 12.5، الصغير 11.5
rep('.chip{\n  background:var(--panel); border:1px solid var(--line); border-radius:99px;\n  padding:4px 11px; font-size:12.5px; color:var(--ink-2)\n}',
    '.chip{\n  background:var(--panel); border:1px solid var(--line); border-radius:99px;\n  padding:5px 12px; font-size:12.5px; color:var(--ink-2)\n}',
    '٣أ) حشوة الشيب')

# ===== ٤) هرمية أزرار الأكشن في صفحة الريكوست =====
# الأساسي (انسخ رد للعميل) = sig، الثانوي (جرّب/تصعيد) = ghost. نوحّد.
# التصعيد warn لونه برتقالي قوي جدًا كإجراء ثانوي — نخليه ghost بحافة تحذير خفيفة
rep(".btn.warn{background:transparent; color:var(--alert); border-color:#E3C3A6}",
    ".btn.warn{background:transparent; color:var(--alert); border-color:var(--line)}", '٤أ) تهدئة زر التصعيد')
rep(".btn.warn:hover{background:var(--alert-soft)}",
    ".btn.warn:hover{background:var(--alert-soft); border-color:#E3C3A6}", '٤ب) هوفر التصعيد')

# ===== ٥) عرض أدنى لخانات الشريط عشان الإنجليزي ما يتقصّش =====
rep(".conn input{width:190px}",
    ".conn input{width:190px}\n.conn select{min-width:120px}", '٥) عرض أدنى للقوائم')

# ===== ٦) الشارة m-* تتساوى في المقاس مع باقي الشارات =====
rep(".tag{display:inline-block; padding:2px 7px;",
    ".tag{display:inline-block; padding:2px 8px;", '٦) حشوة الميثود')

for d in done: print('تمام:',d)
if miss:
    print('!! MISS:'); [print('  ',x) for x in miss]; sys.exit(1)
open(P,'w',encoding='utf-8').write(s)
print(f'اتكتب — {len(done)} تعديل')
