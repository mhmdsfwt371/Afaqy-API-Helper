#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v6.43 — مراجعة شاملة: الفتحة الأولى، والمعرفة بتتحفظ، ومتصفح حقيقي في بوابة البناء.

اللي طلع من المراجعة (الأداة اتفتحت في كروم حقيقي، ديسكتوب وموبايل):

١) أول فتحة من غير hash: التبويب بيقول «ابدأ من هنا» واللي ظاهر شاشة
   الريكوستات، وكروت البداية فاضية تحتها. السبب إن boot ما كانش بينده
   showView غير لو فيه hash، وقسمي البحث والبداية الاتنين مش مخفيين في
   الـ HTML. الاختبارات ما مسكتهاش لأن كلها بتنده showView بنفسها.

٢) كارت «سؤال جديد ما جاش قبل كده» بيوجّه لتبويب lab اللي اتشال من زمان،
   واختبار الفرز كان بيعتبره صحيح.

٣) المعلومات اللي الفريق بيضيفها كانت في الذاكرة بس — تقفل التاب قبل ما
   تصدّر، تروح. ودي الحلقة اللي الريدمي بيقول عليها «الفرق بين أداة وأرشيف».

٤) ملف مستورد كان بيظهر فيه وسم <p> كنص، لأن الاستيراد بيهرّب البودي المصدَّر
   اللي هو أصلًا متغلّف بـ <p>.

٥) بوابة البناء ما كانتش بتفتح الأداة في متصفح خالص — وده اللي كان هيمسك (١).
"""
import sys, io, os, re

HERE = os.path.dirname(os.path.abspath(__file__))
PATH = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, 'app_template.html')
src = io.open(PATH, encoding='utf-8').read()
orig = len(src)

def rep(old, new, n=1, tag=''):
    global src
    c = src.count(old)
    if c != n: raise SystemExit('MISMATCH [%s]: expected %d found %d\n---\n%s' % (tag, n, c, old[:240]))
    src = src.replace(old, new, n); print('  ok  %s' % tag)

# ── ١) الفتحة الأولى ────────────────────────────────────────
rep("""(function(){ const h=(location.hash||'').slice(1);
  if(VIEWS.indexOf(h)>=0 && h!=='triage') showView(h); else VIEW_STACK=['triage']; })();""",
"""/* v6.43: من غير hash كان قسم البحث وقسم البداية بيظهروا فوق بعض وكروت البداية
   ما بتترسمش خالص — لأن showView ما كانتش بتتنده غير لو فيه hash.
   البداية بتترسم صراحةً، من غير ما تتسجّل في التاريخ (noPush). */
(function(){ const h=(location.hash||'').slice(1);
  if(VIEWS.indexOf(h)>=0 && h!=='triage') showView(h);
  else { VIEW_STACK=['triage']; showView('triage', true); } })();""", tag='boot: البداية بتترسم فعلًا')

# قسم البحث مخفي من البداية عشان ما يلمعش فوق البداية قبل ما الجافاسكريبت تشتغل
rep('<section class="view" id="v-search">', '<section class="view" id="v-search" hidden>', tag='v-search مخفي في الأول')

# ── ٢) كارت السؤال الجديد بيوجّه لتبويب موجود ─────────────
rep("  go:{tab:'lab'},", "  go:{tab:'search'},", tag='كارت «سؤال جديد» → البحث')
rep("'لقيت الريكوست؟ روح للمختبر وجرّبه على حساب العميل قبل ما تبعت.'",
    "'لقيت الريكوست؟ دوس «جرّب» عليه على حساب العميل قبل ما تبعت.'", tag='خطوة الكارت بالعربي')
rep("'Found the request? Take it to the lab and run it against the customer account before replying.'",
    "'Found the request? Press Try on it against the customer account before replying.'", tag='خطوة الكارت بالإنجليزي')

# ── ٣) المعرفة المضافة بتتحفظ على الجهاز ────────────────────
rep("""/* معرفة يضيفها الفريق بنفسه — من غير ما حد يفتح الكود */
let ADDED = [];""",
"""/* معرفة يضيفها الفريق بنفسه — من غير ما حد يفتح الكود.
   v6.43: كانت بتعيش في الذاكرة بس — تقفل التاب قبل ما تصدّر، تروح.
   دلوقتي بتتحفظ على الجهاز ده (نفس أسلوب الحسابات والعدّاد) وبترجع مع كل
   فتحة، ومعاها علامة هل اتصدّرت ولا لسه. */
let ADDED = [];
const ADDED_KEY = 'afaqy.added.v1', ADDED_EXP_KEY = 'afaqy.added.exportedAt';
const addedClean = v => typeof v==='string' ? esc(v).replace(/&lt;br&gt;/g,'<br>') : '';
/* غلاف <p> بيتشال قبل التنضيف — ملف مصدَّر من الأداة نفسها كان بيترجع بوسم <p> ظاهر كنص */
const addedUnwrap = v => String(v||'').replace(/^\\s*<p>/,'').replace(/<\\/p>\\s*$/,'');
/* الملف ممكن ييجي من أي حد — بنشيل أي وسوم قبل ما نعرضه */
function addedSafe(x){
  x = x || {};
  return {
    sev: x.sev==='high' ? 'high' : (x.sev==='mid' ? 'mid' : 'ok'),
    t:   {ar: addedClean((x.t||{}).ar||''), en: addedClean((x.t||{}).en||(x.t||{}).ar||'')},
    src: {ar: addedClean((x.src||{}).ar||''), en: addedClean((x.src||{}).en||(x.src||{}).ar||'')},
    body:{ar: '<p>'+addedClean(addedUnwrap((x.body||{}).ar))+'</p>',
          en: '<p>'+addedClean(addedUnwrap((x.body||{}).en||(x.body||{}).ar))+'</p>'},
    at:  typeof x.at==='string' ? x.at : ''
  };
}
function addedLoad(){
  try{ const a = JSON.parse(localStorage.getItem(ADDED_KEY) || '[]'); return Array.isArray(a) ? a : []; }
  catch(_){ return []; }
}
function addedStore(){
  try{ localStorage.setItem(ADDED_KEY, JSON.stringify(ADDED.slice(-200))); return true; }
  catch(_){ return false; }
}
function addedExportedAt(){ try{ return localStorage.getItem(ADDED_EXP_KEY) || ''; }catch(_){ return ''; } }
function addedMarkExported(){ try{ localStorage.setItem(ADDED_EXP_KEY, new Date().toISOString()); }catch(_){} }
function addedPending(){ const x = addedExportedAt(); return ADDED.filter(k => !x || String(k.at||'') > x).length; }
/* اللي متخزّن على الجهاز اتكتب بإيد الأداة نفسها — بنتأكد من الشكل بس */
function addedRestore(){
  ADDED = addedLoad().filter(k => k && k.t && k.body && typeof k.t.ar==='string' && typeof k.body.ar==='string');
  ADDED.forEach(k => LEARNED.push(k));
}
function addedStatus(){
  const n = ADDED.length, p = addedPending();
  if(!n) return t('المعلومات اللي بتضيفها بتتحفظ على الجهاز ده وبترجع مع كل فتحة. صدّرها وابعت الملف لمسؤول الأداة عشان تدخل النسخة اللي عند الكل.',
                  'Entries you add are kept on this device and come back every time you open the tool. Export the file and send it to whoever maintains the tool so it reaches everyone.');
  if(p) return t(`عندك ${p} من ${n} لسه ما اتصدّرتش — صدّرها وابعتها لمسؤول الأداة، وإلا هتفضل على جهازك بس.`,
                 `${p} of ${n} entries are not exported yet — export and send them to the maintainer, or they stay on this device only.`);
  return t(`${n} معلومة محفوظة على الجهاز ده وكلها اتصدّرت. لما تدخل النسخة الجديدة، امسحها من هنا عشان ما تتكررش.`,
           `${n} entries kept on this device, all exported. Once they ship in a new version, clear them here so they do not duplicate.`);
}""", tag='تخزين المعرفة المضافة')

rep("""      <label class="btn ghost" style="cursor:pointer">${t('استيراد','Import')}
        <input type="file" id="adImp" accept="application/json" hidden></label>
    </div>""",
"""      <label class="btn ghost" style="cursor:pointer">${t('استيراد','Import')}
        <input type="file" id="adImp" accept="application/json" hidden></label>
      <button class="btn ghost" id="adClr" ${ADDED.length ? '' : 'hidden'}>${t('امسح المحفوظ على الجهاز','Clear saved entries')}</button>
    </div>""", tag='زرار مسح المحفوظ')

rep("""    <div class="note" style="margin-top:10px">${t('المعلومات المضافة بتفضل في الجلسة دي بس. صدّرها وابعت الملف لمسؤول الأداة عشان يضمّها للنسخة اللي عند الكل.',
      'Added entries live in this session only. Export the file and send it to whoever maintains the tool so it reaches everyone.')}</div>""",
"""    <div class="note${addedPending() ? ' warn' : ''}" style="margin-top:10px" id="adStat">${addedStatus()}</div>""", tag='سطر الحالة في الفورم')

rep("""    ADDED.push(item); LEARNED.push(item);
""",
"""    item.at = new Date().toISOString();
    ADDED.push(item); LEARNED.push(item); addedStore();
""", tag='الإضافة بتتحفظ')

rep("""    a.download='afaqy-knowledge.json'; a.click();
  };""",
"""    a.download='afaqy-knowledge.json'; a.click();
    addedMarkExported(); renderFaq();
  };
  const c=$('adClr');
  if(c) c.onclick = ()=>{
    if(!confirm(t(`أمسح ${ADDED.length} معلومة محفوظة على الجهاز ده؟ اللي اتصدّر خلاص موجود في الملف اللي بعتّه.`,
                  `Clear ${ADDED.length} saved entries from this device? Exported ones are already in the file you sent.`))) return;
    ADDED.forEach(k=>{ const i=LEARNED.indexOf(k); if(i>=0) LEARNED.splice(i,1); });
    ADDED = []; addedStore();
    try{ localStorage.removeItem(ADDED_EXP_KEY); }catch(_){}
    toast(t('اتمسحت','Cleared')); renderFaq();
  };""", tag='التصدير بيعلّم + المسح')

rep("""      /* الملف ممكن ييجي من أي حد — بنشيل أي وسوم قبل ما نعرضه */
      const clean = v => typeof v==='string' ? esc(v).replace(/&lt;br&gt;/g,'<br>') : v;
      const safe = x => ({
        sev: (x && x.sev==='high') ? 'high' : (x && x.sev==='mid' ? 'mid' : 'ok'),
        t:   {ar: clean((x.t||{}).ar||''), en: clean((x.t||{}).en||(x.t||{}).ar||'')},
        src: {ar: clean((x.src||{}).ar||''), en: clean((x.src||{}).en||(x.src||{}).ar||'')},
        body:{ar: '<p>'+clean((x.body||{}).ar||'')+'</p>', en: '<p>'+clean((x.body||{}).en||(x.body||{}).ar||'')+'</p>'}
      });
      arr.filter(x=>x && x.t).map(safe).forEach(x=>{ LEARNED.push(x); ADDED.push(x); });""",
"""      const now = new Date().toISOString();
      arr.filter(x=>x && x.t).map(addedSafe).forEach(x=>{ x.at = x.at || now; LEARNED.push(x); ADDED.push(x); });
      addedStore();""", tag='الاستيراد بيستخدم التنضيف الموحّد')

rep("""    LEARNED.unshift(entry); ADDED.push(entry);""",
"""    entry.at = new Date().toISOString();
    LEARNED.unshift(entry); ADDED.push(entry); addedStore();""", tag='الرصد من المنصة بيتحفظ')

rep("""function boot(){
resetEmpty();""",
"""function boot(){
addedRestore();
/* تنبيه مرة واحدة في الجلسة لو فيه معلومات مضافة لسه ما اتبعتتش */
try{ const p = addedPending();
  if(p && !sessionStorage.getItem('addedNag')){ sessionStorage.setItem('addedNag','1');
    setTimeout(()=>toast(t(`عندك ${p} معلومة مضافة لسه ما اتصدّرتش — من تبويب الأساسيات`,
                            `${p} added entries are not exported yet — see the basics tab`)), 1500); }
}catch(_){}
resetEmpty();""", tag='الاسترجاع مع الفتحة')

io.open(PATH, 'w', encoding='utf-8').write(src)
print('القالب: %d → %d بايت' % (orig, len(src)))

# ── ٦) اختبار الفرز: التبويبات من الأداة نفسها، والفشل يفشّل ─────────
tp = os.path.join(HERE, 'test_triage.js')
tt = io.open(tp, encoding='utf-8').read()
def rep2(old, new, tag):
    global tt
    if tt.count(old) != 1: raise SystemExit('MISMATCH test_triage [%s]' % tag)
    tt = tt.replace(old, new); print('  ok  %s' % tag)
rep2("module.exports={ TRIAGE, EVIDENCE, LEARNED, LOG, logCall, dual, t, setL:(l)=>{LANG=l}, RECIPES };",
     "module.exports={ TRIAGE, EVIDENCE, LEARNED, LOG, logCall, dual, t, setL:(l)=>{LANG=l}, RECIPES, VIEWS };", 'تصدير VIEWS')
rep2("const tabs=['search','faq','browse','recipes','lab','triage'];",
     "/* v6.43: كانت قايمة يدوية فيها تبويبات اتشالت (browse, lab) فما مسكتش كارت بيوجّه لمكان مش موجود */\nconst tabs=A.VIEWS;", 'التبويبات من VIEWS')
rep2("console.log('broken tab targets   : ' + (badTab.length ? badTab.map(b=>b.go.tab).join(',') : 'none ✓'));",
     "console.log('broken tab targets   : ' + (badTab.length ? badTab.map(b=>b.go.tab).join(',') : 'none ✓'));\nif(bad.length || badTab.length){ console.error('فشل: كارت بيوجّه لمكان مش موجود'); process.exit(1); }", 'الفشل بيفشّل')
io.open(tp, 'w', encoding='utf-8').write(tt)

# ── ٧) بوابة البناء: متصفح حقيقي + الملفات الجديدة في الزيب ──────────
bp = os.path.join(HERE, 'build.py')
bb = io.open(bp, encoding='utf-8').read()
def rep3(old, new, tag):
    global bb
    if bb.count(old) != 1: raise SystemExit('MISMATCH build.py [%s]' % tag)
    bb = bb.replace(old, new); print('  ok  %s' % tag)
rep3("""def run_tests():""",
"""def run_browser_smoke():
    \"\"\"v6.43: الأداة بتتفتح في كروم حقيقي على الملف النهائي نفسه — الفتحة
       الأولى، والتبويبات، والبحث، واللغة، والوضع الليلي، والمعرفة المحفوظة.
       اختبارات jsdom كلها بتنده showView بنفسها، فعيب الفتحة الأولى عدّى منها.
       لو المتصفح مش موجود على الجهاز بيتخطى بتحذير واضح (زي الدليل وweasyprint)،
       ولو اشتغل وفشل البناء بيقف.\"\"\"
    r = subprocess.run([sys.executable, 'test_browser.py', os.path.join(REPO, 'index.html')],
                       cwd=HERE, capture_output=True, text=True, timeout=300)
    print(r.stdout.rstrip())
    if r.returncode == 2:
        print('!! اختبار المتصفح اتخطى — المتصفح مش متاح هنا. شغّل setup.sh أو اختبره يدويًا قبل النشر.')
        return True
    if r.returncode != 0:
        print((r.stderr or '').strip()[-600:])
    return r.returncode == 0


def run_tests():""", 'دالة اختبار المتصفح')
rep3("""    if not check_docs_sync(ver):
        print('!! البناء وقف — الملفات بتقول أرقام مختلفة')
        sys.exit(1)""",
"""    if not check_docs_sync(ver):
        print('!! البناء وقف — الملفات بتقول أرقام مختلفة')
        sys.exit(1)
    if not run_browser_smoke():
        print('!! البناء وقف — الأداة اتكسرت في المتصفح الحقيقي')
        sys.exit(1)""", 'اختبار المتصفح جوه البوابة')
rep3("""                       or f in ('audit_i18n.py', 'kb_in.json', 'build_kb_in.py',""",
"""                       or f in ('audit_i18n.py', 'kb_in.json', 'build_kb_in.py',
                                'test_browser.py', 'package.json',""", 'الملفات الجديدة في الزيب')
io.open(bp, 'w', encoding='utf-8').write(bb)
print('تمام — شغّل الاختبارات وبعدين build.py')
