/* فحوصات الشكل والاستخدام — بتتأكد إن الحلول موجودة فعلًا في الملف */
const fs=require('fs');
const tpl=fs.readFileSync('app_template.html','utf8');
const fail=s=>{ console.error('فشل: '+s); process.exit(1); };

// ١) مفيش سكرول جوه سكرول
if(/^\.pre\{[^}]*max-height/m.test(tpl)) fail('قاعدة .pre الأساسية لسه فيها ارتفاع أقصى');
if(/<pre class="pre"[^>]*max-height:\d+px/.test(tpl)) fail('لسه في بلوك بارتفاع ثابت متكتوب بالإيد');
if(tpl.indexOf('.preWrap.clip .pre{max-height:300px; overflow:hidden}')<0) fail('القص مش متعرّف');
if(tpl.indexOf('function clipBlocks')<0) fail('دالة القص مش موجودة');
const calls=(tpl.match(/clipBlocks\(/g)||[]).length;
if(calls < 5) fail('القص مش متنادى في كل مكان: '+calls);
console.log('مفيش سكرول جوه سكرول   ✓  ('+(calls-1)+' مكان بينادوه)');

// ٢) اسم الإندبوينت ثابت وانت نازل
if(tpl.indexOf('.p-head{padding:14px 18px; border-bottom:1px solid var(--line-soft);\n  position:sticky')<0) fail('هيدر الإندبوينت مش ثابت');
if(tpl.indexOf('@media(max-width:900px){ .p-head{position:static} }')<0) fail('التثبيت مش متلغي على الموبايل');
console.log('هيدر الإندبوينت ثابت    ✓');

// ٣) الموبايل
const mob = tpl.slice(tpl.indexOf('@media(max-width:760px)'), tpl.indexOf('@media print'));
if(!mob) fail('مفيش قواعد للموبايل');
[['.tabs-in{overflow-x:auto','التبويبات بتتزحلق'],
 ['font-size:16px','خانة البحث 16px عشان آيفون ما يزوّمش'],
 ['.cards{grid-template-columns:1fr}','الكروت عمود واحد'],
 ['.conn input{flex:1 1 120px','شريط الاتصال بيتلف']].forEach(([k,why])=>{
  if(mob.indexOf(k)<0) fail('ناقص للموبايل: '+why);
});
console.log('الموبايل                ✓  (تبويبات، بحث، كروت، شريط الاتصال)');

// ٤) زرار إغلاق واحد
if((tpl.match(/id="mclose"|id="mx"/g)||[]).length !== 1) fail('أكتر من زرار إغلاق');
console.log('زرار إغلاق واحد         ✓');
