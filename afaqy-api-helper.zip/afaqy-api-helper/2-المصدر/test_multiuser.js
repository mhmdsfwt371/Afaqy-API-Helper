/* موظفين شغالين في نفس الوقت: كل واحد نسخته المستقلة.
   بنشغّل نسختين من الأداة جنب بعض ونتأكد إن مفيش أي تسريب بينهم. */
const fs = require('fs');
const SRC = fs.readFileSync('app_template.html','utf8').split('<script>')[1].split('</script>')[0]
  .replace('/*__KB__*/', fs.readFileSync('kb_slim.json','utf8'))
  .replace('/*__DOCS__*/', fs.readFileSync('docs.json','utf8'));

/* في المتصفح كل تبويب ليه متغيراته. في نود مشتركة، فبنبدّلها قبل كل نداء. */
function boot(token, units, user){
  const R = {};
  const el = id => ({id, hidden:false, innerHTML:'', value:'', textContent:'', className:'', dataset:{}, style:{},
    files:[], disabled:false, classList:{toggle(){},add(){},remove(){}}, querySelectorAll(){return[]},
    addEventListener(){}, focus(){}, select(){}, click(){}, setAttribute(){}, getAttribute(){return null},
    dispatchEvent(){}, appendChild(){}, remove(){}, scrollIntoView(){}, onclick:null});
  R.sesU = el('sesU'); R.sesU.value = user;
  R.sesP = el('sesP'); R.sesP.value = 'pw';
  global.document = {documentElement:el(), body:el(), addEventListener(){}, querySelectorAll(){return[]},
    querySelector(){return null}, createElement(){return el()},
    getElementById(i){ return R[i] || (R[i] = el(i)); }};
  global.history={pushState(){},replaceState(){}};
  global.location={hash:'',pathname:'/',replace(){},reload(){}};
  global.setInterval=()=>0;
  global.navigator={clipboard:{writeText(){return Promise.resolve()}}};
  global.window={scrollTo(){},addEventListener(){}};
  global.AbortController=function(){this.signal={};this.abort=()=>{}};
  global.Blob=function(){}; global.URL={createObjectURL(){return''}}; global.FileReader=function(){};
  global.fetch=()=>Promise.resolve({ok:true, status:200, text:()=>Promise.resolve(JSON.stringify(
    {message:'success', status_code:200, data:{token, items:units}}))});
  const env = {document:global.document, fetch:global.fetch, location:global.location};
  const m={};
  new Function('module', SRC + "\nmodule.exports={SESSION,connect,resolveUnit,EPS,prepBody};")(m);
  return {api:m.exports, env};
}
function use(inst){
  global.document = inst.env.document;
  global.fetch    = inst.env.fetch;
  global.location = inst.env.location;
  return inst.api;
}
const fail = s => { console.error('فشل: ' + s); process.exit(1); };

(async ()=>{
  const iA = boot('TOKEN_A', [{_id:'UA', name:'عربية أ', imei:'111'}], 'clientA');
  const iB = boot('TOKEN_B', [{_id:'UB', name:'عربية ب', imei:'222'}], 'clientB');
  const A = iA.api, B = iB.api;
  await use(iA).connect(true);
  await use(iB).connect(true);

  if(A.SESSION.token === B.SESSION.token) fail('التوكنات اتخلطت');
  if(A.SESSION.token !== 'TOKEN_A') fail('توكن أ اتغيّر');
  if(B.SESSION.token !== 'TOKEN_B') fail('توكن ب اتغيّر');
  console.log('التوكنات منفصلة   : أ=' + A.SESSION.token + '  ب=' + B.SESSION.token + ' ✓');

  await use(iA).resolveUnit('عربية أ');
  await use(iB).resolveUnit('عربية ب');
  if(!A.SESSION.unit || A.SESSION.unit.uid !== 'UA') fail('عربية أ مش مظبوطة');
  if(!B.SESSION.unit || B.SESSION.unit.uid !== 'UB') fail('عربية ب مش مظبوطة');
  console.log('العربيات منفصلة   : أ=' + A.SESSION.unit.name + '  ب=' + B.SESSION.unit.name + ' ✓');

  const sigA = A.EPS.find(e=>e.p==='/units/signals');
  const sigB = B.EPS.find(e=>e.p==='/units/signals');
  const bA = A.prepBody(sigA).text, bB = B.prepBody(sigB).text;
  if(bA.indexOf('UA') < 0 || bA.indexOf('UB') >= 0) fail('بودي أ فيه رقم غلط');
  if(bB.indexOf('UB') < 0 || bB.indexOf('UA') >= 0) fail('بودي ب فيه رقم غلط');
  console.log('البوديهات منفصلة  : كل واحد برقم عربيته ✓');

  A.SESSION.unit = null;
  if(!B.SESSION.unit) fail('التغيير عند أ أثّر على ب');
  console.log('التأثير المتبادل  : مفيش ✓');

  if(A.EPS === B.EPS) fail('الكولكشن نفسه مشترك بين النسختين');
  console.log('الحالة مشتركة؟    : لأ — كل نسخة ليها ذاكرتها ✓');
})();
