const fs=require('fs');
function el(id){return{id,hidden:false,innerHTML:'',value:'',textContent:'',className:'',dataset:{},style:{},files:[],disabled:false,
 classList:{toggle(){},add(){},remove(){}},querySelectorAll(){return[]},addEventListener(){},focus(){},select(){},click(){},
 setAttribute(){},getAttribute(){return null},dispatchEvent(){},appendChild(){},remove(){},scrollIntoView(){}}}
const R={};global.document={documentElement:el(),body:el(),addEventListener(){},querySelectorAll(){return[]},
 querySelector(){return null},createElement(){return el()},getElementById(i){return R[i]||(R[i]=el(i))}};
global.history={pushState(){},replaceState(){}};global.location={hash:''};
global.navigator={clipboard:{writeText(){return Promise.resolve()}}};
global.window={scrollTo(){},addEventListener(){}};
global.fetch=()=>Promise.reject(0);global.Blob=function(){};global.URL={createObjectURL(){return''}};global.FileReader=function(){};
let js=fs.readFileSync('app_template.html','utf8').split('<script>')[1].split('</script>')[0]
 .replace('/*__KB__*/',fs.readFileSync('kb_slim.json','utf8'))
 .replace('/*__DOCS__*/',fs.readFileSync('docs.json','utf8'));
const m={};new Function('module',js+`
module.exports={EPS,RESOLVERS,depsOf,missingDeps,setDep,depValue,SESSION,depSteps,prepBody,dual,setL:(l)=>{LANG=l}};`)(m);
const A=m.exports; A.setL('ar');
const pick=p=>A.EPS.find(e=>e.p===p);

console.log('=== أي ريكوست محتاج إيه ===');
[['/units/signals'],['/events/view'],['/events/assign_units'],['/drivers/view'],['/zones/view'],
 ['/unit_sensors/lists'],['/user_reports/data'],['/units/lists'],['/auth/login']].forEach(([p])=>{
  const e=pick(p); if(!e) return;
  const d=A.depsOf(e).map(r=>A.dual(r.label));
  console.log('  '+p.padEnd(26)+' → '+(d.length?d.join(' + '):'مش محتاج حاجة'));
});

console.log('\n=== مثالك بالظبط: بيانات حدث معين ===');
const ev=pick('/events/view');
console.log('  المطلوب: '+A.missingDeps(ev).map(r=>A.dual(r.ask)).join(' , '));
const r=A.RESOLVERS.find(x=>x.key==='event');
console.log('  اللستة اللي هنجيب منها: '+r.list.path+'  '+JSON.stringify(r.list.body));
console.log('  الخطوات اليدوية:');
A.depSteps(r).forEach((x,i)=>console.log('   '+(i+1)+') '+x));

console.log('\n=== بعد ما نحل الحدث ===');
A.setDep(r, {id:'64789adf456478a0530580b2', name:'تجاوز السرعة'});
console.log('  ناقص لسه؟ '+(A.missingDeps(ev).length?'أيوه':'لأ ✓'));
console.log('  البودي بقى: '+A.prepBody(ev).text.replace(/\s+/g,' '));

console.log('\n=== والعربيات لسه شغالة زي ما هي ===');
const sig=pick('/units/signals');
console.log('  قبل: '+(A.missingDeps(sig).length?'محتاج عربية ✓':'مش محتاج'));
A.setDep(A.RESOLVERS[0], {id:'5fb0e2e703ed529bb30f9af3', name:'NB YD'});
console.log('  بعد: '+(A.missingDeps(sig).length?'لسه محتاج':'جاهز ✓'));
console.log('  البودي: '+JSON.parse(A.prepBody(sig).text).data.unit_id);
