/* v7.6 — قياس فايدة الأداة: كل تحليل بيتعدّ مرة، والنتيجة بزرار، والتقرير بالشهر وتجميع الفريق — من غير أي بيانات عملاء. */
const fs=require('fs'); const {JSDOM}=require('jsdom');
let F=0; const ok=(m,c,x)=>{ console.log((c?'  \u2713 ':'  \u2717 ')+m+(c||!x?'':'  \u2014 '+String(x).slice(0,180))); if(!c) F++; };
const html=fs.readFileSync(process.argv[2]||'app_template.html','utf8')
  .replace('/*__KB__*/',()=>fs.readFileSync('kb_slim.json','utf8'))
  .replace('/*__DOCS__*/',()=>fs.readFileSync('docs.json','utf8'))
  .replace('/*__KBIN__*/',()=>fs.readFileSync('kb_in.json','utf8'))
  .replace('/*__MSGREADER__*/',()=>fs.readFileSync('vendor_msgreader.min.js','utf8'));
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
function boot(pre){ const w=new JSDOM(html,{runScripts:'dangerously',pretendToBeVisual:true,url:'https://localhost/',beforeParse(win){ if(pre) win.localStorage.setItem('afaqy.stats.v1', pre); }}).window;
  w.alert=()=>{}; w.scrollTo=()=>{}; w.TextDecoder=require('util').TextDecoder; w.TextEncoder=require('util').TextEncoder;
  w.showView('inspect'); w.eval("INSPVIEW='case'"); w.paintInspect(); return w; }
const T1='Dear team, Acme Logistics (contact Ahmed). POST /units/locations {"data":{"unit_id":"861230044934025"}} returns {"message":"not_allowed","status_code":401}';
(async()=>{
/* ١) التحليل بيتعدّ مرة، بنوعه، من غير نص */
{ const w=boot();
  w.document.getElementById('caseText').value=T1; w.document.getElementById('caseGo').click(); await sleep(40);
  w.document.getElementById('caseGo').click(); await sleep(40);   /* نفس النص تاني */
  const a=JSON.parse(w.localStorage.getItem('afaqy.stats.v1')||'[]');
  ok('التحليل اتعدّ مرة واحدة حتى لو اتحلّل مرتين', a.length===1, a.length);
  ok('نوع الحالة اتسجّل: قاعدة IMEI مكان الـ UID', a[0].k==='rule:imei-vs-uid' && a[0].src==='text', JSON.stringify(a[0]));
  const blob=w.localStorage.getItem('afaqy.stats.v1');
  ok('مفيش نص ولا اسم ولا رقم جهاز في المحفوظ', !/acme|ahmed|logistics|861230044934025|not_allowed|units\/locations/i.test(blob), blob);
  ok('زراير النتيجة تحت التحليل', ['ok','no','esc'].every(o=>!!w.document.querySelector(`[data-fb="${o}"]`)));
  w.document.querySelector('[data-fb="no"]').click(); w.document.querySelector('[data-fb="ok"]').click();
  const a2=JSON.parse(w.localStorage.getItem('afaqy.stats.v1'));
  ok('آخر اختيار هو اللي بيتحسب', a2.length===1 && a2[0].o==='ok', JSON.stringify(a2));
  ok('الزرار المختار متعلّم', w.document.querySelector('[data-fb="ok"]').className.includes('sig'));
  /* بعد إعادة الرسم (UID أوتوماتيك مثلًا) الاختيار فاضل ظاهر */
  w.renderCase(T1); await sleep(30);
  ok('بعد إعادة الرسم الاختيار فاضل', w.document.querySelector('[data-fb="ok"]').className.includes('sig'));
}
/* ٢) المصدر: ملف إيميل */
{ const w=boot(); w.ocrImage=async()=>({text:''});
  const eml=['Subject: test','Content-Type: text/plain; charset=utf-8','','Can we send the token in an Authorization header?'].join('\r\n');
  const u8=new Uint8Array(Buffer.from(eml)); const f=new w.File([u8],'x.eml'); f.arrayBuffer=async()=>u8.buffer;
  await w.mailIngest(f); await sleep(40);
  const a=JSON.parse(w.localStorage.getItem('afaqy.stats.v1')||'[]');
  ok('تحليل جه من ملف إيميل متسجّل كده', a.length===1 && a[0].src==='mail', JSON.stringify(a));
}
/* ٣) التقرير بالشهر */
{ const m=new Date().toISOString().slice(0,7), d=m+'-05';
  const ev=[{e:'case',h:'a',d,k:'rule:imei-vs-uid',src:'mail',o:'ok',sim:true},{e:'case',h:'b',d,k:'rule:imei-vs-uid',src:'text',o:'ok'},
            {e:'case',h:'c',d,k:'integration_request',src:'text',o:'esc'},{e:'case',h:'d',d,k:'unknown',src:'image',o:'no'},{e:'case',h:'e',d,k:'unknown',src:'text'},
            {e:'case',h:'f',d:'2026-01-03',k:'unknown',src:'text',o:'ok'}];
  const w=boot(JSON.stringify(ev)); const r=w.statsReport(ev, m);
  ok('الأرقام: 5 تحليلات، 4 متقيّمة، 50% اتحلّت، 25% اتصعّدت', r.n===5 && r.rated===4 && r.okPct===50 && r.escPct===25, JSON.stringify(r));
  ok('أكتر نوع أول، والمصادر والشبيه', r.kinds[0].k==='rule:imei-vs-uid' && r.kinds[0].n===2 && r.src.mail===1 && r.src.image===1 && r.sim===1);
  w.showView('faq'); w.eval("FAQVIEW='basics'"); w.renderFaq();
  const card=w.document.getElementById('usageCard'); const tx=card ? card.textContent : '';
  ok('«تقرير الاستخدام» في الأساسيات بالأرقام وأنواع الحالات', /تقرير الاستخدام/.test(tx) && /50%/.test(tx) && /25%/.test(tx) && /IMEI/.test(tx), tx.slice(0,200));
  ok('اختيار الشهر فيه الشهرين', w.document.getElementById('usMonth').options.length===2);
  /* التصدير */
  let parts=null; w.URL.createObjectURL=()=>'blob:x'; w.HTMLAnchorElement.prototype.click=function(){};
  const Bl=w.Blob; w.Blob=function(p,o){ parts=p; return new Bl(p,o); };
  w.document.getElementById('usExp').click();
  const j=parts && JSON.parse(parts.join(''));
  ok('التصدير: ملف تقرير بالشهر ده بس', j && j.kind==='afaqy-usage' && j.month===m && j.events.length===5 && !j.events.some(e=>e.d.startsWith('2026-01')), j && j.events.length);
  /* تجميع الفريق: ملفين من جهازين */
  const mk=(dev, evs)=>{ const s=JSON.stringify({kind:'afaqy-usage',v:1,month:m,device:dev,events:evs}); const f=new w.File([s],dev+'.json',{type:'application/json'}); f.text=async()=>s; return f; };
  const inp=w.document.getElementById('usTeam');
  Object.defineProperty(inp,'files',{value:[mk('dev1',ev.slice(0,3)), mk('dev2',ev.slice(3,5)), (()=>{ const f=new w.File(['{}'],'bad.json'); f.text=async()=>'not json'; return f; })()]});
  inp.dispatchEvent(new w.Event('change')); await sleep(40);
  const tx2=w.document.getElementById('usageCard').textContent;
  ok('تجميع الفريق: ملفين صالحين، والتالف اتساب', /الفريق كله/.test(tx2) && w.eval('USAGE_VIEW.teamFiles')===2, tx2.slice(0,160));
  const rt=w.statsReport(w.eval('USAGE_VIEW.team'), m);
  ok('أرقام الفريق مجمّعة من الجهازين', rt.n===5 && rt.engineers===2, JSON.stringify(rt));
  w.document.getElementById('usOwn').click();
  ok('«ارجع لأرقام الجهاز ده»', !/الفريق كله/.test(w.document.getElementById('usageCard').textContent));
}
console.log(F?`\nفشل ${F}`:'\nقياس فايدة الأداة: تمام'); process.exit(F?1:0);
})();
