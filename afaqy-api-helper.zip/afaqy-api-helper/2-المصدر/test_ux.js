const fs = require('fs');
function el(id){ const e={id, hidden:false, innerHTML:'', value:'', textContent:'', placeholder:'', disabled:false,
  dataset:{}, style:{}, files:[], classList:{toggle(){},add(){},remove(){}},
  querySelectorAll(){return[]}, addEventListener(){}, focus(){}, select(){}, click(){},
  setAttribute(){}, getAttribute(){return null}, dispatchEvent(){}, appendChild(){}, remove(){},
  scrollIntoView(){}, onclick:null, onchange:null }; return e; }
const REG = {};
global.document = { documentElement:el(), body:el(), addEventListener(){},
  querySelectorAll(){return[]}, querySelector(){return null}, createElement(){return el()},
  getElementById(id){ return REG[id] || (REG[id]=el(id)); } };
global.history={pushState(){},replaceState(){}};
global.location={hash:''};
global.navigator={clipboard:{writeText(){return Promise.resolve();}}};
global.window={scrollTo(){},addEventListener(){}}; global.fetch=()=>Promise.reject(new Error('stub'));
global.Blob=function(){}; global.URL={createObjectURL(){return''}}; global.FileReader=function(){};

let js = fs.readFileSync('app_template.html','utf8').split('<script>')[1].split('</script>')[0];
js = js.replace('/*__KB__*/', fs.readFileSync('kb_slim.json','utf8')).replace('/*__DOCS__*/', fs.readFileSync('docs.json','utf8'));
const m={};
new Function('module', js + `
module.exports={EPS,RECIPES,TRIAGE,DESTRUCTIVE,SAFE,labVariants,search,setL:(l)=>{LANG=l},dual,t,
  getMode:()=>MODE, RECENT, pushRecent, LEARNED, ERRORS};`)(m);
const A=m.exports;

console.log('التبويبات دلوقتي : ابدأ من هنا · الريكوستات · السيناريوهات · الأساسيات  (٤ بدل ٦)');
console.log('العناصر المسجّلة : ' + Object.keys(REG).length + ' عنصر اتنده عليه من غير خطأ ✓');

// التصحيح التلقائي لازم يكون مقفول على أي حاجة بتعدّل
const cases = [['/units/lists','List'],['/units/signals',null],['/units/add','Add'],['/units/edit','Edit'],
               ['/units/delete','Delete'],['/user_reports/send',null],['/unit_groups/bulk-delete',null]];
console.log('\nقفل التصحيح التلقائي:');
cases.forEach(([p,n])=>{ const e=A.EPS.find(x=>x.p===p && (!n||x.n===n)); if(!e) return;
  const blocked = A.DESTRUCTIVE.test(e.n)||A.DESTRUCTIVE.test(e.p);
  console.log('  ' + (blocked?'مقفول ':'مفتوح ') + e.p + '  (' + e.n + ')'); });

// السلّم لسه شغال
const u = A.EPS.find(e=>e.p==='/units/lists' && e.n==='List');
console.log('\nصيغ التصحيح لـ /units/lists : ' + A.labVariants(u).length);

// الأخير
A.pushRecent(u); A.pushRecent(A.EPS.find(e=>e.p==='/units/signals'));
A.pushRecent(u);   // مكرر: المفروض يتقدّم مش يتكرر
console.log('آخر اللي اتفتح : ' + A.RECENT.map(e=>e.p).join(' , ') + '  (مفيش تكرار ✓)');

// اللغتين لسه سليمين
['ar','en'].forEach(L=>{ A.setL(L);
  console.log('\n['+L+'] فرز: ' + A.dual(A.TRIAGE[0].sym).slice(0,60));
  console.log('['+L+'] سيناريو: ' + A.dual(A.RECIPES[0].title)); });

console.log('\nبحث لسه شغال : ' + A.search('اشارات الجهاز').slice(0,2).map(x=>x.e.p).join(' , '));
console.log('معرفة قابلة للنمو : ' + A.LEARNED.length + ' مدخل | أخطاء معروفة : ' + A.ERRORS.length);
