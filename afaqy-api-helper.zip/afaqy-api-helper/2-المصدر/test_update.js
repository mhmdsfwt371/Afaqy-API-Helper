const fs = require('fs');
function el(id){return{id,hidden:true,innerHTML:'',value:'',textContent:'',className:'',dataset:{},style:{},files:[],disabled:false,
 classList:{toggle(){},add(){},remove(){}},querySelectorAll(){return[]},addEventListener(){},focus(){},select(){},click(){},
 setAttribute(){},getAttribute(){return null},dispatchEvent(){},appendChild(){},remove(){},scrollIntoView(){}}}
const R={};global.document={documentElement:el(),body:el(),addEventListener(){},querySelectorAll(){return[]},
 querySelector(){return null},createElement(){return el()},getElementById(i){return R[i]||(R[i]=el(i))}};
global.history={pushState(){},replaceState(){}};
let REPLACED=null;
global.location={hash:'#search',pathname:'/Afaqy-API-Helper/',replace(u){REPLACED=u}};
global.setInterval=()=>0;
global.navigator={userAgent:'node',clipboard:{writeText(){return Promise.resolve()}}};
global.window={scrollTo(){},addEventListener(){},matchMedia:()=>({matches:false}),navigator:{}};
let SERVED=null;
global.fetch=(u)=>{ if(String(u).indexOf('version.json')>=0 && SERVED)
    return Promise.resolve({ok:true, json:()=>Promise.resolve(SERVED)});
  return Promise.reject(new Error('no net')); };
global.Blob=function(){};global.URL={createObjectURL(){return''}};global.FileReader=function(){};

let js = fs.readFileSync('app_template.html','utf8').split('<script>')[1].split('</script>')[0]
  .replace('/*__KB__*/', fs.readFileSync('kb_slim.json','utf8')).replace('/*__KBIN__*/', fs.readFileSync('kb_in.json','utf8'))
  .replace('/*__DOCS__*/', fs.readFileSync('docs.json','utf8'));
const m={};
new Function('module', js + "\nmodule.exports={checkUpdate,applyUpdate,DOCS};")(m);
const A=m.exports;
const fail = s => { console.error('فشل: '+s); process.exit(1); };
const bar = document.getElementById('updBar'), msg = document.getElementById('updMsg');

(async ()=>{
  // نفس النسخة → مفيش شريط
  SERVED={version:A.DOCS.version, notes:{ar:['حاجة'],en:['x']}};
  bar.hidden=true; await A.checkUpdate();
  if(!bar.hidden) fail('الشريط طلع مع إن النسخة نفسها');
  console.log('نفس النسخة        : مفيش شريط ✓');

  // نسخة أحدث → الشريط يطلع وفيه الرقم والجديد
  SERVED={version:'9.9', notes:{ar:['حاجة جديدة','وحاجة تانية'],en:['a','b']}};
  await A.checkUpdate();
  if(bar.hidden) fail('الشريط ما طلعش مع نسخة أحدث');
  if(msg.innerHTML.indexOf('9.9')<0) fail('رقم النسخة مش ظاهر');
  if(msg.innerHTML.indexOf('حاجة جديدة')<0) fail('الجديد مش ظاهر');
  if(msg.innerHTML.indexOf(A.DOCS.version)<0) fail('النسخة الحالية مش ظاهرة');
  console.log('نسخة أحدث         : الشريط طلع بالتفاصيل ✓');

  // ما يزنّش تاني على نفس النسخة
  bar.hidden=true; await A.checkUpdate();
  if(!bar.hidden) fail('زنّ تاني على نفس النسخة');
  console.log('ما يزنّش مرتين     : ✓');

  // نسخة أقدم (كاش متأخر) → ما يطلعش شريط
  SERVED={version:'0.9', notes:{ar:['قديمة'],en:['old']}};
  bar.hidden=true; await A.checkUpdate();
  if(!bar.hidden) fail('طلع شريط لنسخة أقدم');
  console.log('نسخة أقدم         : مفيش شريط ✓');

  // مفيش نت → ما يكسرش
  SERVED=null; bar.hidden=true;
  await A.checkUpdate();
  console.log('من غير نت         : ما كسرش ✓');

  // التحديث بيرجّعك لنفس التبويب
  A.applyUpdate();
  if(!REPLACED || REPLACED.indexOf('#search')<0) fail('التحديث ما رجّعش لنفس التبويب: '+REPLACED);
  if(REPLACED.indexOf('?v=')<0) fail('مفيش كسر للكاش');
  console.log('التحديث           : بيرجّع لنفس التبويب مع كسر الكاش ✓');
})();
