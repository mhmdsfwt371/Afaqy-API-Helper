const fs = require('fs');
global.document = { addEventListener(){}, querySelectorAll(){return[]}, createElement(){return{select(){},remove(){}}}, body:{appendChild(){}} };
global.history={pushState(){},replaceState(){}};
global.location={hash:''};
global.navigator = { clipboard:{ writeText(){return Promise.resolve();} } };
global.window = { scrollTo(){}, addEventListener(){} };
global.fetch = () => Promise.reject(new Error('stub'));

let js = fs.readFileSync('app_template.html','utf8').split('<script>')[1].split('</script>')[0];
js = js.replace('/*__KB__*/', fs.readFileSync('kb_slim.json','utf8')).replace('/*__KBIN__*/', fs.readFileSync('kb_in.json','utf8')).replace('/*__DOCS__*/', fs.readFileSync('docs.json','utf8')).split('/* ---------------- views ---------------- */')[0];
js = js.replace('const $ = id => document.getElementById(id);',
  "const $ = id => ({hidden:false,innerHTML:'',value:'',textContent:'',placeholder:'',querySelectorAll(){return[]},addEventListener(){},focus(){},setAttribute(){},dispatchEvent(){},onclick:null});");
const mod = {};
new Function('module', js + '\nmodule.exports={RECIPES,deepFindObj,LEARNED,ERRORS};')(mod);
const A = mod.exports;

// الرد الحقيقي من حالة عميل ج
const real = { status:true, data:{ items:[{
  _id:'5fb0e2e703ed529bb30f9af3', name:'NB YD - TH - 1129 SSA',
  counters:{ odometer_type:'gps', odometer:233207.232139,
             engine_hours_type:'acc', engine_hours:95761694, last_acc:0 } }]}};

const c = A.deepFindObj(real,'counters');
console.log('العدادات المستخرجة:', JSON.stringify(c));
console.log('ساعات محسوبة =', Math.round(c.engine_hours/3600), '| المتوقع من الإيميل = 26600');
console.log('مطابق؟', Math.round(c.engine_hours/3600) === 26600 ? 'أيوه ✓' : 'لأ ✗');
console.log('المسافة =', c.odometer.toFixed(2), 'كم | الشاشة بتقول 233207 كم');

const r = A.RECIPES.find(x=>x.id==='counters');
console.log('\nبودي جلب الجهاز بالمعرّف:');
console.log(JSON.stringify(r.steps[0].body({unitId:'5fb0e2e703ed529bb30f9af3'}), null, 1));

console.log('\nعدد الوصفات =', A.RECIPES.length);
console.log('معارف مسجّلة =', A.LEARNED.length, '| أخطاء في الكتالوج =', A.ERRORS.length);
