const fs=require('fs');
function el(id){return{id,hidden:false,innerHTML:'',value:'',textContent:'',className:'',dataset:{},style:{},files:[],disabled:false,
 classList:{toggle(){},add(){},remove(){}},querySelectorAll(){return[]},addEventListener(){},focus(){},select(){},click(){},
 setAttribute(){},getAttribute(){return null},dispatchEvent(){},appendChild(){},remove(){},scrollIntoView(){}}}
const R={};global.document={documentElement:el(),body:el(),addEventListener(){},querySelectorAll(){return[]},
 querySelector(){return null},createElement(){return el()},getElementById(i){return R[i]||(R[i]=el(i))}};
const PUSHED=[];
global.history={pushState(st,_,url){PUSHED.push(url)},replaceState(){}};
global.location={hash:''};
global.navigator={clipboard:{writeText(){return Promise.resolve()}}};
global.window={scrollTo(){},addEventListener(){}};
global.fetch=()=>Promise.reject(0);global.Blob=function(){};global.URL={createObjectURL(){return''}};global.FileReader=function(){};
let js=fs.readFileSync('app_template.html','utf8').split('<script>')[1].split('</script>')[0]
 .replace('/*__KB__*/',fs.readFileSync('kb_slim.json','utf8'))
 .replace('/*__DOCS__*/',fs.readFileSync('docs.json','utf8'));
const m={};new Function('module',js+'\nmodule.exports={showView,goBack,VIEWS,getStack:()=>VIEW_STACK};')(m);
const A=m.exports;

console.log('التبويبات المسجّلة: '+A.VIEWS.join(' , '));
A.showView('search'); A.showView('recipes'); A.showView('docs');
console.log('المسار اللي مشيته : '+A.getStack().join(' → '));
console.log('اللي اتسجل في المتصفح: '+PUSHED.join(' '));
A.goBack(); console.log('بعد رجوع واحدة  : '+A.getStack().join(' → '));
A.goBack(); console.log('بعد رجوع تانية  : '+A.getStack().join(' → '));
A.goBack(); A.goBack(); A.goBack();
console.log('بعد رجوع كتير    : '+A.getStack().join(' → ')+'  (المفروض يقف عند البداية)');
