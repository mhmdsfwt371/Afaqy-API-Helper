global.setInterval=()=>0;global.clearInterval=()=>{};
const fs=require('fs');
function el(id){return{id,hidden:false,innerHTML:'',value:'',textContent:'',className:'',dataset:{},style:{},files:[],disabled:false,
 classList:{toggle(){},add(){},remove(){}},querySelectorAll(){return[]},addEventListener(){},focus(){},select(){},click(){},
 setAttribute(){},getAttribute(){return null},dispatchEvent(){},appendChild(){},remove(){},scrollIntoView(){}}}
const R={};global.document={documentElement:el(),body:el(),addEventListener(){},querySelectorAll(){return[]},
 querySelector(){return null},createElement(){return el()},getElementById(i){return R[i]||(R[i]=el(i))}};
global.history={pushState(){},replaceState(){}};
global.location={hash:''};
global.navigator={clipboard:{writeText(){return Promise.resolve()}}};global.window={scrollTo(){},addEventListener(){}};
global.fetch=()=>Promise.reject(0);global.Blob=function(){};global.URL={createObjectURL(){return''}};global.FileReader=function(){};
let js=fs.readFileSync('app_template.html','utf8').split('<script>')[1].split('</script>')[0]
  .replace('/*__KB__*/',fs.readFileSync('kb_slim.json','utf8')).replace('/*__KBIN__*/', fs.readFileSync('kb_in.json','utf8')).replace('/*__DOCS__*/',fs.readFileSync('docs.json','utf8'));
const m={};new Function('module',js+`
module.exports={EPS,SESSION,prepBody,bodyOf,gen,unitScopedEp,labVariants,setL:(l)=>{LANG=l}};`)(m);
const A=m.exports;
const UID='5fb0e2e703ed529bb30f9af3';
const pick=p=>A.EPS.find(e=>e.p===p);

console.log('=== قبل ما نحدد عربية: البودي زي الكولكشن ===');
console.log(A.bodyOf(pick('/units/signals')).split('\n').slice(0,3).join('\n'));

A.SESSION.unit={uid:UID,name:'NB YD - TH - 1129',imei:'357454075086551'};
console.log('\n=== بعد ما حددنا العربية بالـ IMEI ===');

const checks=[
 ['/units/signals','unit_id'],
 ['/units/locations','unit_id'],
 ['/units/view','id'],
 ['/units/set_status','unit_id'],
 ['/unit_sensors/lists', null],
];
checks.forEach(([p])=>{
  const e=pick(p); if(!e) return;
  const pr=A.prepBody(e);
  const has=pr.text.includes(UID);
  console.log('  '+(has?'✓ اتحط':'—  ما اتحطش')+'  '+p.padEnd(22)+(pr.applied?'  (اتغيّر)':''));
});

console.log('\n=== إندبوينت مش بتاع عربيات: المفروض ما يتلمسش ===');
[['/zones/view'],['/user_reports/data'],['/customers/view'],['/role/view']].forEach(([p])=>{
  const e=pick(p); if(!e) return;
  const pr=A.prepBody(e);
  console.log('  '+(pr.text.includes(UID)?'✗ اتلمس! خطر':'✓ سليم — ما اتلمسش')+'  '+p);
});

console.log('\n=== الـ curl بيطلع بالـ UID تلقائي ===');
const sig=pick('/units/signals');
const c=A.gen(sig,'curl');
console.log('  فيه الـ UID؟ '+(c.includes(UID)?'أيوه ✓':'لأ ✗'));
console.log('  فيه رقم العينة القديم؟ '+(c.includes('5c3df02803ed52d83c067df1')?'أيوه ✗':'لأ ✓'));

console.log('\n=== سلّم التصحيح بياخد البودي الجاهز ===');
const v=A.labVariants(sig);
console.log('  أول صيغة فيها الـ UID؟ '+(JSON.stringify(v[0].body).includes(UID)?'أيوه ✓':'لأ ✗'));

console.log('\n=== python و js كمان ===');
['js','python'].forEach(md=>console.log('  '+md+': '+(A.gen(sig,md).includes(UID)?'✓':'✗')));

console.log('\n=== الفخ: /unit_* اللي مش /units/ ===');
[['/unit_groups/view','id = رقم مجموعة'],['/unit_sensors/lists','فيه unit_id صراحةً'],
 ['/unit_services/view','id = رقم صيانة'],['/units/view','id = رقم عربية — المفروض يتحط']].forEach(([p,what])=>{
  const e=pick(p); if(!e) return;
  const pr=A.prepBody(e);
  const hit=pr.text.includes(UID);
  // صح إن الـ UID يتحط لو المسار /units/ أو لو البودي فيه unit_id صراحةً
  const should = p.startsWith('/units/') || /"unit_id"/.test(e.b||'');
  console.log('  '+((hit===should)?'✓':'✗ غلط')+'  '+p.padEnd(24)+' '+what+'  →  '+(hit?'اتحط':'ما اتحطش'));
});
