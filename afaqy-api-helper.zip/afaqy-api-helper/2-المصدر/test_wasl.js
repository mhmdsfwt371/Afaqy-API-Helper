/* لوحة وصل: اللستة، والبحث، والاستعلام على المعروض بس، والتصدير في أي مرحلة */
const fs=require('fs');
const R={}; let CSV=null;
function el(id){return{id,hidden:false,innerHTML:'',value:'',textContent:'',className:'',dataset:{},style:{},files:[],disabled:false,
 href:'',download:'',placeholder:'',classList:{toggle(){},add(){},remove(){}},
 querySelectorAll(){return[]},addEventListener(){},focus(){},select(){},click(){},setAttribute(){},getAttribute(){return null},
 dispatchEvent(){},appendChild(){},remove(){},scrollIntoView(){},onclick:null}}
global.document={documentElement:el(),body:el(),addEventListener(){},querySelectorAll(){return[]},
 querySelector(){return null},createElement(){return el()},getElementById(i){return R[i]||(R[i]=el(i))}};
global.history={pushState(){},replaceState(){}};global.location={hash:'',pathname:'/',replace(){},reload(){}};
global.setInterval=()=>0;global.setTimeout=(f)=>{f();return 0};global.clearTimeout=()=>{};
global.navigator={clipboard:{writeText(){return Promise.resolve()}}};
global.window={scrollTo(){},addEventListener(){}};
global.AbortController=function(){this.signal={};this.abort=()=>{}};
global.TextEncoder=require('util').TextEncoder;
global.Blob=function(parts){CSV=Buffer.concat(parts.map(p=>Buffer.from(p)))};
global.URL={createObjectURL(){return'blob:x'}};global.FileReader=function(){};
global.confirm=()=>true;
let CALLS=[];
global.fetch=(u,o)=>{ CALLS.push(String(u));
  const body = String(u).indexOf('inquiry')>=0
    ? {message:'success',status_code:200,data:{registrationStatus:'REGISTERED',isActive:true}}
    : {message:'success',status_code:200,data:{items:[]}};
  return Promise.resolve({ok:true,status:200,text:()=>Promise.resolve(JSON.stringify(body))}); };
let js=fs.readFileSync('app_template.html','utf8').split('<script>')[1].split('</script>')[0]
 .replace('/*__KB__*/',fs.readFileSync('kb_slim.json','utf8')).replace('/*__KBIN__*/', fs.readFileSync('kb_in.json','utf8'))
 .replace('/*__DOCS__*/',fs.readFileSync('docs.json','utf8'));
const m={};new Function('module',js+
 "\nmodule.exports={WASL,SESSION,waslRender,waslFiltered,waslInquire,waslExport,waslStatusText,waslCols};")(m);
const A=m.exports;
const fail=s=>{console.error('فشل: '+s);process.exit(1)};
const strip=h=>String(h||'').replace(/<[^>]+>/g,' ').replace(/\s+/g,' ').trim();

A.SESSION.token='T'; A.SESSION.user='u'; A.SESSION.pass='p';
A.WASL.rows=[
 {id:'W1',name:'fakieh 01',imei:'864626044942111',plate_number:'ABC 123'},
 {id:'W2',name:'fakieh 02',imei:'864626044978222',plate_number:'ABC 456'},
 {id:'W3',name:'panda-co 05',imei:'869286031227999',plate_number:'XYZ 789'}];
A.WASL.at=new Date();

A.waslRender();
let out=strip(R['waslOut'].innerHTML);
if(out.indexOf('fakieh 01')<0) fail('اللستة مش ظاهرة');
if(out.indexOf('3 من 3')<0 && out.indexOf('3 of 3')<0) fail('العدد غلط');
console.log('اللستة        : 3 عربيات ظهرت ✓');

// البحث
A.WASL.q='panda'; A.waslRender();
if(A.waslFiltered().length!==1) fail('البحث بالاسم ما اشتغلش');
A.WASL.q='864626044978'; A.waslRender();
if(A.waslFiltered().length!==1) fail('البحث بالـ IMEI ما اشتغلش');
if(A.waslFiltered()[0].name!=='fakieh 02') fail('البحث بالـ IMEI لقى الغلط');
A.WASL.q='XYZ'; if(A.waslFiltered().length!==1) fail('البحث باللوحة ما اشتغلش');
console.log('البحث         : بالاسم والـ IMEI واللوحة ✓');

// التصدير قبل الاستعلام — ملف إكسل
A.WASL.q=''; A.waslExport();
if(!CSV) fail('ما صدّرش اللستة');
if(CSV.slice(0,2).toString()!=='PK') fail('مش ملف إكسل');
require('fs').writeFileSync('/tmp/wasl1.xlsx', CSV);
if(CSV.indexOf(Buffer.from('wasl_status'))>=0) fail('حط عمود حالة قبل ما يستعلم');
console.log('تصدير اللستة  : ملف xlsx من غير عمود الحالة ✓');

// الاستعلام على المعروض بس
A.WASL.q='panda'; CALLS=[];
(async()=>{
  await A.waslInquire();
  const inqCalls=CALLS.filter(u=>u.indexOf('inquiry')>=0);
  if(inqCalls.length!==1) fail('استعلم عن '+inqCalls.length+' بدل ١ — المفروض المعروض بس');
  if(!A.WASL.inq['W3']) fail('نتيجة الاستعلام مش متخزنة');
  if(A.WASL.inq['W3'].txt.indexOf('REGISTERED')<0) fail('الحالة ما اتقرتش');
  console.log('الاستعلام     : ريكوست واحد للمعروض بس، والحالة REGISTERED ✓');

  // التصدير بعد الاستعلام
  CSV=null; A.waslExport();
  require('fs').writeFileSync('/tmp/wasl2.xlsx', CSV);
  if(CSV.indexOf(Buffer.from('wasl_status'))<0) fail('عمود الحالة ناقص بعد الاستعلام');
  if(CSV.indexOf(Buffer.from('REGISTERED'))<0) fail('الحالة مش في الملف');
  console.log('تصدير الاستعلام: عمود الحالة موجود في الإكسل ✓');

  // لستة فاضية = رد نهائي
  A.WASL.rows=[]; A.waslRender();
  if(strip(R['waslOut'].innerHTML).indexOf('رد نهائي')<0) fail('ما وضّحش إن اللستة الفاضية رد نهائي');
  console.log('حساب بلا وصل  : اتقال إنه رد نهائي ✓');

  // شكل رد استعلام مختلف
  if(A.waslStatusText({weird:{deep:1}}).indexOf('حقل حالة')<0) fail('ما تعاملش مع رد غريب');
  console.log('رد استعلام غريب: ما كسرش ✓');
})();
