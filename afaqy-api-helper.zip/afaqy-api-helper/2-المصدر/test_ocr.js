/* v6.45 — صورة الرد. المحرك نفسه بيتجرّب في المتصفح الحقيقي (test_browser.py)؛
   هنا: تنضيف نص الـ OCR، وإن المحرك ما بيتحمّلش غير لما حد يرفع صورة،
   وإن النسخ مثبّتة، وإن الخانتين موصولتين بالرفع واللصق. */
const fs=require('fs'); const {JSDOM}=require('jsdom');
let F=0; const pass=m=>console.log('  \u2713 '+m); const fail=m=>{console.log('  \u2717 '+m);F++;};
const ok=(m,c,x)=>c?pass(m):fail(m+(x?'  \u2014 '+String(x).slice(0,160):''));
const build=()=>fs.readFileSync(process.argv[2]||'app_template.html','utf8')
  .replace('/*__KB__*/',()=>fs.readFileSync('kb_slim.json','utf8'))
  .replace('/*__DOCS__*/',()=>fs.readFileSync('docs.json','utf8'))
  .replace('/*__KBIN__*/',()=>fs.readFileSync('kb_in.json','utf8'));
function boot(){
  const w=new JSDOM(build(),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://localhost/'}).window;
  w.alert=()=>{}; w.confirm=()=>true; w.scrollTo=()=>{}; w.URL.createObjectURL=()=>'blob:x'; w.URL.revokeObjectURL=()=>{};
  return w;
}

(async()=>{
/* ═════ ١) التنضيف: اللي الـ OCR بيغلط فيه في JSON ═════ */
{
  const w=boot();
  const c=t=>w.ocrClean(t);
  /* رد بوستمان بأرقام سطور + سطر الهيدر + قوس لازق في الرقم */
  const r1=c('Body Cookies Headers (12) TestResults 2000K 312ms 12KB\n1 {\n\n2    “message”: "unauthorized",\n\n3     "status_code": 401,\n\n4    "extra": []\n\n5}');
  ok('أرقام السطور اتشالت حتى اللازقة في القوس', /^\{\n/m.test(r1.text) && /\n\}$/.test(r1.text) && !/\n5\}/.test(r1.text), r1.text);
  ok('التنصيص المعوج اتظبط', /"message": "unauthorized"/.test(r1.text));
  ok('الهيدر اللي قبل الرد اتساب للمصلّح العام (مش شغلة الـ OCR)', /^Body Cookies/.test(r1.text));
  ok('التصليحات بتتقال', r1.fixes.some(f=>/أرقام السطور/.test(f)) && r1.fixes.some(f=>/تنصيص/.test(f)), r1.fixes.join(' | '));
  /* قوس إغلاق اتقرى «Is» + status_code مقروء 464 */
  const r2=c('{\n"message": "not_found",\n"status_code": 464,\n"extra": {\n"unit_id": "The unit_id 5fb6e2e703ed529bb36f9af3 is not found"\nIs\n"data": null\n}');
  let parsed=null; try{ parsed=JSON.parse(r2.text); }catch(_){}
  ok('«Is» رجع قوس إغلاق بفاصلة والرد بقى يتقرا', parsed && parsed.extra && parsed.extra.unit_id && parsed.data===null, r2.text);
  ok('status_code 464 اتصلّح لـ 404 واتقال', parsed && parsed.status_code===404 && r2.fixes.some(f=>/464/.test(f)), r2.fixes.join(' | '));
  ok('المعرّف الطويل ما اتلعبش فيه — ده شغل الموظف', parsed && /5fb6e2e703ed529bb36f9af3/.test(parsed.extra.unit_id));
  /* مفتاح اتقطع بمسافة، وصفر اتقرى @ أو o */
  const r3=c('{\n"status code": 200,\n"last update": {\n"spd": @,\n"acc": 1,\n"lat": 21.5o33\n}\n}');
  ok('«status code» و«last update» بقوا بشرطة', /"status_code": 200/.test(r3.text) && /"last_update"/.test(r3.text), r3.text);
  ok('@ وo في مكان الرقم بقوا صفر', /"spd": 0,/.test(r3.text) && /21\.5033/.test(r3.text), r3.text);
  /* ما يلمسش رد سليم */
  const good='{\n  "message": "ok",\n  "status_code": 200,\n  "data": {"id": "5c3df02803ed52d83c067df1", "name": "Truck 12"}\n}';
  const r4=c(good);
  ok('رد سليم بيعدّي زي ما هو من غير تصليحات', r4.text===good && r4.fixes.length===0, r4.fixes.join(' | '));
  /* كود معروف ما يتغيّرش حتى لو فيه 6 أو 8 */
  ok('406 و 408 أكواد معروفة ما بتتحوّلش', /"status_code": 406/.test(c('{"status_code": 406}').text) && /"status_code": 408/.test(c('{"status_code": 408}').text));

  /* v6.46: لقطة نافذة بوستمان كاملة — بودي الريكوست فوق والرد تحت، وأقواس الإغلاق اتقرت أرقام وحروف */
  const full = c('POST https://api.afaqy.sa/units/locations?token={{token}}\nParams Authorization Headers (8) Body\n1 {\n2      "data": {\n3          "unit id": "6a69c3976435eef5460b0278",\n4       "address": true\n5    }\n6 }\nBody Cookies Headers (12) Test Results\nPretty Raw Preview Visualize JSON\n1 {\n2    "message": "validation error",\n3     "status_code": 465,\n4    "errors": {\n5      "unit_id": [\n6          "not_found"\n7       1\n8    LL\n9    "extra": [1]\n10 }');
  let fp=null; try{ fp=JSON.parse(full.text.split('\n\n')[0]); }catch(_){}
  ok('الرد اتحط الأول قبل بودي الريكوست', fp && fp.message==='validation_error' && fp.status_code===405, full.text.slice(0,120));
  ok('«1» و«LL» بقوا ] و}, على الترتيب', fp && Array.isArray(fp.errors.unit_id) && fp.errors.unit_id[0]==='not_found', JSON.stringify(fp && fp.errors));
  ok('«validation error» اتلمّت لأنها قيمة معروفة', full.fixes.some(f=>/قيم معروفة/.test(f)));
  ok('البلوك التاني (الريكوست) لسه موجود تحت', /"address": true/.test(full.text.split('\n\n').slice(1).join('')));
  /* رقم لوحده قبل قوس حقيقي بيفضل رقم */
  const arr = c('{\n"ids": [\n1\n]\n}');
  ok('عنصر مصفوفة لوحده قبل ] ما بيتحوّلش لقوس', /\[\n1\n\]/.test(arr.text), arr.text);
  /* تحديد الرد جوه لقطة شاشة كاملة */
  const L = (text,y,h=12,x=300,w=200)=>({text, bbox:{x0:x,y0:y,x1:x+w,y1:y+h}});
  const lines = [L('Collections',10,12,10,100), L('POST Login',40,12,10,100), L('POST https://api',10), L('Params Authorization',40),
                 L('1 {',90), L('2 "data": {',105), L('3 "unit_id": "6a69"',120), L('4 }',135),
                 L('Body Cookies Headers',200), L('1 {',260), L('2 "message": "x",',275), L('3 "status_code": 405,',290), L('4 }',305)];
  const loc = w.ocrLocate(lines, 1, 1920, 1080);
  ok('لقطة النافذة الكاملة: المنطقة حوالين سطور الـ JSON بس', loc.region && loc.region.x < 300 && loc.region.y < 90 && loc.region.y+loc.region.h > 317 && loc.region.w < 700, JSON.stringify(loc.region));
  ok('ارتفاع السطر اتقاس من السطور نفسها', loc.lineH===12, loc.lineH);
  const only = [L('{',10,13,5,300), L('"message": "x",',30,13,5,300), L('"status_code": 401,',50,13,5,300), L('}',70,13,5,300)];
  const loc2 = w.ocrLocate(only, 2, 160, 48);
  ok('لقطة للرد بس (الـ JSON مالي الصورة): مفيش قص', loc2.region===null && loc2.lineH===6.5, JSON.stringify(loc2));
  ok('المقاس: خط ١٣ بكسل → ×٢، وخط ٣٠ → ×١، وخط ٧ → ×٣ كحد أقصى', w.ocrScaleFor(13)===2 && w.ocrScaleFor(30)===1 && w.ocrScaleFor(7)===3, [w.ocrScaleFor(13),w.ocrScaleFor(30),w.ocrScaleFor(7)].join());
  ok('مفيش بلوكين → مفيش إعادة ترتيب', w.ocrPickResponse('{"a":1}')===null && w.ocrPickResponse('{"message":"x"}\n{"data":1}')===null);

  /* v6.47: من الإيميل الحقيقي — القص بدأ بعد القوس الخارجي، والتنصيص اتقرى نجمة، والصفر اتقرى © */
  const bareTxt = c('“data”: {\n"unit_id": "861230044934025",\n"address": true,\n"date": {\n“interval”: “interval”,\n“from*: "2026-10-10 ©0:00:00",\n"to": "2026-10-11 23:59:59"\n}\n3\n');
  let bp=null; try{ bp=JSON.parse(bareTxt.text); }catch(_){}
  ok('القوس الخارجي اترجّع والبودي بقى {"data":{…}}', bp && bp.data && bp.data.unit_id==='861230044934025', bareTxt.text.slice(0,80));
  ok('«from*:» بقت "from": و«©0» بقت 00', bp && bp.data.date.from==='2026-10-10 00:00:00', bp && bp.data.date.from);
  const lost = c('i\n"message": "x",\n"status_code": 401\n}');
  let lp=null; try{ lp=JSON.parse(lost.text); }catch(_){}
  ok('قوس الفتح اللي اتقرى «i» اترجّع', lp && lp.status_code===401, lost.text);
  /* جدول Preview */
  const tb = w.ocrTable('SF TTT\nmessage   not_allowed\nstatus_code 401\ndata       8)');
  ok('جدول Preview بقى كائن: الرسالة والكود و[]', tb && tb.message==='not_allowed' && tb.status_code===401 && Array.isArray(tb.data) && tb.data.length===0, JSON.stringify(tb));
  ok('سطر شريط الأدوات (مفتاح كبير قصير) اتشال', tb && !('SF' in tb));
  ok('«data 0» في جدول بتبقى [] مش صفر', JSON.stringify(w.ocrTable('message x\ndata 0').data)==='[]');
  /* تقسيم لقطة إيميل: كلام العميل، اللينك، الريكوست، الرد */
  const S = (text,x0,y0,x1,y1)=>({text, bbox:{x0,y0,x1,y1}});
  const em = [S('RE: Integration',20,22,870,41), S('Sender <s@x.com>',80,66,392,80), S('To Someone',80,85,194,95), S('Sun 10/11/2026 12:55 PM',944,86,1075,96),
    S('Dear team,',11,143,204,158), S('We are testing the APIs and we get an error when getting',10,184,1071,198), S('the last location for the unit.',10,204,202,215),
    S('Please check if any role is missing.',11,246,577,260), S('Postman Response:',11,328,147,342),
    S('POST v https://api.afaqy.sa/units/locations?token= {{tok}}',17,355,463,366), S('Docs Params Authorization Body',13,389,441,400),
    S('"data": {',103,464,160,474), S('"unit_id": "861230044934025",',129,480,317,490), S('"to": "2026-10-11 23:59:59"',156,564,331,572),
    S('Body Cookies Headers 8 Test Results 2000K 171s',12,681,757,698), S('{}JsoN Preview Visualize',12,712,240,725),
    S('message not_allowed',12,744,150,759), S('status_code 401',12,771,107,781), S('data 8)',12,792,103,811)];
  const sec = w.ocrSections(em, 1, 1098, 869);
  ok('اللقطة اتعرفت إنها تذكرة: لينك وشريط رد', !!sec && sec.method==='POST' && sec.url==='https://api.afaqy.sa/units/locations', sec && sec.url);
  ok('كلام العميل من «Dear» من غير هيدر الإيميل، فقرات منفصلة', sec && /^Dear team,/.test(sec.prose) && /\n\nPlease check/.test(sec.prose) && !/Sun 10\/11|<s@x\.com>|To Someone/.test(sec.prose), sec && sec.prose);
  ok('منطقة الريكوست بين اللينك والشريط', sec && sec.reqRegion && sec.reqRegion.y > 366 && sec.reqRegion.y + sec.reqRegion.h <= 681, JSON.stringify(sec && sec.reqRegion));
  ok('منطقة الرد بتبدأ تحت سطر الأوضاع وبتتعرف إنها جدول', sec && sec.respRegion && sec.respRegion.y > 725 && sec.respIsTable, JSON.stringify(sec && sec.respRegion));
  ok('لقطة رد بس (من غير لينك) مش تذكرة', w.ocrSections([S('{',5,5,20,15), S('"message": "x"',5,20,200,30)], 1, 300, 100)===null);
}
/* ═════ ٥) التذكرة اللي طلعت من الإيميل الحقيقي بتتحل صح (v6.47) ═════ */
{
  const w=boot();
  const TICKET = `Dear team,\n\nWe are testing the APIs and we are able to successfully get the token and Fetch vehicle list. However, we have encountered the following error when getting the last location for the unit.\n\nPlease check if any role is missing for the ID or if there is any issue with the API Call.\n\nPostman Response:\n\nRequest:\nPOST https://api.afaqy.sa/units/locations?token=<TOKEN>\n{\n  "data": {\n    "unit_id": "861230044934025",\n    "address": true,\n    "date": {\n      "interval": "interval",\n      "from": "2026-10-10 00:00:00",\n      "to": "2026-10-11 23:59:59"\n    }\n  }\n}\n\nResponse:\n{\n  "message": "not_allowed",\n  "status_code": 401,\n  "data": []\n}`;
  const a=w.analyzeCase(TICKET); a._raw=TICKET;
  ok('البودي اللي فيه unit_id اتعرف إنه ريكوست', a.blocks.some(b=>b.kind==='request'), JSON.stringify(a.blocks.map(b=>b.kind)));
  const m=w.caseMatch(a);
  ok('التشخيص: IMEI مكان رقم العربية (مش «٢٠٠ وجواه خطأ»)', m && m.r.id==='imei-vs-uid' && m.h.score>=80, m && (m.r.id+' '+m.h.score));
  const rep=w.caseReply(a);
  ok('الرد بيقول قيمة الـ IMEI اللي اتبعتت', /unit_id carries 861230044934025, which is the IMEI/.test(rep));
  ok('الرد بيقول إن الـ API بتعرّف العربية بالـ UID مش الـ IMEI', /identifies vehicles by their unit ID \(UID\), not by the device IMEI/.test(rep));
  ok('الرد بيجاوب سؤال الرول: مفيش رول ناقص، السبب الـ IMEI', /not_allowed response comes from the IMEI in unit_id — no role or permission change is needed/.test(rep) && !/still returns not_allowed/.test(rep));
  ok('خطوة ١ موثّقة: /units/lists مفلتر بالـ IMEI بتاعه نفسه', /1\. POST \/units\/lists\n\s+\{"data":\{"offset":0,"limit":1,"projection":\["basic","last_update"\],"filters":\{"imei":\{"value":\["861230044934025"\],"op":"in"\}\}\}\}/.test(rep));
  ok('الرد بيبدأ الطريق بالتوكن (اللينك أو Bearer)', /0\. Use the token from POST \/auth\/login — as \?token= in the URL or as an Authorization: Bearer header/.test(rep));
  ok('خطوة ٢ موثّقة: /units/signals بدل /units/locations، بفترة العميل نفسها', /2\. POST \/units\/signals\n\s+\{"data":\{"unit_id":"<UID from step 1>","date":\{"interval":"interval","from":"2026-10-10 00:00:00","to":"2026-10-11 23:59:59"\}/.test(rep) && !/POST \/units\/locations/.test(rep), rep.slice(rep.indexOf('2. POST'), rep.indexOf('2. POST')+200));
  /* الموظف حدّد نفس الـ IMEI من الشريط: الـ UID الحقيقي بيتكتب في الرد والكولكشن */
  w.eval("SESSION.unit={uid:'5e6790e103ed52cf443362c9', name:'L S A-6220', imei:'861230044934025'}");
  const repU=w.caseReply(a);
  ok('الـ UID الحقيقي في الرد لما الأداة عارفاه', /For this vehicle the UID is 5e6790e103ed52cf443362c9/.test(repU) && /"unit_id":"5e6790e103ed52cf443362c9"/.test(repU));
  const colU=w.pmFromCase(a), V=k=>(colU.variable.find(v=>v.key===k)||{}).value;
  ok('الكولكشن متعبّي: IMEI و UID وفترة العميل', V('imei')==='861230044934025' && V('unit_id')==='5e6790e103ed52cf443362c9' && V('date_from')==='2026-10-10' && V('date_to')==='2026-10-11', JSON.stringify(colU.variable));
  w.eval("SESSION.unit={uid:'aaaaaaaaaaaaaaaaaaaaaaaa', name:'X', imei:'111111111111111'}");
  ok('عربية تانية متحددة فوق: الـ UID بتاعها ما يتكتبش في رد العميل ده', !/aaaaaaaaaaaaaaaaaaaaaaaa/.test(w.caseReply(a)));
  w.eval("SESSION.unit=null");
  const col=w.pmFromCase(a);
  ok('كولكشن الحل بيتولّد فعلًا: دخول ثم لستة مفلترة ثم signals', col && col.item.length===3 && /\/units\/lists/.test(col.item[1].request.url.raw) && /\/units\/signals/.test(col.item[2].request.url.raw), col && col.item.map(i=>i.name).join(' | '));
  ok('الكولكشن من غير توكن', col && col.variable.find(v=>v.key==='token').value==='');
  /* السؤال من غير not_allowed ولا role: مفيش جملة صلاحيات */
  const a2=w.analyzeCase('POST https://api.afaqy.sa/units/locations\n{"data":{"unit_id":"861230044934025"}}\n{"message":"validation_error","status_code":405,"errors":{"unit_id":["not_found"]}}'); a2._raw='x';
  const r2=w.caseReply(a2);
  ok('من غير not_allowed ولا سؤال صلاحيات: الرد ما بيتكلمش عن الرول', r2 && !/no role or permission change/.test(r2) && /861230044934025/.test(r2), r2 && r2.slice(0,160));
}
/* ═════ ٢ب) المحرك كسول ومثبّت النسخة ═════ */
{
  const w=boot();
  ok('مفيش سكريبت خارجي اتحمّل مع فتح الأداة', !w.document.querySelector('script[src*="tesseract"]') && !w.document.querySelector('script[src*="jsdelivr"]'));
  const O=w.eval('OCR');
  ok('النسخ مثبّتة بالرقم مش latest', /@5\.1\.1$/.test(O.lib) && /@5\.1\.1$/.test(O.core) && /@1\.0\.0\//.test(O.lang), JSON.stringify(O));
  ok('المصدر الافتراضي jsDelivr', w.ocrCdn()==='https://cdn.jsdelivr.net/npm/');
  w.OCR_CDN_OVERRIDE='http://127.0.0.1:1/'; ok('الاختبار يقدر يوجّهه لسيرفر محلي', w.ocrCdn()==='http://127.0.0.1:1/');
  ok('المحرك مش محمّل قبل أول صورة', O.worker===null && O.loading===null);
}
/* ═════ ٣) الخانتين موصولتين: رفع صورة ولصق صورة بيوصلوا للقارئ ═════ */
{
  const w=boot();
  const calls=[];
  w.ocrImage = async (file, progress)=>{ calls.push(file && file.type); progress && progress('x'); return {text:'{"message":"unauthorized","status_code":401,"extra":[]}', fixes:[], dark:true, confidence:80}; };
  w.showView('inspect'); w.paintInspect();
  ok('خانة الرد بتقبل صور', /image\/\*/.test(w.document.getElementById('inFile').accept));
  ok('التسمية بتقول صورة', /صورة/.test(w.document.getElementById('inFileLbl').textContent));
  /* لصق صورة */
  const file=new w.File(['x'],'shot.png',{type:'image/png'});
  const dt={items:[{type:'image/png', getAsFile:()=>file}]};
  const ev=new w.Event('paste',{bubbles:true,cancelable:true}); ev.clipboardData=dt;
  w.document.getElementById('inText').dispatchEvent(ev);
  await new Promise(r=>setTimeout(r,50));
  ok('لصق صورة في خانة الرد بينده القارئ', calls.length===1 && calls[0]==='image/png', calls);
  ok('النص اتحط واتفحص: الخطأ اتشخّص', /unauthorized/.test(w.document.getElementById('inText').value) && /مش مصرّح|التوكن/.test(w.document.getElementById('inOut').textContent), w.document.getElementById('inOut').textContent.slice(0,120));
  ok('صندوق الصورة بيقول اتقرت وبيحذّر من الأرقام', /اتقرت من الصورة/.test(w.document.getElementById('inImgBox').textContent) && /6 أو 8/.test(w.document.getElementById('inImgBox').textContent));
  w.document.getElementById('inClear').click();
  ok('المسح بيخفي صندوق الصورة', w.document.getElementById('inImgBox').hidden);
  /* خانة الرسالة */
  w.eval("INSPVIEW='case'"); w.paintInspect();
  ok('خانة الرسالة فيها زرار صورة', !!w.document.getElementById('caseImg') && /image\/\*/.test(w.document.getElementById('caseImg').accept));
  w.document.getElementById('caseText').value='We get this when calling last location:\nPostman Response:';
  w.ocrImage = async ()=>({text:'{"message":"unauthorized","status_code":401,"extra":[]}', fixes:[], dark:false, confidence:80});
  const ev2=new w.Event('paste',{bubbles:true,cancelable:true}); ev2.clipboardData=dt;
  w.document.getElementById('caseText').dispatchEvent(ev2);
  await new Promise(r=>setTimeout(r,50));
  const v=w.document.getElementById('caseText').value;
  ok('نص الصورة اتحط تحت كلام العميل مش مكانه', /Postman Response:\n\n\{"message":"unauthorized"/.test(v), v);
  ok('الرسالة اتحلّلت بعد القراءة', !!w.document.getElementById('caseOut').innerHTML.trim());
  /* ملف مش صورة */
  const bad=new w.File(['x'],'x.txt',{type:'text/plain'});
  const ev3=new w.Event('paste',{bubbles:true,cancelable:true}); ev3.clipboardData={items:[{type:'text/plain', getAsFile:()=>bad}]};
  const before=w.document.getElementById('caseText').value;
  w.document.getElementById('caseText').dispatchEvent(ev3);
  await new Promise(r=>setTimeout(r,30));
  ok('لصق نص عادي بيعدّي للمتصفح زي ما هو', w.document.getElementById('caseText').value===before && !ev3.defaultPrevented);
}
/* ═════ ٤) فشل التحميل بيتقال بوضوح ═════ */
{
  const w=boot();
  w.ocrImage = async ()=>{ throw new Error('load https://cdn.jsdelivr.net/npm/tesseract.js@5.1.1/dist/tesseract.min.js'); };
  w.showView('inspect'); w.paintInspect();
  const file=new w.File(['x'],'shot.png',{type:'image/png'});
  const ev=new w.Event('paste',{bubbles:true,cancelable:true}); ev.clipboardData={items:[{type:'image/png', getAsFile:()=>file}]};
  w.document.getElementById('inText').dispatchEvent(ev);
  await new Promise(r=>setTimeout(r,50));
  ok('لو المحرك ما نزلش بيقول محتاج نت أول مرة', /نت أول مرة/.test(w.document.getElementById('inImgBox').textContent), w.document.getElementById('inImgBox').textContent.slice(0,120));
}

console.log(F ? `\nفشل ${F}` : '\nصورة الرد: تمام');
process.exit(F?1:0);
})();
