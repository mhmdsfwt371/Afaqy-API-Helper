/* v6.45 — صورة الرد. المحرك نفسه بيتجرّب في المتصفح الحقيقي (test_browser.py)؛
   هنا: تنضيف نص الـ OCR، وإن المحرك ما بيتحمّلش غير لما حد يرفع صورة،
   وإن النسخ مثبّتة، وإن الخانتين موصولتين بالرفع واللصق. */
const fs=require('fs'); const {JSDOM}=require('jsdom');
let F=0; const pass=m=>console.log('  \u2713 '+m); const fail=m=>{console.log('  \u2717 '+m);F++;};
const ok=(m,c,x)=>c?pass(m):fail(m+(x?'  \u2014 '+String(x).slice(0,160):''));
const build=()=>fs.readFileSync(process.argv[2]||'app_template.html','utf8')
  .replace('/*__KB__*/',()=>fs.readFileSync('kb_slim.json','utf8'))
  .replace('/*__DOCS__*/',()=>fs.readFileSync('docs.json','utf8'))
  .replace('/*__KBIN__*/',()=>fs.readFileSync('kb_in.json','utf8'));
function boot(){
  const w=new JSDOM(build(),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://localhost/'}).window;
  w.alert=()=>{}; w.confirm=()=>true; w.scrollTo=()=>{}; w.URL.createObjectURL=()=>'blob:x'; w.URL.revokeObjectURL=()=>{};
  return w;
}

(async()=>{
/* ═════ ١) التنضيف: اللي الـ OCR بيغلط فيه في JSON ═════ */
{
  const w=boot();
  const c=t=>w.ocrClean(t);
  /* رد بوستمان بأرقام سطور + سطر الهيدر + قوس لازق في الرقم */
  const r1=c('Body Cookies Headers (12) TestResults 2000K 312ms 12KB\n1 {\n\n2    “message”: "unauthorized",\n\n3     "status_code": 401,\n\n4    "extra": []\n\n5}');
  ok('أرقام السطور اتشالت حتى اللازقة في القوس', /^\{\n/m.test(r1.text) && /\n\}$/.test(r1.text) && !/\n5\}/.test(r1.text), r1.text);
  ok('التنصيص المعوج اتظبط', /"message": "unauthorized"/.test(r1.text));
  ok('الهيدر اللي قبل الرد اتساب للمصلّح العام (مش شغلة الـ OCR)', /^Body Cookies/.test(r1.text));
  ok('التصليحات بتتقال', r1.fixes.some(f=>/أرقام السطور/.test(f)) && r1.fixes.some(f=>/تنصيص/.test(f)), r1.fixes.join(' | '));
  /* قوس إغلاق اتقرى «Is» + status_code مقروء 464 */
  const r2=c('{\n"message": "not_found",\n"status_code": 464,\n"extra": {\n"unit_id": "The unit_id 5fb6e2e703ed529bb36f9af3 is not found"\nIs\n"data": null\n}');
  let parsed=null; try{ parsed=JSON.parse(r2.text); }catch(_){}
  ok('«Is» رجع قوس إغلاق بفاصلة والرد بقى يتقرا', parsed && parsed.extra && parsed.extra.unit_id && parsed.data===null, r2.text);
  ok('status_code 464 اتصلّح لـ 404 واتقال', parsed && parsed.status_code===404 && r2.fixes.some(f=>/464/.test(f)), r2.fixes.join(' | '));
  ok('المعرّف الطويل ما اتلعبش فيه — ده شغل الموظف', parsed && /5fb6e2e703ed529bb36f9af3/.test(parsed.extra.unit_id));
  /* مفتاح اتقطع بمسافة، وصفر اتقرى @ أو o */
  const r3=c('{\n"status code": 200,\n"last update": {\n"spd": @,\n"acc": 1,\n"lat": 21.5o33\n}\n}');
  ok('«status code» و«last update» بقوا بشرطة', /"status_code": 200/.test(r3.text) && /"last_update"/.test(r3.text), r3.text);
  ok('@ وo في مكان الرقم بقوا صفر', /"spd": 0,/.test(r3.text) && /21\.5033/.test(r3.text), r3.text);
  /* ما يلمسش رد سليم */
  const good='{\n  "message": "ok",\n  "status_code": 200,\n  "data": {"id": "5c3df02803ed52d83c067df1", "name": "Truck 12"}\n}';
  const r4=c(good);
  ok('رد سليم بيعدّي زي ما هو من غير تصليحات', r4.text===good && r4.fixes.length===0, r4.fixes.join(' | '));
  /* كود معروف ما يتغيّرش حتى لو فيه 6 أو 8 */
  ok('406 و 408 أكواد معروفة ما بتتحوّلش', /"status_code": 406/.test(c('{"status_code": 406}').text) && /"status_code": 408/.test(c('{"status_code": 408}').text));

  /* v6.46: لقطة نافذة بوستمان كاملة — بودي الريكوست فوق والرد تحت، وأقواس الإغلاق اتقرت أرقام وحروف */
  const full = c('POST https://api.afaqy.sa/units/locations?token={{token}}\nParams Authorization Headers (8) Body\n1 {\n2      "data": {\n3          "unit id": "6a69c3976435eef5460b0278",\n4       "address": true\n5    }\n6 }\nBody Cookies Headers (12) Test Results\nPretty Raw Preview Visualize JSON\n1 {\n2    "message": "validation error",\n3     "status_code": 465,\n4    "errors": {\n5      "unit_id": [\n6          "not_found"\n7       1\n8    LL\n9    "extra": [1]\n10 }');
  let fp=null; try{ fp=JSON.parse(full.text.split('\n\n')[0]); }catch(_){}
  ok('الرد اتحط الأول قبل بودي الريكوست', fp && fp.message==='validation_error' && fp.status_code===405, full.text.slice(0,120));
  ok('«1» و«LL» بقوا ] و}, على الترتيب', fp && Array.isArray(fp.errors.unit_id) && fp.errors.unit_id[0]==='not_found', JSON.stringify(fp && fp.errors));
  ok('«validation error» اتلمّت لأنها قيمة معروفة', full.fixes.some(f=>/قيم معروفة/.test(f)));
  ok('البلوك التاني (الريكوست) لسه موجود تحت', /"address": true/.test(full.text.split('\n\n').slice(1).join('')));
  /* رقم لوحده قبل قوس حقيقي بيفضل رقم */
  const arr = c('{\n"ids": [\n1\n]\n}');
  ok('عنصر مصفوفة لوحده قبل ] ما بيتحوّلش لقوس', /\[\n1\n\]/.test(arr.text), arr.text);
  /* تحديد الرد جوه لقطة شاشة كاملة */
  const L = (text,y,h=12,x=300,w=200)=>({text, bbox:{x0:x,y0:y,x1:x+w,y1:y+h}});
  const lines = [L('Collections',10,12,10,100), L('POST Login',40,12,10,100), L('POST https://api',10), L('Params Authorization',40),
                 L('1 {',90), L('2 "data": {',105), L('3 "unit_id": "6a69"',120), L('4 }',135),
                 L('Body Cookies Headers',200), L('1 {',260), L('2 "message": "x",',275), L('3 "status_code": 405,',290), L('4 }',305)];
  const loc = w.ocrLocate(lines, 1, 1920, 1080);
  ok('لقطة النافذة الكاملة: المنطقة حوالين سطور الـ JSON بس', loc.region && loc.region.x < 300 && loc.region.y < 90 && loc.region.y+loc.region.h > 317 && loc.region.w < 700, JSON.stringify(loc.region));
  ok('ارتفاع السطر اتقاس من السطور نفسها', loc.lineH===12, loc.lineH);
  const only = [L('{',10,13,5,300), L('"message": "x",',30,13,5,300), L('"status_code": 401,',50,13,5,300), L('}',70,13,5,300)];
  const loc2 = w.ocrLocate(only, 2, 160, 48);
  ok('لقطة للرد بس (الـ JSON مالي الصورة): مفيش قص', loc2.region===null && loc2.lineH===6.5, JSON.stringify(loc2));
  ok('المقاس: خط ١٣ بكسل → ×٢، وخط ٣٠ → ×١، وخط ٧ → ×٣ كحد أقصى', w.ocrScaleFor(13)===2 && w.ocrScaleFor(30)===1 && w.ocrScaleFor(7)===3, [w.ocrScaleFor(13),w.ocrScaleFor(30),w.ocrScaleFor(7)].join());
  ok('مفيش بلوكين → مفيش إعادة ترتيب', w.ocrPickResponse('{"a":1}')===null && w.ocrPickResponse('{"message":"x"}\n{"data":1}')===null);
}
/* ═════ ٢) المحرك كسول ومثبّت النسخة ═════ */
{
  const w=boot();
  ok('مفيش سكريبت خارجي اتحمّل مع فتح الأداة', !w.document.querySelector('script[src*="tesseract"]') && !w.document.querySelector('script[src*="jsdelivr"]'));
  const O=w.eval('OCR');
  ok('النسخ مثبّتة بالرقم مش latest', /@5\.1\.1$/.test(O.lib) && /@5\.1\.1$/.test(O.core) && /@1\.0\.0\//.test(O.lang), JSON.stringify(O));
  ok('المصدر الافتراضي jsDelivr', w.ocrCdn()==='https://cdn.jsdelivr.net/npm/');
  w.OCR_CDN_OVERRIDE='http://127.0.0.1:1/'; ok('الاختبار يقدر يوجّهه لسيرفر محلي', w.ocrCdn()==='http://127.0.0.1:1/');
  ok('المحرك مش محمّل قبل أول صورة', O.worker===null && O.loading===null);
}
/* ═════ ٣) الخانتين موصولتين: رفع صورة ولصق صورة بيوصلوا للقارئ ═════ */
{
  const w=boot();
  const calls=[];
  w.ocrImage = async (file, progress)=>{ calls.push(file && file.type); progress && progress('x'); return {text:'{"message":"unauthorized","status_code":401,"extra":[]}', fixes:[], dark:true, confidence:80}; };
  w.showView('inspect'); w.paintInspect();
  ok('خانة الرد بتقبل صور', /image\/\*/.test(w.document.getElementById('inFile').accept));
  ok('التسمية بتقول صورة', /صورة/.test(w.document.getElementById('inFileLbl').textContent));
  /* لصق صورة */
  const file=new w.File(['x'],'shot.png',{type:'image/png'});
  const dt={items:[{type:'image/png', getAsFile:()=>file}]};
  const ev=new w.Event('paste',{bubbles:true,cancelable:true}); ev.clipboardData=dt;
  w.document.getElementById('inText').dispatchEvent(ev);
  await new Promise(r=>setTimeout(r,50));
  ok('لصق صورة في خانة الرد بينده القارئ', calls.length===1 && calls[0]==='image/png', calls);
  ok('النص اتحط واتفحص: الخطأ اتشخّص', /unauthorized/.test(w.document.getElementById('inText').value) && /مش مصرّح|التوكن/.test(w.document.getElementById('inOut').textContent), w.document.getElementById('inOut').textContent.slice(0,120));
  ok('صندوق الصورة بيقول اتقرت وبيحذّر من الأرقام', /اتقرت من الصورة/.test(w.document.getElementById('inImgBox').textContent) && /6 أو 8/.test(w.document.getElementById('inImgBox').textContent));
  w.document.getElementById('inClear').click();
  ok('المسح بيخفي صندوق الصورة', w.document.getElementById('inImgBox').hidden);
  /* خانة الرسالة */
  w.eval("INSPVIEW='case'"); w.paintInspect();
  ok('خانة الرسالة فيها زرار صورة', !!w.document.getElementById('caseImg') && /image\/\*/.test(w.document.getElementById('caseImg').accept));
  w.document.getElementById('caseText').value='We get this when calling last location:\nPostman Response:';
  w.ocrImage = async ()=>({text:'{"message":"unauthorized","status_code":401,"extra":[]}', fixes:[], dark:false, confidence:80});
  const ev2=new w.Event('paste',{bubbles:true,cancelable:true}); ev2.clipboardData=dt;
  w.document.getElementById('caseText').dispatchEvent(ev2);
  await new Promise(r=>setTimeout(r,50));
  const v=w.document.getElementById('caseText').value;
  ok('نص الصورة اتحط تحت كلام العميل مش مكانه', /Postman Response:\n\n\{"message":"unauthorized"/.test(v), v);
  ok('الرسالة اتحلّلت بعد القراءة', !!w.document.getElementById('caseOut').innerHTML.trim());
  /* ملف مش صورة */
  const bad=new w.File(['x'],'x.txt',{type:'text/plain'});
  const ev3=new w.Event('paste',{bubbles:true,cancelable:true}); ev3.clipboardData={items:[{type:'text/plain', getAsFile:()=>bad}]};
  const before=w.document.getElementById('caseText').value;
  w.document.getElementById('caseText').dispatchEvent(ev3);
  await new Promise(r=>setTimeout(r,30));
  ok('لصق نص عادي بيعدّي للمتصفح زي ما هو', w.document.getElementById('caseText').value===before && !ev3.defaultPrevented);
}
/* ═════ ٤) فشل التحميل بيتقال بوضوح ═════ */
{
  const w=boot();
  w.ocrImage = async ()=>{ throw new Error('load https://cdn.jsdelivr.net/npm/tesseract.js@5.1.1/dist/tesseract.min.js'); };
  w.showView('inspect'); w.paintInspect();
  const file=new w.File(['x'],'shot.png',{type:'image/png'});
  const ev=new w.Event('paste',{bubbles:true,cancelable:true}); ev.clipboardData={items:[{type:'image/png', getAsFile:()=>file}]};
  w.document.getElementById('inText').dispatchEvent(ev);
  await new Promise(r=>setTimeout(r,50));
  ok('لو المحرك ما نزلش بيقول محتاج نت أول مرة', /نت أول مرة/.test(w.document.getElementById('inImgBox').textContent), w.document.getElementById('inImgBox').textContent.slice(0,120));
}

console.log(F ? `\nفشل ${F}` : '\nصورة الرد: تمام');
process.exit(F?1:0);
})();
