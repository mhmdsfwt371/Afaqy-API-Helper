/* v6.45 — صورة الرد. المحرك نفسه بيتجرّب في المتصفح الحقيقي (test_browser.py)؛
   هنا: تنضيف نص الـ OCR، وإن المحرك ما بيتحمّلش غير لما حد يرفع صورة،
   وإن النسخ مثبّتة، وإن الخانتين موصولتين بالرفع واللصق. */
const fs=require('fs'); const {JSDOM}=require('jsdom');
let F=0; const pass=m=>console.log('  \u2713 '+m); const fail=m=>{console.log('  \u2717 '+m);F++;};
const ok=(m,c,x)=>c?pass(m):fail(m+(x?'  \u2014 '+String(x).slice(0,160):''));
const build=()=>fs.readFileSync(process.argv[2]||'app_template.html','utf8')
  .replace('/*__KB__*/',()=>fs.readFileSync('kb_slim.json','utf8'))
  .replace('/*__DOCS__*/',()=>fs.readFileSync('docs.json','utf8'))
  .replace('/*__KBIN__*/',()=>fs.readFileSync('kb_in.json','utf8'));
function boot(){
  const w=new JSDOM(build(),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://localhost/'}).window;
  w.alert=()=>{}; w.confirm=()=>true; w.scrollTo=()=>{}; w.URL.createObjectURL=()=>'blob:x'; w.URL.revokeObjectURL=()=>{};
  return w;
}

(async()=>{
/* ═════ ١) التنضيف: اللي الـ OCR بيغلط فيه في JSON ═════ */
{
  const w=boot();
  const c=t=>w.ocrClean(t);
  /* رد بوستمان بأرقام سطور + سطر الهيدر + قوس لازق في الرقم */
  const r1=c('Body Cookies Headers (12) TestResults 2000K 312ms 12KB\n1 {\n\n2    “message”: "unauthorized",\n\n3     "status_code": 401,\n\n4    "extra": []\n\n5}');
  ok('أرقام السطور اتشالت حتى اللازقة في القوس', /^\{\n/m.test(r1.text) && /\n\}$/.test(r1.text) && !/\n5\}/.test(r1.text), r1.text);
  ok('التنصيص المعوج اتظبط', /"message": "unauthorized"/.test(r1.text));
  ok('الهيدر اللي قبل الرد اتساب للمصلّح العام (مش شغلة الـ OCR)', /^Body Cookies/.test(r1.text));
  ok('التصليحات بتتقال', r1.fixes.some(f=>/أرقام السطور/.test(f)) && r1.fixes.some(f=>/تنصيص/.test(f)), r1.fixes.join(' | '));
  /* قوس إغلاق اتقرى «Is» + status_code مقروء 464 */
  const r2=c('{\n"message": "not_found",\n"status_code": 464,\n"extra": {\n"unit_id": "The unit_id 5fb6e2e703ed529bb36f9af3 is not found"\nIs\n"data": null\n}');
  let parsed=null; try{ parsed=JSON.parse(r2.text); }catch(_){}
  ok('«Is» رجع قوس إغلاق بفاصلة والرد بقى يتقرا', parsed && parsed.extra && parsed.extra.unit_id && parsed.data===null, r2.text);
  ok('status_code 464 اتصلّح لـ 404 واتقال', parsed && parsed.status_code===404 && r2.fixes.some(f=>/464/.test(f)), r2.fixes.join(' | '));
  ok('المعرّف الطويل ما اتلعبش فيه — ده شغل الموظف', parsed && /5fb6e2e703ed529bb36f9af3/.test(parsed.extra.unit_id));
  /* مفتاح اتقطع بمسافة، وصفر اتقرى @ أو o */
  const r3=c('{\n"status code": 200,\n"last update": {\n"spd": @,\n"acc": 1,\n"lat": 21.5o33\n}\n}');
  ok('«status code» و«last update» بقوا بشرطة', /"status_code": 200/.test(r3.text) && /"last_update"/.test(r3.text), r3.text);
  ok('@ وo في مكان الرقم بقوا صفر', /"spd": 0,/.test(r3.text) && /21\.5033/.test(r3.text), r3.text);
  /* ما يلمسش رد سليم */
  const good='{\n  "message": "ok",\n  "status_code": 200,\n  "data": {"id": "5c3df02803ed52d83c067df1", "name": "Truck 12"}\n}';
  const r4=c(good);
  ok('رد سليم بيعدّي زي ما هو من غير تصليحات', r4.text===good && r4.fixes.length===0, r4.fixes.join(' | '));
  /* كود معروف ما يتغيّرش حتى لو فيه 6 أو 8 */
  ok('406 و 408 أكواد معروفة ما بتتحوّلش', /"status_code": 406/.test(c('{"status_code": 406}').text) && /"status_code": 408/.test(c('{"status_code": 408}').text));
}
/* ═════ ٢) المحرك كسول ومثبّت النسخة ═════ */
{
  const w=boot();
  ok('مفيش سكريبت خارجي اتحمّل مع فتح الأداة', !w.document.querySelector('script[src*="tesseract"]') && !w.document.querySelector('script[src*="jsdelivr"]'));
  const O=w.eval('OCR');
  ok('النسخ مثبّتة بالرقم مش latest', /@5\.1\.1$/.test(O.lib) && /@5\.1\.1$/.test(O.core) && /@1\.0\.0\//.test(O.lang), JSON.stringify(O));
  ok('المصدر الافتراضي jsDelivr', w.ocrCdn()==='https://cdn.jsdelivr.net/npm/');
  w.OCR_CDN_OVERRIDE='http://127.0.0.1:1/'; ok('الاختبار يقدر يوجّهه لسيرفر محلي', w.ocrCdn()==='http://127.0.0.1:1/');
  ok('المحرك مش محمّل قبل أول صورة', O.worker===null && O.loading===null);
}
/* ═════ ٣) الخانتين موصولتين: رفع صورة ولصق صورة بيوصلوا للقارئ ═════ */
{
  const w=boot();
  const calls=[];
  w.ocrImage = async (file, progress)=>{ calls.push(file && file.type); progress && progress('x'); return {text:'{"message":"unauthorized","status_code":401,"extra":[]}', fixes:[], dark:true, confidence:80}; };
  w.showView('inspect'); w.paintInspect();
  ok('خانة الرد بتقبل صور', /image\/\*/.test(w.document.getElementById('inFile').accept));
  ok('التسمية بتقول صورة', /صورة/.test(w.document.getElementById('inFileLbl').textContent));
  /* لصق صورة */
  const file=new w.File(['x'],'shot.png',{type:'image/png'});
  const dt={items:[{type:'image/png', getAsFile:()=>file}]};
  const ev=new w.Event('paste',{bubbles:true,cancelable:true}); ev.clipboardData=dt;
  w.document.getElementById('inText').dispatchEvent(ev);
  await new Promise(r=>setTimeout(r,50));
  ok('لصق صورة في خانة الرد بينده القارئ', calls.length===1 && calls[0]==='image/png', calls);
  ok('النص اتحط واتفحص: الخطأ اتشخّص', /unauthorized/.test(w.document.getElementById('inText').value) && /مش مصرّح|التوكن/.test(w.document.getElementById('inOut').textContent), w.document.getElementById('inOut').textContent.slice(0,120));
  ok('صندوق الصورة بيقول اتقرت وبيحذّر من الأرقام', /اتقرت من الصورة/.test(w.document.getElementById('inImgBox').textContent) && /6 أو 8/.test(w.document.getElementById('inImgBox').textContent));
  w.document.getElementById('inClear').click();
  ok('المسح بيخفي صندوق الصورة', w.document.getElementById('inImgBox').hidden);
  /* خانة الرسالة */
  w.eval("INSPVIEW='case'"); w.paintInspect();
  ok('خانة الرسالة فيها زرار صورة', !!w.document.getElementById('caseImg') && /image\/\*/.test(w.document.getElementById('caseImg').accept));
  w.document.getElementById('caseText').value='We get this when calling last location:\nPostman Response:';
  w.ocrImage = async ()=>({text:'{"message":"unauthorized","status_code":401,"extra":[]}', fixes:[], dark:false, confidence:80});
  const ev2=new w.Event('paste',{bubbles:true,cancelable:true}); ev2.clipboardData=dt;
  w.document.getElementById('caseText').dispatchEvent(ev2);
  await new Promise(r=>setTimeout(r,50));
  const v=w.document.getElementById('caseText').value;
  ok('نص الصورة اتحط تحت كلام العميل مش مكانه', /Postman Response:\n\n\{"message":"unauthorized"/.test(v), v);
  ok('الرسالة اتحلّلت بعد القراءة', !!w.document.getElementById('caseOut').innerHTML.trim());
  /* ملف مش صورة */
  const bad=new w.File(['x'],'x.txt',{type:'text/plain'});
  const ev3=new w.Event('paste',{bubbles:true,cancelable:true}); ev3.clipboardData={items:[{type:'text/plain', getAsFile:()=>bad}]};
  const before=w.document.getElementById('caseText').value;
  w.document.getElementById('caseText').dispatchEvent(ev3);
  await new Promise(r=>setTimeout(r,30));
  ok('لصق نص عادي بيعدّي للمتصفح زي ما هو', w.document.getElementById('caseText').value===before && !ev3.defaultPrevented);
}
/* ═════ ٤) فشل التحميل بيتقال بوضوح ═════ */
{
  const w=boot();
  w.ocrImage = async ()=>{ throw new Error('load https://cdn.jsdelivr.net/npm/tesseract.js@5.1.1/dist/tesseract.min.js'); };
  w.showView('inspect'); w.paintInspect();
  const file=new w.File(['x'],'shot.png',{type:'image/png'});
  const ev=new w.Event('paste',{bubbles:true,cancelable:true}); ev.clipboardData={items:[{type:'image/png', getAsFile:()=>file}]};
  w.document.getElementById('inText').dispatchEvent(ev);
  await new Promise(r=>setTimeout(r,50));
  ok('لو المحرك ما نزلش بيقول محتاج نت أول مرة', /نت أول مرة/.test(w.document.getElementById('inImgBox').textContent), w.document.getElementById('inImgBox').textContent.slice(0,120));
}

console.log(F ? `\nفشل ${F}` : '\nصورة الرد: تمام');
process.exit(F?1:0);
})();
