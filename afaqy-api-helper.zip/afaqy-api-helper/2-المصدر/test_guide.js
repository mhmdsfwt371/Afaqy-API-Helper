/* v5.7 — العريض في الدليل: **كلمة** لازم تطلع عريضة مش نجمتين */
global.setInterval=()=>0;global.clearInterval=()=>{};
const fs=require('fs');
function el(){return{hidden:false,innerHTML:'',value:'',textContent:'',dataset:{},style:{},classList:{toggle(){},add(){},remove(){}},querySelectorAll(){return[]},addEventListener(){},focus(){},select(){},click(){},setAttribute(){},getAttribute(){return null},dispatchEvent(){},appendChild(){},remove(){},scrollIntoView(){}}}
const R={};global.document={documentElement:el(),body:el(),addEventListener(){},querySelectorAll(){return[]},querySelector(){return null},createElement(){return el()},getElementById(i){return R[i]||(R[i]=el())}};
global.history={pushState(){},replaceState(){}};global.location={hash:''};
global.navigator={userAgent:'node',clipboard:{writeText(){return Promise.resolve()}}};global.window={scrollTo(){},addEventListener(){},matchMedia:()=>({matches:false}),navigator:{}};
global.fetch=()=>Promise.reject(0);global.Blob=function(){};global.URL={createObjectURL(){return''}};global.FileReader=function(){};
let js=fs.readFileSync('app_template.html','utf8').split('<script>')[1].split('</script>')[0]
 .replace('/*__KB__*/',fs.readFileSync('kb_slim.json','utf8')).replace('/*__KBIN__*/', fs.readFileSync('kb_in.json','utf8'))
 .replace('/*__DOCS__*/',fs.readFileSync('docs.json','utf8'));
const m={};new Function('module',js+'\nmodule.exports={mdBold,DOCS};')(m);const A=m.exports;
const fail=x=>{console.error('فشل: '+x);process.exit(1);};
if(A.mdBold('قبل **جوه** بعد')!=='قبل <b>جوه</b> بعد') fail('التحويل غلط');
if(A.mdBold('من غير نجوم')!=='من غير نجوم') fail('غيّر نص سليم');
const tpl=fs.readFileSync('app_template.html','utf8');
if(tpl.indexOf('mdBold(esc(x))')<0) fail('البنود مش بتعدي على mdBold');
const stars=A.DOCS.sections.reduce((n,sec)=>n+sec.b.ar.join(' ').split('**').length-1,0);
if(stars<2) fail('مفيش نجمتين في الدليل أصلًا — الاختبار فقد معناه');
console.log('العريض في الدليل: التحويل والتوصيل تمام ('+Math.floor(stars/2)+' موضع هيستفيد)');
