/* v6.6 — نظامين API في أداة واحدة.
   الخطر الحقيقي هنا مش إن الريكوست ما يظهرش — الخطر إن الأداة تطلّع
   شكل نظام لعميل على النظام التاني. العميل هيجرّب، هيفشل، ويرجع يسأل.
   الاختبار ده بيحرس الفصل بين الاتنين. */
global.setInterval=()=>0;global.clearInterval=()=>{};
const fs = require('fs');
const R = {};
function el(id){return{id,hidden:false,innerHTML:'',value:'',textContent:'',className:'',dataset:{},style:{},files:[],disabled:false,
 options:[],classList:{toggle(){},add(){},remove(){}},querySelectorAll(){return[]},addEventListener(){},focus(){},select(){},click(){},
 setAttribute(){},getAttribute(){return null},dispatchEvent(){},appendChild(){},remove(){},scrollIntoView(){},title:''}}
global.document={documentElement:el('html'),body:el('body'),addEventListener(){},querySelectorAll(){return[]},
 querySelector(){return null},createElement(){return el()},getElementById:i=>R[i]||(R[i]=el(i))};
global.history={pushState(){},replaceState(){}};global.location={hash:'',pathname:'/',replace(){}};
global.navigator={userAgent:'node',language:'ar',clipboard:{writeText(){return Promise.resolve()}}};
global.window={scrollTo(){},addEventListener(){},matchMedia:()=>({matches:false}),navigator:{}};
global.fetch=()=>Promise.reject(0);global.Blob=function(){};global.URL={createObjectURL(){return''}};global.FileReader=function(){};
global.btoa=x=>Buffer.from(x,'binary').toString('base64');global.atob=x=>Buffer.from(x,'base64').toString('binary');
const D={};global.localStorage={getItem:k=>(k in D?D[k]:null),setItem:(k,v)=>{D[k]=String(v);},removeItem(){}};
global.sessionStorage={getItem:()=>null,setItem(){},removeItem(){}};global.confirm=()=>false;

let js = fs.readFileSync('app_template.html','utf8').split('<script>')[1].split('</script>')[0]
  .replace('/*__KB__*/', fs.readFileSync('kb_slim.json','utf8'))
  .replace('/*__KBIN__*/', fs.readFileSync('kb_in.json','utf8'))
  .replace('/*__DOCS__*/', fs.readFileSync('docs.json','utf8'));
const m={};
new Function('module', js + "\nmodule.exports={EPS,sysOf,fullUrl,search,sysChip,SYSNAME};")(m);
const A = m.exports;
const fail = msg => { console.error('فشل: ' + msg); process.exit(1); };

/* ١) النظامين محمّلين وكل إندبوينت متوسوم */
const inEps  = A.EPS.filter(e => A.sysOf(e) === 'in');
const avlEps = A.EPS.filter(e => A.sysOf(e) === 'avl');
if(inEps.length < 30) fail('إندبوينتس النظام التاني ناقصة: ' + inEps.length);
if(avlEps.length !== 529) fail('إندبوينتس AVL اتغيّر عددها: ' + avlEps.length);
for(const e of A.EPS) if(!e.sys) fail('إندبوينت من غير وسم نظام: ' + e.p);
console.log('التحميل            : ' + avlEps.length + ' AVL + ' + inEps.length + ' أفاقي إن ✓');

/* ٢) أرقام الإندبوينتس ما تتصادمش — الأداة بتفتح بالرقم */
const ids = A.EPS.map(e => e.i);
if(new Set(ids).size !== ids.length) fail('فيه رقم إندبوينت مكرر بين النظامين — هيفتح الغلط');
console.log('الأرقام            : مفيش تصادم بين النظامين ✓');

/* ٣) الرابط: كل نظام بشكله هو — ولا واحد ياخد شكل التاني */
for(const e of inEps){
  const u = A.fullUrl(e, false);
  if(u.indexOf('afaqy.in') < 0) fail('رابط النظام التاني مش على دومينه: ' + e.p);
  if(u.indexOf('?r=') < 0)      fail('رابط النظام التاني من غير باراميتر الأكشن: ' + e.p);
  if(u.indexOf('token=') >= 0)  fail('توكن AVL اتحط في رابط النظام التاني: ' + e.p);
}
const avl = A.EPS.find(e => e.p === '/units/lists' && A.sysOf(e) === 'avl');
const au = A.fullUrl(avl, false);
if(au.indexOf('?r=') >= 0 || au.indexOf('afaqy.in') >= 0)
  fail('ريكوست AVL خد شكل النظام التاني');
console.log('شكل الروابط        : كل نظام بشكله، مفيش تلوث ✓');

/* ٤) الداتا بتتشفّر في الرابط زي التوثيق بالظبط */
const lst = inEps.find(e => e.b.indexOf('userTrackers/list') >= 0);
const lu  = A.fullUrl(lst, false);
if(lu.indexOf('&data=%7B') < 0) fail('الداتا مش متشفّرة في الرابط');
const q = decodeURIComponent(lu.split('&data=')[1]);
const parsed = JSON.parse(q);
if(!('apiKey' in parsed)) fail('الداتا من غير apiKey');
if('token' in parsed) fail('توكن اتسرّب جوه داتا النظام التاني');
console.log('تشفير الداتا       : JSON مشفّر وفيه apiKey ✓');

/* ٥) كل ريكوست في النظام التاني GET — ده شرط النظام نفسه */
for(const e of inEps) if(e.m !== 'GET') fail('ريكوست مش GET في النظام التاني: ' + e.p);
console.log('الميثود            : كل النظام التاني GET ✓');

/* ٦) الوسم بيظهر على النظام التاني بس */
if(!A.sysChip(inEps[0])) fail('وسم النظام مش ظاهر على ريكوستاته');
if(A.sysChip(avl)) fail('وسم النظام ظهر على AVL — هيزحم الشاشة');
console.log('الوسم البصري       : على النظام التاني بس ✓');

/* ٧) البحث بيوصّل للنظامين */
const hits = A.search('لستة العربيات').slice(0, 8).map(r => A.sysOf(r.e));
if(hits.indexOf('avl') < 0) fail('البحث ما رجّعش AVL');
if(hits.indexOf('in')  < 0) fail('البحث ما رجّعش النظام التاني');
console.log('البحث              : بيرجّع النظامين في نفس النتيجة ✓');

/* ٨) الحساس متعلّم في النظام التاني كمان */
const risky = inEps.filter(e => e.s);
if(risky.length < 8) fail('الريكوستات الخطرة في النظام التاني مش متعلّمة: ' + risky.length);
const del = inEps.find(e => e.b.indexOf('userZones/delete') >= 0);
if(!del || !del.s) fail('المسح مش متعلّم كخطر');
console.log('تعليم الخطر        : ' + risky.length + ' ريكوست متعلّم في النظام التاني ✓');

/* ٩) تنبيه الـ UID ما يظهرش على النظام التاني — هو بياخد IMEI مباشرة */
const tpl = fs.readFileSync('app_template.html','utf8');
if(tpl.indexOf("sysOf(e) === 'in') note +=") < 0)
  fail('تنبيه النظام التاني مش موجود — الموظف هيتلخبط ويدوّر على UID');
const iIn  = tpl.indexOf("sysOf(e) === 'in') note +=");
const iUid = tpl.indexOf('والأداة تحطّ الـ UID الصح مكانها');
if(iUid < iIn) fail('تنبيه الـ UID بيسبق شرط النظام التاني — هيظهر عليه بالغلط');
console.log('تنبيه المعرّف      : النظام التاني بياخد IMEI مباشرة، والتنبيه صح ✓');
