#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v6.1 — بقايا الوضع الإنجليزي: الأشرطة، واتجاه الخانات، وعرض خانة التذكرة."""
import sys
P='app_template.html'; s=open(P,encoding='utf-8').read()
miss=[]; done=[]
def rep(old,new,label,cnt=1):
    global s
    c=s.count(old)
    if c!=cnt: miss.append(f'{label} (لقيت {c})'); return
    s=s.replace(old,new); done.append(label)

# ===== ١) نص شريط التثبيت يتعلّم عشان يتحدّث مع اللغة =====
rep("""    $('instMsg').textContent = t('تقدر تثبّت الأداة على الجهاز وتفتحها زي أي تطبيق.',
                                 'You can install this on your device and open it like any app.');""",
    """    /* بنسجّل النصين على العنصر نفسه — الشريط ممكن يفضل مفتوح والمستخدم يقلب اللغة،
       وساعتها setLang بيعيد كتابته زي أي نص تاني في الصفحة. */
    $('instMsg').dataset.ar = 'تقدر تثبّت الأداة على الجهاز وتفتحها زي أي تطبيق.';
    $('instMsg').dataset.en = 'You can install this on your device and open it like any app.';
    $('instMsg').textContent = t($('instMsg').dataset.ar, $('instMsg').dataset.en);""",
    '١) نص شريط التثبيت')

# ===== ٢) شريط التحديث يترسم من جديد مع تغيير اللغة =====
rep("  $('updBar').hidden = false;\n  }catch(err){",
    "  $('updBar').hidden = false;\n    UPD_LAST = v;                       // بنحتفظ بالنسخة عشان نعيد كتابة الشريط لو اللغة اتغيرت\n  }catch(err){",
    '٢أ) حفظ بيانات شريط التحديث')
rep("async function checkUpdate(",
    "let UPD_LAST = null;\nfunction paintUpdBar(){\n  const v = UPD_LAST; if(!v || $('updBar').hidden) return;\n  const items = (v.notes && (LANG==='en' ? v.notes.en : v.notes.ar)) || [];\n  $('updMsg').innerHTML = `<b>${t('في نسخة أحدث','A newer version is available')}: v${esc(v.version)}</b>`\n    + (items.length ? ` — ${esc(items.slice(0,2).join(t('، ','; ')))}` : '')\n    + `<br><span style=\"opacity:.85; font-size:12.5px\">${t('اللي عندك دلوقتي','You are on')} v${esc(DOCS.version)}</span>`;\n}\nasync function checkUpdate(",
    '٢ب) دالة رسم شريط التحديث')
rep("  sesPaint(SESSION.token ? t('متصل — ','Connected — ')+SESSION.user : t('غير متصل','Not connected'));",
    "  paintUpdBar();\n  sesPaint(SESSION.token ? t('متصل — ','Connected — ')+SESSION.user : t('غير متصل','Not connected'));",
    '٢ج) إعادة الرسم مع تغيير اللغة')

# ===== ٣) اتجاه خانات الشريط بيتبع اللغة =====
rep(".conn input{width:190px}",
    """.conn input{width:190px}
/* خانات الاسم والعميل بتتكتب عربي في الوضع العربي وإنجليزي في الإنجليزي —
   الاتجاه الثابت كان بيرمي النقطة قبل الإيميل ويقصّ النص الإنجليزي. */
.conn input.bidi{direction:rtl; text-align:right; font-family:var(--ar)}
body.en .conn input.bidi{direction:ltr; text-align:left; font-family:var(--mono)}""",
    '٣أ) قاعدة اتجاه الخانات')
for lbl,i_d,old_style in [
 ('٣ب) خانة اسم المستخدم','sesU','style="width:130px; font-family:var(--ar); text-align:right; direction:rtl"'),
 ('٣ج) خانة كلمة السر','sesP','style="width:120px; font-family:var(--ar); text-align:right; direction:rtl"'),
]:
    anchor = f'id="{i_d}" type="password" data-arph' if i_d=='sesP' else f'id="{i_d}" data-arph'
    rep(anchor, anchor.replace(f'id="{i_d}"', f'id="{i_d}" class="bidi"'), lbl+' (كلاس)')
    rep(old_style, f'style="width:{130 if i_d=="sesU" else 120}px"', lbl+' (ستايل)')

# ===== ٤) خانة عميل التذكرة: كلاس + عرض يكفي الإنجليزي + نص أقصر =====
rep('<input id="tickCust" autocomplete="off" style="width:150px; font-family:var(--ar); text-align:right; direction:rtl" data-arph="عميل التذكرة (اختياري)" data-enph="Ticket customer (optional)" placeholder="عميل التذكرة (اختياري)">',
    '<input id="tickCust" class="bidi" autocomplete="off" style="width:190px" data-arph="عميل التذكرة (اختياري)" data-enph="Ticket customer" placeholder="عميل التذكرة (اختياري)">',
    '٤) خانة عميل التذكرة')

for d in done: print('تمام:',d)
if miss:
    print('!! MISS:'); [print('  ',x) for x in miss]; sys.exit(1)
open(P,'w',encoding='utf-8').write(s)
print(f'اتكتب — {len(done)} تعديل')
