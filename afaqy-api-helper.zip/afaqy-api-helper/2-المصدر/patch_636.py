#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v6.36 — شاشة «حلّل رسالة عميل» بقت ستة بلوكات فوق بعض،
والرد — اللي هو سبب فتح الشاشة أصلاً — آخر واحد.

الترتيب الجديد: سطر حكم واحد، بعده الرد مقصوص، وبعديهم التحليل
كله مطوي في سطر واحد يتفتح لما تحتاجه.
"""
import sys, io

PATH = sys.argv[1] if len(sys.argv) > 1 else 'app_template.html'
src = io.open(PATH, encoding='utf-8').read()
orig = len(src)

def rep(old, new, n=1, tag=''):
    global src
    c = src.count(old)
    if c != n: raise SystemExit('MISMATCH [%s]: expected %d found %d\n---\n%s' % (tag, n, c, old[:220]))
    src = src.replace(old, new, n); print('  ok  %s' % tag)

# ── ١) ستايل السطر المطوي ─────────────────────────────────────
rep(""".preWrap{position:relative}""",
""".caseMore{border:1px solid var(--line); border-radius:var(--r); background:var(--panel);
  margin-top:12px; overflow:hidden}
.caseMore>summary{cursor:pointer; padding:12px 16px; font-weight:600; font-size:14px;
  color:var(--ink); list-style:none; display:flex; align-items:center; gap:8px}
.caseMore>summary::-webkit-details-marker{display:none}
.caseMore>summary::before{content:'\\25B8'; color:var(--muted); font-size:11px; transition:transform .15s}
.caseMore[open]>summary::before{transform:rotate(90deg)}
.caseMore>summary:hover{background:var(--panel-2)}
.caseMore>summary .cnt{color:var(--muted); font-weight:400; font-size:12.5px}
.caseMore .panel{border:0; border-top:1px solid var(--line-soft); border-radius:0; margin:0}
.caseVerdict{display:flex; justify-content:space-between; align-items:flex-start;
  gap:14px; flex-wrap:wrap}
.preWrap{position:relative}""",
    1, 'CSS: السطر المطوي')

# ── ٢) الرد ياخد class=pre عشان القص التلقائي يشتغل عليه ──────
rep("""<pre id="caseReplyTxt" style="white-space:pre-wrap;""",
    """<pre id="caseReplyTxt" class="pre" style="white-space:pre-wrap;""",
    1, 'الرد بيتقص زي أي بلوك')

# ── ٣) التجميع: حكم فوق، رد تحته، التحليل مطوي ────────────────
rep("""  out.innerHTML = L.join('');
  out.querySelectorAll('[data-goep]').forEach(b => b.onclick = ()=>{""",
"""  /* الرد هو آخر حاجة اتحطت في L لو موجود — بنطلّعه لفوق.
     السبب: الموظف بيفتح الشاشة عشان الرد، مش عشان يقرا التحليل. */
  const replyHtml = reply ? L.pop() : '';
  const vd = caseVerdict(a);
  out.innerHTML = `
    <div class="panel"><div class="sec" style="border-top:0">
      <div class="caseVerdict">
        <div style="flex:1 1 300px; min-width:0">
          <div class="crumb">${t('الحالة','The case')}</div>
          <div style="font-size:15px; font-weight:600; margin-top:5px; line-height:1.6">${vd.line}</div>
        </div>
        <span class="chip ${vd.ok ? 'sig' : ''}" style="pointer-events:none; flex:0 0 auto">${vd.tag}</span>
      </div>
    </div></div>
    ${replyHtml}
    ${L.length ? `<details class="caseMore">
      <summary>${t('التحليل اللي الرد اتبنى عليه','The analysis behind this reply')}
        <span class="cnt">— ${L.length} ${t('قسم','sections')}</span></summary>
      ${L.join('')}</details>` : ''}`;
  clipBlocks(out);
  out.querySelectorAll('[data-goep]').forEach(b => b.onclick = ()=>{""",
    1, 'التجميع الجديد')

# ── ٤) سطر الحكم ──────────────────────────────────────────────
rep("""function renderCase(text){""",
"""/* سطر واحد بيقول الحالة اتحسمت ولا لسه — عشان الموظف يعرف في ثانية
   هيبعت ولا هيسأل، من غير ما يقرا ستة بلوكات. */
function caseVerdict(a){
  const missing = caseNeeds(a).length;
  if(a && a.reportCase) return {ok:true,
    tag:t('محسومة','Resolved'),
    line:t('العميل نادى كتالوج التقارير وهو عايز داتا التقرير. الرد تحت فيه السلسلة الصح كاملة.',
           'The customer called the report catalog while wanting report data. The reply below carries the full correct chain.')};
  if(missing) return {ok:false,
    tag:t('ناقصة أدلة','Evidence needed'),
    line:t(`الرسالة ناقصة ${missing} حاجة عشان نحسمها. الطلب المحدد جوه التحليل تحت.`,
           `The message is missing ${missing} item(s) before this can be settled. The specific ask is in the analysis below.`)};
  return {ok:true,
    tag:t('متشخّصة','Diagnosed'),
    line:t('الرسالة فيها اللي يكفي للتشخيص. اقرا التحليل تحت قبل ما ترد.',
           'The message carries enough to diagnose. Read the analysis below before replying.')};
}

function renderCase(text){""",
    1, 'دالة الحكم')

io.open(PATH, 'w', encoding='utf-8').write(src)
print('\ndone (%d -> %d, +%d)' % (orig, len(src), len(src) - orig))
