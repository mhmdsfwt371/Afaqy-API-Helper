/* اختبارات v6.38 — تعديل البودي، وصدق الكارت لما الداتا مش راجعة */
const fs=require('fs'); const {JSDOM}=require('jsdom');
let F=0; const pass=m=>console.log('  \u2713 '+m); const fail=m=>{console.log('  \u2717 '+m);F++;};
const ok=(m,c,x)=>c?pass(m):fail(m+(x?'  \u2014 '+String(x).slice(0,110):''));
const build=()=>fs.readFileSync(process.argv[2]||'app_template.html','utf8')
  .replace('/*__KB__*/',()=>fs.readFileSync('kb_slim.json','utf8'))
  .replace('/*__DOCS__*/',()=>fs.readFileSync('docs.json','utf8'))
  .replace('/*__KBIN__*/',()=>fs.readFileSync('kb_in.json','utf8'));
function boot(){
  const w=new JSDOM(build(),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://localhost/'}).window;
  w.alert=()=>{}; w.scrollTo=()=>{}; w.confirm=()=>true;
  return w;
}
const openEp = (w, path) => w.eval(`renderDetail(EPS.find(x=>x.p===${JSON.stringify(path)}))`);

/* ═════ ١) صندوق التعديل موجود وبيشتغل ═════ */
console.log('\n\u0661) تعديل البودي');
{
  const w=boot();
  w.eval(`renderDetail(EPS.find(x=>x.p==="/units/lists"))`);
  const box = w.document.getElementById('bodyBox');
  ok('صندوق التعديل ظاهر', !!box);
  ok('جواه البودي الأصلي', box && /"limit"/.test(box.value) && /projection/.test(box.value));
  ok('مقفول افتراضيًا', !w.document.getElementById('bodyEditBox').hasAttribute('open'));

  /* نعدّل الـ limit */
  box.value = box.value.replace('"limit": 1000', '"limit": 25');
  w.document.getElementById('bodyApply').click();
  const sent = w.eval('bodyOf2(EPS.find(x=>x.p==="/units/lists"))');
  ok('التعديل اتخزّن', /"limit": 25/.test(sent), sent.slice(0,60));
  ok('والمثال اتحدّث', /"limit": 25/.test(w.document.getElementById('codeout').textContent));
  ok('ورد العميل بياخد المعدّل',
     /"limit": 25/.test(w.eval('packetFor(EPS.find(x=>x.p==="/units/lists")).text')));

  /* رجّع الأصلي */
  w.document.getElementById('bodyReset').click();
  ok('الرجوع للأصلي شغّال', /"limit": 1000/.test(w.eval('bodyOf2(EPS.find(x=>x.p==="/units/lists"))')));
  w.close();
}

/* ═════ ٢) JSON غلط ما بيتطبقش ═════ */
console.log('\n\u0662) JSON غلط بيترفض');
{
  const w=boot();
  w.eval(`renderDetail(EPS.find(x=>x.p==="/units/lists"))`);
  const box=w.document.getElementById('bodyBox');
  box.value = '{ "data": { "limit": }';
  w.document.getElementById('bodyApply').click();
  ok('ما اتطبقش', w.eval('BODY_EDIT["/units/lists"] === undefined'));
  ok('وقال السبب', /JSON/.test(w.document.getElementById('bodyMsg').textContent),
     w.document.getElementById('bodyMsg').textContent);
  w.close();
}

/* ═════ ٣) الكارت ما يدّعيش أوفلاين ═════ */
console.log('\n\u0663) صدق الكارت');
{
  const w=boot();
  /* عربية من غير last_update ومن غير sensors — زي اللي بيحصل لما الـ projection ناقص */
  const bare = w.eval(`userCard({name:'car-x', imei:'860123456789012', id:'U1'})`);
  /* الشارة بس — مش أي ذكر للكلمة في شرح توضيحي */
  const badgeOf = html => { const m = html.match(/border-radius:3px;[\s\S]{0,120}?>([^<]+)</); return m ? m[1].trim() : ''; };
  ok('الشارة ما قالتش أوفلاين', !/أوفلاين|Offline/.test(badgeOf(bare)), 'الشارة = ' + badgeOf(bare));
  ok('الشارة قالت مش راجعة', /مش راجعة|not returned/.test(badgeOf(bare)), badgeOf(bare));
  ok('قال آخر إشارة مش راجعة', /مش راجعة|not returned/.test(bare));
  ok('ووجّه يحط last_update في الـ projection', /last_update/.test(bare));
  ok('وقال الحساسات مش في الرد', /الحساسات|Sensors/.test(bare) && /sensors/.test(bare));

  /* عربية بآخر إشارة حديثة — لازم تقول أونلاين */
  const now = new Date(Date.now()-5*60000).toISOString().replace('T',' ').slice(0,19);
  const live = w.eval(`userCard({name:'car-y', id:'U2', last_update:{time:${JSON.stringify(now)}}})`);
  ok('العربية الشغّالة لسه بتقول أونلاين', /أونلاين|Online/.test(live));
  ok('وبتعرض آخر تحديث', /آخر تحديث|Last update/.test(live));

  /* عربية بحساسات */
  const sens = w.eval(`userCard({name:'car-z', id:'U3', last_update:{time:${JSON.stringify(now)}},
    sensors:[{name:'Fuel', value:'55'},{name:'Temp', value:'31'}]})`);
  ok('الحساسات بتتعرض بقيمها', /Fuel/.test(sens) && /55/.test(sens));
  ok('ومكتوب إنها قراءة حساس', /قراءة حساس|sensor reading/.test(sens));
  w.close();
}

/* ═════ ٤) أفاقي إن: كله GET والبودي في الرابط ═════ */
console.log('\n\u0664) أفاقي إن — GET وبودي في الرابط');
{
  const w=boot();
  const inEps = w.eval('JSON.stringify(EPS.filter(x=>sysOf(x)==="in").map(x=>x.m))');
  const ms = JSON.parse(inEps);
  ok('كل إندبوينتس أفاقي إن GET', ms.length>0 && ms.every(m=>m==='GET'), ms.slice(0,5).join(','));

  w.eval('renderDetail(EPS.find(x=>sysOf(x)==="in" && /reports\\/generate/.test(x.p)))');
  const box=w.document.getElementById('bodyBox');
  ok('صندوق التعديل ظاهر رغم إنه GET', !!box);
  const urlBefore = w.document.getElementById('fullUrlOut').textContent;
  ok('الرابط فيه data= مشفّرة', /data=%7B|data=\{/.test(urlBefore), urlBefore.slice(0,70));

  box.value = box.value.replace('"sdt": "2016-02-06 00:00:00"', '"sdt": "2026-08-01 00:00:00"');
  w.document.getElementById('bodyApply').click();
  const urlAfter = w.document.getElementById('fullUrlOut').textContent;
  ok('الرابط اتحدّث بالتعديل', decodeURIComponent(urlAfter).indexOf('2026-08-01') > -1,
     decodeURIComponent(urlAfter).slice(0,110));
  ok('والرابط اتغيّر فعلًا', urlAfter !== urlBefore);

  w.document.getElementById('bodyReset').click();
  ok('الرجوع للأصلي بيرجّع الرابط', w.document.getElementById('fullUrlOut').textContent === urlBefore);
  w.close();
}

console.log('\n'+(F?'\u2717 فشل: '+F:'\u2713 كله عدّى'));
process.exit(F?1:0);
