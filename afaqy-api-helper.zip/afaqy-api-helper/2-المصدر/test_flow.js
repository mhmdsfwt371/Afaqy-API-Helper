/* التدفق الكامل: تشغيل ناجح → الرد الكامل بيبقى فيه الرد الحقيقي.
   اتكتب بعد ما اتضح إن تعديلات على tryItRun ما اتطبقتش والنشر عدّى. */
const fs=require('fs');
const R={};
function el(id){return{id,hidden:false,innerHTML:'',value:'',textContent:'',className:'',dataset:{},style:{},files:[],disabled:false,
 classList:{toggle(){},add(){},remove(){}},querySelectorAll(){return[]},addEventListener(){},focus(){},select(){},click(){},
 setAttribute(){},getAttribute(){return null},dispatchEvent(){},appendChild(){},remove(){},scrollIntoView(){},onclick:null}}
global.document={documentElement:el(),body:el(),addEventListener(){},querySelectorAll(){return[]},
 querySelector(){return null},createElement(){return el()},getElementById(i){return R[i]||(R[i]=el(i))}};
global.history={pushState(){},replaceState(){}};global.location={hash:'',pathname:'/',replace(){}};
global.setInterval=()=>0;
global.navigator={clipboard:{writeText(){return Promise.resolve()}}};
global.window={scrollTo(){},addEventListener(){}};
global.Blob=function(){};global.URL={createObjectURL(){return''}};global.FileReader=function(){};

const LOGIN_OK = {message:'success', status_code:200,
                  data:{token:'eyJ0eXAiOiJKV1Q.LIVE_TOKEN.sig', user:{server_id:'1'}}};
global.fetch = () => Promise.resolve({ ok:true, status:200,
  text:()=>Promise.resolve(JSON.stringify(LOGIN_OK)) });

let js=fs.readFileSync('app_template.html','utf8').split('<script>')[1].split('</script>')[0]
 .replace('/*__KB__*/',fs.readFileSync('kb_slim.json','utf8'))
 .replace('/*__DOCS__*/',fs.readFileSync('docs.json','utf8'));
const m={};
new Function('module', js + "\nmodule.exports={EPS,SESSION,tryItRun,packetFor,LAST_RUN:()=>LAST_RUN};")(m);
const A=m.exports;
const fail = s2 => { console.error('فشل: '+s2); process.exit(1); };

(async ()=>{
  const login = A.EPS.find(e=>e.p==='/auth/login');
  A.SESSION.user='safwat'; A.SESSION.pass='pw'; A.SESSION.token='eyJ0eXAiOiJKV1Q.LIVE_TOKEN.sig';

  // قبل التشغيل
  if(A.packetFor(login).live) fail('قال عنده رد حقيقي قبل ما يشغّل');
  console.log('قبل التشغيل   : مفيش رد حقيقي ✓');

  // التشغيل
  const out = document.getElementById('tryout');
  await A.tryItRun(login, out);

  if(out.innerHTML.indexOf('200') < 0) fail('الرد ما اتعرضش');
  if(out.innerHTML.indexOf('cpPacket') < 0) fail('زرار الرد الكامل ما ظهرش بعد النجاح');
  console.log('بعد التشغيل   : الرد ظهر وزرار النسخ ظهر ✓');

  // الرد الكامل لازم يبقى فيه الرد الحقيقي
  const pk = A.packetFor(login);
  if(!pk.live) fail('الرد الكامل لسه بيقول مفيش رد حقيقي');
  if(pk.text.indexOf('not captured yet') >= 0) fail('لسه بيقول not captured');
  if(pk.text.indexOf('"message": "success"') < 0) fail('الرد الحقيقي مش جوه الرد الكامل');
  console.log('الرد الكامل   : فيه الرد الحقيقي ✓');

  // التوكن ما يخرجش
  if(pk.text.indexOf('LIVE_TOKEN') >= 0) fail('التوكن ظاهر في الرد للعميل');
  console.log('التوكن        : متشال ✓');

  // بيانات الدخول الحقيقية اتبعتت مش العلامات
  if(out.innerHTML.indexOf('&lt;USERNAME&gt;') >= 0) fail('بعت العلامات بدل البيانات');
  console.log('بيانات الدخول : اتبعتت حقيقية ✓');
})();
