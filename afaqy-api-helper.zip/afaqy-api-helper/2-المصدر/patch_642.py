#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v6.42 — تحقق من المدخلات قبل ما نضرب السيرفر.

تلات حاجات طلعت من المراجعة، وأخطرهم الأولى:

١) فترة مقلوبة (من ديسمبر لـ يناير) كانت بتمشي لآخر السلسلة، السيرفر
   بيرجّع فاضي، والأداة بتطلّع رد للعميل بيقول «العربية ما تحركتش في
   الفترة». يعني غلطة كتابة بتتحول لجملة واثقة وغلط تتبعت لعميل.
   دي أسوأ نوع باج في أداة زي دي.

٢) IMEI بأرقام عربية (٨٦٠١٢٣...) بيقارن بـ === مع أرقام إنجليزي، فبيقول
   «الرقم ده مش في الحساب» على عربية موجودة فعلًا.

٣) نفس الحاجة لو الرقم اتنسخ من إيميل عربي وجاي معاه علامة اتجاه مخفية
   (U+200F). المستخدم مش شايفها، فالرسالة بتبقى غير قابلة للتفسير.

الحل: تطبيع واحد يتطبّق على الطرفين، وتحقق من الشكل قبل النداء.
"""
import sys, io

PATH = sys.argv[1] if len(sys.argv) > 1 else 'app_template.html'
src = io.open(PATH, encoding='utf-8').read()
orig = len(src)

def rep(old, new, n=1, tag=''):
    global src
    c = src.count(old)
    if c != n: raise SystemExit('MISMATCH [%s]: expected %d found %d\n---\n%s' % (tag, n, c, old[:240]))
    src = src.replace(old, new, n); print('  ok  %s' % tag)

# ── ١) دوال التحقق ──────────────────────────────────────────
HELPERS = r"""
/* ═══ تحقق المدخلات ═══
   الأرقام بتوصل الأداة منسوخة من تذاكر وإيميلات عربية. النسخ من نص
   عربي بيجيب معاه علامات اتجاه غير مرئية، والكيبورد العربي بيكتب
   ٠١٢٣ مش 0123. المقارنة بـ === بتفشل في الحالتين والمستخدم مش شايف
   ليه — فبنطبّع الطرفين قبل أي مقارنة. */
function normDigits(v){
  return String(v == null ? '' : v)
    /* علامات الاتجاه والمسافات الصفرية — بتتنسخ مع النص العربي وهي مخفية */
    .replace(/[\u200B-\u200F\u202A-\u202E\u2066-\u2069\uFEFF]/g, '')
    .replace(/[\u00A0\u2007\u202F]/g, ' ')
    /* ٠-٩ عربية، و ۰-۹ فارسية/أردية */
    .replace(/[\u0660-\u0669]/g, d => String(d.charCodeAt(0) - 0x0660))
    .replace(/[\u06F0-\u06F9]/g, d => String(d.charCodeAt(0) - 0x06F0))
    .trim();
}
/* للمقارنة بس: أرقام وخلاص، عشان الشرطة والمسافة ما يفرّقوش */
function digitsOnly(v){ return normDigits(v).replace(/\D/g, ''); }

/* بترجّع رسالة لو في مشكلة، وسلسلة فاضية لو تمام */
function imeiIssue(v){
  const raw = normDigits(v);
  if(!raw) return '';                       /* فاضي = مسموح، معناه الحساب كله */
  const d = digitsOnly(raw);
  if(!d) return t('الـ IMEI لازم يكون أرقام. اللي مكتوب مفيهوش ولا رقم.',
                  'The IMEI must be digits. What is entered contains none.');
  if(/\D/.test(raw)) return t(`في حروف أو رموز جوه الرقم: ${raw}`,
                              `The value contains non-digit characters: ${raw}`);
  if(d.length !== 15) return t(
    `الـ IMEI بيتكوّن من ١٥ رقم، واللي مكتوب ${d.length}. اتأكد من الرقم قبل ما نضرب السيرفر.`,
    `An IMEI is 15 digits; this one has ${d.length}. Check the number before we call the server.`);
  return '';
}

function periodIssue(from, to){
  if(!from || !to) return t('لازم تحدد الفترة: من يوم ولحد يوم.',
                            'Both dates are required: from and to.');
  const a = new Date(from + 'T00:00:00'), b = new Date(to + 'T00:00:00');
  if(isNaN(a) || isNaN(b)) return t('التواريخ مش مقروءة.','The dates cannot be read.');
  if(a > b) return t(
    `الفترة مقلوبة: «من» ${from} بعد «لحد» ${to}. لو مشينا كده السيرفر هيرجّع فاضي، والأداة هتقول للعميل إن العربية ما تحركتش — وده رد غلط.`,
    `The period is reversed: from ${from} is after to ${to}. If we proceed the server returns nothing and the tool would tell the customer the vehicle did not move — a wrong answer.`);
  const days = (b - a) / 86400000;
  if(days > 366) return t(
    `الفترة ${Math.round(days)} يوم. التقارير الطويلة بتاخد وقت في التوليد وممكن توقف. قصّرها أو قسّمها.`,
    `The period spans ${Math.round(days)} days. Long reports are slow to generate and may time out. Shorten or split it.`);
  return '';
}
"""

rep("\nasync function doRScope(i){", HELPERS + "\nasync function doRScope(i){", 1, 'دوال التحقق')

# ── ٢) التحقق قبل بداية التشغيل التلقائي ────────────────────
rep("""    RC.auto = true;
    try{""",
"""    /* التحقق قبل أول نداء: الفترة المقلوبة كانت بتوصل لآخر السلسلة
       وتطلّع رد غلط للعميل. أوقفها هنا. */
    const _bad = periodIssue(RC.vars.from, RC.vars.to) || imeiIssue(RC.vars.imei);
    if(_bad){
      b.disabled=false;
      openModal(t('المدخلات محتاجة مراجعة','Check the inputs'),
        `<div class="note warn" style="font-size:14px; line-height:1.8">${esc(_bad)}</div>`, false);
      return;
    }
    RC.auto = true;
    try{""", 1, 'التحقق قبل التشغيل')

# ── ٣) مقارنة الـ IMEI بالتطبيع على الطرفين ─────────────────
rep("""      const im = String(RC.vars.imei || '').trim();""",
"""      const im = normDigits(RC.vars.imei);""", 1, 'تطبيع المدخل')

rep("""          const hit = all.find(u => String(u.imei||'') === im);""",
"""          /* التطبيع على الطرفين: الرقم اللي جه من التذكرة واللي راجع
             من الحساب. أي واحد فيهم ممكن يكون فيه علامة مخفية. */
          const imD = digitsOnly(im);
          const hit = all.find(u => digitsOnly(u.imei) === imD);""", 1, 'تطبيع الطرفين')

# ── ٤) الرسالة بتوضّح إن الرقم اتطبّع ───────────────────────
rep("""              msg: t(`الـ IMEI ده مش في الحساب المتصل: ${esc(im)}`, `This IMEI is not on the connected account: ${esc(im)}`),""",
"""              msg: t(`الـ IMEI ده مش في الحساب المتصل: ${esc(imD)}`, `This IMEI is not on the connected account: ${esc(imD)}`),""",
    1, 'الرسالة بالرقم المطبّع')

io.open(PATH, 'w', encoding='utf-8').write(src)
print('\ndone (%d -> %d, +%d)' % (orig, len(src), len(src) - orig))
