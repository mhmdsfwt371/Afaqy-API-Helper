/* التبويبات: ٦ في صفين — الشغل اليومي، وبعدين المرجع والأدوات.
   والدليل بقى تبويب فرعي جوه الأساسيات مش تبويب لوحده. */
const fs=require('fs');
const tpl=fs.readFileSync('app_template.html','utf8');
const fail=s=>{console.error('فشل: '+s);process.exit(1)};

const tabs=[...tpl.matchAll(/data-view="([a-z]+)"[^>]*><span data-ar="([^"]+)"/g)].map(m=>({v:m[1],ar:m[2]}));
if(tabs.length>6) fail('التبويبات رجعت تزيد: '+tabs.length);
if(tabs.some(t=>t.v==='docs')) fail('الدليل لسه تبويب مستقل');
console.log('التبويبات ('+tabs.length+'): '+tabs.map(t=>t.ar).join(' · '));

if(tpl.indexOf('class="tabsep"')<0) fail('الفاصل مش موجود');
const sepAt = tpl.indexOf('class="tabsep"');
const before = tabs.filter(t=>tpl.indexOf('data-view="'+t.v+'"') < sepAt).length;
if(before!==4) fail('الفاصل مكانه غلط — قبله '+before+' بدل ٤');
console.log('الفاصل: ٤ تبويبات شغل يومي، وبعده المرجع والأدوات ✓');

// التنقل
const R={};
function el(id){return{id,hidden:true,innerHTML:'',value:'',textContent:'',className:'',dataset:{},style:{},files:[],disabled:false,
 placeholder:'',classList:{toggle(){},add(){},remove(){}},querySelectorAll(){return[]},addEventListener(){},focus(){},select(){},
 click(){},setAttribute(k,v){this['_'+k]=v},getAttribute(k){return this['_'+k]||null},dispatchEvent(){},appendChild(){},remove(){},
 scrollIntoView(){},onclick:null}}
global.document={documentElement:el(),body:el(),addEventListener(){},querySelectorAll(){return[]},
 querySelector(){return null},createElement(){return el()},getElementById(i){return R[i]||(R[i]=el(i))}};
global.history={pushState(){},replaceState(){}};global.location={hash:'',pathname:'/',replace(){},reload(){}};
global.setInterval=()=>0;global.navigator={clipboard:{writeText(){return Promise.resolve()}}};
global.window={scrollTo(){},addEventListener(){}};global.fetch=()=>Promise.reject(0);
global.TextEncoder=require('util').TextEncoder;global.Blob=function(){};
global.URL={createObjectURL(){return''}};global.FileReader=function(){};global.AbortController=function(){};
let js=tpl.split('<script>')[1].split('</script>')[0]
 .replace('/*__KB__*/',fs.readFileSync('kb_slim.json','utf8'))
 .replace('/*__DOCS__*/',fs.readFileSync('docs.json','utf8'));
const m={};new Function('module',js+"\nmodule.exports={showView,getFaq:()=>FAQVIEW};")(m);
const A=m.exports;

A.showView('faq');
if(R['v-faq'].hidden) fail('الأساسيات ما ظهرتش');
if(!R['v-docs'].hidden) fail('الدليل ظهر مع الأساسيات');
console.log('الأساسيات      : الشروحات ظاهرة والدليل مخفي ✓');

A.showView('docs');   // اللينكات القديمة #docs لازم تفضل شغالة
if(A.getFaq()!=='guide') fail('#docs ما فتحش الدليل');
if(!R['v-faq'].hidden) fail('الشروحات ظهرت مع الدليل');
if(R['v-docs'].hidden) fail('الدليل ما ظهرش');
console.log('لينك #docs     : لسه بيفتح الدليل ✓');

A.showView('search');
if(!R['v-docs'].hidden || !R['v-faq'].hidden) fail('حاجة من المرجع فضلت ظاهرة');
console.log('التنقل         : تبويب واحد ظاهر في المرة ✓');
