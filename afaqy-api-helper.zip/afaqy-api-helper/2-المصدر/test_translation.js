/* v6.0 — حارس الترجمة.
   الاختبار ده اتكتب بعد ما نسخة اتنشرت والوضع الإنجليزي فيها كان لسه بيعرض
   شريط تثبيت عربي، وأسماء صيغ عربية، وفاصلة عليا مكسورة في خانة البحث.
   من دلوقتي أي نص للمستخدم من غير مقابل بيوقّف البناء. */
global.setInterval=()=>0;global.clearInterval=()=>{};
const fs = require('fs');
const tpl = fs.readFileSync('app_template.html','utf8');
const head = tpl.slice(0, tpl.indexOf('<script>'));
const js   = tpl.slice(tpl.indexOf('<script>'));
const AR = /[\u0600-\u06FF]/;
const fail = msg => { console.error('فشل: ' + msg); process.exit(1); };

/* ١) هروب يونيكود حرفي جوه الصفحة — بيظهر للمستخدم كما هو */
const esc = head.match(/\\u[0-9a-fA-F]{4}/g) || [];
if(esc.length) fail('هروب يونيكود حرفي في الصفحة: ' + esc.slice(0,3).join(', '));
console.log('الهروب في الصفحة   : نضيف ✓');

/* ٢) أي نص عربي ثابت في الصفحة لازم يكون معاه مقابل إنجليزي */
const noPair = [];
const re = /<(button|span|option|label|h[1-6]|p|b|em|a)\b([^>]*)>([^<]{2,120})<\/\1>/g;
let m;
while((m = re.exec(head))){
  const [, , attrs, txt] = m;
  if(AR.test(txt) && attrs.indexOf('data-ar=') < 0) noPair.push(txt.trim().slice(0,40));
}
if(noPair.length) fail('نص عربي ثابت من غير مقابل: ' + noPair.join(' · '));
console.log('نصوص الصفحة        : كلها ليها مقابل ✓');

/* ٣) كل data-ar لازم يقابله data-en، وكل placeholder عربي له مقابل */
for(const tag of head.match(/<[^>]*data-ar="[^"]*"[^>]*>/g) || [])
  if(tag.indexOf('data-en=') < 0) fail('data-ar من غير data-en: ' + tag.slice(0,70));
for(const tag of head.match(/<input\b[^>]*>/g) || []){
  const ph = /placeholder="([^"]*)"/.exec(tag);
  if(ph && AR.test(ph[1]) && tag.indexOf('data-arph=') < 0)
    fail('خانة عربية من غير مقابل: ' + ph[1].slice(0,40));
  if(tag.indexOf('data-arph=') >= 0 && tag.indexOf('data-enph=') < 0)
    fail('placeholder من غير مقابل إنجليزي: ' + tag.slice(0,60));
}
console.log('المقابلات          : كل عربي له إنجليزي ✓');

/* ٤) الجانب الإنجليزي في t() مايكونش عربي ولا فاضي */
let pairs = 0, bad = [];
const rt = /t\(\s*'((?:\\.|[^'\\])*)'\s*,\s*'((?:\\.|[^'\\])*)'\s*\)/g;
while((m = rt.exec(js))){
  pairs++;
  const ar = m[1], en = m[2];
  if(AR.test(en)) bad.push('عربي في الإنجليزي: ' + en.slice(0,45));
  else if(!en.trim() && ar.trim()) bad.push('إنجليزي فاضي مقابل: ' + ar.slice(0,35));
}
if(bad.length) fail(bad.slice(0,4).join(' · '));
if(pairs < 500) fail('عدد النصوص المترجمة قلّ فجأة: ' + pairs);
console.log('نصوص الجافاسكريبت  : ' + pairs + ' زوج، كلهم سليمين ✓');

/* ٥) أسماء صيغ التصحيح التلقائي كانت عربية في الوضع الإنجليزي */
const iv = js.indexOf('function labVariants');
const seg = js.slice(iv, js.indexOf('return out;', iv));
const rawNames = seg.match(/n:'[^']*[\u0600-\u06FF][^']*'/g) || [];
if(rawNames.length) fail('اسم صيغة من غير ترجمة: ' + rawNames[0]);
console.log('أسماء الصيغ        : كلها بتترجم ✓');

/* ٦) كلمة تأكيد التنفيذ لها مقابل إنجليزي والأداة بتقبله */
if(js.indexOf("t('نفّذ','RUN')") < 0) fail('كلمة التأكيد مش بتترجم');
if(js.indexOf("v.toUpperCase() === 'RUN'") < 0) fail('الأداة مش بتقبل RUN في الوضع الإنجليزي');
console.log('كلمة التأكيد       : نفّذ / RUN، والاتنين مقبولين ✓');

/* ٧) الدليل: نفس عدد البنود في اللغتين، ومفيش عربي مندسّ في الإنجليزي */
const docs = JSON.parse(fs.readFileSync('docs.json','utf8'));
for(const sec of docs.sections){
  if(sec.b.ar.length !== sec.b.en.length)
    fail('قسم ' + sec.id + ': عدد البنود مختلف بين اللغتين');
  for(const x of sec.b.en)
    if(AR.test(x) && x.indexOf('in Arabic') < 0)
      fail('قسم ' + sec.id + ': عربي في البند الإنجليزي — ' + x.slice(0,45));
}
for(const h of docs.history)
  if(h.items.ar.length !== h.items.en.length)
    fail('نسخة ' + h.v + ': عدد البنود مختلف بين اللغتين');
console.log('الدليل             : ' + docs.sections.length + ' قسم و' + docs.history.length + ' نسخة، متطابقين ✓');

/* ٨) الأشرطة العلوية لازم تتحدّث مع تغيير اللغة، مش تفضل على لغة لحظة ظهورها */
if(js.indexOf("$('instMsg').dataset.ar") < 0) fail('نص شريط التثبيت مش متعلّم — هيفضل بلغته الأولى');
if(js.indexOf('function paintUpdBar') < 0 || js.indexOf('paintUpdBar();\n  sesPaint') < 0)
  fail('شريط التحديث مش بيترسم من جديد مع تغيير اللغة');
console.log('الأشرطة العلوية    : بتتحدّث مع اللغة ✓');

/* ٩) خانات الشريط اتجاهها يتبع اللغة — الاتجاه الثابت كان بيقصّ الإنجليزي ويرمي النقطة قبل الإيميل */
const cssT = tpl.slice(tpl.indexOf('<style>'), tpl.indexOf('</style>'));
if(cssT.indexOf('body.en .conn input.bidi{direction:ltr') < 0) fail('قاعدة اتجاه الخانات في الوضع الإنجليزي ناقصة');
for(const id of ['sesU','sesP','tickCust']){
  const tag = new RegExp('<input id="' + id + '"[^>]*>').exec(head);
  if(!tag) fail('خانة مش موجودة: ' + id);
  if(tag[0].indexOf('class="bidi"') < 0) fail('خانة من غير كلاس الاتجاه: ' + id);
  if(/direction:rtl/.test(tag[0])) fail('خانة لسه باتجاه ثابت: ' + id);
}
console.log('اتجاه خانات الشريط : بيتبع اللغة ✓');
