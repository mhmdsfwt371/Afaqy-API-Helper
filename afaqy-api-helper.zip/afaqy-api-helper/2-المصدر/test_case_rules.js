/* اختبارات محرّك القواعد — v6.37.
   الغرض: نثبت إن الأداة بتفكّر في أي رسالة، مش في حالة التقارير بس.
   كل قاعدة ليها رسالة شكلها زي اللي بتيجي فعلًا من عميل. */
const fs = require('fs');
const { JSDOM } = require('jsdom');
let F = 0;
const pass = m => console.log('  \u2713 ' + m);
const fail = m => { console.log('  \u2717 ' + m); F++; };
const ok = (m, c, x) => c ? pass(m) : fail(m + (x ? '  \u2014 ' + String(x).slice(0,110) : ''));

const build = () => fs.readFileSync(process.argv[2] || 'app_template.html', 'utf8')
  .replace('/*__KB__*/',   () => fs.readFileSync('kb_slim.json', 'utf8'))
  .replace('/*__DOCS__*/', () => fs.readFileSync('docs.json', 'utf8'))
  .replace('/*__KBIN__*/', () => fs.readFileSync('kb_in.json', 'utf8'));

function run(txt){
  const dom = new JSDOM(build(), { runScripts:'dangerously', pretendToBeVisual:true, url:'https://localhost/' });
  const w = dom.window; w.alert = () => {}; w.scrollTo = () => {};
  w.showView('inspect');
  w.document.getElementById('ivCase').click();
  w.document.getElementById('caseText').value = txt;
  w.document.getElementById('caseGo').click();
  const out = w.document.getElementById('caseOut');
  const a = w.eval('JSON.stringify((function(){const x=analyzeCase(document.getElementById("caseText").value);const m=caseMatch(x);return {rule:m?m.r.id:null, score:m?m.h.score:0, ev:m?m.h.ev:[]};})())');
  const pre = out.querySelector('#caseReplyTxt');
  return { w, out, m: JSON.parse(a), reply: pre ? pre.textContent : '' };
}

/* رسايل شكلها زي اللي بتوصل فعلًا */
const MSGS = {
report: `I am integrating https://api.afaqy.sa/reports/lists?token={{afaqy_token}}
The API returns a successful response but the data section contains report configuration
and field metadata rather than the actual report values. Under summary_beta the response
provides fields such as Date - code: date, Route Length - code: route_length,
Engine Work Duration - code: engine_work, Stop Duration - code: stop_duration.
What I need is actual data: Date: 10-08-2026, Route Length: 70 km.
1. Which endpoint returns the actual report data for summary_beta?`,

readEarly: `We create the report and then immediately call
POST https://api.afaqy.sa/user_reports/data-summary
but the response is always empty. The status is 200 and the message says success,
yet data returns [] with no records at all. Nothing is returned for any vehicle.`,

imei: `We are calling POST https://api.afaqy.sa/units/view with our device number
860123456789012 but the API responds not_found every time. The device is online in
the portal. What is wrong with the unit_id we are sending?`,

okError: `The endpoint returns HTTP 200 successful, however inside the body there is
an error message and status_code 400. Our integration treats it as success and stores
bad rows. Response: {"message":"invalid token","status_code":400,"data":[]}`,

emptyNotBroken: `POST /unit_groups/lists returns a successful 200 response but data is
an empty array. No error message at all. Nothing is returned for our account.`,

vague: `The API is not working today. Please advise urgently.`
};

/* ═════ ١) حالة التقارير ما اترجعتش للورا ═════ */
console.log('\n\u0661) حالة التقارير زي ما هي');
{
  const r = run(MSGS.report);
  ok('اتشخّصت كنمط كتالوج', r.m.rule === 'catalog-vs-data', r.m.rule);
  ok('بأعلى ثقة', r.m.score === 100, r.m.score);
  ok('الرد المكتوب بالإيد لسه هو اللي بيطلع', /chain of four calls/.test(r.reply));
  ok('وفيه data-new و resource_id', /data-new/.test(r.reply) && /resource_id/.test(r.reply));
  r.w.close();
}

/* ═════ ٢) كل قاعدة بتمسك رسالتها ═════ */
console.log('\n\u0662) كل نمط بيتمسك');
[['readEarly','read-before-ready'], ['imei','imei-vs-uid'],
 ['okError','ok-with-error'], ['emptyNotBroken','empty-not-broken']].forEach(([k, id]) => {
  const r = run(MSGS[k]);
  ok(k + ' \u2192 ' + id, r.m.rule === id, 'طلع ' + r.m.rule + ' score=' + r.m.score);
  ok('  ومعاه دليل مقروء', Array.isArray(r.m.ev) && r.m.ev.length >= 2, JSON.stringify(r.m.ev));
  r.w.close();
});

/* ═════ ٣) الرسايل دي بقى ليها رد بدل «ابعت أدلة» ═════ */
console.log('\n\u0663) رد بدل طلب أدلة');
['readEarly','imei','okError','emptyNotBroken'].forEach(k => {
  const r = run(MSGS[k]);
  ok(k + ': فيه رد جاهز', r.reply.length > 200, r.reply.length + ' حرف');
  ok('  الرد إنجليزي مفيهوش عربي', !/[\u0600-\u06FF]/.test(r.reply),
     (r.reply.match(/[\u0600-\u06FF][^\n]*/) || [''])[0]);
  ok('  ما رجعش يطلب أدلة', !r.out.querySelector('#caseAskCopy'));
  r.w.close();
});

/* ═════ ٤) الحكم بيسمّي النمط ═════ */
console.log('\n\u0664) الحكم بيسمّي الغلطة');
{
  const r = run(MSGS.imei);
  const v = r.out.querySelector('.caseVerdict').textContent.replace(/\s+/g,' ');
  ok('الحكم بيقول IMEI', /IMEI/i.test(v), v.slice(0,110));
  ok('ومش بيقول «في مشكلة» وخلاص', v.length > 40);
  r.w.close();
}

/* ═════ ٥) الرسالة الفاضية لسه بتطلب أدلة — مش بنخترع تشخيص ═════ */
console.log('\n\u0665) الغامضة لسه بتطلب أدلة');
{
  const r = run(MSGS.vague);
  ok('مفيش قاعدة اتحققت', !r.m.rule || r.m.score < 55, r.m.rule + ' ' + r.m.score);
  ok('ومفيش رد مخترع', !r.reply);
  ok('وبيطلب أدلة', !!r.out.querySelector('#caseAskCopy'));
  r.w.close();
}

/* ═════ ٦) السلسلة بتغذّي الرد والكولكشن من نفس المصدر ═════ */
console.log('\n\u0666) الرد والكولكشن من نفس السلسلة');
{
  const r = run(MSGS.readEarly);
  ok('الرد فيه percentage', /percentage/.test(r.reply), r.reply.slice(0,90));
  ok('وفيه data-summary بعدها',
     r.reply.indexOf('percentage') < r.reply.indexOf('data-summary'));
  ok('السلسلة موجودة في القاعدة',
     r.w.eval('(function(){const x=analyzeCase(document.getElementById("caseText").value);const m=caseMatch(x);const c=m.r.chain(x);return c && c.length>=2;})()'));
  r.w.close();
}

console.log('\n' + (F ? '\u2717 فشل: ' + F : '\u2713 كله عدّى'));
process.exit(F ? 1 : 0);
