/* هيدر النافذة لازم يفضل ثابت وفيه زرار إغلاق، والتوكن مخفي افتراضيًا مع إمكانية إظهاره */
const fs=require('fs');
const tpl=fs.readFileSync('app_template.html','utf8');
const fail=s=>{ console.error('فشل: '+s); process.exit(1); };

if(tpl.indexOf('position:sticky; top:0; background:var(--panel)')<0) fail('هيدر النافذة مش ثابت');
console.log('هيدر النافذة ثابت      ✓');
if(tpl.indexOf('class="mx" id="mclose"')<0) fail('زرار × مش موجود');
if(tpl.indexOf("$('mclose').onclick")<0) fail('زرار × مش مربوط');
/* زرار إغلاق واحد بس — اتنين بنفس المعنى تشويش */
if((tpl.match(/id="mclose"|id="mx"/g)||[]).length !== 1) fail('في أكتر من زرار إغلاق');
console.log('زرار × واحد ومربوط     ✓');
if(tpl.indexOf("ev.key==='Escape'")<0) fail('Esc مش شغال');
console.log('Esc بيقفل              ✓');
if(tpl.indexOf("id=\"tokShow\"")<0) fail('زرار إظهار التوكن مش موجود');
if(tpl.indexOf("btn.dataset.on")<0) fail('التبديل مش مربوط');
console.log('إظهار/إخفاء التوكن     ✓');

/* الرد اللي بيروح للعميل لازم يفضل التوكن متشال فيه مهما حصل */
const R={};
function el(id){return{id,hidden:false,innerHTML:'',value:'',textContent:'',dataset:{},style:{},files:[],disabled:false,
 classList:{toggle(){},add(){},remove(){}},querySelectorAll(){return[]},addEventListener(){},focus(){},select(){},click(){},
 setAttribute(){},getAttribute(){return null},dispatchEvent(){},appendChild(){},remove(){},scrollIntoView(){},onclick:null}}
global.document={documentElement:el(),body:el(),addEventListener(){},querySelectorAll(){return[]},
 querySelector(){return null},createElement(){return el()},getElementById(i){return R[i]||(R[i]=el(i))}};
global.history={pushState(){},replaceState(){}};global.location={hash:'',pathname:'/',replace(){}};
global.setInterval=()=>0;global.navigator={clipboard:{writeText(){return Promise.resolve()}}};
global.window={scrollTo(){},addEventListener(){}};
const OK={message:'success',status_code:200,data:{token:'eyJ0eXAi.REAL_SECRET.sig'}};
global.fetch=()=>Promise.resolve({ok:true,status:200,text:()=>Promise.resolve(JSON.stringify(OK))});
global.Blob=function(){};global.URL={createObjectURL(){return''}};global.FileReader=function(){};
let js=tpl.split('<script>')[1].split('</script>')[0]
 .replace('/*__KB__*/',fs.readFileSync('kb_slim.json','utf8'))
 .replace('/*__DOCS__*/',fs.readFileSync('docs.json','utf8'));
const m={};new Function('module',js+"\nmodule.exports={EPS,SESSION,tryItRun,packetFor};")(m);
const A=m.exports;
(async()=>{
  const login=A.EPS.find(e=>e.p==='/auth/login');
  A.SESSION.user='safwat'; A.SESSION.pass='pw'; A.SESSION.token='eyJ0eXAi.REAL_SECRET.sig';
  await A.tryItRun(login, document.getElementById('tryout'));
  const pk=A.packetFor(login);
  if(pk.text.indexOf('REAL_SECRET')>=0) fail('التوكن خرج في الرد للعميل');
  console.log('الرد للعميل: التوكن متشال ✓');
})();
