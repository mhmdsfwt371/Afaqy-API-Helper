/* v6.49 — بعد «حدّد الجهاز» الـ UID بيظهر جنب اللوحة وبيتنسخ بضغطة */
const fs=require('fs'); const {JSDOM}=require('jsdom');
let F=0; const ok=(m,c,x)=>{ console.log((c?'  \u2713 ':'  \u2717 ')+m+(c||!x?'':'  \u2014 '+String(x).slice(0,140))); if(!c) F++; };
const html=fs.readFileSync(process.argv[2]||'app_template.html','utf8')
  .replace('/*__KB__*/',()=>fs.readFileSync('kb_slim.json','utf8'))
  .replace('/*__DOCS__*/',()=>fs.readFileSync('docs.json','utf8'))
  .replace('/*__KBIN__*/',()=>fs.readFileSync('kb_in.json','utf8'));
(async()=>{
  const w=new JSDOM(html,{runScripts:'dangerously',pretendToBeVisual:true,url:'https://localhost/'}).window;
  w.alert=()=>{}; w.scrollTo=()=>{};
  const chip=()=>w.document.getElementById('unitUid');
  ok('الشريحة موجودة ومخفية قبل الاتصال', chip() && chip().hidden);
  /* اتصال + لستة عربيات وهمية */
  w.eval(`SESSION.token='T'; apiFetch = async (p)=>({ok:true, status:200, json:{status_code:200, data:[
     {id:'6a69c3976435eef5460b0278', name:'L S A-6220', imei:'861230044934025', device_serial:'S1'},
     {id:'5fb0e2e703ed529bb30f9af3', name:'Truck 2', imei:'357454075086551'}]}});`);
  await w.resolveUnit('861230044934025');
  ok('بعد تحديد الجهاز: اللوحة في الشريحة الأولى', /L S A-6220/.test(w.document.getElementById('unitState').textContent));
  ok('والـ UID جنبها كامل', !chip().hidden && chip().textContent==='UID 6a69c3976435eef5460b0278', chip().textContent);
  let copied=null; w.eval('copy = (x,m)=>{ window.__c=[x,m]; }');
  chip().click(); copied=w.__c;
  ok('الضغطة بتنسخ الـ UID نفسه (من غير كلمة UID)', copied && copied[0]==='6a69c3976435eef5460b0278' && /اتنسخ|copied/.test(copied[1]), JSON.stringify(copied));
  await w.resolveUnit('');
  ok('مسح الجهاز بيخفي الشريحة', chip().hidden);
  await w.resolveUnit('000000000000000');
  ok('رقم مش في الحساب: مفيش UID', chip().hidden);
  console.log(F?`\nفشل ${F}`:'\nشريحة الـ UID: تمام'); process.exit(F?1:0);
})();
