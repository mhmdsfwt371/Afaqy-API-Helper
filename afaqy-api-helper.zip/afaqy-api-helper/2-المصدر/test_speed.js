global.setInterval=()=>0;global.clearInterval=()=>{};
const fs=require('fs');
function el(id){return{id,hidden:false,innerHTML:'',value:'',textContent:'',className:'',dataset:{},style:{},files:[],disabled:false,
 classList:{toggle(){},add(){},remove(){}},querySelectorAll(){return[]},addEventListener(){},focus(){},select(){},click(){},
 setAttribute(){},getAttribute(){return null},dispatchEvent(){},appendChild(){},remove(){},scrollIntoView(){}}}
const R={};global.document={documentElement:el(),body:el(),addEventListener(){},querySelectorAll(){return[]},
 querySelector(){return null},createElement(){return el()},getElementById(i){return R[i]||(R[i]=el(i))}};
global.history={pushState(){},replaceState(){}};
global.location={hash:''};
global.navigator={clipboard:{writeText(){return Promise.resolve()}}};global.window={scrollTo(){},addEventListener(){}};
global.fetch=()=>Promise.reject(0);global.Blob=function(){};global.URL={createObjectURL(){return''}};global.FileReader=function(){};
let js=fs.readFileSync('app_template.html','utf8').split('<script>')[1].split('</script>')[0]
  .replace('/*__KB__*/',fs.readFileSync('kb_slim.json','utf8')).replace('/*__DOCS__*/',fs.readFileSync('docs.json','utf8'));
const m={};new Function('module',js+`
module.exports={RECIPES,matchByName,collectSpeeds,doSpeedNow,doSpeedStats,doPick,dual,setL:(l)=>{LANG=l},
  setRC:(v)=>{RC=v}, getRC:()=>RC};`)(m);
const A=m.exports; A.setL('ar');
const strip = h => String(h).replace(/<[^>]+>/g,'').replace(/\s+/g,' ').trim();

const r = A.RECIPES.find(x=>x.id==='speed');
console.log('السيناريو: ' + A.dual(r.title));
console.log('المدخلات : ' + r.inputs.map(f=>A.dual(f.l)).join('  |  '));
console.log('الخطوات  :');
r.steps.forEach((s,n)=>console.log('   '+(n+1)+') '+A.dual(s.t)));

console.log('\n--- بودي الخطوة ٤ اللي هيتبعت فعلاً ---');
console.log(JSON.stringify(r.steps[3].body({unitId:'5fb0e2e703ed529bb30f9af3', from:'2026-08-02', to:'2026-08-03'}), null, 1));

// ردود متخيّلة بأشكال مختلفة عشان نتأكد إن التول بتلاقي السرعة مهما كان الشكل
const listResp={status:true,data:{items:[
 {_id:'5fb0e2e703ed529bb30f9af3', name:'NB YD - TH - 1129', imei:'357454075086551',
  last_update:{ pos:{ lat:23.9, lng:38.3, speed:64 }, time:'2026-08-03 09:12:00' }}]}};

const speeds=[0,0,12,45,64,88,102,97,55,0,0,31,76,110,64,0];
const sigResp={status:true,data:{messages:speeds.map((v,i)=>({t:1785700000+i*60, pos:{lat:23.9,lng:38.3,speed:v}}))}};

A.setRC({ r, vars:{unitKey:'357454075086551', from:'2026-08-02', to:'2026-08-03'},
          results:[{ok:true,json:listResp},null,null,null,null], idx:1 });

A.doPick(1);
console.log('\n٢) ' + strip(A.getRC().results[1].msg));

A.doSpeedNow(2);
const s3=A.getRC().results[2];
console.log('٣) ' + strip(s3.msg));
console.log('   ' + strip(s3.html));

A.getRC().results[3] = {ok:true, json:sigResp};
A.doSpeedStats(4);
const s5=A.getRC().results[4];
console.log('\n٥) ' + strip(s5.msg));
console.log('   ' + strip(s5.html));

// حالة الجهاز الساكت
console.log('\n--- لو الجهاز ما رسلش خالص ---');
A.getRC().results[3] = {ok:true, json:{status:true,data:{messages:[]}}};
A.doSpeedStats(4);
console.log('   ' + strip(A.getRC().results[4].msg).slice(0,150));

// شكل رد مختلف تمامًا
console.log('\n--- شكل رد مختلف (متداخل بعمق) ---');
console.log('   لقى: ' + A.collectSpeeds({a:{b:[{c:{speed:'88'}},{c:{speed:12}}]}}).join(', '));
