#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v6.43 — الأداة في متصفح حقيقي، على الملف اللي هيتنشر نفسه.
    python3 test_browser.py /mnt/user-data/outputs/repo/index.html

ليه: اختبارات jsdom كلها بتنده showView بنفسها، فعيب «الفتحة الأولى بتفتح على
الريكوستات وكروت البداية فاضية» عاش على الموقع من غير ما حد يمسكه.
الاختبار ده بيعمل اللي الموظف بيعمله بالظبط: يفتح اللينك ويدوس.

الخروج: 0 نجاح · 1 فشل (البناء يقف) · 2 المتصفح مش متاح (البناء يكمّل بتحذير).
"""
import sys, os, threading, functools, socket
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler

TARGET = sys.argv[1] if len(sys.argv) > 1 else '/mnt/user-data/outputs/repo/index.html'
if not os.path.exists(TARGET):
    print('!! الملف مش موجود: ' + TARGET); sys.exit(1)
ROOT = os.path.dirname(os.path.abspath(TARGET))

try:
    from playwright.sync_api import sync_playwright
except Exception as ex:
    print('اختبار المتصفح: playwright مش متاح (%s)' % type(ex).__name__); sys.exit(2)

F = 0
def ok(msg, cond, extra=''):
    global F
    if cond: print('  \u2713 ' + msg)
    else:
        F += 1; print('  \u2717 ' + msg + ('  \u2014 ' + str(extra)[:160] if extra else ''))

class Quiet(SimpleHTTPRequestHandler):
    def log_message(self, *a): pass
    def end_headers(self):
        # محرك القراءة بيتجاب من أوريجن تاني (زي jsDelivr) — لازم CORS
        self.send_header('Access-Control-Allow-Origin', '*'); super().end_headers()

def serve(directory=None):
    s = socket.socket(); s.bind(('127.0.0.1', 0)); port = s.getsockname()[1]; s.close()
    srv = ThreadingHTTPServer(('127.0.0.1', port), functools.partial(Quiet, directory=directory or ROOT))
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv, 'http://127.0.0.1:%d/' % port

HERE = os.path.dirname(os.path.abspath(__file__))
def ocr_root():
    """v6.45: محرك القراءة من node_modules بنفس شكل مسارات jsDelivr (<pkg>@<ver>/…).
       لو مش منزّل (setup.sh بينزّله)، خطوة الصورة بتتخطى بتحذير."""
    nm = os.path.join(HERE, 'node_modules')
    if not os.path.isdir(os.path.join(nm, 'tesseract.js')): return None
    root = os.path.join(HERE, '.ocr-serve'); os.makedirs(os.path.join(root, '@tesseract.js-data'), exist_ok=True)
    for link, target in [('tesseract.js@5.1.1', 'tesseract.js'), ('tesseract.js-core@5.1.1', 'tesseract.js-core'),
                         ('@tesseract.js-data/eng@1.0.0', os.path.join('@tesseract.js-data', 'eng'))]:
        lp = os.path.join(root, link)
        if not os.path.lexists(lp): os.symlink(os.path.join(nm, target), lp)
    return root

# v6.46: لقطة نافذة بوستمان كاملة — القائمة واللينك وبودي الريكوست والرد تحت بخط صغير
FULL = '''<html><body style="margin:0;background:#f7f7f7;font-family:Arial,sans-serif;font-size:12px;color:#333"><div style="display:flex;height:1080px">
<div style="width:290px;background:#fff;border-right:1px solid #ddd;padding:12px"><b>Collections</b><div style="color:#666;line-height:1.9;margin-top:8px">AVL Integration<br>&nbsp;&nbsp;Auth<br>&nbsp;&nbsp;&nbsp;&nbsp;POST Login<br>&nbsp;&nbsp;Units<br>&nbsp;&nbsp;&nbsp;&nbsp;POST Units Locations<br>&nbsp;&nbsp;Drivers</div></div>
<div style="flex:1;display:flex;flex-direction:column"><div style="padding:10px 16px;border-bottom:1px solid #ddd;background:#fff"><b style="color:#1a73e8">POST</b> <span style="margin-left:10px;font-family:monospace">https://api.afaqy.sa/units/locations?token={{token}}</span></div>
<div style="padding:8px 16px;background:#fff;color:#555">Params &nbsp; Authorization &nbsp; Headers (8) &nbsp; <b style="color:#333">Body</b> &nbsp; Tests &nbsp; Settings</div>
<pre style="margin:0;padding:8px 24px;background:#fff;font-family:monospace;font-size:12px;line-height:1.45;height:140px">1  {
2      "data": {
3          "unit_id": "6a69c3976435eef5460b0278",
4          "address": true
5      }
6  }</pre>
<div style="padding:8px 16px;background:#fafafa;border-top:1px solid #ddd;border-bottom:1px solid #ddd;color:#555"><b style="color:#333">Body</b> &nbsp; Cookies &nbsp; Headers (12) &nbsp; Test Results <span style="float:right"><span style="color:#2e7d32">200 OK</span> &nbsp; 412 ms</span></div>
<pre style="margin:0;padding:8px 24px;background:#fff;font-family:monospace;font-size:12px;line-height:1.45;flex:1">1  {
2      "message": "validation_error",
3      "status_code": 405,
4      "errors": {
5          "unit_id": [
6              "not_found"
7          ]
8      },
9      "extra": []
10 }</pre></div></div></body></html>'''

# v6.47: إيميل عميل فيه لقطة بوستمان — الرد بوضع Preview (جدول) والـ unit_id فيه IMEI.
# نسخة صناعية بنفس شكل الإيميل الحقيقي — من غير أسماء ولا عناوين حقيقية (الريبو عام).
EMAIL = '''<html><body style="margin:0;background:#fff;font-family:Arial,sans-serif;color:#1f3864">
<div style="padding:14px 18px;font-size:19px;color:#222">RE: API Integration — technical follow-up</div>
<div style="padding:0 18px 0 80px;font-size:13px;color:#333;line-height:1.5">Integration Team &lt;it.team@example.com&gt;<br>To &nbsp; Support Desk<br>Cc &nbsp; Account Manager; Project Lead</div>
<div style="padding:18px 12px 6px;font-size:15px;line-height:1.35">Dear team,<br><br>We are testing the APIs and we are able to successfully get the token and Fetch vehicle list. However, we have encountered the following error when getting the last location for the unit.<br><br>Please check if any role is missing for the ID or if there is any issue with the API Call.<br><br>Postman Response:</div>
<div style="width:770px;margin-left:10px;border:1px solid #ddd;font-size:12px;color:#333">
<div style="padding:8px;border-bottom:1px solid #ddd"><b style="color:#b8860b">POST</b> &nbsp;&nbsp;&nbsp; https://api.afaqy.sa/units/locations?token= {{json_web_token}} <span style="float:right;background:#4a7ee6;color:#fff;padding:3px 14px">Send</span></div>
<div style="padding:6px 8px;color:#555">Docs &nbsp; Params &nbsp; Authorization &nbsp; Headers 9 &nbsp; <b>Body</b> &nbsp; Scripts &nbsp; Settings</div>
<div style="padding:4px 8px;color:#555">none &nbsp; form-data &nbsp; x-www-form-urlencoded &nbsp; raw &nbsp; binary &nbsp; JSON</div>
<pre style="margin:0;padding:6px 8px;font-family:Consolas,monospace;font-size:12px;line-height:1.4;color:#a31515;height:190px"><span style="color:#888"> 1 </span>  <span style="color:#000">{</span>
<span style="color:#888"> 2 </span>      "data": {
<span style="color:#888"> 3 </span>          "unit_id": "861230044934025",
<span style="color:#888"> 4 </span>          "address": <span style="color:#00f">true</span>,
<span style="color:#888"> 5 </span>          "date": {
<span style="color:#888"> 6 </span>              "interval": "interval",
<span style="color:#888"> 7 </span>              "from": "2026-10-10 00:00:00",
<span style="color:#888"> 8 </span>              "to": "2026-10-11 23:59:59"
<span style="color:#888"> 9 </span>          }
<span style="color:#888">10 </span>      }
<span style="color:#888">11 </span>  <span style="color:#000">}</span></pre>
<div style="padding:7px 8px;border-top:1px solid #ddd;color:#555">Body &nbsp; Cookies &nbsp; Headers 8 &nbsp; Test Results <span style="margin-left:180px;color:#1e7e34">200 OK</span> &nbsp; 1.71 s &nbsp; 399 B</div>
<div style="padding:4px 8px;color:#555">{} JSON &nbsp; Preview &nbsp; Visualize</div>
<div style="padding:6px 8px;line-height:2;color:#333"><b>message</b> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; not_allowed<br><b>status_code</b> &nbsp; 401<br><b>data</b> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; []</div>
</div></body></html>'''

# v6.53: إيميل فيه لقطة كارت العربية في المنصة — العميل بيسأل إيه الـ API (أسماء عامة)
PANEL = '''<html><body style="margin:0;background:#fff;font-family:Arial,sans-serif;color:#1f3864">
<div style="padding:16px 14px;font-size:15px">Dear team,<br><br>We need your help in identifying the correct API for the below info. Request you to please share API details along with sample request body.</div>
<div style="width:330px;margin-left:16px;border:1px solid #ccc;font-size:12px;color:#333;padding:8px">
<b>1234-A B C</b><div style="color:#888">34 Seconds ago</div><div>18.307653427124,42.698890686035</div>
<div style="margin-top:8px;font-weight:bold">Vehicle Metrics</div>
<table style="width:100%;font-size:12px"><tr><td>Speed<br><b>0KM/H</b></td><td>Engine Hours<br><b>0H</b></td><td>Odometer<br><b>22553KM</b></td></tr></table>
<div style="margin-top:6px;font-weight:bold">Position Data</div>
<table style="width:100%;font-size:12px"><tr><td>Angle<br><b>168</b></td><td>Altitude<br><b>2013M</b></td><td>Satellites<br><b>12</b></td></tr></table>
<div style="margin-top:6px;font-weight:bold">Main Info</div>
<div style="border:2px solid #d00;padding:4px"><div>POS: <span style="float:right">25-10-2026 12:08:20</span></div><div>SRV: <span style="float:right">25-10-2026 12:08:38</span></div></div>
<div style="margin-top:6px;font-weight:bold">Sensors 3</div>
<div>ACC <span style="float:right">ON</span></div><div>Weight <span style="float:right">14500 KG</span></div><div>Device Battery <span style="float:right">4.02 V</span></div>
</div></body></html>'''

SHOT = '''<html><body style="margin:0;background:#1e1e1e;font-family:monospace;font-size:13px;color:#d4d4d4">
<div style="padding:18px 20px"><div style="color:#9cdcfe;margin-bottom:10px;font-size:12px">Body &nbsp; Cookies &nbsp; Headers (12) &nbsp; Test Results &nbsp;&nbsp; 200 OK &nbsp; 312 ms</div>
<pre style="margin:0;line-height:1.55"><span style="color:#858585">1  </span>{
<span style="color:#858585">2  </span>    "message": "unauthorized",
<span style="color:#858585">3  </span>    "status_code": 401,
<span style="color:#858585">4  </span>    "extra": []
<span style="color:#858585">5  </span>}</pre></div></body></html>'''

VISIBLE = """() => [...document.querySelectorAll('section.view')].filter(s => !s.hidden).map(s => s.id)"""
SELECTED = """() => [...document.querySelectorAll('.tab[aria-selected="true"]')].map(t => t.dataset.view)"""

def main():
    srv, base = serve()
    oroot = ocr_root(); osrv = obase = None
    if oroot: osrv, obase = serve(oroot)
    with sync_playwright() as p:
        try:
            b = p.chromium.launch()
        except Exception as ex:
            print('اختبار المتصفح: كروم مش متاح (%s)' % str(ex).splitlines()[0][:80]); sys.exit(2)
        # خدمة الخلفية مقفولة عشان الاختبار ما يسيبش كاش ولا يتأثر بيه
        ctx = b.new_context(viewport={'width': 1366, 'height': 900}, locale='ar', service_workers='block')
        errors = []
        pg = ctx.new_page()
        if obase: pg.add_init_script("window.OCR_CDN_OVERRIDE = '%s';" % obase)
        pg.on('pageerror', lambda e: errors.append('pageerror: ' + str(e)[:160]))
        # v7.0: خطوة Claude بتنادي الـ API بمفتاح وهمي عمدًا — الـ 401 بتاعها متوقع مش خطأ
        pg.on('console', lambda m: errors.append('console: ' + m.text[:160]) if (m.type == 'error' and 'status of 401' not in m.text) else None)

        # ١) الفتحة الأولى من غير hash — اللي كان مكسور
        pg.goto(base + 'index.html'); pg.wait_for_timeout(1500)
        ok('الفتحة الأولى: التبويب المختار «ابدأ من هنا»', pg.evaluate(SELECTED) == ['triage'], pg.evaluate(SELECTED))
        ok('الفتحة الأولى: قسم واحد بس ظاهر وهو البداية', pg.evaluate(VISIBLE) == ['v-triage'], pg.evaluate(VISIBLE))
        n = pg.evaluate("document.querySelectorAll('#trCards > *').length")
        ok('الفتحة الأولى: كروت البداية مرسومة', n >= 5, n)
        ok('الفتحة الأولى: رقم النسخة ظاهر', pg.evaluate("document.getElementById('verTag').textContent") == 'v' + pg.evaluate('DOCS.version'))
        ok('شريط التحديث مش ظاهر (نفس النسخة)', pg.evaluate("document.getElementById('updBar').hidden"))

        # ٢) كل تبويب بيفتح قسمه هو بس
        for v in ['search', 'recipes', 'dash', 'inspect', 'faq', 'triage']:
            pg.click('.tab[data-view="%s"]' % v); pg.wait_for_timeout(250)
            vis = pg.evaluate(VISIBLE)
            want = ['v-faq'] if v == 'faq' else ['v-' + v]
            ok('تبويب %s بيفتح قسمه بس' % v, vis == want or (v == 'faq' and vis == ['v-docs']), vis)

        # ٣) كل كارت فرز بيوجّه لتبويب موجود
        badgo = pg.evaluate("TRIAGE.filter(x => x.go && VIEWS.indexOf(x.go.tab) < 0).map(x => x.id)")
        ok('كروت الفرز بتوجّه لتبويبات موجودة', badgo == [], badgo)

        # ٤) البحث بكلام العميل
        pg.click('.tab[data-view="search"]'); pg.fill('#q', 'لستة العربيات'); pg.wait_for_timeout(700)
        rn = pg.evaluate("document.querySelectorAll('#results > *').length")
        ok('البحث بيرجّع نتايج', rn > 0, rn)
        det = pg.evaluate("document.getElementById('detail').innerText")
        ok('التفاصيل فيها ريكوست العربيات', '/units' in det, det[:80])

        # ٥) اللغة والوضع الليلي
        pg.click('#langBtn'); pg.wait_for_timeout(300)
        ok('التحويل للإنجليزي', pg.evaluate("document.body.classList.contains('en')")
           and 'Start here' in pg.evaluate("document.querySelector('.tab[data-view=\"triage\"]').textContent"))
        pg.click('#langBtn'); pg.wait_for_timeout(200)
        ok('الرجوع للعربي', not pg.evaluate("document.body.classList.contains('en')"))
        pg.click('#themeBtn'); pg.wait_for_timeout(200)
        ok('الوضع الليلي بيشتغل', pg.evaluate("document.documentElement.getAttribute('data-theme')") == 'dark')
        pg.click('#themeBtn'); pg.wait_for_timeout(200)

        # ٦) المعرفة المضافة بتتحفظ وترجع بعد إعادة الفتح (v6.43)
        pg.click('.tab[data-view="faq"]'); pg.wait_for_timeout(300)
        pg.fill('#adT', 'اختبار حفظ'); pg.fill('#adB', 'تفاصيل الاختبار'); pg.click('#adGo'); pg.wait_for_timeout(300)
        stored = pg.evaluate("JSON.parse(localStorage.getItem('afaqy.added.v1') || '[]').length")
        ok('المعلومة اتحفظت على الجهاز', stored == 1, stored)
        pg.goto(base + 'index.html'); pg.wait_for_timeout(1200)
        ok('المعلومة رجعت بعد إعادة الفتح', pg.evaluate("ADDED.length") == 1 and pg.evaluate("LEARNED.some(k => k.t && k.t.ar === 'اختبار حفظ')"))
        pg.click('.tab[data-view="faq"]'); pg.wait_for_timeout(300)
        st = pg.evaluate("(document.getElementById('adStat') || {}).textContent || ''")
        ok('الفورم بيقول إن فيه معلومة لسه ما اتصدّرتش', 'لسه ما اتصدّرتش' in st, st[:80])
        pg.evaluate("localStorage.removeItem('afaqy.added.v1'); localStorage.removeItem('afaqy.added.exportedAt')")

        # ٧) لينك مباشر على تبويب
        pg.goto(base + 'index.html#recipes'); pg.wait_for_timeout(800)
        ok('لينك #recipes بيفتح السيناريوهات بس', pg.evaluate(VISIBLE) == ['v-recipes'], pg.evaluate(VISIBLE))

        # ٨) الموبايل: التبويبات والبداية ظاهرين
        m = b.new_context(viewport={'width': 390, 'height': 844}, is_mobile=True, locale='ar', service_workers='block').new_page()
        m.on('pageerror', lambda e: errors.append('mobile pageerror: ' + str(e)[:160]))
        m.goto(base + 'index.html'); m.wait_for_timeout(1200)
        ok('الموبايل: البداية ظاهرة', m.evaluate(VISIBLE) == ['v-triage'] and m.evaluate("document.querySelectorAll('#trCards > *').length") >= 5)
        ok('الموبايل: التبويبات ظاهرة', m.evaluate("document.querySelector('.tabs').getBoundingClientRect().height") > 20)

        # ٩) إيميل طلب إنتجريشن → رد نقطة بنقطة (v6.44)
        pg.goto(base + 'index.html'); pg.wait_for_timeout(1000)
        pg.click('.tab[data-view="inspect"]'); pg.wait_for_timeout(300)
        pg.click('#ivCase'); pg.wait_for_timeout(300)
        pg.fill('#caseText', 'نرغب في الاستفادة من خدمة API ونأمل تزويدنا بالبيانات التالية:\n'
                             '1. رقم اللوحة ومعرّف المركبة (Vehicle ID).\n2. إجمالي ساعات تشغيل المحرك (Engine Hours).\n'
                             '3. بيانات مستوى الوقود (Fuel Level).\n4. حدود الاستخدام (Rate Limits).\n• API Documentation.')
        pg.click('#caseGo'); pg.wait_for_timeout(800)
        vt = pg.evaluate("document.getElementById('caseOut').innerText")
        ok('إيميل طلب البيانات بيتعرف عليه', 'طلب إنتجريشن: 5 بند' in vt, vt[:80])
        rp = pg.evaluate("(document.getElementById('caseReplyTxt') || {}).textContent || ''")
        ok('الرد نقطة بنقطة بنص العميل وحالة كل بند', '1) رقم اللوحة' in rp and 'قيد التأكيد' in rp and '3600' in rp, rp[:80])
        pg.click('#reqEn'); pg.wait_for_timeout(300)
        ok('زرار الإنجليزي بيقلب الرد', 'Dear team' in pg.evaluate("document.getElementById('caseReplyTxt').textContent"))

        # ١٠) صورة رد بوستمان (وضع ليلي بأرقام سطور) → تتقرا وتتشخّص (v6.45)
        if obase:
            shot = ctx.new_page(); shot.set_viewport_size({'width': 760, 'height': 220}); shot.set_content(SHOT); shot.wait_for_timeout(200)
            png = os.path.join(HERE, '.ocr-sample.png'); shot.screenshot(path=png, full_page=True); shot.close()
            pg.goto(base + 'index.html'); pg.wait_for_timeout(1000)
            pg.click('.tab[data-view="inspect"]'); pg.wait_for_timeout(300)
            pg.set_input_files('#inFile', png)
            try:
                pg.wait_for_function("/اتقرت|ما قدرناش|ما طلعش/.test(document.getElementById('inImgBox').innerText)", timeout=180000)
            except Exception:
                pass
            box = pg.evaluate("document.getElementById('inImgBox').innerText")
            ok('صورة الرد اتقرت على الجهاز', 'اتقرت من الصورة' in box, box[:120])
            txt = pg.evaluate("document.getElementById('inText').value")
            ok('النص اللي طلع JSON سليم بالرسالة والكود', '"message": "unauthorized"' in txt and '"status_code": 401' in txt, txt[:120])
            outv = pg.evaluate("document.getElementById('inOut').innerText")
            ok('الفحص شخّص الخطأ من الصورة', 'unauthorized' in outv and ('مش مصرّح' in outv or 'التوكن' in outv), outv[:120])
            pg.evaluate("document.getElementById('inClear').click()")

            # ١١) لقطة النافذة الكاملة: الرد بيتلقط من وسطها ويتشخّص بالحقل الغلط (v6.46)
            shot = ctx.new_page(); shot.set_viewport_size({'width': 1920, 'height': 1080}); shot.set_content(FULL); shot.wait_for_timeout(200)
            png2 = os.path.join(HERE, '.ocr-full.png'); shot.screenshot(path=png2); shot.close()
            pg.set_input_files('#inFile', png2)
            try:
                pg.wait_for_function("/اتقرت|ما قدرناش|ما طلعش/.test(document.getElementById('inImgBox').innerText)", timeout=180000)
            except Exception:
                pass
            box2 = pg.evaluate("document.getElementById('inImgBox').innerText")
            ok('لقطة النافذة الكاملة: الرد اتلقط من وسطها', 'اتلقط من وسط لقطة الشاشة' in box2, box2[:120])
            txt2 = pg.evaluate("document.getElementById('inText').value")
            ok('الرد (مش بودي الريكوست) هو اللي اتفحص', '"validation_error"' in txt2 and '"status_code": 405' in txt2 and txt2.strip().startswith('{') and '"message"' in txt2.split('}')[0] + '}', txt2[:140])
            out2 = pg.evaluate("document.getElementById('inOut').innerText")
            ok('التشخيص قال الحقل الغلط: unit_id مش موجود', 'unit_id' in out2 and ('مش موجود' in out2 or 'not found' in out2), out2[:160])
            pg.evaluate("document.getElementById('inClear').click()")

            # ١٢) إيميل فيه لقطة بوستمان → تذكرة → تشخيص ورد (v6.47)
            shot = ctx.new_page(); shot.set_viewport_size({'width': 1100, 'height': 880}); shot.set_content(EMAIL); shot.wait_for_timeout(200)
            png3 = os.path.join(HERE, '.ocr-email.png'); shot.screenshot(path=png3); shot.close()
            pg.click('#ivCase'); pg.wait_for_timeout(300)
            pg.set_input_files('#caseImg', png3)
            try:
                pg.wait_for_function("/اتقرت|ما قدرناش|ما طلعش/.test(document.getElementById('caseImgBox').innerText)", timeout=180000)
            except Exception:
                pass
            pg.wait_for_timeout(600)
            tk = pg.evaluate("document.getElementById('caseText').value")
            ok('الإيميل بقى تذكرة: كلام العميل + Request + Response', tk.startswith('Dear team,') and 'Request:\nPOST https://api.afaqy.sa/units/locations' in tk and 'Response:' in tk, tk[:160])
            ok('بودي الريكوست اتقرا بالـ IMEI والـ data حواليه', '"data": {' in tk and '"unit_id": "861230044934025"' in tk, tk[tk.find('Request:'):tk.find('Request:')+200])
            ok('الرد اللي كان جدول Preview بقى JSON', '"message": "not_allowed"' in tk and '"status_code": 401' in tk, tk[tk.find('Response:'):])
            co = pg.evaluate("document.getElementById('caseOut').innerText")
            ok('التشخيص: IMEI مكان رقم العربية', 'IMEI' in co and 'رقم العربية' in co, co[:140])
            ok('الرد الجاهز بيقول قيمة الـ IMEI ويجاوب سؤال الرول', 'unit_id carries 861230044934025' in co and 'no role or permission change is needed' in co and 'identifies vehicles by their unit ID (UID)' in co, co[:200])
            ok('زرار كولكشن الحل ظاهر', bool(pg.query_selector('#casePm')))
            pg.click('#ivResp'); pg.wait_for_timeout(200)

            # ١٣) لقطة كارت المنصة في إيميل → «إيه الـ API؟» → الريكوست الموثّق بالـ IMEI (v6.53)
            shot = ctx.new_page(); shot.set_viewport_size({'width': 760, 'height': 620}); shot.set_content(PANEL); shot.wait_for_timeout(200)
            png4 = os.path.join(HERE, '.ocr-panel.png'); shot.screenshot(path=png4); shot.close()
            pg.evaluate("SESSION.unit={uid:'5e6790e103ed52cf443362c9', name:'1234-A B C', imei:'861230044934025'}")
            pg.click('#ivCase'); pg.wait_for_timeout(300)
            pg.evaluate("document.getElementById('caseText').value=''")
            pg.set_input_files('#caseImg', png4)
            try:
                pg.wait_for_function("/اتقرت|ما قدرناش|ما طلعش/.test(document.getElementById('caseImgBox').innerText)", timeout=180000)
            except Exception:
                pass
            pg.wait_for_timeout(600)
            co = pg.evaluate("document.getElementById('caseOut').innerText")
            ok('لقطة كارت المنصة اتعرفت: العميل بيسأل إيه الـ API', 'حقول من المنصة' in co, co[:140])
            rp = pg.evaluate("(document.getElementById('caseReplyTxt')||{}).textContent||''")
            ok('الرد بالريكوست الموثّق والـ IMEI و POS/SRV', '"value":["861230044934025"]' in rp and 'last_update.dtt' in rp and 'last_update.dts' in rp, rp[:200])
            pg.evaluate("SESSION.unit=null")

            # ١٤) Claude جوه الأداة: نداء حقيقي من المتصفح لـ api.anthropic.com بمفتاح وهمي → رفض واضح (v7.0)
            pg.evaluate("document.getElementById('caseText').value='Hello, which API returns the vehicle list?'")
            pg.evaluate("AI.key='sk-ant-api03-dummy-key-for-the-gate-0123456789'; AI.remember=false")
            pg.evaluate("aiRun(document.getElementById('caseText').value)")
            try:
                pg.wait_for_function("/المفتاح مرفوض|مفيش نت|ما قدرناش ننده Claude/.test(document.getElementById('caseOut').innerText)", timeout=30000)
            except Exception:
                pass
            co = pg.evaluate("document.getElementById('caseOut').innerText")
            ok('نداء Claude من المتصفح وصل للـ API واتفهم رده (مفتاح وهمي → «المفتاح مرفوض»)، أو قال مفيش نت بوضوح', ('المفتاح مرفوض' in co) or ('مفيش نت' in co), co[:160])
            ok('الإعدادات اتفتحت عشان الموظف يصلّح المفتاح', pg.evaluate("!document.getElementById('aiSet').hidden") or ('مفيش نت' in co))
            pg.evaluate("AI.key=''")
        else:
            print('!! خطوة الصورة اتخطت — محرك القراءة مش منزّل (npm install في فولدر المصدر، أو setup.sh)')

        ok('مفيش أخطاء في الكونسول', not errors, ' | '.join(errors[:3]))
        b.close()
    srv.shutdown()
    if osrv: osrv.shutdown()
    print('اختبار المتصفح   : %s' % ('تمام' if not F else '%d فشل' % F))
    sys.exit(1 if F else 0)

if __name__ == '__main__':
    main()
