#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v6.43 — الأداة في متصفح حقيقي، على الملف اللي هيتنشر نفسه.
    python3 test_browser.py /mnt/user-data/outputs/repo/index.html

ليه: اختبارات jsdom كلها بتنده showView بنفسها، فعيب «الفتحة الأولى بتفتح على
الريكوستات وكروت البداية فاضية» عاش على الموقع من غير ما حد يمسكه.
الاختبار ده بيعمل اللي الموظف بيعمله بالظبط: يفتح اللينك ويدوس.

الخروج: 0 نجاح · 1 فشل (البناء يقف) · 2 المتصفح مش متاح (البناء يكمّل بتحذير).
"""
import sys, os, threading, functools, socket
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler

TARGET = sys.argv[1] if len(sys.argv) > 1 else '/mnt/user-data/outputs/repo/index.html'
if not os.path.exists(TARGET):
    print('!! الملف مش موجود: ' + TARGET); sys.exit(1)
ROOT = os.path.dirname(os.path.abspath(TARGET))

try:
    from playwright.sync_api import sync_playwright
except Exception as ex:
    print('اختبار المتصفح: playwright مش متاح (%s)' % type(ex).__name__); sys.exit(2)

F = 0
def ok(msg, cond, extra=''):
    global F
    if cond: print('  \u2713 ' + msg)
    else:
        F += 1; print('  \u2717 ' + msg + ('  \u2014 ' + str(extra)[:160] if extra else ''))

class Quiet(SimpleHTTPRequestHandler):
    def log_message(self, *a): pass
    def end_headers(self):
        # محرك القراءة بيتجاب من أوريجن تاني (زي jsDelivr) — لازم CORS
        self.send_header('Access-Control-Allow-Origin', '*'); super().end_headers()

def serve(directory=None):
    s = socket.socket(); s.bind(('127.0.0.1', 0)); port = s.getsockname()[1]; s.close()
    srv = ThreadingHTTPServer(('127.0.0.1', port), functools.partial(Quiet, directory=directory or ROOT))
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv, 'http://127.0.0.1:%d/' % port

HERE = os.path.dirname(os.path.abspath(__file__))
def ocr_root():
    """v6.45: محرك القراءة من node_modules بنفس شكل مسارات jsDelivr (<pkg>@<ver>/…).
       لو مش منزّل (setup.sh بينزّله)، خطوة الصورة بتتخطى بتحذير."""
    nm = os.path.join(HERE, 'node_modules')
    if not os.path.isdir(os.path.join(nm, 'tesseract.js')): return None
    root = os.path.join(HERE, '.ocr-serve'); os.makedirs(os.path.join(root, '@tesseract.js-data'), exist_ok=True)
    for link, target in [('tesseract.js@5.1.1', 'tesseract.js'), ('tesseract.js-core@5.1.1', 'tesseract.js-core'),
                         ('@tesseract.js-data/eng@1.0.0', os.path.join('@tesseract.js-data', 'eng'))]:
        lp = os.path.join(root, link)
        if not os.path.lexists(lp): os.symlink(os.path.join(nm, target), lp)
    return root

SHOT = '''<html><body style="margin:0;background:#1e1e1e;font-family:monospace;font-size:13px;color:#d4d4d4">
<div style="padding:18px 20px"><div style="color:#9cdcfe;margin-bottom:10px;font-size:12px">Body &nbsp; Cookies &nbsp; Headers (12) &nbsp; Test Results &nbsp;&nbsp; 200 OK &nbsp; 312 ms</div>
<pre style="margin:0;line-height:1.55"><span style="color:#858585">1  </span>{
<span style="color:#858585">2  </span>    "message": "unauthorized",
<span style="color:#858585">3  </span>    "status_code": 401,
<span style="color:#858585">4  </span>    "extra": []
<span style="color:#858585">5  </span>}</pre></div></body></html>'''

VISIBLE = """() => [...document.querySelectorAll('section.view')].filter(s => !s.hidden).map(s => s.id)"""
SELECTED = """() => [...document.querySelectorAll('.tab[aria-selected="true"]')].map(t => t.dataset.view)"""

def main():
    srv, base = serve()
    oroot = ocr_root(); osrv = obase = None
    if oroot: osrv, obase = serve(oroot)
    with sync_playwright() as p:
        try:
            b = p.chromium.launch()
        except Exception as ex:
            print('اختبار المتصفح: كروم مش متاح (%s)' % str(ex).splitlines()[0][:80]); sys.exit(2)
        # خدمة الخلفية مقفولة عشان الاختبار ما يسيبش كاش ولا يتأثر بيه
        ctx = b.new_context(viewport={'width': 1366, 'height': 900}, locale='ar', service_workers='block')
        errors = []
        pg = ctx.new_page()
        if obase: pg.add_init_script("window.OCR_CDN_OVERRIDE = '%s';" % obase)
        pg.on('pageerror', lambda e: errors.append('pageerror: ' + str(e)[:160]))
        pg.on('console', lambda m: errors.append('console: ' + m.text[:160]) if m.type == 'error' else None)

        # ١) الفتحة الأولى من غير hash — اللي كان مكسور
        pg.goto(base + 'index.html'); pg.wait_for_timeout(1500)
        ok('الفتحة الأولى: التبويب المختار «ابدأ من هنا»', pg.evaluate(SELECTED) == ['triage'], pg.evaluate(SELECTED))
        ok('الفتحة الأولى: قسم واحد بس ظاهر وهو البداية', pg.evaluate(VISIBLE) == ['v-triage'], pg.evaluate(VISIBLE))
        n = pg.evaluate("document.querySelectorAll('#trCards > *').length")
        ok('الفتحة الأولى: كروت البداية مرسومة', n >= 5, n)
        ok('الفتحة الأولى: رقم النسخة ظاهر', pg.evaluate("document.getElementById('verTag').textContent") == 'v' + pg.evaluate('DOCS.version'))
        ok('شريط التحديث مش ظاهر (نفس النسخة)', pg.evaluate("document.getElementById('updBar').hidden"))

        # ٢) كل تبويب بيفتح قسمه هو بس
        for v in ['search', 'recipes', 'dash', 'inspect', 'faq', 'triage']:
            pg.click('.tab[data-view="%s"]' % v); pg.wait_for_timeout(250)
            vis = pg.evaluate(VISIBLE)
            want = ['v-faq'] if v == 'faq' else ['v-' + v]
            ok('تبويب %s بيفتح قسمه بس' % v, vis == want or (v == 'faq' and vis == ['v-docs']), vis)

        # ٣) كل كارت فرز بيوجّه لتبويب موجود
        badgo = pg.evaluate("TRIAGE.filter(x => x.go && VIEWS.indexOf(x.go.tab) < 0).map(x => x.id)")
        ok('كروت الفرز بتوجّه لتبويبات موجودة', badgo == [], badgo)

        # ٤) البحث بكلام العميل
        pg.click('.tab[data-view="search"]'); pg.fill('#q', 'لستة العربيات'); pg.wait_for_timeout(700)
        rn = pg.evaluate("document.querySelectorAll('#results > *').length")
        ok('البحث بيرجّع نتايج', rn > 0, rn)
        det = pg.evaluate("document.getElementById('detail').innerText")
        ok('التفاصيل فيها ريكوست العربيات', '/units' in det, det[:80])

        # ٥) اللغة والوضع الليلي
        pg.click('#langBtn'); pg.wait_for_timeout(300)
        ok('التحويل للإنجليزي', pg.evaluate("document.body.classList.contains('en')")
           and 'Start here' in pg.evaluate("document.querySelector('.tab[data-view=\"triage\"]').textContent"))
        pg.click('#langBtn'); pg.wait_for_timeout(200)
        ok('الرجوع للعربي', not pg.evaluate("document.body.classList.contains('en')"))
        pg.click('#themeBtn'); pg.wait_for_timeout(200)
        ok('الوضع الليلي بيشتغل', pg.evaluate("document.documentElement.getAttribute('data-theme')") == 'dark')
        pg.click('#themeBtn'); pg.wait_for_timeout(200)

        # ٦) المعرفة المضافة بتتحفظ وترجع بعد إعادة الفتح (v6.43)
        pg.click('.tab[data-view="faq"]'); pg.wait_for_timeout(300)
        pg.fill('#adT', 'اختبار حفظ'); pg.fill('#adB', 'تفاصيل الاختبار'); pg.click('#adGo'); pg.wait_for_timeout(300)
        stored = pg.evaluate("JSON.parse(localStorage.getItem('afaqy.added.v1') || '[]').length")
        ok('المعلومة اتحفظت على الجهاز', stored == 1, stored)
        pg.goto(base + 'index.html'); pg.wait_for_timeout(1200)
        ok('المعلومة رجعت بعد إعادة الفتح', pg.evaluate("ADDED.length") == 1 and pg.evaluate("LEARNED.some(k => k.t && k.t.ar === 'اختبار حفظ')"))
        pg.click('.tab[data-view="faq"]'); pg.wait_for_timeout(300)
        st = pg.evaluate("(document.getElementById('adStat') || {}).textContent || ''")
        ok('الفورم بيقول إن فيه معلومة لسه ما اتصدّرتش', 'لسه ما اتصدّرتش' in st, st[:80])
        pg.evaluate("localStorage.removeItem('afaqy.added.v1'); localStorage.removeItem('afaqy.added.exportedAt')")

        # ٧) لينك مباشر على تبويب
        pg.goto(base + 'index.html#recipes'); pg.wait_for_timeout(800)
        ok('لينك #recipes بيفتح السيناريوهات بس', pg.evaluate(VISIBLE) == ['v-recipes'], pg.evaluate(VISIBLE))

        # ٨) الموبايل: التبويبات والبداية ظاهرين
        m = b.new_context(viewport={'width': 390, 'height': 844}, is_mobile=True, locale='ar', service_workers='block').new_page()
        m.on('pageerror', lambda e: errors.append('mobile pageerror: ' + str(e)[:160]))
        m.goto(base + 'index.html'); m.wait_for_timeout(1200)
        ok('الموبايل: البداية ظاهرة', m.evaluate(VISIBLE) == ['v-triage'] and m.evaluate("document.querySelectorAll('#trCards > *').length") >= 5)
        ok('الموبايل: التبويبات ظاهرة', m.evaluate("document.querySelector('.tabs').getBoundingClientRect().height") > 20)

        # ٩) إيميل طلب إنتجريشن → رد نقطة بنقطة (v6.44)
        pg.goto(base + 'index.html'); pg.wait_for_timeout(1000)
        pg.click('.tab[data-view="inspect"]'); pg.wait_for_timeout(300)
        pg.click('#ivCase'); pg.wait_for_timeout(300)
        pg.fill('#caseText', 'نرغب في الاستفادة من خدمة API ونأمل تزويدنا بالبيانات التالية:\n'
                             '1. رقم اللوحة ومعرّف المركبة (Vehicle ID).\n2. إجمالي ساعات تشغيل المحرك (Engine Hours).\n'
                             '3. بيانات مستوى الوقود (Fuel Level).\n4. حدود الاستخدام (Rate Limits).\n• API Documentation.')
        pg.click('#caseGo'); pg.wait_for_timeout(800)
        vt = pg.evaluate("document.getElementById('caseOut').innerText")
        ok('إيميل طلب البيانات بيتعرف عليه', 'طلب إنتجريشن: 5 بند' in vt, vt[:80])
        rp = pg.evaluate("(document.getElementById('caseReplyTxt') || {}).textContent || ''")
        ok('الرد نقطة بنقطة بنص العميل وحالة كل بند', '1) رقم اللوحة' in rp and 'قيد التأكيد' in rp and '3600' in rp, rp[:80])
        pg.click('#reqEn'); pg.wait_for_timeout(300)
        ok('زرار الإنجليزي بيقلب الرد', 'Dear team' in pg.evaluate("document.getElementById('caseReplyTxt').textContent"))

        # ١٠) صورة رد بوستمان (وضع ليلي بأرقام سطور) → تتقرا وتتشخّص (v6.45)
        if obase:
            shot = ctx.new_page(); shot.set_viewport_size({'width': 760, 'height': 220}); shot.set_content(SHOT); shot.wait_for_timeout(200)
            png = os.path.join(HERE, '.ocr-sample.png'); shot.screenshot(path=png, full_page=True); shot.close()
            pg.goto(base + 'index.html'); pg.wait_for_timeout(1000)
            pg.click('.tab[data-view="inspect"]'); pg.wait_for_timeout(300)
            pg.set_input_files('#inFile', png)
            try:
                pg.wait_for_function("/اتقرت|ما قدرناش|ما طلعش/.test(document.getElementById('inImgBox').innerText)", timeout=180000)
            except Exception:
                pass
            box = pg.evaluate("document.getElementById('inImgBox').innerText")
            ok('صورة الرد اتقرت على الجهاز', 'اتقرت من الصورة' in box, box[:120])
            txt = pg.evaluate("document.getElementById('inText').value")
            ok('النص اللي طلع JSON سليم بالرسالة والكود', '"message": "unauthorized"' in txt and '"status_code": 401' in txt, txt[:120])
            outv = pg.evaluate("document.getElementById('inOut').innerText")
            ok('الفحص شخّص الخطأ من الصورة', 'unauthorized' in outv and ('مش مصرّح' in outv or 'التوكن' in outv), outv[:120])
            pg.evaluate("document.getElementById('inClear').click()")
        else:
            print('!! خطوة الصورة اتخطت — محرك القراءة مش منزّل (npm install في فولدر المصدر، أو setup.sh)')

        ok('مفيش أخطاء في الكونسول', not errors, ' | '.join(errors[:3]))
        b.close()
    srv.shutdown()
    if osrv: osrv.shutdown()
    print('اختبار المتصفح   : %s' % ('تمام' if not F else '%d فشل' % F))
    sys.exit(1 if F else 0)

if __name__ == '__main__':
    main()
