/* v6.52 — التذكرة فيها IMEI: الأداة بتجيب الـ UID لوحدها من الحساب المتصل وتكتبه في الرد */
const fs=require('fs'); const {JSDOM}=require('jsdom');
let F=0; const ok=(m,c,x)=>{ console.log((c?'  \u2713 ':'  \u2717 ')+m+(c||!x?'':'  \u2014 '+String(x).slice(0,160))); if(!c) F++; };
const html=fs.readFileSync(process.argv[2]||'app_template.html','utf8')
  .replace('/*__KB__*/',()=>fs.readFileSync('kb_slim.json','utf8'))
  .replace('/*__DOCS__*/',()=>fs.readFileSync('docs.json','utf8'))
  .replace('/*__KBIN__*/',()=>fs.readFileSync('kb_in.json','utf8'));
const TICKET=`Dear team,\n\nWe have encountered the following error when getting the last location for the unit.\n\nRequest:\nPOST https://api.afaqy.sa/units/locations?token=<TOKEN>\n{\n  "data": {\n    "unit_id": "861230044934025",\n    "address": true,\n    "date": {"interval": "interval", "from": "2026-10-10 00:00:00", "to": "2026-10-11 23:59:59"}\n  }\n}\n\nResponse:\n{\n  "message": "not_allowed",\n  "status_code": 401,\n  "data": []\n}`;
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
function boot(){
  const w=new JSDOM(html,{runScripts:'dangerously',pretendToBeVisual:true,url:'https://localhost/'}).window;
  w.alert=()=>{}; w.scrollTo=()=>{};
  w.showView('inspect'); w.eval("INSPVIEW='case'"); w.paintInspect();
  return w;
}
const FLEET={status_code:200, data:[{id:'5e6790e103ed52cf443362c9', name:'L S A-6220', imei:'861230044934025'},
                                    {id:'aaaaaaaaaaaaaaaaaaaaaaaa', name:'Other', imei:'111111111111111'}]};
(async()=>{
/* ١) متصل، ومفيش جهاز متحدد فوق: الـ UID بيتجاب لوحده */
{ const w=boot(); const calls=[];
  w.eval('SESSION.token="T"; SESSION.unit=null;');
  w.__fleet=FLEET; w.__calls=calls;
  w.eval(`apiFetch = async (p,b)=>{ window.__calls.push(JSON.stringify(b)); return {ok:true,status:200,json:window.__fleet}; };`);
  w.document.getElementById('caseText').value=TICKET; w.document.getElementById('caseGo').click();
  await sleep(80);
  const rep=w.document.getElementById('caseReplyTxt').textContent, out=w.document.getElementById('caseOut').textContent;
  ok('الأداة نادت /units/lists مفلتر بالـ IMEI من غير ما حد يطلب', calls.length>=1 && /"filters":\{"imei":\{"value":\["861230044934025"\],"op":"in"\}\}/.test(calls[0]), calls[0]);
  ok('الـ UID الحقيقي مكتوب في الرد', /For this vehicle the UID is 5e6790e103ed52cf443362c9/.test(rep) && /"unit_id":"5e6790e103ed52cf443362c9"/.test(rep));
  ok('مفيش «<UID from step 1>» في الرد', !/<UID from step 1>/.test(rep));
  ok('الملاحظة بتقول اتجاب أوتوماتيك واسم العربية', /اتجاب أوتوماتيك/.test(out) && /L S A-6220/.test(out));
  ok('الشريط فوق ما اتغيّرش', w.eval('SESSION.unit')===null);
  const col=w.pmFromCase(Object.assign(w.analyzeCase(TICKET),{_raw:TICKET}));
  ok('الكولكشن متعبّي بالـ UID اللي اتجاب', col.variable.find(v=>v.key==='unit_id').value==='5e6790e103ed52cf443362c9');
  const n=calls.length; w.document.getElementById('caseGo').click(); await sleep(50);
  ok('تحليل تاني لنفس التذكرة ما بينادش السيرفر تاني', calls.length===n, calls.length+' vs '+n);
  /* الحساب اتغيّر: الكاش بيتمسح */
  w.eval('SESSION.token="T2"'); w.__fleet={status_code:200, data:[]}; w.eval('UNITS_CACHE=null');
  w.document.getElementById('caseGo').click(); await sleep(80);
  ok('حساب تاني ما يشوفش العربية: الـ UID القديم ما يتكتبش', !/5e6790e103ed52cf443362c9/.test(w.document.getElementById('caseReplyTxt').textContent));
  ok('والملاحظة بتقول العربية مش على الحساب المتصل', /مش على الحساب المتصل/.test(w.document.getElementById('caseOut').textContent));
}
/* ٢) الفلتر ما اشتغلش (السيرفر رجّع لستة عادية) — بيدوّر جوه اللستة */
{ const w=boot(); w.eval('SESSION.token="T"');
  w.__resp={status_code:200, data:[{id:'bbbbbbbbbbbbbbbbbbbbbbbb', name:'First', imei:'222222222222222'}, {id:'5e6790e103ed52cf443362c9', name:'L S A-6220', imei:'861230044934025'}]};
  w.eval(`apiFetch = async ()=>({ok:true,status:200,json:window.__resp});`);
  w.document.getElementById('caseText').value=TICKET; w.document.getElementById('caseGo').click(); await sleep(80);
  ok('فلتر متجاهَل: لقاها جوه اللستة بالـ IMEI', /"unit_id":"5e6790e103ed52cf443362c9"/.test(w.document.getElementById('caseReplyTxt').textContent));
}
/* ٣) التطابق على الـ IMEI بس — عربية اسمها نفس الرقم ما تتاخدش */
{ const w=boot(); w.eval('SESSION.token="T"');
  w.__resp={status_code:200, data:[{id:'cccccccccccccccccccccccc', name:'861230044934025', imei:'999999999999999'}]};
  w.eval(`apiFetch = async ()=>({ok:true,status:200,json:window.__resp});`);
  w.document.getElementById('caseText').value=TICKET; w.document.getElementById('caseGo').click(); await sleep(80);
  ok('اسم عربية = الرقم ده بس الـ IMEI مختلف: ما يتكتبش UID غلط', !/cccccccccccccccccccccccc/.test(w.document.getElementById('caseReplyTxt').textContent));
}
/* ٤) مش متصل: مفيش نداء، والملاحظة بتقول اتصل */
{ const w=boot(); const calls=[]; w.__calls=calls;
  w.eval('SESSION.token=null'); w.eval(`apiFetch = async (p,b)=>{ window.__calls.push(1); return {ok:false}; };`);
  w.document.getElementById('caseText').value=TICKET; w.document.getElementById('caseGo').click(); await sleep(50);
  ok('مش متصل: مفيش نداء للسيرفر', calls.length===0);
  ok('والملاحظة بتقول اتصل والـ UID هيتكتب لوحده', /اتصل بحساب العميل/.test(w.document.getElementById('caseOut').textContent));
}
console.log(F?`\nفشل ${F}`:'\nالـ UID الأوتوماتيك: تمام'); process.exit(F?1:0);
})();
