#!/usr/bin/env bash
# تجهيز بيئة البناء من الصفر — أمر واحد بعد أي تصفير للبيئة.
#   bash setup.sh
# بيجهّز: jsdom للاختبارات، وكروم لاختبار المتصفح وطباعة الدليل، وweasyprint احتياطي،
# وفولدر النشر من نسخة الزيب لو فاضي. ما بيلمسش private_names.json — ده يتحط بالإيد.
set -euo pipefail
cd "$(dirname "$0")"
command -v node    >/dev/null || { echo "!! node مش موجود"; exit 1; }
command -v python3 >/dev/null || { echo "!! python3 مش موجود"; exit 1; }
echo "node $(node --version) · $(python3 --version)"

[ -d node_modules/jsdom ] || npm install --no-audit --no-fund --silent
node -e "require('jsdom')" && echo "jsdom          : تمام"

python3 -c "import playwright" 2>/dev/null || pip install --break-system-packages -q playwright
if python3 -m playwright install chromium >/dev/null 2>&1; then echo "كروم           : تمام"
else echo "كروم           : ما نزلش — الدليل هيتطبع بـ weasyprint واختبار المتصفح هيتخطى بتحذير"; fi
python3 -c "import weasyprint" 2>/dev/null || pip install --break-system-packages -q weasyprint || true

OUT=/mnt/user-data/outputs/repo
mkdir -p "$OUT"
if [ ! -f "$OUT/manifest.json" ] && [ -d "../1-الأداة-للنشر" ]; then
  cp -r "../1-الأداة-للنشر/." "$OUT/"; echo "فولدر النشر    : اتملى من نسخة الزيب"
fi

if [ -f private_names.json ]; then echo "الأسماء الخاصة : موجودة"
else echo "!! فاكر: private_names.json لازم يتحط هنا يدويًا قبل البناء — مش في الزيب ولا الريبو أبدًا"; fi
echo "البيئة جاهزة — python3 build.py"
