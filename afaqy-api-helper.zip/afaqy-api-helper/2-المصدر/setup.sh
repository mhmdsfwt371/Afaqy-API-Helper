#!/usr/bin/env bash
# تجهيز جهاز جديد للبناء — من غير ده مفيش غير شخص واحد يقدر ينشر.
#   bash setup.sh
set -euo pipefail
cd "$(dirname "$0")"

echo "=== تجهيز بيئة البناء ==="

need() { command -v "$1" >/dev/null 2>&1 || { echo "!! ناقص: $1 — نصّبه الأول"; exit 1; }; }
need python3
need node
echo "  python3 : $(python3 --version 2>&1 | cut -d' ' -f2)"
echo "  node    : $(node --version)"

echo ""
echo "=== مكتبات بايثون ==="
python3 -m pip install --quiet --break-system-packages playwright 2>/dev/null \
  || python3 -m pip install --quiet playwright
python3 -m playwright install chromium >/dev/null 2>&1 || {
  echo "  !! ما قدرناش ننزّل المتصفح — الدليل PDF مش هيتولّد."
  echo "     الباقي هيشتغل عادي."
}
echo "  playwright + chromium: تمام"

echo ""
echo "=== الخطوط العربية ==="
FONT_DIR="${HOME}/.local/share/fonts"
mkdir -p "$FONT_DIR"
if ! fc-list 2>/dev/null | grep -qi "cairo\|naskh"; then
  for u in \
    "https://raw.githubusercontent.com/google/fonts/main/ofl/cairo/Cairo%5Bslnt%2Cwght%5D.ttf|Cairo.ttf" \
    "https://raw.githubusercontent.com/google/fonts/main/ofl/notonaskharabic/NotoNaskhArabic%5Bwght%5D.ttf|NotoNaskhArabic.ttf"
  do
    url="${u%%|*}"; name="${u##*|}"
    curl -sfL "$url" -o "$FONT_DIR/$name" && echo "  نزّل: $name"
  done
  fc-cache -f >/dev/null 2>&1 || true
else
  echo "  الخطوط موجودة"
fi

echo ""
echo "=== تجربة البناء ==="
python3 build.py

echo ""
echo "=== خلص ==="
echo "  البناء     : python3 build.py"
echo "  رفع نسخة   : python3 bump.py 4.4 notes.json"
echo "  النشر      : GH_TOKEN='...' MSG_FILE=msg.txt bash deploy.sh"
echo ""
echo "  البناء بيوقف لوحده لو اختبار فشل، أو لو في اسم عميل أو توكن في"
echo "  الملفات العامة، أو لو ملف بيقول رقم نسخة مختلف عن الباقي."
