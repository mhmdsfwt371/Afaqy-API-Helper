const fs=require('fs');
const fail = s => { console.error('فشل: '+s); process.exit(1); };

// ١) المانيفست سليم
const m = JSON.parse(fs.readFileSync('/mnt/user-data/outputs/repo/manifest.json','utf8'));
['name','short_name','start_url','scope','display','theme_color','background_color','icons'].forEach(k=>{
  if(!(k in m)) fail('المانيفست ناقص: '+k); });
if(m.display!=='standalone') fail('display لازم standalone');
if(!m.icons.some(i=>i.sizes==='192x192')) fail('أيقونة 192 ناقصة');
if(!m.icons.some(i=>i.sizes==='512x512')) fail('أيقونة 512 ناقصة');
if(!m.icons.some(i=>i.purpose==='maskable')) fail('أيقونة maskable ناقصة');
console.log('المانيفست         : تمام ('+m.icons.length+' أيقونة)');

// ٢) الأيقونات موجودة فعلًا
m.icons.forEach(i=>{
  const p='/mnt/user-data/outputs/repo/'+i.src;
  if(!fs.existsSync(p)) fail('أيقونة ناقصة: '+i.src);
  if(fs.statSync(p).size < 500) fail('أيقونة فاضية: '+i.src);
});
['icons/apple-touch-icon.png','icons/favicon-32.png'].forEach(f=>{
  if(!fs.existsSync('/mnt/user-data/outputs/repo/'+f)) fail('ناقص: '+f); });
console.log('الأيقونات          : كلها موجودة');

// ٣) الخدمة: الشبكة الأول، والنداءات الخارجية ما تتخزنش
const sw = fs.readFileSync('/mnt/user-data/outputs/repo/sw.js','utf8');
if(sw.indexOf('fetch(req)') < sw.indexOf('caches.match')) {} // ترتيب
if(!/url\.origin !== self\.location\.origin/.test(sw)) fail('السيرفر الخارجي مش مستثنى');
if(!/version\.json/.test(sw)) fail('فحص النسخة مش مستثنى من الكاش');
if(!/req\.method !== 'GET'/.test(sw)) fail('نداءات الـ API ممكن تتخزن');
if(!/skipWaiting/.test(sw) || !/clients\.claim/.test(sw)) fail('التحديث الفوري مش مفعّل');
console.log('الخدمة             : الشبكة الأول، والـ API والنسخة مستثنيين');

// ٤) وسوم الصفحة
const h = fs.readFileSync('app_template.html','utf8');   // القالب — قبل البناء
[['rel="manifest"','المانيفست'],['apple-touch-icon','أيقونة آيفون'],
 ['apple-mobile-web-app-capable','وضع التطبيق على آيفون'],['theme-color','لون الشريط'],
 ['serviceWorker','تسجيل الخدمة'],['beforeinstallprompt','دعوة التثبيت'],
 ['Add to Home Screen','شرح آيفون']].forEach(([n,label])=>{
  if(h.indexOf(n)<0) fail('ناقص في الصفحة: '+label); });
console.log('وسوم الصفحة        : تمام');

// ٥) الموبايل
if(h.indexOf('max-width:760px')<0) fail('تنسيق الموبايل ناقص');
if(h.indexOf('.searchbar input{font-size:16px}')<0) fail('خانة البحث هتزوّم على آيفون');
console.log('تنسيق الموبايل     : تمام');
