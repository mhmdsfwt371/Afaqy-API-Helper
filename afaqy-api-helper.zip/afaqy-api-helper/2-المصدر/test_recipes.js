const fs = require('fs');

// stubs for browser globals
global.document = { addEventListener(){}, querySelectorAll(){return[]}, createElement(){return{select(){},remove(){}}}, body:{appendChild(){}} };
global.history={pushState(){},replaceState(){}};
global.location={hash:''};
global.navigator = { clipboard: { writeText(){ return Promise.resolve(); } } };
global.window = { scrollTo(){}, addEventListener(){} };
global.fetch = () => Promise.reject(new Error('stub'));

let js = fs.readFileSync('app_template.html','utf8').split('<script>')[1].split('</script>')[0];
js = js.replace('/*__KB__*/', fs.readFileSync('kb_slim.json','utf8')).replace('/*__DOCS__*/', fs.readFileSync('docs.json','utf8'));
js = js.split('/* ---------------- views ---------------- */')[0];
js = js.replace('const $ = id => document.getElementById(id);',
  "const $ = id => ({hidden:false, innerHTML:'', value:'', textContent:'', placeholder:'', querySelectorAll(){return[]}, addEventListener(){}, focus(){}, setAttribute(){}, dispatchEvent(){}, onclick:null});");

const mod = {};
new Function('module', js + '\nmodule.exports = {prevMonth, monthRange, deepItems, matchByName, deepFindKey, RECIPES, diagnose};')(mod);
const A = mod.exports;

console.log('prevMonth   =', A.prevMonth());
console.log('monthRange  =', JSON.stringify(A.monthRange(A.prevMonth())));

const fake = { status:true, data:{ items:[
  {_id:'aaa111', name:'ABC-1234'},
  {_id:'bbb222', name:'مرسيدس 45'},
  {id:'ccc333', name:'Truck 7'} ]}};

console.log('deepItems   =', A.deepItems(fake).map(x=>x.id+':'+x.name).join('  |  '));
console.log('match مرسيدس ->', (A.matchByName(fake,'مرسيدس 45').hit||{}).id);
console.log('match "truck 7" ->', (A.matchByName(fake,'truck 7').hit||{}).id);
const miss = A.matchByName(fake,'حاجة متعرفهاش');
console.log('match مجهول ->', (miss.hit||{}).id, '| بدائل معروضة:', miss.items.length);
console.log('token       =', A.deepFindKey({status:true,data:{token:'eyJ.SIGNED', user:{id:1}}}, 'token'));
console.log('recipes     =', A.RECIPES.map(r=>r.title).join('  /  '));

const r = A.RECIPES.find(x=>x.id==='unit-report');
const vars = { unitName:'x', month:'2026-07', unitId:'U1', unitLabel:'مرسيدس 45',
               _tplRaw:{ code:'summary', fields:[{name:'Date', code:'date'}] } };
console.log('\nبودي إنشاء التقرير:');
console.log(JSON.stringify(r.steps[4].body(vars), null, 1));

console.log('\nطبيب الأخطاء:');
[401,404,405,422,500].forEach(c => console.log('  ' + c + ' → ' + A.diagnose(c, '')));
