#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v7.4 — إيميل Outlook من غير لقطة شاشة، وحالات شبيهة اتحلّت قبل كده — كله محلي.

قرار صفوت (٢٧ أكتوبر): أي حاجة محتاجة Claude API ما تتعملش. الباقي:

(١) إيميل Outlook مباشرة:
- اسحب الإيميل من Outlook للديسكتوب (.msg) أو احفظه .eml، وارميه في خانة الرسالة
  أو ارفعه بالزرار. الأداة بتقرا الموضوع والمرسل والنص بالحرف (من غير OCR)،
  وأي صورة مرفقة كبيرة (لقطة بوستمان أو كارت المنصة) بتتقرا بالقارئ المحلي
  وبتتضاف للتذكرة. اللوجوهات الصغيرة بتتساب.
- .msg بيتقرا بـ msgreader 1.28.0 (Apache-2.0) متحزّم في ملف واحد جوه الأداة
  (شغّال من غير نت)؛ .eml بيتقرا بمحلّل MIME مكتوب هنا.

(٢) حالات شبيهة:
- تحت أي رد جاهز من القواعد: «احفظ الحالة دي للفريق». بيتحفظ الرد اللي الأداة
  طلّعته + بصمة الحالة — وعمره ما بيتحفظ نص رسالة العميل: البصمة كلمات
  تقنية بس من قاموس التوثيق (مسارات، أكواد أخطاء، كلمات الريكوستات)، فمفيش
  أسماء ولا شركات توصل للتصدير أو للريبو.
- أول ما رسالة جديدة تتحلّل: لو شبه حالة اتحفظت، «حالة شبيهة اتحلّت قبل كده»
  بتظهر فوق بالرد اللي نفع وزرار نسخه. المقارنة في المتصفح.

(٣) طبقة Claude ما تزحمش: الإعدادات مقفولة لحد ما حد يفتحها، وزراير Claude
    مستخبية من غير مفتاح، واقتراح «القواعد ما عرفتش» بيوجّه للحالات الشبيهة
    والتصعيد بدل المفتاح.
"""
import sys, io, os
HERE = os.path.dirname(os.path.abspath(__file__))
PATH = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, 'app_template.html')
src = io.open(PATH, encoding='utf-8').read(); orig = len(src)
def rep(old, new, n=1, tag=''):
    global src
    c = src.count(old)
    if c != n: raise SystemExit('MISMATCH [%s]: expected %d found %d\n---\n%s' % (tag, n, c, old[:200]))
    src = src.replace(old, new, n); print('  ok  %s' % tag)

MAIL_JS = r"""
/* ============ إيميل Outlook من غير لقطة شاشة (.msg / .eml) ============ */
function mailHtmlText(h){
  return String(h || '').replace(/<style[\s\S]*?<\/style>|<script[\s\S]*?<\/script>/gi, '')
    .replace(/<br\s*\/?>|<\/(p|div|tr|li|h\d)>/gi, '\n').replace(/<[^>]+>/g, '')
    .replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;/g, "'")
    .replace(/[ \t]+\n/g, '\n').replace(/\n{3,}/g, '\n\n').trim();
}
const _bin = u8 => { let s = ''; for(let i = 0; i < u8.length; i += 8192) s += String.fromCharCode.apply(null, u8.subarray(i, i + 8192)); return s; };
const _u8 = s => { const a = new Uint8Array(s.length); for(let i = 0; i < s.length; i++) a[i] = s.charCodeAt(i) & 255; return a; };
const _dec = (u8, cs) => { try{ return new TextDecoder(String(cs || 'utf-8').toLowerCase().replace(/^cp/, 'windows-')).decode(u8); }catch(_){ return new TextDecoder('utf-8').decode(u8); } };
/* =?utf-8?B?…?= و =?…?Q?…?= في الهيدرز */
function mailWord(s){
  return String(s || '').replace(/=\?([^?]+)\?([bqBQ])\?([^?]*)\?=\s*/g, (m, cs, enc, txt) => {
    try{ const bytes = /b/i.test(enc) ? _u8(atob(txt)) : _u8(txt.replace(/_/g, ' ').replace(/=([0-9A-F]{2})/gi, (x, h) => String.fromCharCode(parseInt(h, 16)))); return _dec(bytes, cs); }catch(_){ return m; }
  });
}
function _mimeHeaders(block){
  const H = {}; String(block).replace(/\r?\n[ \t]+/g, ' ').split(/\r?\n/).forEach(l => { const i = l.indexOf(':'); if(i > 0) H[l.slice(0, i).trim().toLowerCase()] = l.slice(i + 1).trim(); });
  return H;
}
const _param = (v, k) => { const m = String(v || '').match(new RegExp(k + '\\*?=\\s*"?([^";]+)"?', 'i')); return m ? m[1] : ''; };
/* محلّل MIME صغير: نص الإيميل + المرفقات */
function emlParse(bin){
  const out = {text:'', html:'', atts:[]};
  (function part(raw){
    const cut = raw.search(/\r?\n\r?\n/); const H = _mimeHeaders(cut < 0 ? raw : raw.slice(0, cut)); let body = cut < 0 ? '' : raw.slice(cut).replace(/^\r?\n\r?\n/, '');
    const ct = H['content-type'] || 'text/plain', bnd = _param(ct, 'boundary');
    if(/^multipart\//i.test(ct) && bnd){ body.split('--' + bnd).slice(1).forEach(p => { if(!/^--/.test(p)) part(p.replace(/^\r?\n/, '')); }); return; }
    const te = String(H['content-transfer-encoding'] || '').toLowerCase();
    let bytes = te === 'base64' ? _u8(atob(body.replace(/[^A-Za-z0-9+/=]/g, '')))
      : te === 'quoted-printable' ? _u8(body.replace(/=\r?\n/g, '').replace(/=([0-9A-F]{2})/gi, (x, h) => String.fromCharCode(parseInt(h, 16)))) : _u8(body);
    const name = mailWord(_param(H['content-disposition'], 'filename') || _param(ct, 'name'));
    if(/^text\/plain/i.test(ct) && !name && !out.text) out.text = _dec(bytes, _param(ct, 'charset'));
    else if(/^text\/html/i.test(ct) && !name && !out.html) out.html = _dec(bytes, _param(ct, 'charset'));
    else if(/^(image|application|text)\//i.test(ct)) out.atts.push({name: name || 'attachment', type: ct.split(';')[0].trim().toLowerCase(), data: bytes});
  })(bin);
  const top = _mimeHeaders(bin.slice(0, Math.max(0, bin.search(/\r?\n\r?\n/))));
  return { from: mailWord(top['from'] || ''), subject: mailWord(top['subject'] || ''), date: top['date'] || '',
           body: out.text.trim() || mailHtmlText(out.html), atts: out.atts };
}
function _mimeOf(n){ const e = String(n || '').toLowerCase().split('.').pop(); return {png:'image/png', jpg:'image/jpeg', jpeg:'image/jpeg', gif:'image/gif', bmp:'image/bmp', webp:'image/webp'}[e] || ''; }
async function mailParse(file){
  /* نسخة في ArrayBuffer بتاع الصفحة نفسها — المحلّل بيتأكد من النوع */
  const src0 = new Uint8Array(await file.arrayBuffer()), u8 = new Uint8Array(new ArrayBuffer(src0.length)); u8.set(src0);
  if(u8[0] === 0xD0 && u8[1] === 0xCF && u8[2] === 0x11 && u8[3] === 0xE0){
    if(typeof window.AfaqyMsgReader !== 'function') throw new Error('msgreader');
    const r = new window.AfaqyMsgReader(u8.buffer), f = r.getFileData();
    if(f.error) throw new Error(String(f.error));
    const html = f.bodyHtml || (f.html ? _dec(f.html instanceof Uint8Array ? f.html : new Uint8Array(f.html), 'utf-8') : '');
    const atts = (f.attachments || []).map(a => { try{ const x = r.getAttachment(a); const n = x.fileName || a.fileName || a.name || 'attachment';
      return {name:n, type:(a.attachMimeTag || _mimeOf(n) || '').toLowerCase(), data:x.content}; }catch(_){ return null; } }).filter(Boolean);
    return { from: f.senderName ? f.senderName + (f.senderEmail ? ' <' + f.senderEmail + '>' : '') : (f.senderEmail || ''), subject: f.subject || '',
             date: f.messageDeliveryTime || f.clientSubmitTime || '', body: String(f.body || '').trim() || mailHtmlText(html), atts };
  }
  return emlParse(_bin(u8));
}
const MAIL_IMG_MIN = 15000;   /* أصغر من كده غالبًا لوجو في التوقيع */
async function mailIngest(file){
  const ta = $('caseText'), box = $('caseImgBox'); if(!ta) return;
  box.hidden = false; box.innerHTML = `<div class="note">${t('بنقرا الإيميل…','Reading the email…')}</div>`;
  let m;
  try{ m = await mailParse(file); }
  catch(err){ box.innerHTML = `<div class="note warn">${t('ما قدرناش نقرا الملف ده كإيميل. احفظه من Outlook كـ .msg (اسحبه للديسكتوب) أو .eml.','Could not read this file as an email. Save it from Outlook as .msg (drag it to the desktop) or .eml.')}</div>`; return; }
  const head = [m.subject ? 'Subject: ' + m.subject : '', m.from ? 'From: ' + m.from : ''].filter(Boolean).join('\n');
  let text = (head ? head + '\n\n' : '') + String(m.body || '').replace(/\r\n/g, '\n');
  ta.value = text;
  const imgs = (m.atts || []).filter(a => /^image\//.test(a.type || _mimeOf(a.name)) && a.data && a.data.length >= MAIL_IMG_MIN).sort((a, b) => b.data.length - a.data.length).slice(0, 3);
  const read = [];
  for(const a of imgs){
    box.innerHTML = `<div class="note">${t('بنقرا المرفق','Reading the attachment')} ${esc(a.name)}…</div>`;
    try{
      const f = new File([a.data], a.name, {type: a.type || _mimeOf(a.name) || 'image/png'});
      AI.lastImage = AI.lastImage || f;
      const r = await ocrImage(f, () => {});
      const add = r.isTicket ? r.tech : (r.text || '');
      if(String(add).trim()){ text += '\n\n[' + a.name + ']\n' + add; read.push(a.name); }
    }catch(_){}
  }
  ta.value = text;
  const n = (m.atts || []).length;
  box.innerHTML = `<div class="note sig"><b>${t('اتقرا الإيميل','Email read')}</b>${m.subject ? ' — ' + esc(m.subject) : ''}<br>
    ${t(`النص بالحرف من الإيميل نفسه. المرفقات: ${n}`, `Text taken verbatim from the email. Attachments: ${n}`)}${read.length ? ' — ' + t('اتقرت الصور: ','images read: ') + read.map(esc).join('، ') : ''}${n && !read.length ? ' — ' + t('مفيش صورة كبيرة تتقري (اللوجوهات بتتساب)','no large image to read (logos are skipped)') : ''}</div>`;
  renderCase(text);
}

/* ============ حالات شبيهة اتحلّت قبل كده — محلي ============
   البصمة كلمات تقنية بس من قاموس التوثيق — عمرها ما بتشيل اسم ولا شركة. */
let _CASE_VOCAB = null;
function caseVocab(){
  if(_CASE_VOCAB) return _CASE_VOCAB;
  const V = new Set(), add = s => (String(s || '').toLowerCase().match(/[a-z_]{3,}|[\u0600-\u06FF]{3,}/g) || []).forEach(w => V.add(norm(w)));
  EPS.forEach(e => { add(e.n); add(e.p.replace(/\//g, ' ')); add(e.g); add(String(e.d || '').slice(0, 400)); });
  try{ Object.keys(VOCAB).forEach(k => { add(k); (VOCAB[k] || []).forEach(add); }); }catch(_){}
  try{ FAQ.forEach(f => { add(f.t.ar); add(f.t.en); }); CASE_RULES.forEach(r => { add(r.name.en); add(r.name.ar); add(r.mistake.en); }); ERRORS.forEach(x => add(x.code)); }catch(_){}
  ['imei','uid','token','bearer','status_code','not_allowed','validation_error','not_found','unauthorized','invalid_credentials','unit_id','webhook','webhooks','projection','offset','limit','filters','report','location','signals','sensor','sensors','odometer','engine','driver','trip','fuel','speed'].forEach(w => V.add(w));
  ['the','and','for','with','you','your','our','are','this','that','from','have','please','dear','team','hello','thanks','thank','regards','best','would','could','need','want','get','can','not','but','was','were','will','all','any','also','some','when','what','which','there'].forEach(w => V.delete(w));
  return (_CASE_VOCAB = V);
}
function caseSig(text){
  const s = String(text || ''), V = caseVocab();
  const tok = [...new Set((s.toLowerCase().match(/[a-z_]{3,}|[\u0600-\u06FF]{3,}/g) || []).map(norm).filter(w => V.has(w)))].slice(0, 80);
  const paths = [...new Set((mentionedPaths(s) || []).filter(p => EPS.some(e => e.p === p)))];
  const errs = [...new Set((s.match(/\b(not_allowed|validation_error|not_found|unauthori[sz]ed|invalid_credentials|forbidden|expired|bad_request|server_error)\b/gi) || []).map(x => x.toLowerCase()))];
  const mk = []; if(/\b\d{15}\b/.test(normDigits(s))) mk.push('imei15'); if(/\b[a-f0-9]{24}\b/i.test(s)) mk.push('uid24'); if(/"?status_code"?\s*[:=]\s*[45]\d\d/.test(s)) mk.push('err4xx');
  return {tok, paths, errs, mk};
}
function caseSimScore(a, b){
  if(!a || !b) return 0;
  const J = (x, y) => { const X = new Set(x || []), Y = new Set(y || []); if(!X.size && !Y.size) return 0; let n = 0; X.forEach(v => { if(Y.has(v)) n++; }); return n / (X.size + Y.size - n); };
  const share = (x, y) => (x || []).some(v => (y || []).includes(v)) ? 1 : 0;
  return J(a.tok, b.tok) + 0.35 * share(a.paths, b.paths) + 0.35 * share(a.errs, b.errs) + 0.15 * J(a.mk, b.mk);
}
const CASE_SIM_MIN = 0.45;
function caseSimilar(text){
  const sig = caseSig(text);
  return ADDED.filter(k => k.kind === 'case' && k.sig).map(k => ({k, s: caseSimScore(sig, k.sig)})).filter(x => x.s >= CASE_SIM_MIN).sort((x, y) => y.s - x.s).slice(0, 3);
}
/* الحفظ: الرد اللي الأداة طلّعته + البصمة — من غير نص رسالة العميل */
function caseKeep(text, title){
  const r = $('caseReplyTxt'); const reply = r ? r.textContent.trim() : ''; if(!reply) return 'empty';
  const sig = caseSig(text), T = String(title || '').replace(/\s+/g, ' ').trim().slice(0, 140) || t('حالة محفوظة','Saved case');
  if(ADDED.some(k => k.kind === 'case' && k.reply === reply)) return 'dup';
  const item = { sev:'ok', kind:'case', t:{ar:T, en:T}, src:{ar:'حالة اتحلّت — اتحفظت من حلّل رسالة عميل', en:'A resolved case — saved from Analyse a customer message'},
    body:{ar:'<pre class="pre">' + esc(reply) + '</pre>', en:'<pre class="pre">' + esc(reply) + '</pre>'}, reply, sig, at:new Date().toISOString() };
  ADDED.push(item); LEARNED.push(item); addedStore();
  return 'ok';
}
/* بعد كل تحليل: الحالات الشبيهة فوق، وشريط الحفظ تحت */
function caseAfter(text){
  const out = $('caseOut'); if(!out || !out.innerHTML) return;
  ['caseSim', 'caseKeepBar'].forEach(id => { const x = $(id); if(x) x.remove(); });
  const sim = caseSimilar(text);
  if(sim.length){
    out.insertAdjacentHTML('afterbegin', `<div class="panel" id="caseSim" style="margin-bottom:12px; border-inline-start:4px solid var(--signal)"><div class="sec" style="border-top:0">
      <h3>${t('حالة شبيهة اتحلّت قبل كده','A similar case was resolved before')}</h3>
      ${sim.map((x, i) => `<details ${i === 0 ? 'open' : ''} style="margin-top:6px"><summary style="cursor:pointer"><b>${esc(x.k.t.ar)}</b>
          <span style="color:var(--muted); font-size:12px"> · ${t('تشابه','match')} ${Math.round(Math.min(1, x.s) * 100)}% · ${esc(String(x.k.at || '').slice(0, 10))}</span></summary>
        <pre class="pre" style="white-space:pre-wrap; font-size:12.5px; margin-top:6px">${esc(x.k.reply || '')}</pre>
        <button class="btn ghost" data-simcopy="${i}" style="padding:3px 10px; font-size:12px">${t('انسخ الرد ده','Copy this reply')}</button></details>`).join('')}
      <div style="font-size:12px; color:var(--muted); margin-top:6px">${t('المقارنة على المسارات وأكواد الأخطاء والكلمات التقنية — اتأكد إن الحالة فعلًا زيها قبل ما تبعت.','Matched on paths, error codes and technical words — check the case really is the same before sending.')}</div>
    </div></div>`);
    out.querySelectorAll('[data-simcopy]').forEach(b => b.onclick = ()=>copy(sim[+b.dataset.simcopy].k.reply, t('الرد اتنسخ','Reply copied')));
  }
  if($('caseReplyTxt')){
    const v = out.querySelector('.caseVerdict'); const title = v ? (v.querySelector('div[style*="font-weight:600"]') || v).textContent : '';
    out.insertAdjacentHTML('beforeend', `<div class="row" id="caseKeepBar" style="margin-top:10px">
      <button class="btn ghost" id="caseKeep">${t('احفظ الحالة دي للفريق','Save this case for the team')}</button>
      <span style="font-size:12px; color:var(--muted); align-self:center">${t('بعد ما الرد ينفع مع العميل. بيتحفظ الرد وبصمة تقنية للحالة بس — مش نص الرسالة.','Once the reply worked with the customer. Only the reply and a technical fingerprint are kept — not the message text.')}</span></div>`);
    $('caseKeep').onclick = ()=>{ const r = caseKeep(text, title); toast(r === 'dup' ? t('متحفوظة قبل كده','Already saved') : r === 'ok' ? t('اتحفظت — صدّرها من الأساسيات عشان توصل للكل','Saved — export from Basics so everyone gets it') : t('مفيش رد يتحفظ','No reply to save')); if(r !== 'empty') $('caseKeep').disabled = true; };
  }
}
"""

# ── ١) الكود قبل renderCase + نداء بعد كل تحليل ─────────────────
rep("\nfunction renderCase(text){\n  const out = $('caseOut');",
    MAIL_JS + "\nfunction renderCase(text){\n  setTimeout(() => caseAfter(text), 0);   /* v7.4: حالات شبيهة + حفظ — بعد أي عارض */\n  const out = $('caseOut');", tag='الإيميل والحالات الشبيهة')

# ── ٢) زرار الإيميل + السحب ─────────────────────────────────────
rep("""        <label class="btn ghost" style="cursor:pointer">${t('أو ارفع صورة الرد','or upload the response image')}
          <input type="file" id="caseImg" accept="image/*" hidden></label>
        <button class="btn ghost" id="caseClear">${t('مسح','Clear')}</button>""",
"""        <label class="btn ghost" style="cursor:pointer">${t('أو ارفع صورة الرد','or upload the response image')}
          <input type="file" id="caseImg" accept="image/*" hidden></label>
        <label class="btn ghost" style="cursor:pointer" title="${esc(t('اسحب الإيميل من Outlook للديسكتوب (.msg) أو احفظه .eml','Drag the email from Outlook to the desktop (.msg) or save it as .eml'))}">${t('أو ارفع الإيميل (.msg / .eml)','or upload the email (.msg / .eml)')}
          <input type="file" id="caseMail" accept=".msg,.eml,message/rfc822,application/vnd.ms-outlook" hidden></label>
        <button class="btn ghost" id="caseClear">${t('مسح','Clear')}</button>""", tag='زرار الإيميل')
rep("""  $('aiGo').onclick = ()=>aiRun($('caseText').value);""",
"""  $('aiGo').onclick = ()=>aiRun($('caseText').value);
  $('caseMail').onchange = ev => { const f = ev.target.files[0]; if(f) mailIngest(f); ev.target.value = ''; };
  /* سحب إيميل .msg/.eml على الخانة — الصور ليها معالجها */
  $('caseText').addEventListener('drop', ev => { const f = ev.dataTransfer && ev.dataTransfer.files && ev.dataTransfer.files[0];
    if(f && /\\.(msg|eml)$/i.test(f.name || '')){ ev.preventDefault(); ev.stopImmediatePropagation(); mailIngest(f); } }, true);""", tag='ربط الإيميل')

# ── ٣) البصمة والرد بيعدّوا على التنضيف ─────────────────────────
rep("""    body:{ar: body(B.ar), en: body(B.en||B.ar)},
    at:  typeof x.at==='string' ? x.at : ''
  };
}""",
"""    body:{ar: body(B.ar), en: body(B.en||B.ar)},
    at:  typeof x.at==='string' ? x.at : '',
    /* v7.4: حالة محفوظة — الرد نص عادي، والبصمة كلمات قصيرة بس */
    ...(x.kind === 'case' ? (()=>{ const L = (a, n) => Array.isArray(a) ? a.filter(v => typeof v === 'string' && v.length <= 60).slice(0, n) : [];
      const g = x.sig || {}; return {kind:'case', reply: typeof x.reply === 'string' ? x.reply.slice(0, 6000) : '', sig:{tok:L(g.tok, 80), paths:L(g.paths, 10), errs:L(g.errs, 10), mk:L(g.mk, 5)}}; })() : {})
  };
}""", tag='التنضيف بيحفظ البصمة')

# ── ٤) طبقة Claude ما تزحمش ────────────────────────────────────
rep("""  return `<div id="aiSet" class="panel" style="margin-top:10px" ${aiReady() ? 'hidden' : ''}><div class="sec" style="border-top:0">""",
    """  return `<div id="aiSet" class="panel" style="margin-top:10px" hidden><div class="sec" style="border-top:0">""", tag='الإعدادات مقفولة')
rep("""        <button class="btn" id="aiGo" ${aiReady() ? '' : 'disabled'} title=""",
    """        <button class="btn" id="aiGo" ${aiReady() ? '' : 'hidden'} title=""", tag='زرار Claude مستخبي من غير مفتاح')
rep("""    const box = $('aiSet'); if(box) box.hidden = aiReady(); const b = $('aiGo'); if(b) b.disabled = !aiReady(); };""",
    """    const box = $('aiSet'); if(box) box.hidden = aiReady(); const b = $('aiGo'); if(b) b.hidden = !aiReady(); };""", tag='الزرار بعد الحفظ')
rep("""  out.insertAdjacentHTML('afterbegin', `<div class="note sig" style="margin-bottom:10px"><b>${t('القواعد ما عرفتش الحالة دي.','The rules did not recognise this case.')}</b> ${aiReady()
    ? t('اضغط «افهمها بـ Claude» وهتاخد الفهم والتشخيص والرد من التوثيق الرسمي.','Press "Understand with Claude" for the understanding, the diagnosis and the reply from the official documentation.')
    : t('حط مفتاح Anthropic في الإعدادات تحت و«افهمها بـ Claude» هتفهمها من التوثيق الرسمي.','Add an Anthropic key in the settings below and "Understand with Claude" will handle it from the official documentation.')}</div>`);""",
"""  out.insertAdjacentHTML('afterbegin', `<div class="note sig" style="margin-bottom:10px"><b>${t('القواعد ما عرفتش الحالة دي.','The rules did not recognise this case.')}</b> ${aiReady()
    ? t('اضغط «افهمها بـ Claude» وهتاخد الفهم والتشخيص والرد من التوثيق الرسمي.','Press "Understand with Claude" for the understanding, the diagnosis and the reply from the official documentation.')
    : t('دوّر على الريكوست من تبويب الريكوستات، أو ابعت للعميل الطلب اللي تحت، أو صعّدها. ولما تتحل، احفظها للفريق عشان المرة الجاية تطلع هنا كحالة شبيهة.','Look the request up in the Requests tab, send the customer the request below, or escalate. Once resolved, save it for the team so it shows here as a similar case next time.')}</div>`);""", tag='اقتراح من غير مفتاح')
rep("""  box.innerHTML = (lastQ && lastQ.trim().length > 6 ? `<button class="chip" id="aiAskR\"""",
    """  box.innerHTML = (aiReady() && lastQ && lastQ.trim().length > 6 ? `<button class="chip" id="aiAskR\"""", tag='شريحة البحث بالمفتاح بس')
rep("""      <button class="btn sig" id="aiAsk0">${t('اسأل Claude عن ده','Ask Claude about it')}</button>""",
    """      <button class="btn sig" id="aiAsk0" ${aiReady() ? '' : 'hidden'}>${t('اسأل Claude عن ده','Ask Claude about it')}</button>""", tag='زرار البحث بالمفتاح بس')
rep("""    <div style="font-size:12.5px; color:var(--muted); margin-top:8px">${t('Claude بيجاوب من التوثيق الرسمي بس، وكل مسار بيتفحص قبل ما يظهر.','Claude answers from the official documentation only, and every path is checked before it is shown.')}</div></div></div>`;""",
    """    ${aiReady() ? `<div style="font-size:12.5px; color:var(--muted); margin-top:8px">${t('Claude بيجاوب من التوثيق الرسمي بس، وكل مسار بيتفحص قبل ما يظهر.','Claude answers from the official documentation only, and every path is checked before it is shown.')}</div>` : ''}</div></div>`;""", tag='سطر Claude بالمفتاح بس')

# ── ٥) مكان المحلّل: بلوك سكريبت بعد الأساسي ─────────────────────
rep("""authGate(boot);
</script>
</body>""", """authGate(boot);
</script>
<script>/*__MSGREADER__*/</script>
</body>""", tag='مكان المحلّل')

io.open(PATH, 'w', encoding='utf-8').write(src)
print('القالب: %d → %d بايت' % (orig, len(src)))

# ── ٦) البناء: حقن المحلّل، ورزمه في الزيب، وعلامة ───────────────
bp = os.path.join(HERE, 'build.py'); bb = io.open(bp, encoding='utf-8').read()
edits = [
 ("""    full = tpl.replace('/*__KB__*/', kb).replace('/*__DOCS__*/', docs).replace('/*__KBIN__*/', kb_in)""",
  """    # v7.4: قارئ إيميلات Outlook (.msg) — متحزّم في ملف واحد ومتثبّت على 1.28.0
    msgr = open(os.path.join(HERE, 'vendor_msgreader.min.js'), encoding='utf-8').read()
    assert '</script' not in msgr.lower(), 'المحلّل فيه </script>'
    assert '/*__MSGREADER__*/' in tpl, 'علامة قارئ الإيميلات ناقصة في القالب'
    full = tpl.replace('/*__KB__*/', kb).replace('/*__DOCS__*/', docs).replace('/*__KBIN__*/', kb_in).replace('/*__MSGREADER__*/', msgr)"""),
 ("""    pub = pub.replace('/*__KB__*/', kb).replace('/*__DOCS__*/', docs).replace('/*__KBIN__*/', kb_in)""",
  """    pub = pub.replace('/*__KB__*/', kb).replace('/*__DOCS__*/', docs).replace('/*__KBIN__*/', kb_in).replace('/*__MSGREADER__*/', msgr)"""),
 ("""                                'build_kb_from_collection.py', 'avl_integration_documentation.postman_collection.json'))""",
  """                                'build_kb_from_collection.py', 'avl_integration_documentation.postman_collection.json',
                                # v7.4: قارئ .msg المتحزّم (Apache-2.0) — نسخة الأداة بتتبني منه
                                'vendor_msgreader.min.js'))"""),
 ("""    ('function aiValidate',          'Claude جوه الأداة — وكل مسار بيتفحص'),\n]""",
  """    ('function aiValidate',          'Claude جوه الأداة — وكل مسار بيتفحص'),\n    ('function mailIngest',          'إيميل Outlook من غير لقطة شاشة'),\n    ('function caseSimilar',         'حالات شبيهة اتحلّت قبل كده'),\n    ('AfaqyMsgReader=',              'قارئ .msg متحزّم جوه الأداة'),\n]"""),
]
for o, n in edits:
    if n.split('\n')[0] in bb and o not in bb: continue
    if bb.count(o) != 1: raise SystemExit('MISMATCH build.py: ' + o[:80])
    bb = bb.replace(o, n)
io.open(bp, 'w', encoding='utf-8').write(bb); print('  ok  البناء')
