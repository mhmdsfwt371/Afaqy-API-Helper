/* التدفق السريع من أول IMEI لآخر curl. اتكتب بعد ما اتكشف إن ladderCore
   اتشالت وسابت runQuick بتنده عليها — والتدفق كان بيقع صامت. */
const fs=require('fs');
const R={};
function el(id){return{id,hidden:false,innerHTML:'',value:'',textContent:'',className:'',dataset:{},style:{},files:[],disabled:false,
 classList:{toggle(){},add(){},remove(){}},querySelectorAll(){return[]},addEventListener(){},focus(){},select(){},click(){},
 setAttribute(){},getAttribute(){return null},dispatchEvent(){},appendChild(){},remove(){},scrollIntoView(){},onclick:null}}
global.document={documentElement:el(),body:el(),addEventListener(){},querySelectorAll(){return[]},
 querySelector(){return null},createElement(){return el()},getElementById(i){return R[i]||(R[i]=el(i))}};
global.history={pushState(){},replaceState(){}};global.location={hash:'',pathname:'/',replace(){},reload(){}};
global.setInterval=()=>0;global.navigator={clipboard:{writeText(){return Promise.resolve()}}};
global.window={scrollTo(){},addEventListener(){}};
global.AbortController=function(){this.signal={};this.abort=()=>{}};
global.Blob=function(){};global.URL={createObjectURL(){return''}};global.FileReader=function(){};
global.fetch=()=>Promise.resolve({ok:true,status:200,text:()=>Promise.resolve(JSON.stringify(
 {message:'success',status_code:200,data:{items:[{_id:'U1',name:'NB YD',imei:'357454075086551'}],messages:[{pos:{speed:40}}]}}))});
let js=fs.readFileSync('app_template.html','utf8').split('<script>')[1].split('</script>')[0]
 .replace('/*__KB__*/',fs.readFileSync('kb_slim.json','utf8'))
 .replace('/*__DOCS__*/',fs.readFileSync('docs.json','utf8'));
const m={};new Function('module',js+"\nmodule.exports={SESSION,runQuick,QUICK,EPS,ladderCore};")(m);
const A=m.exports;
const fail=s=>{console.error('فشل: '+s);process.exit(1)};
if(typeof A.ladderCore!=='function') fail('ladderCore مش موجودة');
(async()=>{
  A.SESSION.token='T'; A.SESSION.user='u'; A.SESSION.pass='p';
  A.QUICK.ep = A.EPS.find(e=>e.p==='/units/signals');
  Object.assign(R, {qkImei:{value:'357454075086551'}, qkFrom:{value:'2026-08-01'},
                    qkTo:{value:'2026-08-02'}, qkGo:{disabled:false,textContent:'جهّز'}});
  await A.runQuick();
  const out = (R['qkOut']&&R['qkOut'].innerHTML)||'';
  if(!out) fail('التدفق ما طلّعش حاجة');
  const txt = out.replace(/<[^>]+>/g,' ').replace(/\s+/g,' ');
  if(txt.indexOf('NB YD')<0) fail('ما لقاش العربية بالـ IMEI');
  if(txt.indexOf('U1')<0) fail('الـ UID مش ظاهر');
  if(out.indexOf('curl')<0) fail('الـ curl مش موجود');
  if(!A.SESSION.unit || A.SESSION.unit.uid!=='U1') fail('العربية ما اتحددتش للجلسة');
  console.log('التدفق السريع: IMEI → UID → تجربة → curl  ✓');
  console.log('  العربية: '+A.SESSION.unit.name+'  UID: '+A.SESSION.unit.uid);
})();
