/* v6.53 — «إيه الـ API اللي بيرجّع الحقول دي؟» من لقطة كارت العربية في المنصة.
   النص هنا شكل قراءة الصورة (المرحلة الأولى) من غير أي اسم حقيقي — الريبو عام. */
const fs=require('fs'); const {JSDOM}=require('jsdom');
let F=0; const ok=(m,c,x)=>{ console.log((c?'  \u2713 ':'  \u2717 ')+m+(c||!x?'':'  \u2014 '+String(x).slice(0,170))); if(!c) F++; };
const html=fs.readFileSync(process.argv[2]||'app_template.html','utf8')
  .replace('/*__KB__*/',()=>fs.readFileSync('kb_slim.json','utf8'))
  .replace('/*__DOCS__*/',()=>fs.readFileSync('docs.json','utf8'))
  .replace('/*__KBIN__*/',()=>fs.readFileSync('kb_in.json','utf8'));
const PANEL=`Dear team,

We need your help in identifying the correct API for the below info. Request you to please share API details along with sample request body.

| 1234-A B C =
34 Seconds ago
18.307653427124,42.698890686035
Vehicle Metrics
(7) Speed      @ Engine Hours  ( Odometer
OKM/H          OH              22553KkM
Position Data
@ Angle        m] Altitude     £8 Satellites
168°           2013M           12
Proximity Information
©, Nearest Geofence      (Db Nearest Marker
Zone-A    269.85 KM      0.00 KM
@ Main Info
25-10-2026 12:08:20
25-10-2026 12:08:38
Company      Example Co
Operation Code:
4 Sensors 8
AACC         ON
Wweight      14500 KG
WDevice Battery   4a02v`;
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
function boot(){ const w=new JSDOM(html,{runScripts:'dangerously',pretendToBeVisual:true,url:'https://localhost/'}).window;
  w.alert=()=>{}; w.scrollTo=()=>{}; w.URL.createObjectURL=()=>'blob:x'; w.HTMLAnchorElement.prototype.click=function(){}; return w; }
(async()=>{
/* ١) التعرف والخريطة */
{ const w=boot(); const a=w.analyzeCase(PANEL);
  ok('اتعرفت كحالة «حقول من المنصة» مش تذكرة ناقصة أدلة', a.fieldsCase===true && !a.reqCase);
  const ids=a.fields.hits.map(h=>h.id);
  ok('POS و SRV اتحددوا من التوقيتين حتى من غير اسم الخانة', ids.includes('pos') && ids.includes('srv'), ids.join(','));
  ['coords','speed','angle','alt','acc','engine_hours','odometer','sensors'].forEach(id=>ok('حقل متعرّف: '+id, ids.includes(id)));
  ['sat','geo','marker','company','opcode'].forEach(id=>ok('متعرّف ومتعلّم «مش في الرد»: '+id, a.fields.hits.find(h=>h.id===id && h.src==='none')));
  const M=w.eval('FIELD_MAP');
  ok('POS = last_update.dtt و SRV = last_update.dts (من رد التوثيق)', M.find(f=>f.id==='pos').path==='last_update.dtt' && M.find(f=>f.id==='srv').path==='last_update.dts');
  ok('كل حقل مربوط بمسار ليه مصدر (doc أو verified)، واللي من غير مسار متعلّم none', M.every(f=>f.path ? ['doc','verified'].includes(f.src) : f.src==='none'));
}
/* ٢) الرد: الريكوست الموثّق بالـ IMEI، والخريطة، ومن غير اختراع */
{ const w=boot(); w.eval("SESSION.unit={uid:'5e6790e103ed52cf443362c9', name:'L S A-6220', imei:'861230044934025'}");
  const a=w.analyzeCase(PANEL), rep=w.caseReply(a);
  ok('الرد بالريكوست الموثّق /units/lists مفلتر بالـ IMEI اللي فوق', /POST https:\/\/api\.afaqy\.sa\/units\/lists\?token=<YOUR_TOKEN>\n\{"data":\{"offset":0,"limit":1,"projection":\["basic","last_update","counters","sensors"\],"filters":\{"imei":\{"value":\["861230044934025"\],"op":"in"\}\}\}\}/.test(rep), rep.slice(0,300));
  ok('POS و SRV في الرد بمساراتهم ومعناهم', /POS — time of the last position: last_update\.dtt — .*epoch milliseconds/.test(rep) && /SRV — time the server received it: last_update\.dts/.test(rep));
  ok('ساعات المحرك بالثواني ÷ 3600', /counters\.engine_hours — In seconds — divide by 3600/.test(rep));
  ok('اللي مش في الرد متقال صراحة', /Not part of this response: Satellites, Nearest geofence, Nearest marker, Company, Operation code\./.test(rep));
  ok('مفيش مسار مخترع للأقمار ولا للشركة', !/satellite[^s,]*: \w+\./i.test(rep) && !/Company: \S+_\S+/.test(rep));
  ok('العربي للرسالة العربية / الإنجليزي للإنجليزية', /^Hello,/.test(rep) && /^السادة/.test(w.fieldsReply(a,'ar')));
  const col=w.pmFromCase(a);
  ok('الكولكشن: دخول + الريكوست، و imei متعبّي', col.item.length===2 && /\/units\/lists/.test(col.item[1].request.url.raw) && col.variable.find(v=>v.key==='imei').value==='861230044934025');
}
/* ٣) مفيش IMEI: الرد بـ <IMEI> والملاحظة بتقول حدّد العربية */
{ const w=boot(); w.eval('SESSION.unit=null; SESSION.token=null'); w.showView('inspect'); w.eval("INSPVIEW='case'"); w.paintInspect();
  w.document.getElementById('caseText').value=PANEL; w.document.getElementById('caseGo').click(); await sleep(40);
  const out=w.document.getElementById('caseOut').textContent;
  ok('من غير IMEI: الرد بـ <IMEI>', /"value":\["<IMEI>"\]/.test(w.document.getElementById('caseReplyTxt').textContent));
  ok('والملاحظة بتقول حدّد العربية من الشريط', /حدّد العربية من الشريط/.test(out));
}
/* ٤) لايف: نفس الريكوست مرة واحدة، والقيم جنب كل حقل، والتوقيت بتوقيت السعودية */
{ const w=boot(); w.__calls=[];
  w.eval(`SESSION.token='T'; SESSION.unit={uid:'5e6790e103ed52cf443362c9', name:'L S A-6220', imei:'861230044934025'};
    apiFetch = async (p,b)=>{ window.__calls.push(p+' '+JSON.stringify(b)); return {ok:true,status:200,json:{status_code:200,data:[
      {id:'5e6790e103ed52cf443362c9', name:'L S A-6220', imei:'861230044934025', counters:{odometer:22553, engine_hours:7200},
       last_update:{dtt:1792919300000, dts:1792919318000, spd:0, ang:168, alt:2013, acc:1, lat:18.3, lng:42.6,
         sensors_chDate:{w:[{sensorValue:{name:'Weight', value:14500, representation:'14500 KG'}}]}}}]}}; };`);
  w.showView('inspect'); w.eval("INSPVIEW='case'"); w.paintInspect();
  w.document.getElementById('caseText').value=PANEL; w.document.getElementById('caseGo').click(); await sleep(120);
  const out=w.document.getElementById('caseOut').textContent;
  ok('الأداة نادت نفس الريكوست اللي في الرد مرة واحدة', w.__calls.length===1 && /"filters":\{"imei":\{"value":\["861230044934025"\]/.test(w.__calls[0]), w.__calls.join(' | '));
  ok('قيمة POS لايف محوّلة لتوقيت السعودية', /1792919300000 → .*\(KSA\)/.test(out), out.slice(out.indexOf('POS')).slice(0,200));
  ok('ساعات المحرك لايف بالساعات', /7200 s → 2\.0 h/.test(out));
  ok('الحساسات لايف بالعرض', /Weight: 14500 KG/.test(out));
  ok('العداد لايف', /22553/.test(out));
  w.document.getElementById('caseGo').click(); await sleep(60);
  ok('تحليل تاني ما بينادش تاني', w.__calls.length===1);
}
/* ٥) مش بيبلع حالات تانية */
{ const w=boot();
  const T1='POST https://api.afaqy.sa/units/locations\n{"data":{"unit_id":"861230044934025"}}\n{"message":"not_allowed","status_code":401,"data":[]}\nWhat is wrong with the speed and odometer and engine hours?';
  ok('تذكرة فيها مسار وخطأ فضلت تذكرة', w.analyzeCase(T1).fieldsCase===false);
  ok('كلام عن الحقول من غير طلب API مش حالة حقول', w.analyzeCase('The speed, odometer and engine hours look wrong on the screen today.').fieldsCase===false);
  const L='We would like to integrate:\n1. Vehicle ID and plate\n2. Distance per day\n3. Engine hours\n4. Fuel level\n- API documentation';
  ok('لستة بيانات مرقّمة فضلت طلب إنتجريشن', w.analyzeCase(L).reqCase===true && w.analyzeCase(L).fieldsCase===false);
}
console.log(F?`\nفشل ${F}`:'\nحقول كارت المنصة: تمام'); process.exit(F?1:0);
})();
