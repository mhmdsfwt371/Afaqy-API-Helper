/* رصد ريكوست من المنصة: تحليل الـ cURL، ومقارنته بالكولكشن، وتطبيق التصحيح */
const fs=require('fs');
const R={};
function el(id){return{id,hidden:false,innerHTML:'',value:'',textContent:'',className:'',dataset:{},style:{},files:[],disabled:false,
 placeholder:'',classList:{toggle(){},add(){},remove(){}},querySelectorAll(){return[]},addEventListener(){},focus(){},select(){},
 click(){},setAttribute(){},getAttribute(){return null},dispatchEvent(){},appendChild(){},remove(){},scrollIntoView(){},onclick:null}}
global.document={documentElement:el(),body:el(),addEventListener(){},querySelectorAll(){return[]},
 querySelector(){return null},createElement(){return el()},getElementById(i){return R[i]||(R[i]=el(i))}};
global.history={pushState(){},replaceState(){}};global.location={hash:'',pathname:'/',replace(){},reload(){}};
global.setInterval=()=>0;global.navigator={clipboard:{writeText(){return Promise.resolve()}}};
global.window={scrollTo(){},addEventListener(){}};global.fetch=()=>Promise.reject(0);
global.AbortController=function(){this.signal={};this.abort=()=>{}};
global.Blob=function(){};global.URL=class{constructor(u){const m=String(u).match(/^https?:\/\/[^/]+(\/[^?#]*)/);this.pathname=m?m[1]:'/';}
 static createObjectURL(){return''}};
global.FileReader=function(){};
let js=fs.readFileSync('app_template.html','utf8').split('<script>')[1].split('</script>')[0]
 .replace('/*__KB__*/',fs.readFileSync('kb_slim.json','utf8')).replace('/*__KBIN__*/', fs.readFileSync('kb_in.json','utf8'))
 .replace('/*__DOCS__*/',fs.readFileSync('docs.json','utf8'));
const m={};new Function('module',js+
 "\nmodule.exports={parseCurl,capBody,analyzeCapture,OVERRIDES,CAP,LEARNED,EPS,labVariants,SESSION};")(m);
const A=m.exports;
const fail=s=>{console.error('فشل: '+s);process.exit(1)};
const strip=h=>String(h||'').replace(/<[^>]+>/g,' ').replace(/\s+/g,' ').trim();

// اللقطة الحقيقية اللي بعتها
const CURL = `curl 'https://api.afaqy.sa/units/getAddress?token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.SECRET.sig' \\
  -H 'Content-Type: application/x-www-form-urlencoded' \\
  -H 'Accept: application/json' \\
  --data-raw 'data=%7B%22lat%22%3A%2221.503312857817008%22%2C%22lng%22%3A%2239.183279590869745%22%7D'`;

const p=A.parseCurl(CURL);
if(!p) fail('ما حللش الـ cURL');
if(p.url.indexOf('/units/getAddress')<0) fail('اللينك غلط');
if(!p.form) fail('ما عرفش إنه form-encoded');
console.log('تحليل الـ cURL   : '+p.method+' '+p.url.split('?')[0]+'  ·  form-encoded ✓');

const b=A.capBody(p);
if(b.shape.indexOf('form-encoded')<0) fail('شكل البودي غلط: '+b.shape);
if(!b.obj || !b.obj.data || b.obj.data.lat!=='21.503312857817008') fail('ما فكّش الـ data الصح');
console.log('فك البودي        : '+b.shape+'  ·  lat='+b.obj.data.lat+' ✓');

A.analyzeCapture(CURL);
const out=strip(R['capOut'].innerHTML);
if(out.indexOf('موجود في الكولكشن')<0) fail('ما لقاش الإندبوينت في الكولكشن');
if(out.indexOf('شكل البودي مختلف')<0) fail('ما رصدش فرق شكل البودي');
if(out.indexOf('SECRET')>=0) fail('التوكن ظاهر في العرض!');
if(out.indexOf('YOUR_TOKEN')<0) fail('التوكن ما اتشطبش');
console.log('التحليل          : لقى الفرق، والتوكن متشطوب ✓');

// التطبيق
const before=A.LEARNED.length;
if(!R['capApply']||!R['capApply'].onclick) fail('زرار التطبيق مش موجود');
R['capApply'].onclick();
const ep=A.CAP.ep;
if(!A.OVERRIDES[ep.i]) fail('ما اتسجّلش التصحيح');
if(A.LEARNED.length!==before+1) fail('ما اتسجّلش في المعرفة');
if(A.LEARNED[0].body.ar.indexOf('SECRET')>=0) fail('التوكن اتسجّل في المعرفة!');
console.log('التطبيق          : اتسجّل في التصحيح والمعرفة، والتوكن متشال ✓');

// الشكل المرصود بقى أول صيغة
const vs=A.labVariants(ep);
if(vs[0].n!=='الشكل المرصود من المنصة') fail('الشكل المرصود مش أول صيغة: '+vs[0].n);
if(vs[0].raw===undefined || vs[0].raw.indexOf('data=')!==0) fail('الصيغة المرصودة شكلها غلط');
if(vs[0].h['Content-Type']!=='application/x-www-form-urlencoded') fail('الهيدر غلط');
console.log('الترتيب          : الشكل المرصود بقى أول حاجة تتجرّب ✓');

// نص مش cURL
A.analyzeCapture('مش cURL خالص');
if(strip(R['capOut'].innerHTML).indexOf('مش أمر cURL')<0) fail('ما مسكش النص الغلط');
console.log('نص غلط           : اتمسك برسالة واضحة ✓');

// إندبوينت مش في الكولكشن
A.analyzeCapture("curl 'https://api.afaqy.sa/something/new' -H 'Content-Type: application/json' --data-raw '{\"data\":{}}'");
if(strip(R['capOut'].innerHTML).indexOf('مش في الكولكشن أصلًا')<0) fail('ما نبّهش إن الإندبوينت جديد');
if(A.CAP.ep) fail('طابق إندبوينت غلط');
console.log('إندبوينت جديد    : اتنبّه عليه ✓');
