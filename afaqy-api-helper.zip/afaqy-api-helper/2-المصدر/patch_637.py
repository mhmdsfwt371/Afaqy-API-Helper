#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v6.37 — التشخيص بقى جدول أنماط، مش حالة واحدة.

كانت الأداة فيها حالة واحدة متشخّصة (التقارير) مربوطة في ثمن مواضع
بـ if. أي رسالة تانية كانت بتروح على «ناقص أدلة» وتطلب من الموظف
يبعت حاجات.

دلوقتي: جدول قواعد. كل قاعدة بتوصف نمط بيتكرر، وبتقرا دليلها من
الرسالة نفسها، وبتطلّع السلسلة الصح — والسلسلة دي بتغذّي الرد
والكولكشن مع بعض. حالة التقارير بقت القاعدة الأولى في الجدول.
"""
import sys, io

PATH = sys.argv[1] if len(sys.argv) > 1 else 'app_template.html'
src = io.open(PATH, encoding='utf-8').read()
orig = len(src)

def rep(old, new, n=1, tag=''):
    global src
    c = src.count(old)
    if c != n: raise SystemExit('MISMATCH [%s]: expected %d found %d\n---\n%s' % (tag, n, c, old[:220]))
    src = src.replace(old, new, n); print('  ok  %s' % tag)

ENGINE = r"""
/* ═══════════ محرّك تشخيص رسايل العملاء ═══════════
   كل قاعدة = نمط بيتكرر في رسايل التكامل، مش حالة واحدة.

   hit(a)   بتقرا الدليل من الرسالة وترجّع {score, ev[]} أو null.
            الدليل نص بيتعرض للموظف — عشان يشوف الأداة اتكلت على إيه
            ويقدر يكذّبها، مش ياخد الحكم على عماه.
   chain(a) السلسلة الصح. بتغذّي الرد والكولكشن الاتنين من نفس المصدر،
            فمستحيل يختلفوا.

   القاعدة اللي score بتاعها أعلى هي اللي بتتعرض. الترتيب في الجدول
   ما بيفرقش — النتيجة هي اللي بتحكم. */

/* هل الرسالة بتشتكي إن الرد رجع سليم بس من غير قيمة مفيدة؟ */
function _saysEmpty(a){
  return /empty|no data|no record|not return|nothing|returns \[\]|فاضي|فاضية|مرجعش|ما رجع|مفيش داتا/i
    .test(String(a.words||''));
}
function _saysOk(a){
  const raw = (a.blocks||[]).map(b=>b.raw).join(' ') + ' ' + String(a.words||'');
  return /200|success|successful|ناجح|سليم/i.test(raw);
}
/* الأرقام اللي شكلها IMEI: ١٥ رقم متتالية */
function _imeis(a){
  const all = String(a.words||'') + ' ' + (a.blocks||[]).map(b=>b.raw).join(' ');
  return (all.match(/\b\d{15}\b/g) || []).slice(0, 6);
}
/* المسارات اللي اتذكرت في الرسالة، منضّفة */
function _paths(a){
  return (a.paths||[]).map(p => String(p).replace(/\?.*$/, '').replace(/^https?:\/\/[^/]+/, ''))
                      .filter(Boolean);
}
/* بيدوّر على الإندبوينت في قاعدة المعرفة */
function _ep(path){
  if(!path) return null;
  const want = String(path).toLowerCase();
  return (typeof EPS !== 'undefined' ? EPS : []).find(e => String(e.p||'').toLowerCase() === want) || null;
}

const CASE_RULES = [

/* ①  كتالوج مكان تنفيذ — حالة التقارير نموذج منه، مش استثناء */
{ id:'catalog-vs-data',
  name:{ar:'كتالوج مكان تنفيذ', en:'A catalog where execution was needed'},
  hit(a){
    const ps = _paths(a);
    const cat = ps.filter(p => /\/(lists|view|templates)$/.test(p) || /\/reports\/lists/.test(p));
    const wantsValues = /value|values|actual|real data|records|قيم|قيمة|بيانات فعلية/i.test(String(a.words||''));
    if(a.reportCase) return {score:100, ev:[
      t('الرسالة فيها أسماء حقول وأكوادها من غير قيم','The message carries field names and codes without values'),
      t('والعميل طالب القيم الفعلية صراحة','and the customer explicitly asks for the actual values')]};
    if(!cat.length || !wantsValues) return null;
    return {score:70, ev:[
      t(`نادى ${cat[0]} وده إندبوينت لستة`, `Called ${cat[0]}, which is a listing endpoint`),
      t('وطالب قيم فعلية','and asked for actual values')]};
  },
  mistake:{ar:'نادى إندبوينت بيرجّع تعريفات وهو عايز نتيجة تنفيذ.',
           en:'Called an endpoint that returns definitions while wanting an execution result.'},
  why:{ar:'العائلتين اسمهم متقارب، واللستة بترجّع ٢٠٠ فمفيش حاجة توحي إن في غلط.',
       en:'The two families are named alike, and the listing answers 200, so nothing signals a mistake.'},
  chain(a){ return null; } },   /* التقارير ليها سلسلتها الخاصة تحت */

/* ②  قرا قبل ما التوليد يخلص */
{ id:'read-before-ready',
  name:{ar:'قرا قبل ما يخلص', en:'Read before it was ready'},
  hit(a){
    const ps = _paths(a);
    const reads = ps.filter(p => /(data-summary|data-new|\/data$|charts\/data)/.test(p));
    if(!reads.length) return null;
    if(!_saysEmpty(a)) return null;
    const ev = [t(`بيقرا من ${reads[0]}`, `Reading from ${reads[0]}`),
                t('والنتيجة راجعة فاضية','and the result comes back empty')];
    if(_saysOk(a)) ev.push(t('والرد نفسه ٢٠٠ وناجح','while the response itself is 200 and successful'));
    const polled = ps.some(p => /percentage/.test(p));
    if(polled) return null;                         /* بيتابع أصلاً — النمط مش ده */
    ev.push(t('ومفيش أي نداء على percentage في الرسالة','and no percentage call appears anywhere in the message'));
    return {score:85, ev};
  },
  mistake:{ar:'قرا الداتا والتوليد لسه شغّال، فرجعت فاضية ومعاها رد سليم.',
           en:'Read the data while generation was still running, so it came back empty with a valid response.'},
  why:{ar:'التوليد بيحصل على السيرفر بعد الإنشاء. الرد الفاضي بييجي بـ ٢٠٠ وmessage success، فشكله نجاح مش انتظار.',
       en:'Generation happens server-side after creation. The empty answer arrives as 200 with message success, so it reads as success rather than as waiting.'},
  chain(a){
    const isChart = _paths(a).some(p => /charts/.test(p));
    const fam = isChart ? 'charts' : 'user_reports';
    return [
      {m:'POST', p:'/'+fam+'/percentage', body:{data:{ids:['{{report_id}}']}},
       note:t('كرّرها كل تلات ثواني لحد ما percentage توصل ١٠٠. قبل كده الصفوف مش موجودة.',
              'Repeat every few seconds until percentage reaches 100. Before that the rows do not exist.')},
      {m:'POST', p:'/user_reports/data-summary', body:{data:{id:'{{report_id}}'}},
       note:t('دلوقتي بس الصفوف جاهزة.','Only now are the rows ready.')}
    ];
  } },

/* ③  IMEI مكان UID */
{ id:'imei-vs-uid',
  name:{ar:'IMEI مكان رقم العربية', en:'An IMEI where a unit id belongs'},
  hit(a){
    const ims = _imeis(a);
    if(!ims.length) return null;
    const ps = _paths(a);
    const needsUid = ps.some(p => {
      const e = _ep(p); const b = e ? String(e.b||'') : '';
      return /unit_id|"resources"|resource_id|unitId/.test(b);
    }) || /resources|unit_id|resource_id/i.test(String(a.words||''));
    const err = (a.errs||[]).length || /not_found|not found|invalid|غير موجود/i.test(String(a.words||''));
    if(!needsUid && !err) return null;
    const ev = [t(`في الرسالة رقم من ١٥ خانة (${ims[0]}) — ده شكل IMEI`,
                  `The message carries a 15-digit number (${ims[0]}), which is an IMEI`)];
    if(needsUid) ev.push(t('والريكوست بياخد رقم عربية مش رقم جهاز','and the request takes a unit id, not a device id'));
    if(err) ev.push(t('والرد رجع مش لاقي','and the response came back not-found'));
    return {score: needsUid && err ? 80 : 60, ev};
  },
  mistake:{ar:'بعت رقم الجهاز (IMEI) في خانة بتاخد رقم العربية (UID).',
           en:'Sent the device number (IMEI) where the unit id (UID) belongs.'},
  why:{ar:'الاتنين أرقام طويلة، والـ IMEI هو اللي مكتوب على الجهاز فطبيعي حد يفتكره المعرّف. الـ UID بيتجاب من نداء تاني.',
       en:'Both are long numbers, and the IMEI is the one printed on the device, so it is natural to assume it is the identifier. The UID comes from a separate call.'},
  chain(a){
    return [
      {m:'POST', p:'/units/lists', body:{data:{offset:0, limit:1000, projection:['basic']}},
       note:t('دوّر على العربية اللي imei بتاعها = بتاعك، وخد id بتاعها.',
              'Find the unit whose imei matches yours and take its id.')},
      {m:'POST', p:(_paths(a)[0] || '/units/view'), body:{data:{id:'{{unit_id}}'}},
       note:t('وبعدين نفس الريكوست بس بالـ id.','Then the same request, this time with the id.')}
    ];
  } },

/* ④  ريكوست محتاج حاجة قبله */
{ id:'needs-prereq',
  name:{ar:'ناقص خطوة قبله', en:'A prerequisite step is missing'},
  hit(a){
    const ps = _paths(a);
    for(const p of ps){
      const e = _ep(p);
      if(!e) continue;
      const b = String(e.b || '');
      /* الحقول اللي قيمتها لازم تيجي من نداء تاني */
      const refs = (b.match(/"(unit_id|user_id|driver_id|group_id|report_id|resource_id|template_id)"/g) || [])
                     .map(x => x.replace(/"/g, ''));
      if(refs.length && !/lists/.test(p)){
        return {score:55, ev:[
          t(`${p} بياخد ${refs.slice(0,3).join(' و')}`, `${p} takes ${refs.slice(0,3).join(', ')}`),
          t('والقيم دي بتيجي من نداءات تانية مش من عند العميل','and those values come from other calls, not from the customer')]};
      }
    }
    return null;
  },
  mistake:{ar:'الريكوست بياخد معرّفات بتيجي من نداءات قبله، والعميل بيملاها من عنده.',
           en:'The request takes identifiers produced by earlier calls, and the customer is filling them in by hand.'},
  why:{ar:'شكل البودي ما بيقولش المعرّف ده بيتجاب منين، فطبيعي حد يفتكره حاجة عنده.',
       en:'The body shape does not say where each identifier comes from, so it is natural to assume it is something you already hold.'},
  chain(a){
    const p = _paths(a)[0] || '';
    return [
      {m:'POST', p:'/units/lists', body:{data:{offset:0, limit:1000, projection:['basic']}},
       note:t('منها بتاخد رقم العربية.','This gives you the unit id.')},
      {m:'POST', p: p || '/units/view', body:{data:{id:'{{unit_id}}'}},
       note:t('وبعدين الريكوست الأصلي بالمعرّف الصح.','Then the original request with the correct identifier.')}
    ];
  } },

/* ⑤  ٢٠٠ وجواه خطأ */
{ id:'ok-with-error',
  name:{ar:'٢٠٠ وجواه خطأ', en:'A 200 carrying an error'},
  hit(a){
    if(!(a.errs||[]).length) return null;
    if(!_saysOk(a)) return null;
    return {score:75, ev:[
      t('الرد رجع بحالة نجاح','The response came back with a success status'),
      t('وجواه رسالة خطأ في نفس الوقت','and carries an error message at the same time')]};
  },
  mistake:{ar:'الكود بيعتبر ٢٠٠ نجاح، والمنصة بتبعت أخطاء جوه ٢٠٠.',
           en:'The integration treats 200 as success, while the platform returns errors inside a 200.'},
  why:{ar:'ده سلوك المنصة نفسها مش غلطة العميل. أي تكامل بيقيس على الـ status code لوحده هيعدّي الخطأ ده.',
       en:'This is the platform behaviour, not a customer mistake. Any integration that checks the status code alone will let this through.'},
  chain(a){ return null; },
  extra:{ar:'اقرا حقل message و status_code اللي جوه البودي، مش كود الـ HTTP بس.',
         en:'Read the message and status_code fields inside the body, not only the HTTP code.'} },

/* ⑥  فاضي مش عطلان */
{ id:'empty-not-broken',
  name:{ar:'فاضي مش عطلان', en:'Empty, not broken'},
  hit(a){
    if(!_saysEmpty(a) || !_saysOk(a)) return null;
    if((a.errs||[]).length) return null;
    const ps = _paths(a);
    if(ps.some(p => /(data-summary|data-new|charts\/data)/.test(p))) return null;  /* ده نمط ② */
    return {score:45, ev:[
      t('الرد ٢٠٠ وناجح','The response is 200 and successful'),
      t('والداتا راجعة فاضية من غير رسالة خطأ','and the data comes back empty with no error message')]};
  },
  mistake:{ar:'الرد سليم والداتا فاضية — وده مش عطل.',
           en:'The response is valid and the data is empty — and that is not a fault.'},
  why:{ar:'الفاضي هنا معناه إن الحساب مش شايف حاجة: يا الصلاحيات، يا مفيش موارد مربوطة، يا الفلتر ما طابقش.',
       en:'Empty here means the account sees nothing: either permissions, or no resources assigned, or a filter that matched nothing.'},
  chain(a){
    return [
      {m:'POST', p:'/units/lists', body:{data:{offset:0, limit:1000, projection:['basic']}},
       note:t('لو دي كمان رجعت فاضية، المشكلة صلاحيات مش الإندبوينت اللي بتسأل عنه.',
              'If this comes back empty too, the problem is permissions rather than the endpoint you are asking about.')}
    ];
  } }

];

/* أعلى قاعدة اتحققت. بنرجّع الدليل كمان عشان الموظف يقدر يكذّبنا. */
function caseMatch(a){
  if(!a) return null;
  let best = null;
  CASE_RULES.forEach(r => {
    let h = null;
    try { h = r.hit(a); } catch(e){ h = null; }
    if(h && h.score && (!best || h.score > best.h.score)) best = {r, h};
  });
  return best;
}

/* الرد المولّد من قاعدة — للحالات اللي مالهاش رد مكتوب بالإيد */
function ruleReply(a, m){
  const r = m.r, ch = r.chain(a);
  const L = [];
  L.push('Hello,');
  L.push('');
  L.push('Thank you for the detail. ' + (r.mistake.en));
  L.push('');
  L.push((r.why.en));
  if(r.extra){ L.push(''); L.push((r.extra.en)); }
  if(ch && ch.length){
    L.push('');
    L.push('The sequence that returns what you need:');
    L.push('');
    ch.forEach((s, i) => {
      L.push('  ' + String(i + 1) + '. ' + s.m + ' ' + s.p);
      L.push('     ' + JSON.stringify(s.body));
      if(s.note) L.push('     ' + String(s.note));
      L.push('');
    });
    L.push('A Postman collection with these requests is attached; the identifiers move between the steps on their own.');
  }
  L.push('');
  L.push('Please try this and tell us what comes back if anything differs.');
  L.push('');
  L.push('Best regards,');
  return L.join('\n');
}
"""

# ── ١) المحرّك قبل caseNeeds ────────────────────────────────
rep("function caseNeeds(a){", ENGINE.lstrip('\n') + "\nfunction caseNeeds(a){", 1, 'المحرّك')

# ── ٢) الرد: قاعدة التقارير ليها ردها، والباقي من المحرّك ──
rep("""  if(!a.reportCase) return null;""",
"""  if(!a.reportCase){
    /* مش حالة التقارير — نشوف الجدول. الرد المولّد أضعف من المكتوب
       بالإيد، بس أنفع بكتير من «ابعتلنا أدلة». */
    const m = caseMatch(a);
    return m ? ruleReply(a, m) : null;
  }""", 1, 'الرد من الجدول')

# ── ٣) الأدلة الناقصة: لو قاعدة اتحققت مفيش ناقص ───────────
rep("""  if(a && a.reportCase) return [];""",
"""  if(a && a.reportCase) return [];
  /* أي قاعدة اتحققت بدليل كافي = الحالة اتشخّصت، مش ناقصة أدلة */
  const _m = caseMatch(a);
  if(_m && _m.h.score >= 55) return [];""", 1, 'الأدلة الناقصة')

# ── ٤) الحكم بياخد اسم النمط ────────────────────────────────
rep("""  const missing = caseNeeds(a).length;
  if(a && a.reportCase) return {ok:true,""",
"""  const missing = caseNeeds(a).length;
  const m = caseMatch(a);
  if(m && !(a && a.reportCase) && m.h.score >= 55) return {ok:true,
    tag: dual(m.r.name),
    line: dual(m.r.mistake) + ' ' + t('الرد تحت فيه السلسلة الصح.','The reply below carries the correct sequence.')};
  if(a && a.reportCase) return {ok:true,""", 1, 'الحكم')

io.open(PATH, 'w', encoding='utf-8').write(src)
print('\ndone (%d -> %d, +%d)' % (orig, len(src), len(src) - orig))
