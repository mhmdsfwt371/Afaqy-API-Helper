/* v5.6 — كارت العربية: الشريحة وآخر إشارة وتاريخ الإضافة.
   اتكتب مع النسخة اللي زوّدتهم — الكارت لازم يعرضهم لما البيانات موجودة،
   ويستخبّوا من غير سطور فاضية لما مش موجودة. */
global.setInterval=()=>0;global.clearInterval=()=>{};
const fs = require('fs');
function el(id){return{id,hidden:false,innerHTML:'',value:'',textContent:'',className:'',dataset:{},style:{},files:[],disabled:false,
 classList:{toggle(){},add(){},remove(){}},querySelectorAll(){return[]},addEventListener(){},focus(){},select(){},click(){},
 setAttribute(){},getAttribute(){return null},dispatchEvent(){},appendChild(){},remove(){},scrollIntoView(){}}}
const R={};global.document={documentElement:el(),body:el(),addEventListener(){},querySelectorAll(){return[]},
 querySelector(){return null},createElement(){return el()},getElementById(i){return R[i]||(R[i]=el(i))}};
global.history={pushState(){},replaceState(){}};global.location={hash:'',pathname:'/',replace(){}};
global.navigator={userAgent:'node',clipboard:{writeText(){return Promise.resolve()}}};
global.window={scrollTo(){},addEventListener(){},matchMedia:()=>({matches:false}),navigator:{}};
global.fetch=()=>Promise.reject(0);global.Blob=function(){};global.URL={createObjectURL(){return''}};global.FileReader=function(){};

let js = fs.readFileSync('app_template.html','utf8').split('<script>')[1].split('</script>')[0]
  .replace('/*__KB__*/', fs.readFileSync('kb_slim.json','utf8')).replace('/*__KBIN__*/', fs.readFileSync('kb_in.json','utf8'))
  .replace('/*__DOCS__*/', fs.readFileSync('docs.json','utf8'));
const m={};
new Function('module', js + "\nmodule.exports={userCard,simOf,EPS};")(m);
const A = m.exports;
const fail = msg => { console.error('فشل: ' + msg); process.exit(1); };

/* ١) كل حاجة موجودة — كل الصفوف تظهر */
const full = A.userCard({
  name:'LSR-8031', imei:'869487062749717', id:'6819dce3', device_serial:'869487062749717',
  sim_number:'0100200300', created_at:'2020-02-13 13:57:19',
  last_update:{time:'2026-08-05 10:00:00'}, counters:{}, groups:[{name:'أسطول جدة'},{name:'مواقع'}]
});
if(full.indexOf('الشريحة')<0 || full.indexOf('0100200300')<0) fail('الشريحة مش ظاهرة من السجل');
if(full.indexOf('آخر تحديث')<0 || full.indexOf('2026-08-05 10:00:00')<0) fail('آخر تحديث مش ظاهر');
if(full.indexOf('أونلاين/أوفلاين')<0) fail('شرح آخر تحديث ناقص');
if(full.indexOf('المجموعات')<0 || full.indexOf('أسطول جدة')<0) fail('المجموعات مش ظاهرة');
if(full.indexOf('اتضافت على الحساب')<0 || full.indexOf('2020-02-13')<0) fail('تاريخ الإضافة مش ظاهر');
console.log('كل البيانات موجودة : الشريحة + آخر تحديث + تاريخ الإضافة ✓');

/* ٢) الشريحة متسجلة في الحقول المخصصة بالاسم العربي */
if(A.simOf({custom_fields:[{name:'رقم الشريحة', value:'0111222333'}]}) !== '0111222333')
  fail('الشريحة من الحقول المخصصة (عربي) مش متقروءة');
if(A.simOf({custom_fields:{'SIM Number':'0555'}}) !== '0555')
  fail('الشريحة من الحقول المخصصة (أوبجكت) مش متقروءة');
const viaCf = A.userCard({name:'X', custom_fields:[{name:'sim', value:'0777'}]});
if(viaCf.indexOf('الشريحة')<0 || viaCf.indexOf('0777')<0) fail('كارت الحقول المخصصة مش عارض الشريحة');
console.log('الحقول المخصصة     : عربي وإنجليزي وأوبجكت ✓');

/* ٣) تاريخ غريب الصيغة — آخر تحديث يظهر خام بدل ما يختفي */
const odd = A.userCard({name:'Y', last_update:{time:'٢٠٢٦/٠٨/٠٥ غريب'}});
if(odd.indexOf('آخر تحديث')<0 || odd.indexOf('٢٠٢٦/٠٨/٠٥ غريب')<0) fail('الصيغة الغريبة خفت السطر');
console.log('صيغة تاريخ غريبة   : السطر ظهر بالخام ✓');

/* ٤) مفيش بيانات — مفيش سطور فاضية */
const bare = A.userCard({name:'Z'});
for(const lbl of ['الشريحة','آخر تحديث','اتضافت على الحساب','المجموعات'])
  if(bare.indexOf(lbl)>=0) fail('سطر فاضي ظهر: '+lbl);
console.log('سجل فاضي           : ولا سطر فاضي ✓');

/* ٥) عينة اللستة بقت تطلب created_at من السيستم */
const ep = A.EPS.find(e=>e.p==='/units/lists' && e.n==='List');
if(!ep || ep.b.indexOf('"created_at"')<0) fail('البروجيكشن مش طالب created_at');
console.log('بروجيكشن اللستة    : created_at متطلب ✓');
