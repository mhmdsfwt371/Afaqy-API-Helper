const fs=require('fs');
function el(id){return{id,hidden:false,innerHTML:'',value:'',textContent:'',dataset:{},style:{},files:[],disabled:false,
 classList:{toggle(){},add(){},remove(){}},querySelectorAll(){return[]},addEventListener(){},focus(){},select(){},click(){},
 setAttribute(){},getAttribute(){return null},dispatchEvent(){},appendChild(){},remove(){},scrollIntoView(){}}}
const R={};global.document={documentElement:el(),body:el(),addEventListener(){},querySelectorAll(){return[]},
 querySelector(){return null},createElement(){return el()},getElementById(i){return R[i]||(R[i]=el(i))}};
global.history={pushState(){},replaceState(){}};
global.location={hash:''};
global.navigator={clipboard:{writeText(){return Promise.resolve()}}};global.window={scrollTo(){},addEventListener(){}};
global.fetch=()=>Promise.reject(0);global.Blob=function(){};global.URL={createObjectURL(){return''}};global.FileReader=function(){};
let js=fs.readFileSync('app_template.html','utf8').split('<script>')[1].split('</script>')[0]
  .replace('/*__KB__*/',fs.readFileSync('kb_slim.json','utf8')).replace('/*__DOCS__*/',fs.readFileSync('docs.json','utf8'));
const m={};new Function('module',js+`
module.exports={RECIPES,matchByName,GLOSSARY,EVIDENCE,dual,setL:(l)=>{LANG=l},startRecipe,doUid,RC:()=>RC,setRC:(v)=>{RC=v}};`)(m);
const A=m.exports;
A.setL('ar');
console.log('السيناريوهات:');
A.RECIPES.forEach((r,i)=>console.log('  '+r.icon+' '+A.dual(r.title)));

const conv=A.RECIPES.find(r=>r.id==='imei2uid');
console.log('\nسيناريو التحويل: '+conv.steps.length+' خطوات → '+conv.steps.map(s=>A.dual(s.t)).join(' , '));
console.log('بودي الخطوة الأولى: '+JSON.stringify(conv.steps[0].body({})));

// محاكاة التحويل
const resp={status:true,data:{items:[
 {_id:'5fb0e2e703ed529bb30f9af3',name:'NB YD - TH - 1129',imei:'357454075086551',device_serial:'861230048816917',plate_number:'ABC 1234'}]}};
A.setRC({r:conv, vars:{anyKey:'357454075086551'}, results:[{ok:true,json:resp},null], idx:1});
A.doUid(1);
const res=A.RC().results[1];
console.log('\nنتيجة التحويل: '+(res.ok?'نجح':'فشل'));
console.log('  '+res.msg.replace(/<[^>]+>/g,''));
console.log('  UID المستخرج: '+A.RC().vars.unitId);
console.log('  فيه زرار نسخ للـ UID؟ '+(res.html.includes('data-cp="5fb0e2e703ed529bb30f9af3"')?'أيوه ✓':'لأ ✗'));
console.log('  بيقول إن الـ UID هو اللي بيتحط؟ '+(res.html.includes('UID')?'أيوه ✓':'لأ'));

console.log('\nمصطلح UID موجود؟ '+(A.GLOSSARY.some(g=>g.w==='UID')?'أيوه ✓':'لأ ✗'));
console.log('أدلة التصعيد: '+A.EVIDENCE.map(e=>e.ar).join(' / '));
