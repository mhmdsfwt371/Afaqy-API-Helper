#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v6.44 — طلب إنتجريشن: الإيميل اللي فيه لستة بيانات بيتحوّل لرد نقطة بنقطة.

المحك: إيميل حقيقي من عميل (٢٧ سبتمبر) فيه ١٤ نقطة بيانات و٨ أسئلة فنية.
محلّل الرسايل كان بيقرأه كتذكرة ناقصة أدلة — لأن كل قواعده لتشخيص الأعطال.

اللي بيتعمل:
- كل سطر في اللستة بيتقابل مع كتالوج مبني من الكولكشن ومن المعرفة المؤكدة
  (الحقول اللي اتأكدت من رد حقيقي، ودروس التذاكر). مفيش نقطة بتتقال «متاحة»
  إلا لو الريكوست موجود في الكولكشن. اللي مش في الكولكشن بيتعلّم «يحتاج
  تأكيد» — والسؤال التجاري بيتحوّل لمدير الحساب. سطر ما لقيناش له مقابل
  بيظهر كده صراحةً، مش بيتخمّن.
- الرد للعميل بلغة إيميله (عربي فصيح أو إنجليزي) بنفس ترقيمه، وزرار يقلب
  اللغة، وكولكشن Postman فيه الريكوستات المتاحة بس بعلامات مكان.
- للموظف: جدول بكل نقطة وحالتها والريكوست والملاحظة اللي تخلّيه يجاوب صح.
"""
import sys, io, os

HERE = os.path.dirname(os.path.abspath(__file__))
PATH = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, 'app_template.html')
src = io.open(PATH, encoding='utf-8').read()
orig = len(src)

def rep(old, new, n=1, tag=''):
    global src
    c = src.count(old)
    if c != n: raise SystemExit('MISMATCH [%s]: expected %d found %d\n---\n%s' % (tag, n, c, old[:240]))
    src = src.replace(old, new, n); print('  ok  %s' % tag)

REQ_JS = r"""
/* ============ طلب إنتجريشن — رد نقطة بنقطة ============
   الإيميل اللي بيقول «نرغب في الحصول على: ١) … ٢) …» مش تذكرة عطل، ده طلب
   بيانات. كل سطر في لستته بيتقابل مع الكتالوج ده، وكل بند فيه مربوط
   بريكوست موجود فعلًا في الكولكشن أو بمعلومة اتأكدت من رد حقيقي أو تذكرة.

   الحالات:
     ok      متاح — الريكوست في الكولكشن
     part    متاح جزئيًا — جزء مؤكد وجزء محتاج تأكيد
     sensor  متاح لو الجهاز فيه الحساس — بيتأكد لكل عربية
     confirm يحتاج تأكيد من تيم مصر — ما يتقالش للعميل كمؤكد
     sales   قرار تجاري — مدير الحساب
   وسطر ما لقيناش له مقابل بياخد none — بيتقال كده بصراحة، مش بيتخمّن. */
const REQ_ST = {
  ok:     {ar:'متاح',                    en:'Available'},
  part:   {ar:'متاح جزئيًا',             en:'Partly available'},
  sensor: {ar:'حسب الجهاز',              en:'Depends on the device'},
  confirm:{ar:'يحتاج تأكيد',             en:'To be confirmed'},
  sales:  {ar:'قرار تجاري',              en:'Commercial'},
  none:   {ar:'مفيش مقابل في الكولكشن',  en:'No match in the collection'}
};
const REQ_CATALOG = [
{ id:'vehicle-id', st:'ok', eps:['/units/lists'],
  kw:/vehicle\s*id|unit\s*id|plate|licen[cs]e|لوحة|معر[ّ]?ف المركبة|رقم المركبة|list of (vehicles|units)|لستة (العربيات|المركبات)|قائمة (المركبات|العربيات)/i,
  t:{ar:'رقم اللوحة ومعرّف المركبة', en:'Vehicle id and plate'},
  note:{ar:'/units/lists بيرجّع كل عربيات الحساب: id (ده الـ UID اللي كل الريكوستات بتشتغل بيه) والاسم والـ IMEI ورقم الجهاز والشريحة، واللوحة زي ما هي متسجّلة على المنصة. projection ["basic"] يخلّي الرد خفيف.',
        en:'/units/lists returns every vehicle on the account: id (the UID every other call uses), name, IMEI, device serial, SIM, and the plate as registered on the platform. projection ["basic"] keeps it light.'},
  reply:{ar:'متاح. الطلب POST /units/lists يعيد جميع المركبات المسجلة في الحساب مع معرّف كل مركبة (id — وهو المعرّف المستخدم في بقية الطلبات) واسمها ورقم الـ IMEI والرقم التسلسلي للجهاز ورقم اللوحة كما هو مسجّل في المنصة.',
         en:'Available. POST /units/lists returns every vehicle on the account with its id (the identifier used by all other calls), name, IMEI, device serial and the plate number as registered on the platform.'} },

{ id:'distance', st:'ok', eps:['/user_reports/add','/units/lists'],
  kw:/distance|mileage|kilomet|\bkm\b|odometer|المسافة|مسافة|كيلومتر|عداد المسافة/i,
  t:{ar:'المسافة المقطوعة', en:'Distance travelled'},
  note:{ar:'المسافة عن فترة من تقرير الـ Summary (حقل route_length) — والفترة بتتقسم بالأيام بـ interval_unit: days فيطلع صف لكل يوم لكل عربية. المسافة التراكمية من counters.odometer في /units/lists بالكيلومتر (بتطابق الشاشة على طول).',
        en:'Distance per period comes from the Summary report (route_length); split the period with interval_unit "days" for one row per day per vehicle. The cumulative odometer is counters.odometer in /units/lists, in kilometres (matches the dashboard).'},
  reply:{ar:'متاح. تقرير الملخص (Summary) يعيد المسافة المقطوعة (الحقل route_length) لأي فترة، ويمكن تقسيم الفترة يوميًا (interval_unit = days) فيعود صف لكل يوم لكل مركبة. كما يعيد الطلب POST /units/lists عداد المسافة التراكمي في الحقل counters.odometer بالكيلومتر.',
         en:'Available. The Summary report returns the distance travelled (field route_length) for any period, and the period can be split per day (interval_unit "days") so you receive one row per day per vehicle. The cumulative odometer is also returned by POST /units/lists under counters.odometer, in kilometres.'} },

{ id:'trips', st:'confirm', eps:['/user_report_templates/lists','/user_reports/add'],
  kw:/\btrips?\b|journey|رحلة|رحلات|الرحلة/i,
  t:{ar:'تفاصيل كل رحلة', en:'Per-trip detail'},
  note:{ar:'تفاصيل كل رحلة على حدة (بداية ونهاية ومدة) بتيجي من قالب تقرير رحلات في حساب العميل. الكولكشن فيه آلية التقارير نفسها (إنشاء → انتظار → قراءة) بس مش قالب الرحلات. اجلب /user_report_templates/lists على حساب العميل: لو فيه قالب رحلات، النقطة متاحة بنفس السلسلة؛ لو مفيش، اسأل مصر — وما تقولش للعميل «متاح» قبل كده.',
        en:'Per-trip detail (start, end, duration) comes from a trips report template on the customer account. The collection carries the reports mechanism (create → wait → read) but not the trips template itself. Fetch /user_report_templates/lists on the customer account: if a trips template exists the point is available through the same chain; if not, ask development — do not tell the customer it is available before that.'},
  reply:{ar:'قيد التأكيد. تفاصيل كل رحلة (وقت البداية والنهاية والمدة) تُستخرج عبر منظومة التقارير بنفس تسلسل الإنشاء ثم الانتظار ثم القراءة، وسنؤكد لكم قالب تقرير الرحلات المتاح في حسابكم ونضمّنه في المجموعة المرسلة.',
         en:'To be confirmed. Trip-level detail (start time, end time, duration) is produced through the reports family using the same create → wait → read sequence; we will confirm the trip report template available on your account and include it in the collection we send.'} },

{ id:'ignition', st:'ok', eps:['/units/lists','/units/signals','/user_reports/add'],
  kw:/ignition|\bacc\b|engine\s*(on|off|status|state)|تشغيل و(إيقاف|ايقاف) المحرك|حالة المحرك|حالة تشغيل/i,
  not:/idl|idle|hours|ساعات|وقوف/i,
  t:{ar:'حالة تشغيل وإيقاف المحرك', en:'Ignition ON/OFF'},
  note:{ar:'الحالة الحالية جوه سجل العربية من /units/lists مع projection last_update: حقول acc و accOn و accOff — متأكدة من رد حقيقي. عن فترة: الرسائل الخام بتوقيتها من /units/signals، ومدة التشغيل من تقرير Summary (engine_work).',
        en:'Current state is in the vehicle record from /units/lists with projection last_update: acc, accOn and accOff — confirmed from a real response. For a period: the raw messages with their times from /units/signals, and the engine-on duration from the Summary report (engine_work).'},
  reply:{ar:'متاح. الحالة الحالية للمحرك تعود مع سجل المركبة من الطلب POST /units/lists (projection: basic و last_update) في الحقول acc و accOn و accOff. أما عن فترة محددة فيعيد الطلب POST /units/signals رسائل الجهاز بتوقيتها، ويعيد تقرير الملخص مدة تشغيل المحرك (engine_work).',
         en:'Available. The current ignition state comes with the vehicle record from POST /units/lists (projection basic and last_update) in the fields acc, accOn and accOff. For a period, POST /units/signals returns the device messages with their timestamps, and the Summary report gives the engine-on duration (engine_work).'} },

{ id:'engine-hours', st:'ok', eps:['/units/lists','/user_reports/add'],
  kw:/engine\s*hours|engine\s*work|ساعات (تشغيل|عمل) المحرك|ساعات المحرك/i,
  t:{ar:'إجمالي ساعات تشغيل المحرك', en:'Total engine hours'},
  note:{ar:'counters.engine_hours في /units/lists مع projection counters — القيمة بالثواني، اقسمها على 3600 (أكتر سؤال بيتكرر مع أي إنتجريشن). عن فترة: engine_work في Summary.',
        en:'counters.engine_hours in /units/lists with projection counters — the value is in seconds; divide by 3600 (the most repeated integration question). Per period: engine_work in the Summary report.'},
  reply:{ar:'متاح. الطلب POST /units/lists (projection: basic و counters) يعيد إجمالي ساعات التشغيل في الحقل counters.engine_hours، مع ملاحظة أن القيمة بالثواني ويلزم قسمتها على 3600 للحصول على الساعات. ويعيد تقرير الملخص مدة التشغيل عن أي فترة في الحقل engine_work.',
         en:'Available. POST /units/lists (projection basic and counters) returns the total in counters.engine_hours. Note that the value is in seconds — divide by 3600 for hours. Engine-on time for a period is engine_work in the Summary report.'} },

{ id:'idling', st:'part', eps:['/user_reports/add'],
  kw:/idl|idle|وقوف المركبة والمحرك|المحرك في حالة تشغيل|الخمول|تباطؤ/i,
  t:{ar:'مدة التشغيل بدون حركة', en:'Idling duration'},
  note:{ar:'مدة التشغيل بدون حركة عن فترة من Summary (engine_idle) — ويوميًا لو قسّمت الفترة. أما وقت بداية ونهاية كل حالة على حدة فمحتاج قالب تقرير في حساب العميل — يحتاج تأكيد.',
        en:'Idling duration per period from the Summary report (engine_idle) — per day if you split the period. The start and end time of each idling episode needs a report template on the customer account — to be confirmed.'},
  reply:{ar:'متاح جزئيًا. مدة التشغيل بدون حركة عن أي فترة (ويوميًا عند تقسيم الفترة) تعود في تقرير الملخص في الحقل engine_idle. أما وقت بداية ونهاية كل حالة على حدة فسنؤكد لكم قالب التقرير المتاح لذلك في حسابكم.',
         en:'Partly available. The idling duration for any period (per day when the period is split) is returned by the Summary report in engine_idle. The start and end time of each idling episode requires a dedicated report template; we will confirm the one available on your account.'} },

{ id:'stops', st:'part', eps:['/user_reports/add'],
  kw:/\bstops?\b|parking|\bpark|التوقف|توقفات|الوقوف|وقوف/i,
  not:/idl|idle|المحرك في حالة تشغيل/i,
  t:{ar:'التوقفات والوقوف', en:'Stops and parking'},
  note:{ar:'مدة التوقف عن فترة من Summary (stop_duration). قايمة التوقفات نفسها (بداية ونهاية ومدة وموقع لكل توقف) محتاجة قالب تقرير توقفات في حساب العميل — يحتاج تأكيد.',
        en:'Stop duration per period from the Summary report (stop_duration). A per-stop list (start, end, duration and location) needs a stops report template on the customer account — to be confirmed.'},
  reply:{ar:'متاح جزئيًا. إجمالي مدة التوقف عن أي فترة يعود في تقرير الملخص في الحقل stop_duration. أما قائمة التوقفات تفصيليًا (وقت البداية والنهاية والمدة والموقع لكل توقف) فتُستخرج عبر قالب تقرير التوقفات، وسنؤكد لكم المتاح منه في حسابكم.',
         en:'Partly available. The total stop duration for any period is returned by the Summary report in stop_duration. A detailed stop list (start, end, duration and location per stop) is produced through a stops report template; we will confirm the one available on your account.'} },

{ id:'gps-history', st:'ok', eps:['/units/locations','/units/signals','/units/lists'],
  kw:/\bgps\b|location|position|coordinates|\broutes?\b|track|history|مسار|المسارات|الموقع|مواقع|إحداثيات|حركة المركبة|تحركات/i,
  not:/historical data|maximum\s+period|retention|أقصى مدة|البيانات التاريخية|stop|parking|توقف|وقوف/i,
  t:{ar:'المواقع والمسارات التاريخية', en:'GPS positions and historical routes'},
  note:{ar:'المواقع خلال فترة: /units/locations بـ unit_id و date (from/to) و address:true. الرسائل الخام بكل حقولها (سرعة واتجاه وارتفاع…): /units/signals بنفس الفترة، بـ limit و offset — عينة الكولكشن فيها offset 50، لازم يبقى 0. آخر موقع: last_update في /units/lists.',
        en:'Positions over a period: /units/locations with unit_id, date (from/to) and address:true. The raw messages with every field (speed, heading, altitude…): /units/signals over the same period, paginated with limit and offset — the collection sample has offset 50, it must be 0. Latest position: last_update in /units/lists.'},
  reply:{ar:'متاح. الطلب POST /units/locations يعيد مواقع المركبة خلال فترة زمنية محددة (مع العنوان عند تفعيل address)، ويعيد الطلب POST /units/signals رسائل الجهاز الخام خلال الفترة نفسها (بالتاريخ والوقت والسرعة) مع إمكانية التقسيم إلى صفحات بالحقلين limit و offset، ويعود آخر موقع للمركبة في الحقل last_update من الطلب POST /units/lists.',
         en:'Available. POST /units/locations returns the positions of a vehicle over a date range (with the address when address is true); POST /units/signals returns the raw device messages for the same range (date, time, speed and more), paginated with limit and offset; the latest position is in last_update from POST /units/lists.'} },

{ id:'speed', st:'ok', eps:['/units/signals','/user_reports/add','/units/lists'],
  kw:/speed|السرعة|سرعة/i,
  t:{ar:'بيانات السرعة', en:'Speed data'},
  note:{ar:'السرعة الحالية spd جوه last_update، والسرعة في كل رسالة من /units/signals، وأقصى ومتوسط السرعة عن فترة من Summary (max_spd و avg_spd).',
        en:'Current speed is spd inside last_update, speed per message from /units/signals, and maximum and average speed per period from the Summary report (max_spd, avg_spd).'},
  reply:{ar:'متاح. السرعة الحالية تعود في الحقل spd ضمن last_update، وتعود سرعة كل رسالة من الطلب POST /units/signals، كما يعيد تقرير الملخص أقصى سرعة ومتوسط السرعة عن أي فترة (الحقلان max_spd و avg_spd).',
         en:'Available. The current speed is the field spd inside last_update, each message from POST /units/signals carries its speed, and the Summary report returns the maximum and average speed for any period (max_spd and avg_spd).'} },

{ id:'reefer-pto', st:'sensor', eps:['/unit_sensors/lists','/units/signals','/units/lists'],
  kw:/reefer|refrigerat|cooling unit|\bpto\b|التبريد|المبردة|مبردة|تبريد/i,
  t:{ar:'وحدة التبريد والـ PTO', en:'Refrigeration unit and PTO'},
  note:{ar:'دي حساسات: بتيجي بس لو الجهاز موصّل فعلًا على وحدة التبريد أو الـ PTO ومعمول له حساس على المنصة. اتأكد لكل عربية من /unit_sensors/lists بفلتر unit_id — رد حقيقي عن الجهاز ده (جهاز GPS بسيط بيرجّع فاضي). القراءات بتيجي مع رسائل الجهاز من /units/signals بـ sensors:true. ساعات تشغيل وحدة التبريد وأوقات البداية والنهاية: يحتاج تأكيد من مصر.',
        en:'These are sensors: they exist only where the device is actually wired to the refrigeration unit or PTO and a sensor is configured on the platform. Check per vehicle with /unit_sensors/lists filtered by unit_id — a real answer for that device (a plain GPS unit returns an empty list). Readings come with the device messages from /units/signals with sensors:true. Running hours and start/end times of the unit: confirm with development.'},
  reply:{ar:'متاح بحسب الجهاز. تعود حالة وحدة التبريد أو الـ PTO فقط للمركبات التي يكون جهاز التتبع فيها موصولًا بالوحدة مع تعريف حساس لها في المنصة؛ يعيد الطلب POST /unit_sensors/lists الحساسات المعرّفة لكل مركبة، وتعود قراءات الحساسات مع رسائل الجهاز من الطلب POST /units/signals (الخيار sensors). وسنؤكد لكم أي المركبات المبردة لديكم تتوفر فيها هذه المدخلات، وإمكانية استخراج ساعات تشغيل وحدة التبريد وأوقات بدايتها ونهايتها.',
         en:'Depends on the device. The refrigeration unit or PTO state is available only for vehicles whose tracking device is wired to the unit with a sensor configured on the platform; POST /unit_sensors/lists returns the sensors defined on a vehicle, and the sensor readings come with the device messages from POST /units/signals (sensors option). We will confirm which of your refrigerated vehicles have this input, and whether the unit running hours and start/end times can be reported.'} },

{ id:'fuel', st:'sensor', eps:['/unit_sensors/lists','/units/signals','/user_reports/add'],
  kw:/fuel|can\s*-?\s*bus|الوقود|وقود/i,
  t:{ar:'مستوى الوقود واستهلاكه', en:'Fuel level and consumption'},
  note:{ar:'حساس: لو العربية فيها حساس وقود أو CAN معمول له حساس (اتأكد من /unit_sensors/lists بفلتر unit_id)، القراءات بتيجي مع رسائل /units/signals بـ sensors:true، والاستهلاك عن فترة من Summary (fuel_level_sensor). لو مفيش حساس، Summary فيه استهلاك حسابي (fuel_consumption) من المسافة ومعدل الاستهلاك المسجّل للعربية — ده تقدير مش قراءة، وقوله للعميل كده.',
        en:'Sensor-based: where the vehicle has a fuel sensor or a CAN connection with a sensor configured (check /unit_sensors/lists filtered by unit_id), the readings come with the /units/signals messages with sensors:true, and the consumption per period from the Summary report (fuel_level_sensor). Without a sensor the Summary report gives a calculated consumption (fuel_consumption) from distance and the configured rate — an estimate, not a reading; say so.'},
  reply:{ar:'متاح بحسب الجهاز. للمركبات المزودة بحساس وقود أو باتصال CAN مع تعريف حساس في المنصة، تعود قراءات مستوى الوقود مع رسائل الجهاز من الطلب POST /units/signals (الخيار sensors) ويعيد تقرير الملخص الاستهلاك عن الفترة في الحقل fuel_level_sensor. أما المركبات غير المزودة بحساس فيعيد تقرير الملخص استهلاكًا محسوبًا (fuel_consumption) من المسافة ومعدل الاستهلاك المسجّل للمركبة، وهو تقدير وليس قراءة فعلية. وسنؤكد لكم المركبات المزودة بحساس وقود لديكم.',
         en:'Depends on the device. For vehicles fitted with a fuel sensor or a CAN-bus connection with a sensor configured on the platform, the fuel level readings come with the device messages from POST /units/signals (sensors option) and the consumption per period is returned by the Summary report in fuel_level_sensor. For vehicles without a sensor, the Summary report returns a calculated consumption (fuel_consumption) derived from distance and the vehicle configured rate — an estimate, not a reading. We will confirm which of your vehicles have a fuel sensor.'} },

{ id:'driver', st:'ok', eps:['/drivers/get_unit_driver','/drivers/lists','/units/lists'],
  kw:/driver|السائق|سائق|السواق/i,
  t:{ar:'السائق المرتبط بالمركبة', en:'Driver linked to the vehicle'},
  note:{ar:'السائق المرتبط بعربية في وقت معين: /drivers/get_unit_driver بـ unit_id و date. بيانات السواقين كلهم من /drivers/lists، و driver_id جوه سجل العربية في /units/lists.',
        en:'The driver assigned to a vehicle at a given time: /drivers/get_unit_driver with unit_id and date. All drivers from /drivers/lists, and driver_id inside the vehicle record in /units/lists.'},
  reply:{ar:'متاح. يعيد الطلب POST /drivers/get_unit_driver السائق المرتبط بالمركبة في تاريخ ووقت محددين (الحقلان unit_id و date)، ويعيد الطلب POST /drivers/lists بيانات السائقين في الحساب، كما يحمل سجل المركبة من POST /units/lists الحقل driver_id.',
         en:'Available. POST /drivers/get_unit_driver returns the driver assigned to a vehicle at a given date and time (unit_id and date), POST /drivers/lists returns the drivers on the account, and the vehicle record from POST /units/lists carries driver_id.'} },

{ id:'retention', st:'confirm', eps:[],
  kw:/historical data|maximum\s+period|maximum\s+history|retention|how far back|أقصى مدة|البيانات التاريخية|مدة الاحتفاظ/i,
  t:{ar:'أقصى مدة للبيانات التاريخية', en:'Maximum historical period'},
  note:{ar:'الاستعلام التاريخي نفسه متاح (فترات على /units/locations و /units/signals والتقارير). لكن مدة الاحتفاظ بالبيانات مش موجودة في الكولكشن — اسأل مصر، وما تقولش رقم.',
        en:'Historical querying itself is available (date ranges on /units/locations, /units/signals and the reports). The retention period is not in the collection — ask development, and do not quote a number.'},
  reply:{ar:'قيد التأكيد. الاستعلام عن البيانات التاريخية متاح عبر الطلبات المذكورة أعلاه (فترات زمنية على /units/locations و /units/signals والتقارير)، وسنوافيكم بأقصى مدة احتفاظ بالبيانات المتاحة عبر الواجهة بعد تأكيدها من فريق المنصة.',
         en:'To be confirmed. Historical queries are supported by the calls above (date ranges on /units/locations, /units/signals and the reports); the maximum retention period available through the API is being confirmed with our platform team and we will state it in our follow-up.'} },

{ id:'docs', st:'ok', eps:[],
  kw:/documentation|\bdocs\b|توثيق|التوثيق|الدليل الفني/i,
  t:{ar:'توثيق الـ API', en:'API documentation'},
  note:{ar:'في توثيق رسمي — ابعت اللينك مع أي طلب إنتجريشن جديد.', en:'There is official documentation — send the link with every new integration request.'},
  reply:{ar:'التوثيق الرسمي للواجهة متاح على الرابط: https://api.afaqy.sa/docs/',
         en:'The official API documentation is available at: https://api.afaqy.sa/docs/'} },

{ id:'auth', st:'ok', eps:['/auth/login'],
  kw:/authentication|\bauth\b|\blogin\b|المصادقة|تسجيل الدخول|طريقة الدخول/i,
  t:{ar:'طريقة المصادقة', en:'Authentication'},
  note:{ar:'POST /auth/login بـ data.username و data.password والتوكن في data.token. التوكن بيتبعت كباراميتر في اللينك ?token= مش هيدر (504 ريكوست من 534). كله POST تقريبًا والبودي جوه data، والرد 200 حتى لو فشل — الخطأ جوه status_code و message.',
        en:'POST /auth/login with data.username and data.password; the token is data.token. It is sent as a URL parameter ?token=, not a header (504 of 534 requests). Almost everything is POST with the body inside data, and the HTTP status is 200 even on failure — the error is in status_code and message.'},
  reply:{ar:'المصادقة تتم عبر الطلب POST /auth/login بالجسم {"data":{"username":"…","password":"…"}}، ويعود الرمز في الحقل data.token. يُمرَّر الرمز في كل طلب كمعامل في الرابط، مثل: POST /units/lists?token=YOUR_TOKEN. معظم الطلبات من نوع POST وجسمها داخل الكائن data، وتعيد الواجهة الحالة HTTP 200 حتى عند فشل الطلب؛ لذا يُقرأ الحقلان status_code و message من جسم الاستجابة.',
         en:'Authentication is POST /auth/login with the body {"data":{"username":"…","password":"…"}}; the token is returned in data.token. The token is passed on every call as a URL parameter, e.g. POST /units/lists?token=YOUR_TOKEN. Almost every endpoint is POST with the body wrapped in a "data" object, and the API returns HTTP 200 even when a call fails — read status_code and message from the response body.'} },

{ id:'readonly-token', st:'confirm', eps:['/auth/login'],
  kw:/api\s*key|read.?only|بصلاحية|صلاحية القراءة|مفتاح/i,
  t:{ar:'مفتاح أو توكن بصلاحية قراءة فقط', en:'API key or read-only token'},
  note:{ar:'التوكن مرتبط بحساب مستخدم مش مفتاح مستقل. الكولكشن فيه Roles and Permissions، فمستخدم فرعي بدور محدود للإنتجريشن ممكن — بس إن الدور ينفع «قراءة فقط» بالظبط ده يتأكد من مصر قبل ما يتوعد.',
        en:'The token belongs to a user account; it is not a standalone key. The collection has Roles and Permissions, so a dedicated sub-user with a restricted role is possible — but that the role can be exactly "read only" must be confirmed with development before it is promised.'},
  reply:{ar:'قيد التأكيد. الرمز يُصدر لحساب مستخدم عبر POST /auth/login وليس مفتاحًا مستقلًا، ويمكن إنشاء مستخدم فرعي مخصص للتكامل بدور محدود الصلاحيات؛ وسنؤكد لكم مجموعة صلاحيات القراءة فقط المتاحة وننشئ المستخدم لكم.',
         en:'To be confirmed. The token is issued to a user account through POST /auth/login rather than as a standalone key; a dedicated sub-user with a restricted role can be created for the integration. We will confirm the exact read-only permission set available and create the user for you.'} },

{ id:'endpoints-list', st:'ok', eps:[],
  kw:/endpoints?|list of (calls|requests)|الإندبوينت|قائمة الطلبات|المسارات المتاحة/i,
  t:{ar:'قائمة الإندبوينتس', en:'List of endpoints'},
  note:{ar:'التوثيق فيه القايمة كاملة. الأداة بتطلّع كولكشن Postman فيه الريكوستات المتاحة للنقط دي بالظبط — من الزرار تحت.', en:'The documentation carries the full list. The tool produces a Postman collection with exactly the requests for these points — the button below.'},
  reply:{ar:'قائمة الطلبات كاملة في التوثيق. وللبنود المذكورة أعلاه أرفقنا مجموعة Postman تحتوي الطلبات تحديدًا (تسجيل الدخول، المركبات، المواقع، الإشارات، الحساسات، السائقون، وتسلسل التقارير) مع مواضع فارغة للرمز ومعرّف المركبة.',
         en:'The full list is in the documentation. For the points above, the attached Postman collection contains the exact requests (login, vehicles, locations, signals, sensors, drivers and the report chain) with placeholders for your token and vehicle id.'} },

{ id:'rate-limits', st:'confirm', eps:[],
  kw:/rate\s*limit|throttl|quota|حدود الاستخدام|حد الاستدعاء|الحد الأقصى للطلبات|عدد الطلبات/i,
  t:{ar:'حدود الاستخدام', en:'Rate limits'},
  note:{ar:'مفيش أي معلومة عن حد أقصى للريكوستات في الكولكشن — اسأل مصر. ما تقولش «مفيش حد».', en:'Nothing about request limits in the collection — ask development. Do not say "no limit".'},
  reply:{ar:'قيد التأكيد. سنوافيكم بحدود الاستخدام بعد تأكيدها من فريق المنصة.',
         en:'To be confirmed. We will state the rate limits after confirming them with our platform team.'} },

{ id:'webhooks', st:'part', eps:[],
  kw:/webhook|callback|\bpush\b|notification url|الإشعارات|ويب ?هوك/i,
  t:{ar:'الإشعارات الفورية', en:'Webhooks'},
  note:{ar:'من التذاكر: رابط إشعارات للأحداث والتنبيهات بيدفع البيانات لسيرفر العميل موجود، والبث اللحظي للمواقع خدمة مدفوعة بتتحوّل لمدير الحساب. تفاصيل إعداد الرابط: مصر.',
        en:'From tickets: a notification URL that pushes events and alerts to the customer server exists, and continuous live streaming of positions is a paid service handled by the account manager. Setup details for the URL: development.'},
  reply:{ar:'متاح جزئيًا. يمكن إعداد رابط إشعارات يدفع الأحداث والتنبيهات إلى الخادم الخاص بكم، وسنؤكد لكم تفاصيل إعداده. أما البث اللحظي المستمر للمواقع فهو خدمة إضافية مدفوعة يوضح تفاصيلها مدير حسابكم.',
         en:'Partly available. A notification URL can be configured to push events and alerts to your endpoint; we will confirm the setup details. Continuous real-time streaming of positions is a separate paid add-on that your account manager can advise on.'} },

{ id:'sandbox', st:'confirm', eps:[],
  kw:/sandbox|test environment|staging|test account|بيئة تجريبية|بيانات تجريبية|تجريبي|حساب تجريبي/i,
  t:{ar:'بيئة تجريبية', en:'Sandbox or test environment'},
  note:{ar:'الكولكشن فيه عناوين apibeta و stageavl كعينات، بس أنهي واحد بيتدي للعملاء دلوقتي محتاج تأكيد من مصر.', en:'The collection carries apibeta and stageavl as sample environments, but which one is offered to customers now must be confirmed with development.'},
  reply:{ar:'قيد التأكيد. سنوافيكم بإمكانية توفير بيئة أو حساب تجريبي للتكامل بعد التأكيد من فريق المنصة.',
         en:'To be confirmed. We will advise whether a test environment or test account can be provided for your integration after checking with our platform team.'} },

{ id:'fees', st:'sales', eps:[],
  kw:/\bfees?\b|cost|pricing|charge|رسوم|تكلفة|مدفوع/i,
  t:{ar:'الرسوم', en:'Fees'},
  note:{ar:'من التذاكر: الـ REST العادي مشمول، والبث اللحظي مدفوع. أي رقم أو عرض: مدير الحساب — ده سؤال تجاري مش تقني.', en:'From tickets: standard REST access is included, live streaming is paid. Any figure or offer: the account manager — a commercial question, not a technical one.'},
  reply:{ar:'الوصول القياسي إلى الواجهة (REST) مشمول ضمن الحساب. أما البث اللحظي فخدمة منفصلة مدفوعة، وتفاصيلها التجارية لدى مدير حسابكم.',
         en:'Standard REST API access is included with the account. Real-time streaming is a separate paid service; its commercial details are handled by your account manager.'} }
];

/* أوصاف الريكوستات في كولكشن العميل — إنجليزي دايمًا لأن الملف رايح للعميل */
const REQ_EPDESC = {
  '/units/lists':             {n:'Vehicles on the account', d:'Lists every vehicle on the account. The id in each record is the vehicle identifier used by all other calls. Use projection to choose what comes back: basic, last_update (latest position, speed and ignition), counters (odometer in km, engine_hours in seconds), sensors.'},
  '/units/locations':         {n:'Vehicle positions over a period', d:'Positions of one vehicle over a date range. Set address to true to receive the address with each point.'},
  '/units/signals':           {n:'Vehicle messages over a period', d:'Raw device messages of one vehicle over a date range, with speed and the other message fields; with sensors true the sensor readings come with each message. Paginated with limit and offset — keep offset at 0 for the first page.'},
  '/unit_sensors/lists':      {n:'Sensors configured on a vehicle', d:'The sensors configured on a vehicle (fuel, temperature, digital inputs such as a refrigeration unit or PTO), filtered by unit_id. A data point that depends on a sensor exists only where the sensor is listed here; a plain GPS unit returns an empty list.'},
  '/drivers/get_unit_driver': {n:'Driver assigned to a vehicle at a time', d:'The driver assigned to a vehicle at a given date and time.'},
  '/drivers/lists':           {n:'Drivers on the account', d:'The drivers registered on the account.'}
};

/* السطور اللي شكلها بند في لستة: رقم أو نقطة أو شرطة في الأول */
function reqExtract(text){
  const out = [];
  String(text||'').split(/\r?\n/).forEach(line=>{
    const l = normDigits(line).trim();
    const m = l.match(/^(?:(\d{1,2})\s*[\.\)\-:،]\s*|[•\-\*·▪◦–]\s*)(.+)$/);
    if(m && m[2].trim().length >= 3) out.push({num:m[1]||'', text:m[2].trim()});
  });
  return out;
}
function reqMatch(item){
  const s = normDigits(item.text).toLowerCase();
  return REQ_CATALOG.filter(c => c.kw.test(s) && !(c.not && c.not.test(s)));
}
/* الحالة الأضعف بتحكم على السطر: ok < part < sensor < confirm < sales */
const REQ_RANK = {ok:0, part:1, sensor:2, confirm:3, sales:4};
function reqAnalyze(text, errs, defs, paths, reportCase){
  /* تذكرة فيها رد أو خطأ أو مسار اتنادى أو كلام عن عطل — دي مش طلب بيانات حتى لو فيها لستة */
  const trouble = (errs||[]).length || (defs||[]).length || (paths||[]).length || reportCase
    || /\b(response|returning|returned|not working|error|failed|failing|fails|fail|unauthori[sz]ed|status_code)\b|مش شغال|بيرجع|بترجع|رجع فاضي|خطأ|فشل/i.test(String(text||''));
  const items = reqExtract(text).map(it=>{
    const hits = reqMatch(it);
    const st = hits.length ? hits.slice().sort((a,b)=>REQ_RANK[b.st]-REQ_RANK[a.st])[0].st : 'none';
    return {num:it.num, text:it.text, hits, st};
  });
  const matched = items.filter(x=>x.hits.length).length;
  const asks = /نرغب|نأمل|نرجو|تزويدنا|إمكانية|الحصول على|نود|please provide|we would like|we need|access to|integrat|\bapi\b/i.test(String(text||''));
  const reqCase = !trouble && items.length >= 3 && matched >= 3 && matched >= Math.ceil(items.length * 0.4) && asks;
  const count = {ok:0, part:0, sensor:0, confirm:0, sales:0, none:0};
  items.forEach(x=>{ count[x.st]++; });
  return {items, matched, reqCase, count};
}

/* الرد للعميل بلغة إيميله — بنفس ترقيمه. الحالة بتتقال في أول كل بند. */
function reqReply(a, lang){
  const L = lang === 'ar';
  const r = a.req; if(!r) return '';
  const P = (ar,en) => L ? ar : en;
  const out = [];
  out.push(P('السادة/ فريق تقنية المعلومات المحترمين،', 'Dear team,'));
  out.push('');
  out.push(P('نشكر لكم اهتمامكم بالتكامل مع منصة أفاقي. فيما يلي الرد على كل بند من طلبكم بالترتيب نفسه. البنود المعلَّمة «قيد التأكيد» يجري التحقق منها مع فريق المنصة وسنوافيكم بتفاصيلها في رد لاحق.',
             'Thank you for your interest in integrating with the AFAQY platform. Below is a point-by-point answer to your list, in the same order. Items marked "to be confirmed" are being checked with our platform team and we will revert with the details.'));
  out.push('');
  /* العنوان: نص العميل نفسه لو الرد بلغة إيميله، وإلا عنوان البند من الكتالوج */
  const same = (L === !!a.arabic);
  r.items.forEach(it=>{
    const head = (same || !it.hits.length) ? it.text
               : it.hits.map(h => L ? h.t.ar : h.t.en).join(L ? ' · ' : ' · ');
    out.push((it.num ? it.num + ') ' : '• ') + head);
    if(!it.hits.length){
      out.push('   ' + P('قيد التأكيد. نتحقق من هذا البند وسنوافيكم بالإجابة في ردنا اللاحق.',
                         'To be confirmed. We are checking this point and will answer it in our follow-up.'));
    } else {
      it.hits.forEach(h=>{ out.push('   ' + (L ? h.reply.ar : h.reply.en)); });
    }
    out.push('');
  });
  const has = id => r.items.some(it=>it.hits.some(h=>h.id===id));
  if(!has('docs') || !has('auth')){
    out.push(P('للبدء:', 'Getting started:'));
    if(!has('docs')) out.push('   ' + P('التوثيق الرسمي: https://api.afaqy.sa/docs/', 'Documentation: https://api.afaqy.sa/docs/'));
    if(!has('auth')) out.push('   ' + REQ_CATALOG.find(c=>c.id==='auth').reply[L?'ar':'en']);
    out.push('');
  }
  const pend = r.items.filter(it=>it.st==='confirm' || it.st==='none' || it.st==='part')
    .map(it=>it.num || (it.hits.length ? (L ? it.hits[0].t.ar : it.hits[0].t.en) : it.text.split(/\s+/).slice(0,4).join(' ')));
  if(pend.length){
    out.push(P('البنود التي سنوافيكم بها في رد لاحق: ' + pend.join('، ') + '.',
               'Points we will come back to in a follow-up: ' + pend.join(', ') + '.'));
    out.push('');
  }
  out.push(P('مرفق مجموعة Postman تحتوي الطلبات المتاحة للبنود أعلاه مع مواضع فارغة للرمز ومعرّف المركبة، ونرحب بأي استفسار أثناء التنفيذ.',
             'Attached is a Postman collection with the available requests for the points above, with placeholders for your token and vehicle id. We are glad to help with any question during implementation.'));
  out.push('');
  out.push(P('وتفضلوا بقبول فائق الاحترام،', 'Best regards,'));
  return out.join('\n');
}

/* كولكشن للعميل: الدخول + سلسلة التقرير + الريكوستات المتاحة للنقط اللي طلبها.
   من غير توكن ولا أرقام — كله علامات مكان. */
function reqPmBody(e){
  let obj = null; try{ obj = e.b ? JSON.parse(e.b) : null; }catch(_){ return e.b || ''; }
  const scoped = /^\/units\//i.test(e.p||'');
  const walk = (x, k) => {
    if(Array.isArray(x)) return k==='resources' ? ['{{unit_id}}'] : x.map(v=>walk(v,k));
    if(x && typeof x==='object'){ const o={}; Object.keys(x).forEach(kk=>{ o[kk]=walk(x[kk],kk); }); return o; }
    if(k==='unit_id' || (scoped && k==='id')) return '{{unit_id}}';
    if(k==='user_id') return '{{user_id}}';
    if(k==='offset') return 0;
    if(typeof x==='string' && /^\d{4}-\d{1,2}-\d{1,2}/.test(x)){
      if(k==='from') return '{{date_from}} 00:00:00';
      return '{{date_to}} 23:59:59';
    }
    return x;
  };
  return walk(obj, null);
}
function pmFromReq(a){
  if(!a || !a.req) return null;
  const r = RECIPES.find(x=>x.id === 'summary-report');
  const col = r ? pmFromRecipe(r, false) : pmWrap('AFAQY — Integration', '', [pmLogin()], []);
  const have = new Set(col.item.map(it=>String((it.request&&it.request.url&&it.request.url.raw)||'').replace(/^\{\{base_url\}\}/,'').replace(/\?.*$/,'')));
  const paths = [];
  a.req.items.forEach(it=>it.hits.forEach(h=>{ if(REQ_RANK[h.st] <= REQ_RANK.sensor) h.eps.forEach(p=>{ if(paths.indexOf(p)<0) paths.push(p); }); }));
  paths.forEach(p=>{
    if(have.has(p) || /user_report/.test(p)) return;
    const e = EPS.find(x=>x.p===p && sysOf(x)==='avl' && (x.m||'POST')==='POST') || EPS.find(x=>x.p===p);
    if(!e) return;
    const d = REQ_EPDESC[p] || {n:e.n, d:''};
    col.item.push(pmReq({name:d.n + '  (' + p + ')', path:p, method:e.m||'POST', body:reqPmBody(e), desc:d.d}));
    have.add(p);
  });
  col.info.name = 'AFAQY — Integration requests';
  col.info.description =
    'The requests behind the data points in our reply, ready to run.\n\n'
  + 'HOW TO USE\n'
  + '  - Open the Variables tab and fill in username and password, or paste a token.\n'
  + '  - Run Login first; the token and user id are captured automatically.\n'
  + '  - Run the vehicle list; copy the id of a vehicle into unit_id (or put its IMEI in imei).\n'
  + '  - Set date_from and date_to (YYYY-MM-DD) for the period requests.\n\n'
  + 'THREE THINGS TO KNOW\n'
  + '  - Almost every endpoint is POST, and the body is always wrapped in a "data" object.\n'
  + '  - The token goes in the URL as ?token=..., not in a header.\n'
  + '  - The API returns HTTP 200 even when a call fails: read status_code and message from the body.\n\n'
  + 'Reports are generated asynchronously: create, then poll the percentage until 100, then read the rows.';
  return col;
}

/* شاشة الموظف: الرد فوق، والجدول اللي اتبنى منه تحت */
let REQ_LANG = null;
function renderReq(a, out){
  const r = a.req, c = r.count;
  const lang = REQ_LANG || (a.arabic ? 'ar' : 'en');
  const reply = reqReply(a, lang);
  const chip = st => `<span class="pill" style="${st==='ok'?'background:var(--ok-soft); color:var(--ok)':
    st==='part'||st==='sensor'?'background:var(--signal-soft); color:var(--signal-deep)':
    st==='sales'?'background:var(--panel-2); color:var(--ink-2)':'background:var(--alert-soft); color:var(--alert-ink)'}">${esc(dual(REQ_ST[st]))}</span>`;
  const sum = [
    c.ok      ? t(`${c.ok} متاحة`, `${c.ok} available`) : '',
    c.part    ? t(`${c.part} جزئيًا`, `${c.part} partly`) : '',
    c.sensor  ? t(`${c.sensor} حسب الجهاز`, `${c.sensor} device-dependent`) : '',
    c.confirm ? t(`${c.confirm} تحتاج تأكيد`, `${c.confirm} to confirm`) : '',
    c.sales   ? t(`${c.sales} تجارية`, `${c.sales} commercial`) : '',
    c.none    ? t(`${c.none} من غير مقابل`, `${c.none} unmatched`) : ''
  ].filter(Boolean).join(' · ');
  const epBtn = p => { const e = EPS.find(x=>x.p===p && sysOf(x)==='avl'); return e
    ? `<button class="chip" data-goep="${e.i}" style="padding:1px 8px"><code>${esc(p)}</code></button>` : `<code>${esc(p)}</code>`; };
  const rows = r.items.map((it,i)=>`<tr>
    <td style="width:26%; font-size:13px; font-family:var(--ar); color:var(--ink)"><b>${esc(it.num ? it.num+')' : '•')}</b> ${esc(it.text)}</td>
    <td style="width:12%">${chip(it.st)}</td>
    <td style="font-size:12.5px; color:var(--ink-2)">${it.hits.length
      ? it.hits.map(h=>`<div style="margin-bottom:6px"><b>${esc(dual(h.t))}</b>${h.eps.length ? ' — ' + h.eps.map(epBtn).join(' ') : ''}<br>${esc(dual(h.note))}</div>`).join('')
      : t('ما لقيناش لها مقابل في الكولكشن — اسأل مصر أو صعّد، وما تجاوبش عليها من دماغك.',
          'No match in the collection — ask development or escalate; do not answer it from memory.')}</td></tr>`).join('');
  out.innerHTML = `
    <div class="panel"><div class="sec" style="border-top:0">
      <div class="caseVerdict">
        <div style="flex:1 1 300px; min-width:0">
          <div class="crumb">${t('الحالة','The case')}</div>
          <div style="font-size:15px; font-weight:600; margin-top:5px; line-height:1.6">${t(
            `طلب إنتجريشن: ${r.items.length} بند — ${sum}. الرد تحت بيجاوب كل بند بحالته، والبنود اللي «تحتاج تأكيد» اتقالت كده للعميل مش اتخمّنت.`,
            `Integration request: ${r.items.length} points — ${sum}. The reply answers each point with its status; "to be confirmed" points are stated as such, not guessed.`)}</div>
        </div>
        <span class="chip sig" style="pointer-events:none; flex:0 0 auto">${t('رد نقطة بنقطة','Point-by-point reply')}</span>
      </div>
    </div></div>
    <div class="panel" style="margin-top:12px"><div class="sec" style="border-top:0">
      <h3>${t('رد جاهز للعميل — نقطة بنقطة','A reply ready to send — point by point')}</h3>
      <div class="row" style="margin-bottom:8px">
        <button class="ct" id="reqAr" aria-selected="${lang==='ar'}">${t('عربي','Arabic')}</button>
        <button class="ct" id="reqEn" aria-selected="${lang==='en'}">${t('إنجليزي','English')}</button>
        <span style="font-size:12.5px; color:var(--muted); align-self:center">${t('بلغة إيميله افتراضيًا. اقراه قبل ما تبعته.','In the language of their email by default. Read it before sending.')}</span>
      </div>
      <pre id="caseReplyTxt" class="pre" style="white-space:pre-wrap; font-family:var(--ar); font-size:13.5px; background:var(--panel-2); padding:14px; border-radius:var(--r); border:1px solid var(--line); direction:${lang==='ar'?'rtl':'ltr'}; text-align:${lang==='ar'?'right':'left'}; color:var(--ink)">${esc(reply)}</pre>
      <div class="row" style="margin-top:10px">
        <button class="btn sig" id="caseCopy">${t('انسخ الرد','Copy the reply')}</button>
        <button class="btn ghost" id="casePm">${t('نزّل كولكشن Postman للعميل','Download the Postman collection')}</button>
      </div>
      <div class="note" style="margin-top:8px">${t(
        'الكولكشن فيه الدخول وسلسلة التقرير والريكوستات المتاحة للنقط اللي طلبها بس — من غير توكن ولا أرقام، كله علامات مكان. ابعته أتاشمنت مع الرد.',
        'The collection carries login, the report chain and only the requests behind the points they asked for — no token and no ids, placeholders throughout. Attach it to the reply.')}</div>
    </div></div>
    <details class="caseMore" open>
      <summary>${t('كل بند وحالته والريكوست بتاعه','Each point, its status and its request')}<span class="cnt">— ${r.items.length}</span></summary>
      <div class="panel" style="margin-top:12px"><div class="sec" style="border-top:0">
        <div class="note" style="margin-bottom:8px">${t(
          'الحالة بتيجي من الكولكشن ومن المعرفة المؤكدة: «متاح» يعني الريكوست موجود فعلًا. «حسب الجهاز» يعني حساس لازم يتأكد لكل عربية. «يحتاج تأكيد» ما يتقالش للعميل كمؤكد.',
          'Status comes from the collection and verified knowledge: "available" means the request exists. "Depends on the device" means a sensor to check per vehicle. "To be confirmed" is never stated to the customer as certain.')}</div>
        <table class="kv" style="font-size:13px">${rows}</table>
      </div></div>
    </details>`;
  out.querySelectorAll('[data-goep]').forEach(b => b.onclick = ()=>{
    const e = EPS.find(x => String(x.i) === b.dataset.goep);
    if(e){ showView('search'); select(e, []); pushRecent(e); }
  });
  $('caseCopy').onclick = ()=>{ copy(reply); toast(t('الرد اتنسخ','Reply copied')); };
  $('casePm').onclick = ()=>{ const col = pmFromReq(a); if(col) pmSave(col, 'AFAQY_Integration_Requests.postman_collection.json'); };
  $('reqAr').onclick = ()=>{ REQ_LANG='ar'; renderReq(a, out); };
  $('reqEn').onclick = ()=>{ REQ_LANG='en'; renderReq(a, out); };
}
"""

# ── ١) الكود قبل renderCase ──────────────────────────────────
rep("function renderCase(text){\n  const out = $('caseOut');",
    REQ_JS + "\nfunction renderCase(text){\n  const out = $('caseOut');", tag='كتالوج الطلبات ودوال الرد')

# ── ٢) التحليل بيرجّع الطلب ───────────────────────────────────
rep("""  return {isMsg, arabic, blocks: kinds, defs, wanted, errs, qs, paths,
          reportCase, words, proseCodes, matched, reportCode};""",
"""  /* v6.44: إيميل فيه لستة بيانات مطلوبة مش تذكرة — بيتقابل مع الكتالوج */
  const req = reqAnalyze(text, errs, defs, paths, reportCase);
  return {isMsg, arabic, blocks: kinds, defs, wanted, errs, qs, paths,
          reportCase, words, proseCodes, matched, reportCode,
          req, reqCase: req.reqCase};""", tag='analyzeCase بيرجّع req')

# ── ٣) renderCase بيحوّل لشاشة الطلب ─────────────────────────
rep("""  const a = analyzeCase(text);
  /* أكبر بلوك في الرسالة هو غالبًا الرد — بنديه للقواعد عشان تشخّص عليه */""",
"""  const a = analyzeCase(text);
  a._raw = text;
  /* طلب بيانات مش تذكرة عطل: شاشة تانية خالص — رد نقطة بنقطة */
  if(a.reqCase){ renderReq(a, out); clipBlocks(out); return; }
  /* أكبر بلوك في الرسالة هو غالبًا الرد — بنديه للقواعد عشان تشخّص عليه */""", tag='renderCase → renderReq')

# ── ٤) الرد الجاهز ما يقعش على طلب ─────────────────────────────
rep("""function caseReply(a){
  /* الدليل من الكولكشن""",
"""function caseReply(a){
  if(a && a.reqCase) return reqReply(a, REQ_LANG || (a.arabic ? 'ar' : 'en'));
  /* الدليل من الكولكشن""", tag='caseReply بيعرف الطلب')

# ── ٥) كارت الفرز بيقول للموظف يعمل إيه بالإيميل ─────────────
rep("""  steps:{ar:['ابعت لينك التوثيق الرسمي.',
             'اشرح الأربع نقط اللي بتوقّع كل العملاء (في الرد الجاهز تحت).',""",
"""  steps:{ar:['لو الإيميل فيه لستة بيانات مطلوبة (١) … ٢) …)، الصقه في «افحص رد ← حلّل رسالة عميل» — بيطلّع رد نقطة بنقطة وكولكشن.',
             'ابعت لينك التوثيق الرسمي.',
             'اشرح الأربع نقط اللي بتوقّع كل العملاء (في الرد الجاهز تحت).',""", tag='خطوة الكارت بالعربي')
rep("""         en:['Send the official documentation link.',
             'Explain the four things that trip up every customer (in the ready reply below).',""",
"""         en:['If the email lists the data they want (1) … 2) …), paste it into Inspect → Analyse a customer message — it produces a point-by-point reply and a collection.',
             'Send the official documentation link.',
             'Explain the four things that trip up every customer (in the ready reply below).',""", tag='خطوة الكارت بالإنجليزي')

# ── ٦) مقدمة التبويب ─────────────────────────────────────────
rep("""      'الصق رسالة العميل كاملة — كلام وأكواد وأسئلة. الأداة بتفصل الرد اللي اشتكى منه عن المثال اللي عايزه، وتقولك عمل إيه وإيه الغلط، وتطلّعلك رد جاهز تبعته.',""",
"""      'الصق رسالة العميل كاملة — كلام وأكواد وأسئلة. الأداة بتفصل الرد اللي اشتكى منه عن المثال اللي عايزه، وتقولك عمل إيه وإيه الغلط، وتطلّعلك رد جاهز تبعته. ولو الإيميل طلب بيانات (١) … ٢) …) بتجاوب كل بند بحالته.',""", tag='مقدمة التبويب بالعربي')
rep("""      'Paste the whole customer message — prose, code blocks and questions. The tool separates the response they complained about from the shape they want, tells you what they did and what went wrong, and drafts a reply you can send.');""",
"""      'Paste the whole customer message — prose, code blocks and questions. The tool separates the response they complained about from the shape they want, tells you what they did and what went wrong, and drafts a reply you can send. If the email asks for data (1) … 2) …), every point is answered with its status.');""", tag='مقدمة التبويب بالإنجليزي')

io.open(PATH, 'w', encoding='utf-8').write(src)
print('القالب: %d → %d بايت' % (orig, len(src)))

# ── ٧) بوابة البناء: علامة إلزامية ───────────────────────────
bp = os.path.join(HERE, 'build.py')
bb = io.open(bp, encoding='utf-8').read()
old = "    (\"showView('triage', true)\",     'الفتحة الأولى بتفتح على البداية'),\n]"
new = "    (\"showView('triage', true)\",     'الفتحة الأولى بتفتح على البداية'),\n    ('const REQ_CATALOG',            'طلب إنتجريشن نقطة بنقطة'),\n]"
if bb.count(old) != 1: raise SystemExit('MISMATCH build.py markers')
io.open(bp, 'w', encoding='utf-8').write(bb.replace(old, new)); print('  ok  علامة البناء')
print('تمام — شغّل الاختبارات وبعدين build.py')
