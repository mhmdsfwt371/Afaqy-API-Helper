#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v6.2 — المراجعة الختامية: قفل منفذ الحقن في الكارت، شبكة أمان الوعود، واكتمال زيب المصدر."""
import sys
P='app_template.html'; s=open(P,encoding='utf-8').read()
miss=[]; done=[]
def rep(old,new,label,cnt=1):
    global s
    c=s.count(old)
    if c!=cnt: miss.append(f'{label} (لقيت {c})'); return
    s=s.replace(old,new); done.append(label)

# ===== ١) صف الكارت: التسمية بتتهرّب زي القيمة =====
# التسميات العادية جاية من t() ومافيهاش HTML، لكن أسماء الحساسات جاية من رد السيرفر —
# ومن غير التهريب هنا أي اسم فيه وسوم بيتنفذ جوه الصفحة.
rep('${rows.map(r=>`<tr><td style="width:38%; font-family:var(--ar); color:var(--ink)">${r.lbl}</td>',
    '${rows.map(r=>`<tr><td style="width:38%; font-family:var(--ar); color:var(--ink)">${esc(String(r.lbl))}</td>',
    '١أ) تهريب التسمية في الكارت')
# وبما إن القالب بقى بيهرّب، الحساسات ما تبعتش مهرّبة من قبلها — كانت بتظهر &amp; بدل &
rep("sensorsOf(u).slice(0,6).forEach(s2=>add(esc(s2.name), esc(String(s2.value))));",
    "sensorsOf(u).slice(0,6).forEach(s2=>add(String(s2.name), String(s2.value)));",
    '١ب) إلغاء التهريب المزدوج للحساسات')

# ===== ٢) شبكة أمان الوعود =====
i=s.find("window.addEventListener('error'")
if i<0: miss.append('٢) مكان شبكة الأمان')
else:
    j=s.find('});', i)
    if j<0: miss.append('٢) نهاية شبكة الأمان')
    else:
        ins="""
/* نفس الفكرة للوعود: نداء شبكة اتنسي من غير حماية ما يكسرش حاجة بصمت —
   رسالة واضحة للموظف، وتسجيل للكونسول، والأداة تكمّل. */
window.addEventListener('unhandledrejection', ev=>{
  try{ toast(t('حصل خطأ غير متوقع — اتسجّل وتقدر تكمّل عادي','Something unexpected failed — logged, you can continue')); }catch(_){}
  try{ console.error('unhandled promise:', ev.reason); }catch(_){}
  ev.preventDefault();
});"""
        s=s[:j+3]+ins+s[j+3:]; done.append('٢) شبكة أمان الوعود')

for d in done: print('تمام:',d)
if miss:
    print('!! MISS:'); [print('  ',x) for x in miss]; sys.exit(1)
open(P,'w',encoding='utf-8').write(s)
print(f'اتكتب — {len(done)} تعديل')
