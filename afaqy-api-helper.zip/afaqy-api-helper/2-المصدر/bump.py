#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""رفع رقم النسخة وتسجيل الجديد. الاستخدام: python3 bump.py 2.4 notes.json"""
import json, sys, os

HERE = os.path.dirname(os.path.abspath(__file__))
ver = sys.argv[1]
notes = json.load(open(sys.argv[2], encoding='utf-8'))

p = os.path.join(HERE, 'docs.json')
d = json.load(open(p, encoding='utf-8'))

if d['history'] and d['history'][0]['v'] == ver:
    d['history'][0]['items'] = notes            # نفس النسخة: نستبدل البنود
else:
    d['history'].insert(0, {'v': ver, 'date': d['date'], 'items': notes})

d['version'] = ver
json.dump(d, open(p, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)
print(f'docs.json → v{ver} ({len(notes["ar"])} بند)')
