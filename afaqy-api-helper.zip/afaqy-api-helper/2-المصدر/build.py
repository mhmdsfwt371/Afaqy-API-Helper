#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
بناء الأداة والدليل من مصدر واحد.
    python3 build.py
بيطلّع:
    /mnt/user-data/outputs/afaqy-api-helper.html   (النسخة الداخلية بأسماء العملاء)
    /mnt/user-data/outputs/repo/index.html         (النسخة العامة)
    /mnt/user-data/outputs/repo/docs.pdf           (الدليل مطبوع)
"""
import json, os, re, sys, html, subprocess

HERE = os.path.dirname(os.path.abspath(__file__))
OUT  = '/mnt/user-data/outputs'
REPO = os.path.join(OUT, 'repo')

# أسماء العملاء الحقيقية اتنقلت لملف خاص — build.py بقى بيتحط في الزيب العام،
# والأسماء عمرها ما تتحط معاه. من غير الملف البناء بيقف بدل ما ينشر نسخة مسرّبة.
_pn = os.path.join(HERE, 'private_names.json')
if not os.path.exists(_pn):
    print('!! ناقص private_names.json — قايمة تبديل الأسماء. من غيرها النسخة العامة هتطلع بأسماء العملاء.')
    print('   الملف موجود في فولدر المصدر الداخلي عند محمد — ما يتحطش في الزيب ولا الريبو أبدًا.')
    sys.exit(1)
_names = json.load(open(_pn, encoding='utf-8'))
SCRUB = [tuple(x) for x in _names['scrub']]
LEAK = re.compile(_names['leak'])

# ريكوستات متشالة من الأداة عن قصد — الدعم مالوش دعوة يعمل أو يمسح عربيات
EXCLUDE_PATHS = {
    '/units/add',
    '/units/delete',
    '/units/bulk-delete',
    '/units/delete_forever',
    '/units/bulk-delete-forever',
}


def load_kb():
    kb = json.load(open(os.path.join(HERE, 'kb_slim.json'), encoding='utf-8'))
    before = len(kb['endpoints'])
    kb['endpoints'] = [e for e in kb['endpoints'] if e.get('p') not in EXCLUDE_PATHS]
    removed = before - len(kb['endpoints'])
    return json.dumps(kb, ensure_ascii=False, separators=(',', ':')), removed, before


def build_html():
    tpl  = open(os.path.join(HERE, 'app_template.html'), encoding='utf-8').read()
    kb, removed, before = load_kb()
    kb = kb.replace('</script>', '<\\/script>')
    print(f'ريكوستات متشالة: {removed} من {before}')
    docs = open(os.path.join(HERE, 'docs.json'), encoding='utf-8').read().replace('</script>', '<\\/script>')

    assert '/*__KB__*/' in tpl and '/*__DOCS__*/' in tpl, 'العلامات ناقصة في القالب'
    full = tpl.replace('/*__KB__*/', kb).replace('/*__DOCS__*/', docs)

    os.makedirs(REPO, exist_ok=True)
    open(os.path.join(OUT, 'afaqy-api-helper.html'), 'w', encoding='utf-8').write(full)

    pub = tpl
    for a, b in SCRUB:
        pub = pub.replace(a, b)
    pub = pub.replace('/*__KB__*/', kb).replace('/*__DOCS__*/', docs)
    open(os.path.join(REPO, 'index.html'), 'w', encoding='utf-8').write(pub)

    leaks = LEAK.findall(pub)
    tokens = re.findall(r'eyJ[A-Za-z0-9\-_]{15,}', pub)
    return full, pub, leaks, tokens


# ---------------- الدليل المطبوع ----------------
CSS = """
@page { size: A4; margin: 18mm 16mm; }
* { box-sizing: border-box; }
body { font-family: "Cairo", "Noto Naskh Arabic", sans-serif; direction: rtl;
       color: #101A24; font-size: 11.5pt; line-height: 1.9; margin: 0; }
code, .lat { font-family: "DejaVu Sans Mono", monospace; direction: ltr;
             unicode-bidi: isolate; font-size: 10pt; background: #EEF2F5;
             padding: 1px 4px; border-radius: 2px; }
h1 { font-size: 22pt; margin: 0 0 2px; }
.sub { color: #64788B; font-size: 10pt; margin-bottom: 4px; }
.ver { display: inline-block; background: #00707F; color: #fff; padding: 2px 10px;
       border-radius: 99px; font-size: 10pt; }
.rule { height: 4px; background: repeating-linear-gradient(to right,#00707F 0 1px,transparent 1px 9px);
        margin: 10px 0 18px; }
.newbox { background: #D9EEF0; border-inline-start: 4px solid #00707F;
          padding: 12px 16px; border-radius: 0 3px 3px 0; margin-bottom: 20px; }
.newbox b { color: #004F5A; }
h2 { font-size: 14pt; margin: 0 0 6px; padding-bottom: 4px; border-bottom: 1px solid #DFE7ED; }
section { break-inside: avoid; margin-bottom: 16px; padding: 12px 16px;
          border: 1px solid #DFE7ED; border-radius: 3px; }
section.new { border-color: #00707F; border-inline-start: 4px solid #00707F; background: #F6FBFC; }
.tag { background: #DCEFE4; color: #1F6B45; font-size: 9pt; padding: 1px 8px;
       border-radius: 2px; margin-inline-start: 6px; font-weight: 600; }
ul { margin: 4px 0 0; padding-inline-start: 20px; }
li { margin-bottom: 5px; }
table { width: 100%; border-collapse: collapse; font-size: 10.5pt; margin-top: 6px; }
td { border-bottom: 1px solid #DFE7ED; padding: 6px 4px; vertical-align: top; }
.hist td:first-child { width: 78px; font-weight: 700; color: #00707F; }
footer { margin-top: 20px; padding-top: 10px; border-top: 1px solid #DFE7ED;
         color: #64788B; font-size: 9.5pt; }
"""

MONO = re.compile(r'\b([a-z_]+/[a-z_/]+|[a-z_]+\.[a-z_]+|[A-Za-z_]{3,}(?:_[A-Za-z_]+)+|IMEI|UID|API|curl|JSON|HTTP|200|401)\b')


def mono(txt):
    """يحط الكلام الإنجليزي والمسارات في خانة معزولة عشان الاتجاه ما يتلخبطش"""
    out = html.escape(txt)
    out = re.sub(r'(?<![\w>])((?:/[a-z_]+)+|[a-z_]+_[a-z_]+|status_code|message|id|UID|IMEI|API|curl|HTTP)(?![\w<])',
                 r'<code>\1</code>', out)
    out = re.sub(r'\*\*([^*]+)\*\*', r'<b>\1</b>', out)   # v5.7: العريض بيظهر عريض في الدليل المطبوع
    return out


def build_pdf():
    d = json.load(open(os.path.join(HERE, 'docs.json'), encoding='utf-8'))
    cur = d['version']
    newest = d['history'][0]

    secs = []
    for s in d['sections']:
        is_new = s['since'] == cur
        items = ''.join(f'<li>{mono(x)}</li>' for x in s['b']['ar'])
        tag = f'<span class="tag">جديد في {cur}</span>' if is_new else ''
        secs.append(f'<section class="{"new" if is_new else ""}">'
                    f'<h2>{html.escape(s["t"]["ar"])}{tag}</h2><ul>{items}</ul></section>')

    hist = ''.join(
        f'<tr><td>v{html.escape(h["v"])}</td><td>'
        + '<ul>' + ''.join(f'<li>{mono(x)}</li>' for x in h['items']['ar']) + '</ul>'
        + f'<div style="color:#64788B; font-size:9.5pt">{html.escape(h["date"])}</div></td></tr>'
        for h in d['history'])

    new_items = ''.join(f'<li>{mono(x)}</li>' for x in newest['items']['ar'])

    doc = f"""<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="utf-8">
<title>دليل مساعد الإنتجريشن v{cur}</title><style>{CSS}</style></head><body>
<h1>مساعد الإنتجريشن</h1>
<div class="sub">دليل الاستخدام — فريق الدعم الفني، أفاقي</div>
<span class="ver">v{cur}</span> <span class="sub">{html.escape(d['date'])}</span>
<div class="rule"></div>

<div class="newbox"><b>الجديد في النسخة دي — v{html.escape(newest['v'])}</b><ul>{new_items}</ul></div>

{''.join(secs)}

<section><h2>كل النسخ</h2><table class="hist">{hist}</table></section>

<footer>المستند ده بيتولّد من نفس مصدر الأداة. أي تعديل في الأداة بيظهر هنا في نفس اللحظة.<br>
استخدام داخلي — فريق الدعم الفني.</footer>
</body></html>"""

    src = os.path.join(HERE, '_docs.html')
    open(src, 'w', encoding='utf-8').write(doc)

    pdf_path = os.path.join(REPO, 'docs.pdf')
    try:
        from playwright.sync_api import sync_playwright
        with sync_playwright() as p:
            b = p.chromium.launch()
            pg = b.new_page()
            pg.goto('file://' + src)
            pg.wait_for_timeout(600)
            pg.pdf(path=pdf_path, format='A4', print_background=True,
                   margin={'top': '0', 'bottom': '0', 'left': '0', 'right': '0'})
            b.close()
    except Exception as ex:
        # المتصفح مش موجود على الجهاز ده — بنطبع نفس ملف المصدر بمحرك بديل
        print(f'  playwright مش متاح ({type(ex).__name__}) — الدليل بيتطبع بـ weasyprint')
        from weasyprint import HTML
        HTML(filename=src).write_pdf(pdf_path)
    return pdf_path


# علامات لازم تكون موجودة في الملف النهائي.
# اتعملت بعد ما استبدال في القالب فشل من غير ما يقول، ونشرنا نسخة ناقصة.
REQUIRED = [
    ('rememberRun(e, b, r)',       'تسجيل التشغيل الناجح في تبويب الريكوستات'),
    ('id="topCopy"',               'زرار نسخ الرد فوق'),
    ('id="topTry"',                'زرار التجربة فوق'),
    ('id="verTag"',                'رقم النسخة في الهيدر'),
    ('id="cpPacket"',              'زرار الرد الكامل بعد التجربة'),
    ('echoReq(e.m',                'عرض الريكوست اللي اتبعت'),
    ('function packetFor',         'بناء الرد الكامل'),
    ('applyUpdate',                'زرار التحديث'),
    ('rel="manifest"',             'ملف التثبيت مربوط'),
    ('function ensureDeps',        'بوابة المتطلبات'),
    ('async function ladderCore',   'نواة سلّم التصحيح'),
    ('function renderInspect',      'تبويب فحص الرد'),
    ('function pickRows',           'قراءة السجلات من أي شكل رد'),
    ('function epKind',             'تصنيف قراءة/كتابة/حساس'),
    ('wgGo',                        'بوابة تأكيد الكتابة'),
    ('FORBIDDEN',                   'قفل الريكوستات الحساسة'),
    ('id="tickCust"',               'خانة عميل التذكرة'),
    ('function polite',             'سقف التزامن'),
    ('function simOf',              'الشريحة في الكارت'),
    ('function mdBold',             'العريض في الدليل'),
    ('function escCtxLines',        'سياق التصعيد'),
    ('id="acctSel"',               'لستة الحسابات المحفوظة'),
    ('function acctSave',           'حفظ الحساب'),
]


def check_required(html):
    missing = [(m, why) for m, why in REQUIRED if m not in html]
    if missing:
        print('\n!! ناقص في الملف النهائي — استبدال فشل من غير ما يقول:')
        for m, why in missing:
            print(f'   {why}  ({m})')
    return not missing


def run_review():
    """مراجعة ساكنة: دوال ميتة، ونداءات على حاجة مش موجودة، وتعريفات مكررة."""
    r = subprocess.run(['node', 'review.js'], cwd=HERE, capture_output=True, text=True, timeout=60)
    print(r.stdout.rstrip())
    return r.returncode == 0


def run_tests():
    """كل الاختبارات لازم تعدي قبل أي بناء. القاعدة الذهبية التانية."""
    tests = sorted(f for f in os.listdir(HERE) if f.startswith('test_') and f.endswith('.js'))
    if not tests:
        print('!! مفيش اختبارات — ده غلط')
        return False, 0, 0
    failed = []
    for tf in tests:
        r = subprocess.run(['node', tf], cwd=HERE, capture_output=True, text=True, timeout=120)
        if r.returncode != 0:
            failed.append((tf, (r.stderr or r.stdout).strip().splitlines()[-3:]))
    if failed:
        print(f'\n!! فشل {len(failed)} من {len(tests)} اختبار:')
        for tf, err in failed:
            print(f'   {tf}')
            for line in err:
                print(f'      {line[:110]}')
        return False, len(tests) - len(failed), len(tests)
    return True, len(tests), len(tests)


SW_TEMPLATE = """/* خدمة الخلفية — الشبكة الأول، والكاش احتياطي.
   اسم الكاش فيه رقم النسخة، فأي نشر جديد بيلغي القديم بالكامل. */
const VERSION = '%%VER%%';
const CACHE = 'afaqy-helper-' + VERSION;
const SHELL = ['./', './index.html', './manifest.json',
               './icons/icon-192.png', './icons/icon-512.png'];

self.addEventListener('install', ev => {
  ev.waitUntil(caches.open(CACHE).then(c => c.addAll(SHELL)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', ev => {
  ev.waitUntil(
    caches.keys()
      .then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('message', ev => {
  if (ev.data === 'flush') {
    caches.keys().then(keys => Promise.all(keys.map(k => caches.delete(k))));
  }
});

self.addEventListener('fetch', ev => {
  const req = ev.request;
  if (req.method !== 'GET') return;                          // نداءات الـ API ما تتخزنش
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;           // سيرفر أفاقي يعدي على طول
  if (url.pathname.endsWith('version.json')) return;         // فحص النسخة دايمًا من الشبكة
  if (url.pathname.endsWith('sw.js')) return;

  /* الصفحة نفسها بتتجاب من الشبكة متجاهلة كاش المتصفح.
     من غير no-store، سيرفر الصفحات بيرجّع نسخة مخزّنة لحد عشر دقايق
     والأداة تفضل على نسخة قديمة مهما عملت تحديث. */
  const isDoc = req.mode === 'navigate' || url.pathname.endsWith('/') ||
                url.pathname.endsWith('index.html');

  ev.respondWith(
    fetch(isDoc ? new Request(req.url, {cache: 'no-store'}) : req)
      .then(res => {
        if (res && res.ok) {
          const copy = res.clone();
          caches.open(CACHE).then(c => c.put(req, copy));
        }
        return res;
      })
      .catch(() => caches.match(req, {ignoreSearch: true})
                         .then(r => r || caches.match('./index.html')))
  );
});
"""


def write_sw(ver):
    p2 = os.path.join(REPO, 'sw.js')
    open(p2, 'w', encoding='utf-8').write(SW_TEMPLATE.replace('%%VER%%', ver))
    return p2


REPO_URL = 'https://mhmdsfwt371.github.io/Afaqy-API-Helper/'


def sync_readme(ver):
    """الريدمي بيتحدّث مع البناء. سيبته يدوي فوقف عند v1.8 وهو v2.8."""
    p2 = os.path.join(REPO, 'README.md')
    txt = open(p2, encoding='utf-8').read()
    txt = re.sub(r'\*\*النسخة الحالية: v[\d.]+\*\*', f'**النسخة الحالية: v{ver}**', txt)
    txt = re.sub(r'https://<[^>]+>\.github\.io/[\w-]+/?', REPO_URL, txt)
    open(p2, 'w', encoding='utf-8').write(txt)
    return txt


def write_changelog(ver):
    """سجل التغييرات بيتولّد كامل من docs.json — مفيش نسخة يدوية تقع."""
    d = json.load(open(os.path.join(HERE, 'docs.json'), encoding='utf-8'))
    out = ['# سجل التغييرات', '',
           'الملف ده بيتولّد من `docs.json` مع كل بناء. ما تعدّلهوش بالإيد — التعديل هيضيع.', '']
    for h in d['history']:
        out.append(f"## v{h['v']} — {h['date']}")
        out.append('')
        for item in h['items']['ar']:
            out.append(f'- {item}')
        out.append('')
    p2 = os.path.join(REPO, 'CHANGELOG.md')
    open(p2, 'w', encoding='utf-8').write('\n'.join(out))
    return len(d['history'])


def check_docs_sync(ver):
    """أي ملف بيقول رقم نسخة لازم يقول نفس الرقم."""
    bad = []
    rd = open(os.path.join(REPO, 'README.md'), encoding='utf-8').read()
    m = re.search(r'النسخة الحالية: v([\d.]+)', rd)
    if not m or m.group(1) != ver:
        bad.append(f'README.md بيقول v{m.group(1) if m else "?"} والحقيقة v{ver}')
    if re.search(r'https://<[^>]+>', rd):
        bad.append('README.md لسه فيه لينك مؤقت')
    cl = open(os.path.join(REPO, 'CHANGELOG.md'), encoding='utf-8').read()
    m2 = re.search(r'^## v([\d.]+)', cl, re.M)
    if not m2 or m2.group(1) != ver:
        bad.append(f'CHANGELOG.md بيقول v{m2.group(1) if m2 else "?"} والحقيقة v{ver}')
    for f in os.listdir(REPO):
        if f.endswith('.md'):
            t = open(os.path.join(REPO, f), encoding='utf-8').read()
            if re.search(r'https://<[^>]+>', t) and f != 'README.md':
                bad.append(f'{f} فيه لينك مؤقت')
    if bad:
        print('\n!! الملفات مش متطابقة:')
        for b in bad:
            print('   ' + b)
    return not bad


def write_version():
    d = json.load(open(os.path.join(HERE, 'docs.json'), encoding='utf-8'))
    newest = d['history'][0]
    payload = {
        'version': d['version'],
        'date': d['date'],
        'notes': {'ar': newest['items']['ar'][:3], 'en': newest['items']['en'][:3]},
    }
    p2 = os.path.join(REPO, 'version.json')
    json.dump(payload, open(p2, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)
    return p2




def pack_zip(ver):
    """نسخة النجاة: الأداة المنشورة + المصدر كامل في زيب واحد على الريبو.
       بيتبني طازة مع كل نشر — من غير ملف الأسماء الخاص، وبفحص تسريب جوّاه.
       (الزيب القديم كان متجمّد على 4.4 وجواه الأسماء — الاتنين اتصلحوا هنا.)"""
    import zipfile
    zp = os.path.join(REPO, 'afaqy-api-helper.zip')
    top = ['دليل-النشر.md', 'اقرأني.txt', 'afaqy-login-test.ps1', 'afaqy-login-test.sh']
    src_names = sorted(f for f in os.listdir(HERE)
                       if (f.startswith('test_') and f.endswith('.js'))
                       or f in ('app_template.html', 'kb_slim.json', 'docs.json', 'build.py',
                                'bump.py', 'deploy.sh', 'setup.sh', 'review.js', '.gitignore', 'README.md'))
    bad = []
    tok = re.compile(rb'github_pat_[A-Za-z0-9_]{30,}')
    def scan(name, data):
        if tok.search(data):
            bad.append(name + ' (توكن)'); return
        try:
            txt = data.decode('utf-8')
        except UnicodeDecodeError:
            return
        if LEAK.search(txt):
            bad.append(name + ' (اسم عميل)')
    with zipfile.ZipFile(zp, 'w', zipfile.ZIP_DEFLATED) as z:
        for f in top:
            p2 = os.path.join(HERE, f)
            if not os.path.exists(p2):
                continue
            data = open(p2, 'rb').read()
            scan(f, data)
            z.writestr('afaqy-api-helper/' + f, data)
        for root, _, files in os.walk(REPO):
            for f in sorted(files):
                if f == 'afaqy-api-helper.zip':
                    continue
                p2 = os.path.join(root, f)
                rel = os.path.relpath(p2, REPO).replace(os.sep, '/')
                data = open(p2, 'rb').read()
                scan('نشر/' + rel, data)
                z.writestr('afaqy-api-helper/1-الأداة-للنشر/' + rel, data)
        for f in src_names:
            data = open(os.path.join(HERE, f), 'rb').read()
            if f == 'app_template.html':
                # القالب الداخلي فيه الأسماء الحقيقية — نسخة الزيب بتتنضّف بنفس قايمة النشر
                txt = data.decode('utf-8')
                for a, b in SCRUB:
                    txt = txt.replace(a, b)
                data = txt.encode('utf-8')
            scan('مصدر/' + f, data)
            z.writestr('afaqy-api-helper/2-المصدر/' + f, data)
    if bad:
        print('!! تسريب جوه الزيب — البناء وقف:')
        for b2 in bad:
            print('   ' + b2)
        sys.exit(1)
    return zp

if __name__ == '__main__':
    if not run_review():
        print('!! البناء وقف — المراجعة لقت مشكلة')
        sys.exit(1)

    ok, passed, total = run_tests()
    print(f'الاختبارات    : {passed} من {total}')
    if not ok:
        print('!! البناء وقف — صلّح الاختبارات الأول')
        sys.exit(1)

    full, pub, leaks, tokens = build_html()
    if not check_required(pub):
        print('!! البناء وقف')
        sys.exit(1)
    ver = json.load(open(os.path.join(HERE, 'docs.json'), encoding='utf-8'))['version']
    print(f'النسخة        : v{ver}')
    print(f'داخلية        : {len(full):,} بايت')
    print(f'عامة          : {len(pub):,} بايت')
    print(f'أسماء عملاء   : {len(leaks)}')
    print(f'توكنات        : {len(tokens)}')
    pdf = build_pdf()
    print(f'الدليل        : {os.path.getsize(pdf):,} بايت')
    vp = write_version()
    sw = write_sw(ver)
    sync_readme(ver)
    n_rel = write_changelog(ver)
    print(f'README + CHANGELOG: v{ver} ({n_rel} نسخة في السجل)')
    if not check_docs_sync(ver):
        print('!! البناء وقف — الملفات بتقول أرقام مختلفة')
        sys.exit(1)
    print(f'version.json  : v{ver}')
    print(f'sw.js         : كاش afaqy-helper-{ver}')
    zp = pack_zip(ver)
    print(f'الزيب         : {os.path.getsize(zp):,} بايت (الأداة + المصدر، من غير ملف الأسماء)')
    if leaks or tokens:
        print('!! في تسريب — وقّف النشر')
        sys.exit(1)
