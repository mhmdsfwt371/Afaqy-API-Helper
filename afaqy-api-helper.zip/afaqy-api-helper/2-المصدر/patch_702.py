#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v7.2 — عمود UID في لوحة الأجهزة.

طلب صفوت (٢٥ أكتوبر): الجدول كان بيعرض الاسم والـ IMEI والنوع… من غير الـ id
بتاع العربية (الـ UID) — اللي هو اللي العميل بيحتاجه في unit_id. دلوقتي:
- عمود «uid» بعد الاسم مباشرة، بخط ثابت العرض، وضغطة عليه بتنسخه (من غير ما
  تفتح الحساسات).
- نفس العمود في تصدير إكسل وفي الطباعة/PDF.
"""
import sys, io, os
HERE = os.path.dirname(os.path.abspath(__file__))
PATH = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, 'app_template.html')
src = io.open(PATH, encoding='utf-8').read(); orig = len(src)
def rep(old, new, n=1, tag=''):
    global src
    c = src.count(old)
    if c != n: raise SystemExit('MISMATCH [%s]: expected %d found %d\n---\n%s' % (tag, n, c, old[:200]))
    src = src.replace(old, new, n); print('  ok  %s' % tag)

rep("""  const first=['name','imei','device_serial','device','device_type','plate_number','sim_number','active'];
  const rest=[...seen.keys()].filter(k=>!first.includes(k)).sort((a,b)=>seen.get(b)-seen.get(a));
  return first.filter(k=>seen.has(k)).concat(rest).slice(0,14);
}""",
"""  /* v7.2: الـ UID (id العربية) عمود بعد الاسم — ده اللي العميل بيحتاجه في unit_id */
  if(rows.slice(0,300).some(u => u && (u.id || u._id))) seen.set('uid', rows.length);
  const first=['name','uid','imei','device_serial','device','device_type','plate_number','sim_number','active'];
  const rest=[...seen.keys()].filter(k=>!first.includes(k)).sort((a,b)=>seen.get(b)-seen.get(a));
  return first.filter(k=>seen.has(k)).concat(rest).slice(0,15);
}
/* الصف بقيمه + الـ uid — للتصدير والطباعة */
function dashRowOut(u){ return Object.assign({uid: String((u && (u.id || u._id)) || '')}, u || {}); }""", tag='عمود uid')
rep("""  const rows=dashRows(), cols=dashColumns(rows);
  const cell=(u,c)=>{ const v=u[c];
    if(v===null||v===undefined||v==='') return '—';""",
"""  const rows=dashRows(), cols=dashColumns(rows);
  const cell=(u,c)=>{ const v = c==='uid' ? String(u.id||u._id||'') : u[c];
    if(c==='uid') return v ? `<code class="uidc" data-uid="${esc(v)}" title="${esc(t('اضغط للنسخ','Click to copy'))}" style="font-size:11.5px; cursor:copy">${esc(v)}</code>` : '—';
    if(v===null||v===undefined||v==='') return '—';""", tag='خلية uid بتتنسخ')
rep("""  out.querySelectorAll('[data-slice]').forEach(el2=>el2.onclick=()=>{
    const k=el2.dataset.slice;
    DASH.filter = (DASH.filter===k) ? null : k;""",
"""  out.querySelectorAll('.uidc').forEach(el2=>el2.onclick=ev=>{ ev.stopPropagation(); copy(el2.dataset.uid, t('الـ UID اتنسخ','UID copied')); });
  out.querySelectorAll('[data-slice]').forEach(el2=>el2.onclick=()=>{
    const k=el2.dataset.slice;
    DASH.filter = (DASH.filter===k) ? null : k;""", tag='النسخ من غير فتح الحساسات')
rep("""  downloadXlsx(cols, rows, exportName(what), t('العربيات','Vehicles'));""",
    """  downloadXlsx(cols, rows.map(dashRowOut), exportName(what), t('العربيات','Vehicles'));""", tag='إكسل')
rep("""function dashPrint(){
  const rows=dashRows(), cols=dashColumns(rows);
  return printReport(t('تقرير الأجهزة','Device report'), cols, rows,""",
"""function dashPrint(){
  const rows=dashRows(), cols=dashColumns(rows);
  return printReport(t('تقرير الأجهزة','Device report'), cols, rows.map(dashRowOut),""", tag='طباعة')

io.open(PATH, 'w', encoding='utf-8').write(src)
print('القالب: %d → %d بايت' % (orig, len(src)))
