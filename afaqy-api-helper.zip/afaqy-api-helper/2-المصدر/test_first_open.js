/* v6.43 — الفتحة الأولى والمعرفة المحفوظة.
   الأداة بتقوم زي ما الموظف بيفتحها: DOM حقيقي، من غير hash، ومن غير ما
   الاختبار ينده showView بنفسه. ده اللي كل الاختبارات القديمة كانت بتعمله،
   فعيب «التبويب بيقول ابدأ من هنا واللي ظاهر الريكوستات» عدّى منها. */
const fs=require('fs'); const {JSDOM}=require('jsdom');
let F=0; const pass=m=>console.log('  \u2713 '+m); const fail=m=>{console.log('  \u2717 '+m);F++;};
const ok=(m,c,x)=>c?pass(m):fail(m+(x?'  \u2014 '+String(x).slice(0,130):''));
const build=()=>fs.readFileSync(process.argv[2]||'app_template.html','utf8')
  .replace('/*__KB__*/',()=>fs.readFileSync('kb_slim.json','utf8'))
  .replace('/*__DOCS__*/',()=>fs.readFileSync('docs.json','utf8'))
  .replace('/*__KBIN__*/',()=>fs.readFileSync('kb_in.json','utf8'));

function boot(url, seed){
  const w=new JSDOM(build(),{runScripts:'dangerously',pretendToBeVisual:true,url,
    beforeParse(win){ if(seed) Object.entries(seed).forEach(([k,v])=>win.localStorage.setItem(k,v)); }}).window;
  w.alert=()=>{}; w.confirm=()=>true; w.scrollTo=()=>{};
  return w;
}
const visible = w => [...w.document.querySelectorAll('section.view')].filter(s=>!s.hidden).map(s=>s.id);
const selected = w => [...w.document.querySelectorAll('.tab[aria-selected="true"]')].map(t=>t.dataset.view);

(async()=>{
/* ═════ ١) من غير hash: البداية بس ═════ */
{
  const w=boot('https://localhost/');
  await new Promise(r=>setTimeout(r,200));
  ok('التبويب المختار «ابدأ من هنا»', selected(w).join()==='triage', selected(w));
  ok('قسم واحد ظاهر وهو البداية', visible(w).join()==='v-triage', visible(w));
  ok('كروت البداية مرسومة', w.document.querySelectorAll('#trCards > *').length>=5,
     w.document.querySelectorAll('#trCards > *').length);
  ok('سجل التنقل بيبدأ من البداية', w.eval('VIEW_STACK').join()==='triage', w.eval('VIEW_STACK'));
}
/* ═════ ٢) لينك مباشر: التبويب بتاعه بس ═════ */
{
  const w=boot('https://localhost/#recipes');
  await new Promise(r=>setTimeout(r,200));
  ok('#recipes بيفتح السيناريوهات بس', visible(w).join()==='v-recipes', visible(w));
  ok('التبويب المختار السيناريوهات', selected(w).join()==='recipes', selected(w));
}
/* ═════ ٣) كل كارت فرز بيوجّه لتبويب موجود ═════ */
{
  const w=boot('https://localhost/');
  const bad=w.eval('TRIAGE.filter(x=>x.go && VIEWS.indexOf(x.go.tab)<0).map(x=>x.id)');
  ok('مفيش كارت بيوجّه لتبويب اتشال', bad.length===0, bad);
}
/* ═════ ٤) المعرفة المضافة بتتحفظ وترجع ═════ */
{
  const w=boot('https://localhost/');
  w.showView('faq');
  w.document.getElementById('adT').value='درس جديد';
  w.document.getElementById('adB').value='سطر\nتاني';
  w.document.getElementById('adGo').click();
  const raw=w.localStorage.getItem('afaqy.added.v1');
  ok('الإضافة اتكتبت على الجهاز', !!raw && JSON.parse(raw).length===1, raw);
  ok('مسجّلة بوقت الإضافة', /^\d{4}-\d\d-\d\dT/.test(JSON.parse(raw)[0].at||''));
  ok('الفورم بيقول لسه ما اتصدّرتش', /ما اتصدّرتش/.test(w.document.getElementById('adStat').textContent));

  const w2=boot('https://localhost/', {'afaqy.added.v1': raw});
  await new Promise(r=>setTimeout(r,50));
  ok('رجعت بعد إعادة الفتح', w2.eval('ADDED.length')===1 && w2.eval("LEARNED.some(k=>k.t && k.t.ar==='درس جديد')"));
  w2.showView('faq');
  ok('ظاهرة في الأساسيات', w2.document.getElementById('faq').textContent.includes('درس جديد'));
  ok('زرار المسح ظاهر لما فيه محفوظ', !w2.document.getElementById('adClr').hidden);
  w2.document.getElementById('adClr').click();
  ok('المسح بيفضّي الجهاز والقايمة', w2.eval('ADDED.length')===0 && !w2.eval("LEARNED.some(k=>k.t && k.t.ar==='درس جديد')")
     && JSON.parse(w2.localStorage.getItem('afaqy.added.v1')).length===0);

  /* التصدير بيعلّم، والحالة بتتغيّر */
  const w3=boot('https://localhost/', {'afaqy.added.v1': raw});
  w3.URL.createObjectURL=()=>'blob:x'; w3.HTMLAnchorElement.prototype.click=function(){};
  w3.showView('faq'); w3.document.getElementById('adExp').click();
  ok('التصدير بيسجّل وقته', !!w3.localStorage.getItem('afaqy.added.exportedAt'));
  ok('بعد التصدير الفورم بيقول كله اتصدّر', /اتصدّرت/.test(w3.document.getElementById('adStat').textContent)
     && !/ما اتصدّرتش/.test(w3.document.getElementById('adStat').textContent));
}
/* ═════ ٥) ملف مصدَّر من الأداة بيترجع من غير وسم <p> ظاهر ═════ */
{
  const w=boot('https://localhost/');
  const item={sev:'ok', t:{ar:'من ملف',en:'from file'}, src:{ar:'x',en:'x'}, body:{ar:'<p>نص<br>تاني</p>',en:'<p>text</p>'}};
  const s=w.addedSafe(item);
  ok('غلاف <p> ما بيتكررش', s.body.ar==='<p>نص<br>تاني</p>', s.body.ar);
  /* اللي الأداة كتبته بيرجع بالحرف: الاقتباس المهرّب ما بيتهرّبش تاني */
  const q=w.addedSafe({t:{ar:'قال "مش شغال"'}, body:{ar:'<p>قال &quot;مش شغال&quot;</p>'}});
  ok('الاقتباس ما بيتحوّلش لـ &amp;quot; بعد الاستيراد', q.body.ar==='<p>قال &quot;مش شغال&quot;</p>' && q.t.ar==='قال "مش شغال"', q.body.ar);
  const cap=w.addedSafe({body:{ar:'<p>الكولكشن بيوصف شكل تاني.</p><pre class="pre">{&quot;data&quot;:1}</pre>'}});
  ok('رصد المنصة (فقرة + pre) بيرجع زي ما هو', cap.body.ar==='<p>الكولكشن بيوصف شكل تاني.</p><pre class="pre">{&quot;data&quot;:1}</pre>', cap.body.ar);
  const evil=w.addedSafe({t:{ar:'<img src=x onerror=1>عنوان'}, body:{ar:'<script>1</script><p onclick=x>نص</p>'}});
  ok('الوسوم الغريبة بتتشال بصفاتها', evil.t.ar==='عنوان' && evil.body.ar==='<p>1نص</p>', evil.t.ar+' | '+evil.body.ar);
  /* اللي راجع من الجهاز بيعدّي على نفس التنضيف */
  const w2=boot('https://localhost/', {'afaqy.added.v1': JSON.stringify([{t:{ar:'x'}, body:{ar:'<img src=x onerror=1>'}, at:'2026-09-08T00:00:00Z'}])});
  ok('المحفوظ على الجهاز بيتنضّف عند الاسترجاع', w2.eval('ADDED.length')===1 && w2.eval('ADDED[0].body.ar')==='<p></p>', w2.eval('ADDED[0].body.ar'));
}

console.log(F ? `\nفشل ${F}` : '\nالفتحة الأولى والمعرفة المحفوظة: تمام');
process.exit(F?1:0);
})();
