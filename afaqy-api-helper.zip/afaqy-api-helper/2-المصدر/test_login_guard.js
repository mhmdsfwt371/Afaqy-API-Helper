const fs=require('fs');
function el(id){return{id,hidden:false,innerHTML:'',value:'',textContent:'',className:'',dataset:{},style:{},files:[],disabled:false,
 classList:{toggle(){},add(){},remove(){}},querySelectorAll(){return[]},addEventListener(){},focus(){},select(){},click(){},
 setAttribute(){},getAttribute(){return null},dispatchEvent(){},appendChild(){},remove(){},scrollIntoView(){}}}
const R={};global.document={documentElement:el(),body:el(),addEventListener(){},querySelectorAll(){return[]},
 querySelector(){return null},createElement(){return el()},getElementById(i){return R[i]||(R[i]=el(i))}};
global.history={pushState(){},replaceState(){}};
global.location={hash:''};
global.navigator={clipboard:{writeText(){return Promise.resolve()}}};global.window={scrollTo(){},addEventListener(){}};
global.fetch=()=>Promise.reject(0);global.Blob=function(){};global.URL={createObjectURL(){return''}};global.FileReader=function(){};
let js=fs.readFileSync('app_template.html','utf8').split('<script>')[1].split('</script>')[0]
  .replace('/*__KB__*/',fs.readFileSync('kb_slim.json','utf8')).replace('/*__DOCS__*/',fs.readFileSync('docs.json','utf8'));
const m={};new Function('module',js+'\nmodule.exports={EPS,SESSION,NO_RETRY,liveBody,bodyOf,setL:(l)=>{LANG=l}};')(m);
const A=m.exports;
const login=A.EPS.find(e=>e.p==='/auth/login');

console.log('١) قفل إعادة المحاولة على ريكوستات الدخول:');
['/auth/login','/auth/send_login_otp','/auth/verify_login_otp','/auth/login_as','/auth/reset',
 '/units/lists','/units/signals'].forEach(p=>{
  console.log('   '+(A.NO_RETRY.test(p)?'مقفول ':'مسموح ')+p);
});

console.log('\n٢) قبل الاتصال — البودي فيه علامات:');
console.log('   '+A.bodyOf(login).replace(/\s+/g,' '));

console.log('\n٣) بعد الاتصال — «جرّب مرة واحدة» بتستخدم بيانات الجلسة:');
A.SESSION.user='rawahel.hs'; A.SESSION.pass='SuperSecret123';
const live=A.liveBody(login);
console.log('   '+live.replace(/\s+/g,' '));
console.log('   فيه <USERNAME>؟ '+(live.includes('<USERNAME>')?'أيوه ✗':'لأ ✓'));
console.log('   فيه اليوزر الحقيقي؟ '+(live.includes('rawahel.hs')?'أيوه ✓':'لأ ✗'));

console.log('\n٤) الريكوستات العادية ما اتغيرتش:');
const u=A.EPS.find(e=>e.p==='/units/lists'&&e.n==='List');
console.log('   /units/lists فيه كلمة سر؟ '+(A.liveBody(u).includes('SuperSecret')?'أيوه ✗':'لأ ✓'));
