const fs = require('fs');
function el(id){return{id,hidden:false,innerHTML:'',value:'',textContent:'',className:'',dataset:{},style:{},files:[],disabled:false,
 classList:{toggle(){},add(){},remove(){}},querySelectorAll(){return[]},addEventListener(){},focus(){},select(){},click(){},
 setAttribute(){},getAttribute(){return null},dispatchEvent(){},appendChild(){},remove(){},scrollIntoView(){}}}
const R={};global.document={documentElement:el(),body:el(),addEventListener(){},querySelectorAll(){return[]},
 querySelector(){return null},createElement(){return el()},getElementById(i){return R[i]||(R[i]=el(i))}};
global.history={pushState(){},replaceState(){}};global.location={hash:'',pathname:'/',replace(){}};
global.setInterval=()=>0;
global.navigator={userAgent:'node',clipboard:{writeText(){return Promise.resolve()}}};
global.window={scrollTo(){},addEventListener(){},matchMedia:()=>({matches:false}),navigator:{}};
global.fetch=()=>Promise.reject(0);global.Blob=function(){};global.URL={createObjectURL(){return''}};global.FileReader=function(){};

let js = fs.readFileSync('app_template.html','utf8').split('<script>')[1].split('</script>')[0]
  .replace('/*__KB__*/', fs.readFileSync('kb_slim.json','utf8')).replace('/*__KBIN__*/', fs.readFileSync('kb_in.json','utf8'))
  .replace('/*__DOCS__*/', fs.readFileSync('docs.json','utf8'));
const m={};
new Function('module', js + "\nmodule.exports={EPS,labVariants,DESTRUCTIVE,NO_RETRY,redactToken,labBundle,SESSION};")(m);
const A=m.exports;
const fail = msg => { console.error('فشل: ' + msg); process.exit(1); };

const units = A.EPS.find(e=>e.p==='/units/lists' && e.n==='List');
const vs = A.labVariants(units);
if(vs.length < 3) fail('الصيغ أقل من المتوقع: ' + vs.length);
console.log('الصيغ لـ /units/lists : ' + vs.length);

/* الصيغتين المرصودتين من المنصة نفسها لازم يكونوا موجودين */
const names = vs.map(v=>v.n);
if(names.indexOf('data كنص JSON') < 0) fail('صيغة data كنص ناقصة');
if(names.indexOf('form-encoded زي المنصة') < 0) fail('صيغة form-encoded ناقصة');
const fe = vs.find(v=>v.n==='form-encoded زي المنصة');
if(fe.raw === undefined) fail('form-encoded مالهاش بودي خام');
if(fe.raw.indexOf('data=') !== 0) fail('شكل form-encoded غلط');
if(fe.h['Content-Type'] !== 'application/x-www-form-urlencoded') fail('هيدر form-encoded غلط');
console.log('صيغ المنصة المرصودة  : data كنص + form-encoded ✓');

['/units/edit','/unit_groups/bulk-delete','/auth/logout','/user_reports/send'].forEach(p=>{
  const e=A.EPS.find(x=>x.p===p); if(!e) return;
  if(!(A.DESTRUCTIVE.test(e.n)||A.DESTRUCTIVE.test(e.p))) fail('المفروض محظور: '+p); });
['/units/lists','/units/signals','/units/view'].forEach(p=>{
  const e=A.EPS.find(x=>x.p===p); if(!e) return;
  if(A.DESTRUCTIVE.test(e.n)||A.DESTRUCTIVE.test(e.p)) fail('المفروض مسموح: '+p); });
console.log('حظر التعديل والحذف   : تمام');

['/auth/login','/auth/send_login_otp','/auth/login_as'].forEach(p=>{
  if(!A.NO_RETRY.test(p)) fail('المفروض ممنوع إعادته: '+p); });
if(A.NO_RETRY.test('/units/lists')) fail('/units/lists اتمنع بالغلط');
console.log('منع إعادة الدخول     : تمام');

A.SESSION.token = 'eyJhbGciOiJIUzI1NiJ9.SECRET_VALUE_HERE.sig';
const red = A.redactToken('{"token":"eyJhbGciOiJIUzI1NiJ9.SECRET_VALUE_HERE.sig"}');
if(red.indexOf('SECRET_VALUE_HERE') >= 0) fail('التوكن ظاهر بعد الشطب');
console.log('شطب التوكن          : تمام');

const win = { v:{ url:'https://api.afaqy.sa/units/lists?token='+A.SESSION.token,
                  h:{'Content-Type':'application/json'}, body:{data:{limit:10}} }, code:200 };
const safeUrl = win.v.url.split(A.SESSION.token).join('<YOUR_TOKEN>');
const bundle = A.labBundle(units, win, safeUrl, red);
if(bundle.indexOf('SECRET_VALUE_HERE') >= 0) fail('التوكن في الرد الجاهز');
if(bundle.indexOf('status_code') < 0) fail('تحذير الـ 200 ناقص');
console.log('الرد الجاهز         : تمام');

['/units/add','/units/delete','/units/delete_forever'].forEach(p=>{
  if(A.EPS.some(e=>e.p===p)) fail('المفروض متشال: '+p); });
console.log('الإضافة والحذف      : متشالين');
