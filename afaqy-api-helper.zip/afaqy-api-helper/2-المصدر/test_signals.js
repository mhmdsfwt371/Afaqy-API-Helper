const fs = require('fs');
global.document = { addEventListener(){}, querySelectorAll(){return[]}, createElement(){return{select(){},remove(){}}}, body:{appendChild(){}} };
global.history={pushState(){},replaceState(){}};
global.location={hash:''};
global.navigator = { clipboard:{ writeText(){return Promise.resolve();} } };
global.window = { scrollTo(){}, addEventListener(){} };
global.fetch = () => Promise.reject(new Error('stub'));

let js = fs.readFileSync('app_template.html','utf8').split('<script>')[1].split('</script>')[0];
js = js.replace('/*__KB__*/', fs.readFileSync('kb_slim.json','utf8')).replace('/*__DOCS__*/', fs.readFileSync('docs.json','utf8')).split('/* ---------------- views ---------------- */')[0];
js = js.replace('const $ = id => document.getElementById(id);',
  "const $ = id => ({hidden:false,innerHTML:'',value:'',textContent:'',placeholder:'',querySelectorAll(){return[]},addEventListener(){},focus(){},setAttribute(){},dispatchEvent(){},onclick:null});");
const mod = {};
new Function('module', js + '\nmodule.exports={RECIPES,groupUnitIds,countRows,today,dayRange};')(mod);
const A = mod.exports;

console.log('today =', A.today(), '| dayRange =', JSON.stringify(A.dayRange()));

// شكل ١: قائمة معرّفات نصية
console.log('\ngroupUnitIds — نصوص:', A.groupUnitIds({name:'G1', unitsList:['u1','u2','u3']}).map(x=>x.id).join(','));
// شكل ٢: كائنات
console.log('groupUnitIds — كائنات:', A.groupUnitIds({name:'G2', unitsList:[{_id:'a1',name:'شاحنة 1'},{id:'a2',name:'شاحنة 2'}]}).map(x=>x.id+':'+x.name).join(' | '));
// شكل ٣: مفتاح مختلف تمامًا
console.log('groupUnitIds — احتياطي:', A.groupUnitIds({name:'G3', members:[{id:'z9',name:'ونش'}]}).map(x=>x.id+':'+x.name).join(' | '));

// عدّ الإشارات من ردود مختلفة الشكل
console.log('\ncountRows بيرسل =', A.countRows({status:true,data:{signals:[{t:1},{t:2},{t:3},{t:4}]}}));
console.log('countRows ساكت  =', A.countRows({status:true,data:{signals:[]}}));
console.log('countRows متداخل=', A.countRows({d:{x:{rows:[{a:1},{a:2}]}}}));

// أجسام الطلبات
const sig = A.RECIPES.find(r=>r.id==='unit-signals');
console.log('\nبودي إشارات جهاز:');
console.log(JSON.stringify(sig.steps[2].body({unitId:'U9', from:'2026-07-01', to:'2026-07-03'}), null, 1));

const grp = A.RECIPES.find(r=>r.id==='group-signals');
console.log('\nبودي إشارات جهاز داخل المجموعة:');
console.log(JSON.stringify(grp.steps[2].body({from:'2026-08-01', to:'2026-08-02'}, 'U77'), null, 1));

const loc = A.RECIPES.find(r=>r.id==='unit-loc');
console.log('\nبودي المواقع (المصحّح):');
console.log(JSON.stringify(loc.steps[2].body({unitId:'U5', day:'2026-08-03'}), null, 1));
