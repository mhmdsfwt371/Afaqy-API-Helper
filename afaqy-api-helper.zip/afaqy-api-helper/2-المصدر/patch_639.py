#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v6.39 — إندبوينتس التقارير بقت تسأل زي غيرها.

الأداة فيها آلية كاملة: تسأل عن الاسم، تجيب الرقم، تحطه في الريكوست.
شغّالة على العربيات والسواقين والمناطق والأحداث. بس /user_reports/
ما كانتش مطابقة لأي قاعدة في الجدول، فالإندبوينت كان بيتنفّذ برقم
التقرير اللي في العينة — رقم من حساب تاني — ويرجّع 405.

الباتش ده بيزوّد قاعدتين:
  · التقرير: اكتب اسمه، الأداة تجيب رقمه من /user_reports/lists
  · إنشاء تقرير: الصق الـ IMEIs، الأداة تجيب أرقام العربيات وتعمله
"""
import sys, io

PATH = sys.argv[1] if len(sys.argv) > 1 else 'app_template.html'
src = io.open(PATH, encoding='utf-8').read()
orig = len(src)

def rep(old, new, n=1, tag=''):
    global src
    c = src.count(old)
    if c != n: raise SystemExit('MISMATCH [%s]: expected %d found %d\n---\n%s' % (tag, n, c, old[:220]))
    src = src.replace(old, new, n); print('  ok  %s' % tag)

# ── ١) قاعدة التقرير في الجدول ──────────────────────────────
rep(""" { key:'event', fields:['event_id'], path:/^\\/events\\//i,""",
""" /* التقارير: الموظف شايف اسم في شاشة التقارير، والريكوست عايز رقم.
    نفس مشكلة العربيات بالظبط — وكانت مش متغطية. */
 { key:'report', fields:['report_id'], path:/^\\/user_reports\\/(?!lists|add)/i,
   label:{ar:'التقرير', en:'report'},
   ask:{ar:'اسم التقرير زي ما هو في شاشة التقارير', en:'The report name as it appears on the reports screen'},
   list:{path:'/user_reports/lists', body:{data:{limit:1000}}},
   note:{ar:'الرقم اللي في المثال بتاع حساب تاني — لو نفّذت بيه هيرجّع «مش موجود». اكتب اسم التقرير وأنا أجيب رقمه من الحساب المتصل.',
         en:'The id in the example belongs to another account — running with it returns not-found. Type the report name and the tool fetches its id from the connected account.'} },
 { key:'event', fields:['event_id'], path:/^\\/events\\//i,""",
    1, 'قاعدة التقرير')

# ── ٢) صندوق الـ IMEIs يشتغل على الإنشاء كمان ───────────────
rep("""function isReportEp(e){ return /^\\/user_reports\\/(data|data-summary|data-new)$/.test(e && e.p || ''); }""",
"""function isReportEp(e){ return /^\\/user_reports\\/(data|data-summary|data-new)$/.test(e && e.p || ''); }
/* إنشاء تقرير: مالوش رقم يتسأل عنه، بس محتاج عربيات — والموظف
   معاه IMEIs مش أرقام. فبنفتحله نفس الصندوق. */
function isReportMakeEp(e){ return /^\\/user_reports\\/add$/.test(e && e.p || ''); }
function wantsImeis(e){ return isReportEp(e) || isReportMakeEp(e); }""",
    1, 'إندبوينت الإنشاء')

rep("""    ${isReportEp(e) ? `""", """    ${wantsImeis(e) ? `""", 1, 'الصندوق يظهر للإنشاء')

rep("""  if(isReportEp(e) && (RSCOPE.mode === 'imeis' || RSCOPE.mode === 'allExplicit') && RSCOPE.uids.length){""",
"""  if(wantsImeis(e) && (RSCOPE.mode === 'imeis' || RSCOPE.mode === 'allExplicit') && RSCOPE.uids.length){""",
    1, 'الأرقام بتتحط في بودي الإنشاء')

# ── ٣) ensureDeps تفتح الصندوق للإنشاء حتى لو مفيش متطلب ناقص ──
rep("""function ensureDeps(e, cont){
  const missing = missingDeps(e);
  if(!missing.length) return true;""",
"""function ensureDeps(e, cont){
  const missing = missingDeps(e);
  /* إنشاء التقرير مالوش متطلب ناقص بالمعنى الحرفي — البودي كامل.
     بس من غير عربيات هيتعمل على الحساب كله، والموظف غالبًا عايز
     عربيات معيّنة ومعاه IMEIs. فبنفتحله الصندوق مرة قبل التنفيذ. */
  if(!missing.length && isReportMakeEp(e) && RSCOPE.mode !== 'imeis' && RSCOPE.mode !== 'allExplicit'){
    if(!SESSION.token){ toast(t('اتصل بحساب العميل من فوق الأول','Connect to the customer account first')); return false; }
    openDepsModal(e, [], cont);
    return false;
  }
  if(!missing.length) return true;""",
    1, 'ensureDeps للإنشاء')

# ── ٤) العنوان يتكلم صح لما مفيش متطلب ناقص ─────────────────
rep("""  $('mtitle').textContent = t('الريكوست ده محتاج حاجة قبله','This request needs something first');""",
"""  $('mtitle').textContent = missing.length
    ? t('الريكوست ده محتاج حاجة قبله','This request needs something first')
    : t('على أنهي عربيات؟','Which vehicles?');""",
    1, 'عنوان النافذة')

rep("""      ${t('السيستم بيشتغل بالأرقام، وانت شغال بالأسماء. اكتب الاسم وأنا أجيب الرقم — أو خدلك الخطوات وروح جيبه بنفسك.',
          'The platform works with ids and you work with names. Type the name and I will fetch the id — or take the steps and fetch it yourself.')}""",
"""      ${missing.length
        ? t('السيستم بيشتغل بالأرقام، وانت شغال بالأسماء. اكتب الاسم وأنا أجيب الرقم — أو خدلك الخطوات وروح جيبه بنفسك.',
            'The platform works with ids and you work with names. Type the name and I will fetch the id — or take the steps and fetch it yourself.')
        : t('البودي كامل. الحاجة الوحيدة الناقصة هي العربيات: الصق الـ IMEIs تحت وأنا أجيب أرقامها وأحطها، أو سيبها فاضية والتقرير هيتعمل على الحساب كله.',
            'The body is complete. The only open question is the vehicles: paste the IMEIs below and the tool fetches their ids and inserts them, or leave it empty and the report covers the whole account.')}""",
    1, 'شرح النافذة')

io.open(PATH, 'w', encoding='utf-8').write(src)
print('\ndone (%d -> %d, +%d)' % (orig, len(src), len(src) - orig))
