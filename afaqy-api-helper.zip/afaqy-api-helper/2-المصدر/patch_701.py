#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v7.1 — الأداة بتتعلم من كل حالة، و Claude من تبويب البحث، وتجربة المفتاح.

- «احفظ كمعرفة للفريق» تحت رد Claude: لما الموظف يراجع الرد ويعتمده، الفهم
  والخطوات واللي مش مؤكد بيتحفظوا كمعلومة مضافة (زي اللي بيضيفها الفريق):
  بترجع مع كل فتحة، وبتدخل مع كل نداء Claude جاي، وبتتصدّر لمسؤول الأداة
  عشان توصل لكل الفريق. الرد اللي فيه مسار مخترع ما يتحفظش.
- تبويب الريكوستات: لما البحث ما يلاقيش، أو فوق النتايج — «اسأل Claude عن ده»
  بينقل سؤال الموظف لخانة الرسالة ويشغّل الفهم.
- «جرّب المفتاح» في الإعدادات: نداء صغير بيأكد إن المفتاح شغّال قبل أي حالة.
"""
import sys, io, os
HERE = os.path.dirname(os.path.abspath(__file__))
PATH = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, 'app_template.html')
src = io.open(PATH, encoding='utf-8').read(); orig = len(src)
def rep(old, new, n=1, tag=''):
    global src
    c = src.count(old)
    if c != n: raise SystemExit('MISMATCH [%s]: expected %d found %d\n---\n%s' % (tag, n, c, old[:200]))
    src = src.replace(old, new, n); print('  ok  %s' % tag)

# ── ١) احفظ كمعرفة للفريق ───────────────────────────────────────
rep("""      <div class="row" style="margin-top:10px"><button class="btn ${ans.blocked ? 'ghost' : 'sig'}" id="caseCopy">${ans.blocked ? t('انسخ (فيه مسار مخترع!)','Copy (contains an invented path!)') : t('انسخ الرد','Copy the reply')}</button></div>""",
"""      <div class="row" style="margin-top:10px"><button class="btn ${ans.blocked ? 'ghost' : 'sig'}" id="caseCopy">${ans.blocked ? t('انسخ (فيه مسار مخترع!)','Copy (contains an invented path!)') : t('انسخ الرد','Copy the reply')}</button>
        ${!ans.blocked ? `<button class="btn ghost" id="aiKeep">${t('احفظ كمعرفة للفريق','Save as team knowledge')}</button>
        <span style="font-size:12px; color:var(--muted); align-self:center">${t('راجعته واتأكدت؟ بيتحفظ مع المعلومات المضافة وبيدخل مع كل نداء جاي.','Reviewed and confirmed? It is kept with the added entries and goes into every future call.')}</span>` : ''}</div>""",
    tag='زرار الحفظ')
rep("""  $('caseCopy').onclick = ()=>{ copy(reply, t('الرد اتنسخ','Reply copied')); };
  $('aiAr').onclick = ()=>{ AI_LANG = 'ar'; renderAi(ans, out, text); };""",
"""  $('caseCopy').onclick = ()=>{ copy(reply, t('الرد اتنسخ','Reply copied')); };
  const keep = $('aiKeep');
  if(keep) keep.onclick = ()=>{ const r = aiKeep(ans); toast(r === 'dup' ? t('متحفوظة قبل كده','Already saved') : t('اتحفظت مع معلومات الفريق — صدّرها من الأساسيات عشان توصل للكل','Saved with the team entries — export them from Basics so everyone gets them')); keep.disabled = true; };
  $('aiAr').onclick = ()=>{ AI_LANG = 'ar'; renderAi(ans, out, text); };""", tag='تنفيذ الحفظ')
rep("""/* القواعد ما عرفتش → اقتراح Claude فوق النتيجة */
function aiHint(text){""",
"""/* رد Claude اللي الموظف راجعه → معلومة مضافة زي بتوع الفريق: بترجع مع كل فتحة، وبتدخل مع كل نداء جاي، وبتتصدّر */
function aiKeep(ans){
  const T = String(ans.summary_ar || ans.diagnosis_ar || '').trim().slice(0, 160); if(!T) return 'empty';
  if(ADDED.some(k => k.t && k.t.ar === T)) return 'dup';
  const lines = [];
  if(ans.diagnosis_ar) lines.push(ans.diagnosis_ar);
  (ans.steps || []).forEach((s, i) => lines.push(`${i + 1}. ${s.method || 'POST'} ${s.path}` + (s.body && !s.body._raw ? ' ' + JSON.stringify(s.body) : '') + (s.why_ar || s.why_en ? ' — ' + (s.why_ar || s.why_en) : '')));
  (ans.unverified || []).forEach(x => lines.push(t('مش مؤكد: ','Unverified: ') + x));
  const B = lines.join('\\n');
  const item = { sev:'ok', t:{ar:T, en:T}, src:{ar:'من Claude — راجعها الموظف واعتمدها', en:'From Claude — reviewed and approved by the engineer'},
                 body:{ar:'<p>' + esc(B).replace(/\\n/g, '<br>') + '</p>', en:'<p>' + esc(B).replace(/\\n/g, '<br>') + '</p>'}, at:new Date().toISOString() };
  ADDED.push(item); LEARNED.push(item); addedStore();
  return 'ok';
}
/* سؤال الموظف من تبويب البحث → خانة الرسالة → Claude */
function aiFromSearch(q){
  showView('inspect'); INSPVIEW = 'case'; paintInspect();
  $('caseText').value = q; if(aiReady()) aiRun(q); else { const b = $('aiSet'); if(b) b.hidden = false; }
}
/* القواعد ما عرفتش → اقتراح Claude فوق النتيجة */
function aiHint(text){""", tag='دوال الحفظ والبحث')

# ── ٢) تبويب البحث ──────────────────────────────────────────────
rep("""    <div class="row" style="justify-content:center; margin-top:14px">
      <button class="btn warn" id="escal0">${t('تصعيد لتيم مصر','Escalate')}</button>
    </div></div></div>`;
  $('escal0').onclick = ()=>openEscalation(lastQ || t('سؤال غير معروف','unknown question'));""",
"""    <div class="row" style="justify-content:center; margin-top:14px">
      <button class="btn sig" id="aiAsk0">${t('اسأل Claude عن ده','Ask Claude about it')}</button>
      <button class="btn warn" id="escal0">${t('تصعيد لتيم مصر','Escalate')}</button>
    </div>
    <div style="font-size:12.5px; color:var(--muted); margin-top:8px">${t('Claude بيجاوب من التوثيق الرسمي بس، وكل مسار بيتفحص قبل ما يظهر.','Claude answers from the official documentation only, and every path is checked before it is shown.')}</div></div></div>`;
  $('escal0').onclick = ()=>openEscalation(lastQ || t('سؤال غير معروف','unknown question'));
  $('aiAsk0').onclick = ()=>aiFromSearch(lastQ || q || '');""", tag='اسأل Claude لما البحث ما يلاقيش')
rep("""  if(!list.length){ box.innerHTML = ''; return; }
  box.innerHTML = list.map((r,i)=>`""",
"""  if(!list.length){ box.innerHTML = ''; return; }
  box.innerHTML = (lastQ && lastQ.trim().length > 6 ? `<button class="chip" id="aiAskR" style="margin:0 0 8px; font-size:12px" title="${esc(t('بيجاوب من التوثيق الرسمي بس','Answers from the official documentation only'))}">${t('اسأل Claude عن ده','Ask Claude about it')}</button>` : '') + list.map((r,i)=>`""",
    tag='شريحة Claude فوق النتايج')
rep("""function renderResults(list){
  const box = $('results');""",
"""function renderResults(list){
  const box = $('results'); setTimeout(()=>{ const b = $('aiAskR'); if(b) b.onclick = ()=>aiFromSearch(lastQ || ''); }, 0);""", tag='ربط الشريحة')

# ── ٣) تجربة المفتاح ────────────────────────────────────────────
rep("""      <button class="btn sig" id="aiSave" style="margin-inline-start:auto">${t('احفظ','Save')}</button>""",
    """      <button class="btn ghost" id="aiPing" style="margin-inline-start:auto">${t('جرّب المفتاح','Test the key')}</button>
      <button class="btn sig" id="aiSave">${t('احفظ','Save')}</button>""", tag='زرار التجربة')
rep("""function aiWireSettings(){
  const s = $('aiSave'); if(!s) return;""",
"""/* نداء صغير بيأكد إن المفتاح شغّال — من غير التوثيق ولا أدوات */
async function aiPing(key, model){
  const r = await fetch('https://api.anthropic.com/v1/messages', { method:'POST',
    headers: {'content-type':'application/json', 'x-api-key': key, 'anthropic-version':'2023-06-01', 'anthropic-dangerous-direct-browser-access':'true'},
    body: JSON.stringify({ model: model || 'claude-sonnet-5', max_tokens: 5, messages: [{role:'user', content:'Reply with OK'}] }) });
  const j = await r.json().catch(() => ({}));
  if(!r.ok) throw new Error((j && j.error && j.error.message) || ('HTTP ' + r.status));
  return j;
}
function aiWireSettings(){
  const p = $('aiPing');
  if(p) p.onclick = async ()=>{ const k = ($('aiKey').value || '').trim(); if(k.length < 20){ toast(t('اكتب المفتاح الأول','Enter the key first')); return; }
    p.disabled = true; p.textContent = t('بنجرّب…','Testing…');
    try{ await aiPing(k, $('aiModel').value); toast(t('المفتاح شغّال ✓','The key works ✓')); }
    catch(err){ const m = String(err && err.message || err); toast(/invalid x-api-key|authentication/i.test(m) ? t('المفتاح مرفوض','The key was rejected') : /Failed to fetch|network/i.test(m) ? t('مفيش نت','No internet connection') : m.slice(0, 120)); }
    p.disabled = false; p.textContent = t('جرّب المفتاح','Test the key'); };
  const s = $('aiSave'); if(!s) return;""", tag='تنفيذ التجربة')

io.open(PATH, 'w', encoding='utf-8').write(src)
print('القالب: %d → %d بايت' % (orig, len(src)))
