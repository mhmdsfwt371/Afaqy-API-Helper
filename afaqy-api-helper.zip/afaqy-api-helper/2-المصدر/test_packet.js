const fs=require('fs');
function el(id){return{id,hidden:false,innerHTML:'',value:'',textContent:'',className:'',dataset:{},style:{},files:[],disabled:false,
 classList:{toggle(){},add(){},remove(){}},querySelectorAll(){return[]},addEventListener(){},focus(){},select(){},click(){},
 setAttribute(){},getAttribute(){return null},dispatchEvent(){},appendChild(){},remove(){},scrollIntoView(){}}}
const R={};global.document={documentElement:el(),body:el(),addEventListener(){},querySelectorAll(){return[]},
 querySelector(){return null},createElement(){return el()},getElementById(i){return R[i]||(R[i]=el(i))}};
global.history={pushState(){},replaceState(){}};global.location={hash:''};
global.setInterval=()=>0;   // المؤقت بيخلي الاختبار ما يخلصش في Node
global.navigator={userAgent:'node',clipboard:{writeText(){return Promise.resolve()}}};global.window={scrollTo(){},addEventListener(){},matchMedia:()=>({matches:false}),navigator:{}};
global.fetch=()=>Promise.reject(0);global.Blob=function(){};global.URL={createObjectURL(){return''}};global.FileReader=function(){};
let js=fs.readFileSync('app_template.html','utf8').split('<script>')[1].split('</script>')[0]
 .replace('/*__KB__*/',fs.readFileSync('kb_slim.json','utf8'))
 .replace('/*__DOCS__*/',fs.readFileSync('docs.json','utf8'));
const m={};new Function('module',js+'\nmodule.exports={EPS,customerPacket,trimResponse,packetFor,rememberRun,SESSION,setL:(l)=>{LANG=l}};')(m);
const A=m.exports;
A.SESSION.token='eyJSECRETTOKEN.abc';

// رد كبير زي بتاعك
const units=[]; for(let i=0;i<847;i++) units.push({_id:'u'+i,name:'Vehicle '+i,counters:{odometer:1000+i}});
const resp={ok:true, code:200, json:{message:'success', status_code:200, data:units},
             pretty:JSON.stringify({message:'success',status_code:200,data:units},null,2)};

const e=A.EPS.find(x=>x.p==='/units/lists'&&x.n==='List');
const body='{\n  "data": {\n    "offset": 0,\n    "limit": 1000\n  }\n}';
// من غير تشغيل: الرد الحقيقي مش موجود
const before=A.packetFor(e);
if(before.live) { console.error('فشل: قال عنده رد حقيقي وهو ما شغّلش'); process.exit(1); }
if(before.text.indexOf('not captured yet')<0){ console.error('فشل: ما نبّهش إن الرد ناقص'); process.exit(1); }
console.log('من غير تشغيل      : بينبّه إن الرد الحقيقي ناقص ✓');

// بعد تشغيل ناجح: نفس الزرار بيدي الرد الحقيقي
A.rememberRun(e, body, resp);
const after=A.packetFor(e);
if(!after.live){ console.error('فشل: ما فكرش التشغيل'); process.exit(1); }
console.log('بعد تشغيل ناجح    : بيدي الرد الحقيقي ✓');

// إندبوينت تاني ما ياخدش رد إندبوينت غيره
const other=A.EPS.find(x=>x.p==='/units/signals');
if(other && A.packetFor(other).live){ console.error('فشل: خلط رد إندبوينت بإندبوينت تاني'); process.exit(1); }
console.log('ما بيخلطش الردود   : ✓');

const p=after.text;

console.log('=== الرد الكامل ===');
console.log(p.slice(0,900));
console.log('\n...\n');
console.log('=== الفحص ===');
console.log('  فيه الإندبوينت؟   '+(p.includes('POST https://')||p.includes('/units/lists')?'✓':'✗'));
console.log('  فيه البودي؟       '+(p.includes('"limit": 1000')?'✓':'✗'));
console.log('  فيه الرد؟         '+(p.includes('"message": "success"')?'✓':'✗'));
console.log('  التوكن اتشال؟     '+(p.includes('eyJSECRETTOKEN')?'✗ ظاهر!':'✓'));
console.log('  الرد اتقص؟        '+(p.includes('first 2 of 847')?'✓ (بدل 847 عربية)':'✗'));
console.log('  الحجم النهائي     '+p.length+' حرف (بدل '+resp.pretty.length+')');
