#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v6.33 — بانل «حساسات الجهاز» في لوحة الأجهزة: /unit_sensors/lists لايف
مفلتر على الجهاز المختار بس، بدل قايمة تشيك بوكس عامة زي المنصة الرئيسية.
نفس التعديلات المطبّقة على app_template.html، هنا على أي HTML آخر."""
import io, sys

SRC = sys.argv[1] if len(sys.argv) > 1 else 'index.html'
s = io.open(SRC, encoding='utf-8').read()
BEFORE = len(s)
DONE = []

def rep(tag, old, new, count=1):
    global s
    n = s.count(old)
    if n != count:
        print(f'✗ {tag}: لقيت {n} مرة، المتوقع {count}')
        sys.exit(1)
    s = s.replace(old, new, count)
    DONE.append(tag)
    print(f'✓ {tag}')


rep('DASH — حقول اختيار الجهاز',
r"""const DASH = { units:[], filter:null, flag:null, scope:null, state:null, at:null };""",
r"""const DASH = { units:[], filter:null, flag:null, scope:null, state:null, at:null,
                sensorUnit:null, sensorResult:{}, sensorBusy:null };""")

rep('dashLoadUnits — تصفير الاختيار مع كل تحميل',
r"""    DASH.units = got.units;
    DASH.total = got.total;
    DASH.filter = null; DASH.flag = null; DASH.scope = null; DASH.state = null; DASH.at = new Date();""",
r"""    DASH.units = got.units;
    DASH.total = got.total;
    DASH.filter = null; DASH.flag = null; DASH.scope = null; DASH.state = null; DASH.at = new Date();
    DASH.sensorUnit = null; DASH.sensorResult = {}; DASH.sensorBusy = null;""")

rep('دالة الاتصال اللايف بحساسات الجهاز وبانل عرضها',
r"""function typePanel(){""",
r"""/* ============ حساسات جهاز واحد — حقيقة لا تخمين ============
   المنصة الحقيقية بتوري نفس قايمة التشيك بوكس (بطارية/استغاثة/حرارة/رطوبة/وزن)
   لكل الأجهزة زي بعض، سواء الجهاز عليه الحساس ده ولا لأ. إحنا بندّي على
   /unit_sensors/lists بفلتر unit_id — رد حقيقي عن الجهاز ده بالظبط،
   مش قايمة عامة ولا تخمين من اسم حقل زي sensorsOf(). جهاز GPS بسيط
   هيرجع مصفوفة فاضية، وده رد صح مش نقص في الأداة. */
async function dashCheckSensors(id){
  if(!id) return;
  DASH.sensorBusy = id;
  dashRender();
  try{
    const r = await apiFetch('/unit_sensors/lists',
      {data:{filters:{unit_id:id, name:'', type:'', param:''}}},
      {method:'POST', timeout:45000});
    if(!r.ok) throw new Error(diagnose(r.code, r.txt));
    const items = deepItems(r.json).map(x=>x.raw)
      .filter(s2 => s2 && (s2.type || s2.param || s2.name));
    DASH.sensorResult[id] = {ok:true, items, at:new Date()};
  }catch(err){
    DASH.sensorResult[id] = {ok:false, err:String((err && err.message) || err).slice(0,160)};
  }finally{
    DASH.sensorBusy = null;
    dashRender();
  }
}

/* بانل الجهاز المختار — بيظهر لما تدوس على أي صف في جدول البيانات تحت */
function sensorPanel(rows){
  if(!DASH.sensorUnit) return '';
  const id = DASH.sensorUnit;
  const u = rows.find(x => String(x.id||x._id||'')===id) ||
            DASH.units.find(x => String(x.id||x._id||'')===id);
  if(!u) return '';
  const res  = DASH.sensorResult[id];
  const busy = DASH.sensorBusy === id;
  const nm   = u.name || u.imei || id;

  let body;
  if(busy){
    body = `<div class="note">${t('بيجيب…','Loading…')}</div>`;
  } else if(!res){
    body = `<button class="btn sig" id="sensorGo">${t('تحقّق من حساساته الحقيقية','Check its real sensors')}</button>
      <div class="note" style="margin-top:8px">${t(
        'بينادي /unit_sensors/lists بفلتر الجهاز ده بس. مش قايمة عامة زي المنصة — ده اللي متسجّل عليه فعلًا.',
        'Calls /unit_sensors/lists filtered to this device only. Not a generic list like the platform shows — this is what is actually registered on it.')}</div>`;
  } else if(!res.ok){
    body = `<div class="note warn">${t('الريكوست فشل: ','The request failed: ')}${esc(res.err)}</div>
      <button class="btn ghost" id="sensorGo" style="margin-top:8px">${t('حاول تاني','Try again')}</button>`;
  } else if(!res.items.length){
    body = `<div class="note sig">${t(
      'مفيش حساسات مسجّلة على الجهاز ده — ده رد حقيقي من السيرفر مش نقص في الأداة. عادي لجهاز GPS بسيط من غير حساسات إضافية.',
      'No sensors are registered on this device — a real server response, not a gap in the tool. Normal for a plain GPS unit with no extra sensors.')}</div>
      <button class="btn ghost" id="sensorGo" style="margin-top:8px">${t('حدّث','Refresh')}</button>`;
  } else {
    body = `<table class="kv" style="margin-top:4px">
      <tr><td style="font-weight:600; width:40%">${t('الاسم','Name')}</td>
          <td style="font-weight:600; width:30%">${t('النوع','Type')}</td>
          <td style="font-weight:600">${t('الباراميتر','Param')}</td></tr>
      ${res.items.map(s2=>`<tr>
        <td>${esc(String(s2.name||'—'))}</td>
        <td><code style="font-size:12px">${esc(String(s2.type||'—'))}</code></td>
        <td><code style="font-size:12px">${esc(String(s2.param||'—'))}</code></td>
      </tr>`).join('')}
      </table>
      <div class="note" style="margin-top:8px">${t(
        `${res.items.length} حساس مسجّل على الجهاز ده بالظبط — مش قايمة عامة.`,
        `${res.items.length} ${res.items.length===1?'sensor':'sensors'} registered on this exact device — not a generic list.`)}</div>
      <button class="btn ghost" id="sensorGo" style="margin-top:8px">${t('حدّث','Refresh')}</button>`;
  }

  return `<div class="panel" style="margin-bottom:14px"><div class="sec" style="border-top:0">
    <h3 style="display:flex; align-items:center; gap:8px; flex-wrap:wrap">
      ${t('حساسات الجهاز','Device sensors')} — ${esc(String(nm))}
      <span class="tagv">${esc(typeLabel(typeOf(u)))}</span>
    </h3>
    ${body}
  </div></div>`;
}

function typePanel(){""")

rep('إدراج بانل الحساسات فوق جدول البيانات',
r"""  ${(()=>{ const tp=typePanel(); return tp ? `<div class="panel" style="margin-bottom:14px"><div class="sec" style="border-top:0">${tp}</div></div>` : ''; })()}
  <div class="panel"><div class="sec" style="border-top:0">
    <h3>${t('البيانات','The data')} — ${rows.length} ${t('من','of')} ${total}
      ${DASH.flag?`<span class="tagv">${esc(dual((dashInsights().find(x=>x.k===DASH.flag)||{ttl:{ar:'',en:''}}).ttl))}</span>`:''}</h3>
    <div style="overflow-x:auto; margin-top:8px">
      <table class="kv" style="min-width:100%">
        <tr>${cols.map(c=>`<td style="font-family:var(--ar); color:var(--ink); font-weight:600; white-space:nowrap">${esc(c)}</td>`).join('')}</tr>
        ${rows.slice(0,300).map(u=>`<tr>${cols.map(c=>`<td style="white-space:nowrap">${cell(u,c)}</td>`).join('')}</tr>`).join('')}
      </table>
    </div>
    ${rows.length>300?`<div class="note" style="margin-top:8px">${t('بنعرض أول 300. التصدير بينزّل الكل.','Showing the first 300. Export downloads all of them.')}</div>`:''}
  </div></div>`;""",
r"""  ${(()=>{ const tp=typePanel(); return tp ? `<div class="panel" style="margin-bottom:14px"><div class="sec" style="border-top:0">${tp}</div></div>` : ''; })()}
  ${sensorPanel(rows)}
  <div class="panel"><div class="sec" style="border-top:0">
    <h3>${t('البيانات','The data')} — ${rows.length} ${t('من','of')} ${total}
      ${DASH.flag?`<span class="tagv">${esc(dual((dashInsights().find(x=>x.k===DASH.flag)||{ttl:{ar:'',en:''}}).ttl))}</span>`:''}</h3>
    <div class="note" style="margin-top:6px; margin-bottom:2px">${t(
      'دوس على أي صف عشان تشوف حساساته الحقيقية.', 'Click any row to see its real sensors.')}</div>
    <div style="overflow-x:auto; margin-top:8px">
      <table class="kv" style="min-width:100%">
        <tr>${cols.map(c=>`<td style="font-family:var(--ar); color:var(--ink); font-weight:600; white-space:nowrap">${esc(c)}</td>`).join('')}</tr>
        ${rows.slice(0,300).map(u=>{
          const uid = String(u.id||u._id||'');
          const sel = uid && uid===DASH.sensorUnit;
          const attrs = uid ? `data-unit="${esc(uid)}" style="cursor:pointer; ${sel?'background:var(--signal-soft)':''}"` : '';
          return `<tr ${attrs}>${cols.map(c=>`<td style="white-space:nowrap">${cell(u,c)}</td>`).join('')}</tr>`;
        }).join('')}
      </table>
    </div>
    ${rows.length>300?`<div class="note" style="margin-top:8px">${t('بنعرض أول 300. التصدير بينزّل الكل.','Showing the first 300. Export downloads all of them.')}</div>`:''}
  </div></div>`;""")

rep('ربط دوسة الصف وزرار التحقق',
r"""  const ab=$('dashAll'); if(ab) ab.onclick=()=>{
    DASH.filter=null; DASH.flag=null; DASH.scope=null; DASH.state=null; dashRender(); };
}""",
r"""  const ab=$('dashAll'); if(ab) ab.onclick=()=>{
    DASH.filter=null; DASH.flag=null; DASH.scope=null; DASH.state=null; dashRender(); };
  out.querySelectorAll('[data-unit]').forEach(el2=>el2.onclick=()=>{
    const id = el2.dataset.unit;
    DASH.sensorUnit = (DASH.sensorUnit===id) ? null : id;
    dashRender();
  });
  const sg = $('sensorGo'); if(sg) sg.onclick = ()=>dashCheckSensors(DASH.sensorUnit);
}""")

io.open(SRC, 'w', encoding='utf-8').write(s)
print(f'\n{len(DONE)} تعديل اتنفذ · الملف {BEFORE} → {len(s)} حرف')
