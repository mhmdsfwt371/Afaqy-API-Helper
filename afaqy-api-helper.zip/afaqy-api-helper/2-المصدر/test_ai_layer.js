/* v7.0 — Claude جوه الأداة: مؤسس على التوثيق، ومتفحوص قبل ما يظهر. الـ API هنا وهمي؛ الفحص الحقيقي في test_browser.py. */
const fs=require('fs'); const {JSDOM}=require('jsdom');
let F=0; const ok=(m,c,x)=>{ console.log((c?'  \u2713 ':'  \u2717 ')+m+(c||!x?'':'  \u2014 '+String(x).slice(0,170))); if(!c) F++; };
const html=fs.readFileSync(process.argv[2]||'app_template.html','utf8')
  .replace('/*__KB__*/',()=>fs.readFileSync('kb_slim.json','utf8'))
  .replace('/*__DOCS__*/',()=>fs.readFileSync('docs.json','utf8'))
  .replace('/*__KBIN__*/',()=>fs.readFileSync('kb_in.json','utf8'));
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
function boot(){ const w=new JSDOM(html,{runScripts:'dangerously',pretendToBeVisual:true,url:'https://localhost/'}).window;
  w.alert=()=>{}; w.scrollTo=()=>{}; w.showView('inspect'); w.eval("INSPVIEW='case'"); w.paintInspect(); return w; }
const MSG='Dear team, when calling /units/locations with unit_id 861230044934025 and token=eyJabcdefghijklmnopqrstuvwxyz0123456789.abcdefghijklmnop.qrstuvwxyz1234 we get not_allowed 401. Password: "password":"Secret123"';
function answer(over){ return Object.assign({kind:'troubleshoot', summary_ar:'الـ IMEI في unit_id', diagnosis_ar:'المفروض UID', steps:[
   {method:'POST', path:'/units/lists', body:'{"data":{"offset":0,"limit":1,"projection":["basic"],"filters":{"imei":{"value":["861230044934025"],"op":"in"}}}}', why_en:'get the UID'},
   {method:'POST', path:'/units/signals', body:'{"data":{"unit_id":"<UID>"}}', why_en:'positions'}],
   reply_en:'Dear team, use the UID from /units/lists then call /units/signals.', reply_ar:'السادة المحترمين، استخدموا الـ UID من /units/lists ثم /units/signals.', unverified:['retention period'], needs_from_customer:[], confidence:0.9}, over||{}); }
function mockFetch(w, ans, status){
  w.__req=null;
  w.fetch=async (url,opt)=>{ w.__req={url,opt:{headers:opt.headers, body:JSON.parse(opt.body)}};
    if(status) return {ok:false, status, json:async()=>({type:'error', error:{type:'authentication_error', message:'invalid x-api-key'}})};
    return {ok:true, status:200, json:async()=>({model:'claude-sonnet-5', usage:{input_tokens:18000, output_tokens:900, cache_read_input_tokens:0, cache_creation_input_tokens:12000}, content:[{type:'tool_use', name:'answer', input:ans}]})}; };
}
(async()=>{
/* ١) من غير مفتاح: مفيش نداء، والزرار بيفتح الإعدادات */
{ const w=boot(); mockFetch(w, answer());
  ok('الزرار مطفي والإعدادات ظاهرة لما مفيش مفتاح', w.document.getElementById('aiGo').disabled && !w.document.getElementById('aiSet').hidden);
  w.document.getElementById('caseText').value=MSG; await w.aiRun(MSG); await sleep(20);
  ok('مفيش نداء من غير مفتاح', w.__req===null);
}
/* ٢) اللي بيتبعت */
{ const w=boot(); mockFetch(w, answer());
  w.eval("SESSION.token='eyJabcdefghijklmnopqrstuvwxyz0123456789.abcdefghijklmnop.qrstuvwxyz1234'; SESSION.pass='Secret123'; AI.key='sk-ant-test-key-0123456789abcdef'; AI.remember=false;");
  w.document.getElementById('caseText').value=MSG; await w.aiRun(MSG); await sleep(30);
  const r=w.__req; const body=r.opt.body; const sys=body.system.map(s=>s.text).join('\n'); const user=body.messages[0].content.map(c=>c.text||'').join('\n');
  ok('النداء لـ Anthropic API مباشرة بهيدر المتصفح والنسخة', /api\.anthropic\.com\/v1\/messages/.test(r.url) && r.opt.headers['anthropic-dangerous-direct-browser-access']==='true' && r.opt.headers['anthropic-version']==='2023-06-01' && r.opt.headers['x-api-key']==='sk-ant-test-key-0123456789abcdef');
  ok('الموديل الافتراضي claude-sonnet-5 والرد المنظّم بأداة answer', body.model==='claude-sonnet-5' && body.tools[0].name==='answer' && body.tools[0].input_schema.required.includes('reply_ar'));
  ok('فهرس التوثيق كله مع النداء (193 ريكوست)', (sys.match(/^(GET|POST|PUT|DELETE) \//gm)||[]).length>=190, (sys.match(/^(GET|POST|PUT|DELETE) \//gm)||[]).length);
  ok('المحفوظ من غير توثيق متعلّم «ما يتبعتش للعميل»', /\/units\/locations[^\n]*NOT IN OFFICIAL DOCUMENTATION/.test(sys));
  ok('المعرفة المؤكدة مع النداء (الأساسيات ودروس التذاكر والقواعد)', /VERIFIED KNOWLEDGE/.test(sys) && /Known mistake/.test(sys) && /Logging in and getting a token/.test(sys));
  ok('التوثيق الكبير متعلّم للكاش', body.system[1].cache_control && body.system[1].cache_control.type==='ephemeral');
  ok('تفاصيل المرشّحين: المسار المذكور في الرسالة ببوديه ووصفه', /### POST \/units\/locations/.test(user) && /### POST \/units\/lists/.test(user) && /Sample body:/.test(user));
  ok('التوكن وكلمة السر اتشالوا قبل الإرسال', !/eyJabcdefghijklmnop/.test(user) && !/Secret123/.test(user) && /<TOKEN>/.test(user) && /<PASSWORD>/.test(user));
  ok('الـ IMEI فضل زي ما هو (الفهم محتاجه)', /861230044934025/.test(user));
  ok('القواعد الصارمة: ما تخترعش، UID مش IMEI، 200 مع خطأ، ما توعدش', /Never invent an endpoint/.test(sys) && /never by the IMEI/.test(sys) && /HTTP 200 even on failure/.test(sys) && /Never promise/.test(sys));
  const out=w.document.getElementById('caseOut').textContent;
  ok('الرد اتعرض: كل المسارات موثّقة', /اتفحص: كل المسارات موثّقة/.test(out) && /مش مؤكد/.test(out) && /retention period/.test(out));
  ok('التكلفة التقريبية ظاهرة', /\$0\.\d{3}/.test(out));
  const pre=w.document.getElementById('caseReplyTxt').textContent;
  ok('الرد الإنجليزي للرسالة الإنجليزية', /Dear team, use the UID/.test(pre));
  w.document.getElementById('aiAr').click(); ok('زرار العربي بيقلب الرد', /السادة المحترمين/.test(w.document.getElementById('caseReplyTxt').textContent));
}
/* ٣) الفحص: مسار مخترع بيتمسك ويمنع الإرسال، ومحفوظ من غير توثيق تحذير */
{ const w=boot(); w.eval("AI.key='sk-ant-test-key-0123456789abcdef'; AI.remember=false;");
  mockFetch(w, answer({steps:[{method:'POST', path:'/units/last_position', body:'{}'}], reply_en:'Call /units/last_position to get it.', reply_ar:'استخدم /units/last_position.'}));
  w.document.getElementById('caseText').value=MSG; await w.aiRun(MSG); await sleep(30);
  const out=w.document.getElementById('caseOut').textContent, a=w.eval('AI.last');
  ok('مسار مخترع اتمسك في الخطوات وفي الرد', a.blocked && a.steps[0].st==='invented' && a.replyIssues.some(x=>x.path==='/units/last_position' && x.st==='invented'));
  ok('الشاشة بتقول ما تبعتش', /فيه مسار مخترع — ما تبعتش/.test(out) && /انسخ \(فيه مسار مخترع!\)/.test(out));
  mockFetch(w, answer({steps:[{method:'POST', path:'/units/locations', body:'{"data":{"unit_id":"x"}}'}], reply_en:'Use /units/locations.', reply_ar:'استخدم /units/locations.'}));
  await w.aiRun(MSG); await sleep(30);
  const a2=w.eval('AI.last');
  ok('محفوظ من غير توثيق: تحذير مش منع', !a2.blocked && a2.warn && a2.steps[0].st==='undocumented' && /راجع التحذيرات/.test(w.document.getElementById('caseOut').textContent));
  mockFetch(w, answer({steps:[{method:'POST', path:'/units/lists', body:'not json'}]}));
  await w.aiRun(MSG); await sleep(30);
  ok('بودي مش JSON بيتعرض خام من غير ما يكسر', w.eval('AI.last').steps[0].body._raw==='not json');
}
/* ٤) المفتاح: مخفي في التخزين، وبيتحمّل تاني */
{ const w=boot(); w.document.getElementById('aiKey').value='sk-ant-test-key-0123456789abcdef'; w.document.getElementById('aiRemember').checked=true; w.document.getElementById('aiSave').click();
  const raw=w.localStorage.getItem('afaqy.ai.v1');
  ok('المفتاح متخزّن مخفي مش نص صريح', raw && !/sk-ant-test/.test(raw) && JSON.parse(raw).k.length>10);
  ok('بعد الحفظ الزرار شغّال والإعدادات اتخفت', !w.document.getElementById('aiGo').disabled && w.document.getElementById('aiSet').hidden);
  const w2=new JSDOM(html,{runScripts:'dangerously',pretendToBeVisual:true,url:'https://localhost/',beforeParse(win){ win.localStorage.setItem('afaqy.ai.v1', raw); }}).window;
  ok('بيتحمّل مع الفتحة الجاية', w2.eval('AI.key')==='sk-ant-test-key-0123456789abcdef');
  w.document.getElementById('aiRemember').checked=false; w.document.getElementById('aiSave').click();
  ok('من غير «افتكر»: مفيش حاجة على الجهاز', w.localStorage.getItem('afaqy.ai.v1')===null && w.eval('aiReady()'));
}
/* ٥) مفتاح مرفوض: رسالة واضحة والإعدادات بتفتح */
{ const w=boot(); w.eval("AI.key='sk-ant-bad-key-0123456789abcdef'; AI.remember=false;"); mockFetch(w, null, 401);
  w.document.getElementById('caseText').value=MSG; await w.aiRun(MSG); await sleep(30);
  ok('المفتاح المرفوض بيتقال بوضوح', /المفتاح مرفوض/.test(w.document.getElementById('caseOut').textContent) && !w.document.getElementById('aiSet').hidden);
}
/* ٦) الاقتراح لما القواعد ما تعرفش */
{ const w=boot(); const U='Hello, we have a question about your webhooks and the retention of historical data, how long is it kept?';
  w.document.getElementById('caseText').value=U; w.document.getElementById('caseGo').click(); await sleep(30);
  ok('حالة القواعد ما عرفتهاش: اقتراح Claude فوق النتيجة', /القواعد ما عرفتش الحالة دي/.test(w.document.getElementById('caseOut').textContent));
  const T='POST https://api.afaqy.sa/units/locations\n{"data":{"unit_id":"861230044934025"}}\n{"message":"not_allowed","status_code":401,"data":[]}';
  w.document.getElementById('caseText').value=T; w.document.getElementById('caseGo').click(); await sleep(30);
  ok('حالة القواعد عارفاها: مفيش اقتراح', !/القواعد ما عرفتش/.test(w.document.getElementById('caseOut').textContent));
}
console.log(F?`\nفشل ${F}`:'\nClaude جوه الأداة: تمام'); process.exit(F?1:0);
})();
