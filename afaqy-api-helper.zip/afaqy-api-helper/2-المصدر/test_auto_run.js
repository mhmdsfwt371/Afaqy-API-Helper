/* v6.41 — «شغّل كل الخطوات» بيمشي لوحده لآخر السلسلة.
   بنحاكي حساب حقيقي: بنبعت ردود بالأشكال الموثّقة ونشوف الأداة
   بتمشي لوحدها ولا بتقف. */
const fs=require('fs'); const {JSDOM}=require('jsdom');
let F=0; const pass=m=>console.log('  \u2713 '+m); const fail=m=>{console.log('  \u2717 '+m);F++;};
const ok=(m,c,x)=>c?pass(m):fail(m+(x?'  \u2014 '+String(x).slice(0,130):''));
const build=()=>fs.readFileSync(process.argv[2]||'app_template.html','utf8')
  .replace('/*__KB__*/',()=>fs.readFileSync('kb_slim.json','utf8'))
  .replace('/*__DOCS__*/',()=>fs.readFileSync('docs.json','utf8'))
  .replace('/*__KBIN__*/',()=>fs.readFileSync('kb_in.json','utf8'));
const nap=ms=>new Promise(r=>setTimeout(r,ms));
async function until(fn,n,g){ for(let i=0;i<(n||120);i++){ if(fn()) return true; await nap(g||100);} return false; }

const IMEI='860123456789012';
function boot(rowsBack){
  const w=new JSDOM(build(),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://localhost/'}).window;
  w.alert=()=>{}; w.confirm=()=>true; w.scrollTo=()=>{};
  w.eval("SESSION.token='TOK'; SESSION.user='Opp'; SESSION.userId='UID9';");
  const calls=[]; let pct=0;
  w.fetch = async (url,opt)=>{
    let b=null; try{ b=JSON.parse(opt&&opt.body); }catch(_){}
    const p=String(url).split('?')[0].replace(/^https?:\/\/[^/]+/,'');
    calls.push({p, b});
    const J=o=>({ok:true,status:200,text:async()=>JSON.stringify(o)});
    if(p==='/unit_groups/lists') return J({data:{items:[{id:'G1',name:'Riyadh'}]}});
    if(p==='/units/lists') return J({data:{items:[
       {id:'U_A',name:'Truck A',imei:'860999999999999'},
       {id:'U_B',name:'Truck B',imei:IMEI}]}});
    if(p==='/user_report_templates/lists') return J({data:{items:[
       {id:'T0',name:'Trips',   code:'trips',   fields:[{name:'x',code:'x'}]},
       {id:'T1',name:'Summary', code:'summary', fields:[{name:'Route',code:'route_length'}]}]}});
    if(p==='/user_reports/add') return J({data:{id:'RPT7'}});
    if(p==='/user_reports/percentage'){ pct+=34; return J({data:[{reportId:'RPT7',percentage:Math.min(100,pct)}]}); }
    if(p==='/user_reports/data-summary')
      return J({data: rowsBack ? [{resource_id:'U_B',name:'Truck B',route_length:70.4,max_spd:108}] : []});
    return J({data:[]});
  };
  return {w, calls};
}

async function runAll(w){
  w.showView('recipes'); w.startRecipe('summary-report');
  w.eval(`RC.vars.imei='${IMEI}'; RC.vars.from='2026-08-01'; RC.vars.to='2026-08-05';`);
  w.document.getElementById('rcAll').click();
  await until(()=>w.eval('RC.auto===false'), 150, 120);
}

(async () => {
/* ═════ ١) بيمشي لآخره من غير ما يقف ═════ */
console.log('\n\u0661) بيمشي لوحده لآخر السلسلة');
{
  const {w,calls}=boot(true);
  await runAll(w);
  const paths=calls.map(c=>c.p);
  ok('نادى units/lists لتحويل الـ IMEI', paths.includes('/units/lists'));
  ok('نادى القوالب', paths.includes('/user_report_templates/lists'));
  ok('نادى add', paths.includes('/user_reports/add'));
  ok('نادى percentage أكتر من مرة',
     paths.filter(p=>p==='/user_reports/percentage').length>=3,
     paths.filter(p=>p==='/user_reports/percentage').length);
  ok('نادى data-summary', paths.includes('/user_reports/data-summary'));
  const iP=paths.indexOf('/user_reports/percentage'), iS=paths.indexOf('/user_reports/data-summary');
  ok('الانتظار قبل القراءة', iP>-1 && iP<iS, paths.join(' → ').slice(0,150));
  ok('ما وقفش عند أي اختيار',
     w.eval('RC.results.filter(x=>x&&x.picker).length')===0,
     w.eval('RC.results.filter(x=>x&&x.picker).length'));
  w.close();
}

/* ═════ ٢) الـ IMEI اتحوّل لرقم عربية ═════ */
console.log('\n\u0662) الـ IMEI اتحوّل صح');
{
  const {w,calls}=boot(true);
  await runAll(w);
  const add=calls.find(c=>c.p==='/user_reports/add');
  ok('add بعت رقم العربية مش الـ IMEI',
     add && JSON.stringify(add.b.data.resources)===JSON.stringify(['U_B']),
     JSON.stringify(add&&add.b.data.resources));
  ok('والـ IMEI مش في البودي خالص', add && JSON.stringify(add.b).indexOf(IMEI)<0);
  ok('واختار قالب الـ summary مش الأول', add && add.b.data.code==='summary', add&&add.b.data.code);
  ok('والفترة من المدخلات', add && add.b.data.date.from==='2026-08-01 00:00:00', add&&add.b.data.date.from);
  w.close();
}

/* ═════ ٣) الخلاصة والرد بيطلعوا ═════ */
console.log('\n\u0663) الخلاصة والرد الجاهز');
{
  const {w}=boot(true);
  await runAll(w);
  await until(()=>!!w.document.getElementById('rcWrap'), 40, 100);
  const wrap=w.document.getElementById('rcWrap');
  ok('بلوك الخلاصة ظهر', !!wrap);
  ok('بيقول رجع كام صف', wrap && /1 صف|1 row/.test(wrap.textContent), wrap&&wrap.textContent.slice(0,90));
  const rep=w.document.getElementById('rcReplyTxt');
  ok('الرد الجاهز موجود', !!rep && rep.textContent.length>500);
  ok('الرد فيه السلسلة الأربعة', rep && /percentage/.test(rep.textContent) && /data-summary/.test(rep.textContent));
  ok('وبيحذّر من القراءة المبكرة', rep && /looks like a failure/.test(rep.textContent));
  ok('وبيقول resources بتاخد id مش IMEI', rep && /not IMEIs/.test(rep.textContent));
  ok('الرد إنجليزي مفيهوش عربي', rep && !/[\u0600-\u06FF]/.test(rep.textContent),
     rep && (rep.textContent.match(/[\u0600-\u06FF][^\n]*/)||[''])[0]);
  ok('وفيه زرار كولكشن', !!w.document.getElementById('rcWrapPm'));
  w.close();
}

/* ═════ ٤) صفوف فاضية = حالة متشرحة مش فشل ═════ */
console.log('\n\u0664) الفاضي بيتشرح');
{
  const {w}=boot(false);
  await runAll(w);
  await until(()=>!!w.document.getElementById('rcWrap'), 40, 100);
  const rep=w.document.getElementById('rcReplyTxt');
  ok('لسه بيطلّع رد', !!rep);
  ok('بيقول العربية ما تحركتش مش إن في عطل',
     rep && /did not move/.test(rep.textContent) && !/failed|error/i.test(rep.textContent.split('did not move')[0].slice(-200)));
  w.close();
}

/* ═════ ٥) IMEI غلط: بيقول مش موجود ما بيخترعش ═════ */
console.log('\n\u0665) IMEI مش في الحساب');
{
  const {w}=boot(true);
  w.showView('recipes'); w.startRecipe('summary-report');
  w.eval("RC.vars.imei='111111111111111'; RC.vars.from='2026-08-01'; RC.vars.to='2026-08-05';");
  w.document.getElementById('rcAll').click();
  await until(()=>w.eval('RC.auto===false'), 120, 120);
  const txt=w.document.getElementById('rcSteps').textContent;
  ok('قال إن الرقم مش في الحساب', /مش في الحساب|not on the connected/.test(txt), txt.slice(0,110));
  ok('وما كملش على تقرير غلط', w.eval('!RC.vars.reportId'));
  w.close();
}


console.log('\n'+(F?'\u2717 فشل: '+F:'\u2713 كله عدّى'));
process.exit(F?1:0);
})();
