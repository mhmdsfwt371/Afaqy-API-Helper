const fs = require('fs');

function makeEl(){ const e={hidden:false,innerHTML:'',value:'',textContent:'',placeholder:'',dataset:{},style:{},
  classList:{toggle(){},add(){},remove(){}}, querySelectorAll(){return[]}, addEventListener(){}, focus(){},
  setAttribute(){}, dispatchEvent(){}, onclick:null, appendChild(){}, remove(){}, select(){} }; return e; }
global.document = { documentElement:makeEl(), body:makeEl(), addEventListener(){},
  querySelectorAll(){return[]}, querySelector(){return null}, createElement(){return makeEl()},
  getElementById(){return makeEl()} };
global.history={pushState(){},replaceState(){}};
global.location={hash:''};
global.navigator = { clipboard:{ writeText(){return Promise.resolve();} } };
global.window = { scrollTo(){}, addEventListener(){} };
global.fetch = () => Promise.reject(new Error('stub'));

let js = fs.readFileSync('app_template.html','utf8').split('<script>')[1].split('</script>')[0];
js = js.replace('/*__KB__*/', fs.readFileSync('kb_slim.json','utf8')).replace('/*__DOCS__*/', fs.readFileSync('docs.json','utf8'));
const mod = {};
new Function('module', js + `
module.exports = { setLang:(l)=>{LANG=l;}, get L(){return LANG;},
  RECIPES, FAQ, LEARNED, ERRORS, dual, t, diagnose, escalation, INTROS, EPS, search, labVariants };`)(mod);
const A = mod.exports;

function report(lang){
  A.setLang(lang);
  console.log('\n================ ' + lang.toUpperCase() + ' ================');
  console.log('scenarios : ' + A.RECIPES.map(r=>A.dual(r.title)).join(' | '));
  console.log('step ex   : ' + A.RECIPES[5].steps.map(s=>A.dual(s.t)).join(' → '));
  console.log('input ex  : ' + A.dual(A.RECIPES[4].inputs[0].l));
  console.log('faq[8]    : ' + A.dual(A.FAQ[8].t));
  console.log('learned[0]: ' + A.dual(A.LEARNED[0].t));
  console.log('error     : ' + A.dual(A.ERRORS[0].meaning).slice(0,70) + '…');
  console.log('check[1]  : ' + A.dual(A.ERRORS[0].checks)[1]);
  console.log('intro     : ' + A.dual(A.INTROS.faqIntro).replace(/<[^>]+>/g,'').slice(0,80) + '…');
  console.log('diag 404  : ' + A.diagnose(404,'').replace(/<[^>]+>/g,' ').slice(0,80) + '…');
  console.log('diag creds: ' + A.diagnose(200,'{"message":"invalid_credentials"}').replace(/<[^>]+>/g,' ').slice(0,80) + '…');
}
report('ar'); report('en');

// التأكد إن مفيش حقل ناقص ترجمة
A.setLang('en');
let missing = [];
A.RECIPES.forEach(r=>{
  if(!r.title.en) missing.push('title '+r.id);
  if(!r.desc.en) missing.push('desc '+r.id);
  r.inputs.forEach(f=>{ if(!f.l.en) missing.push('input '+r.id+'.'+f.k); });
  r.steps.forEach((st,n)=>{ if(!st.t.en) missing.push('step '+r.id+'#'+n);
                            if(st.hint && !st.hint.en) missing.push('hint '+r.id+'#'+n); });
});
A.FAQ.forEach((f,n)=>{ if(!f.t.en||!f.h.en) missing.push('faq#'+n); });
A.LEARNED.forEach((k,n)=>{ if(!k.t.en||!k.body.en||!k.src.en) missing.push('learned#'+n); });
console.log('\nmissing english fields: ' + (missing.length ? missing.join(', ') : 'none ✓'));

// السلوك ما اتغيرش مع اللغة
console.log('search still works (en): ' + A.search('لستة العربيات').slice(0,1).map(x=>x.e.p));
console.log('variants still built   : ' + A.labVariants(A.EPS.find(e=>e.p==='/units/lists')).length);
