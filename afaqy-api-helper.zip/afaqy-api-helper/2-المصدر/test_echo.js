global.setInterval=()=>0;global.clearInterval=()=>{};
const fs=require('fs');
function el(id){return{id,hidden:false,innerHTML:'',value:'',textContent:'',className:'',dataset:{},style:{},files:[],disabled:false,
 classList:{toggle(){},add(){},remove(){}},querySelectorAll(){return[]},addEventListener(){},focus(){},select(){},click(){},
 setAttribute(){},getAttribute(){return null},dispatchEvent(){},appendChild(){},remove(){},scrollIntoView(){}}}
const R={};global.document={documentElement:el(),body:el(),addEventListener(){},querySelectorAll(){return[]},
 querySelector(){return null},createElement(){return el()},getElementById(i){return R[i]||(R[i]=el(i))}};
global.history={pushState(){},replaceState(){}};
global.location={hash:''};
global.navigator={clipboard:{writeText(){return Promise.resolve()}}};global.window={scrollTo(){},addEventListener(){}};
global.fetch=()=>Promise.reject(0);global.Blob=function(){};global.URL={createObjectURL(){return''}};global.FileReader=function(){};
let js=fs.readFileSync('app_template.html','utf8').split('<script>')[1].split('</script>')[0]
  .replace('/*__KB__*/',fs.readFileSync('kb_slim.json','utf8')).replace('/*__KBIN__*/', fs.readFileSync('kb_in.json','utf8')).replace('/*__DOCS__*/',fs.readFileSync('docs.json','utf8'));
const m={};new Function('module',js+'\nmodule.exports={echoReq,pwFingerprint,SESSION,setL:(l)=>{LANG=l}};')(m);
const A=m.exports;
const strip=h=>String(h).replace(/<[^>]+>/g,' ').replace(/\s+/g,' ').trim();
const H={'Content-Type':'application/json','Accept':'application/json'};

console.log('=== الحالة اللي عندك دلوقتي (علامات) ===');
console.log(strip(A.echoReq('POST','https://api.afaqy.sa/auth/login',H,
  '{"data":{"username":"<USERNAME>","password":"<PASSWORD>"}}')).slice(0,300));

console.log('\n=== بعد الاتصال ببيانات حقيقية ===');
const real='{"data":{"username":"Safwat","password":"XXXXXXXXXXXXXXXX"}}';
const out=A.echoReq('POST','https://api.afaqy.sa/auth/login',H,real);
console.log(strip(out).slice(0,300));
console.log('\nكلمة السر ظاهرة في الناتج؟ '+(out.includes('XXXXXXXXXXXXXXXX')?'أيوه ✗ خطر':'لأ ✓'));

console.log('\n=== بصمة كلمة السر بتمسك المشاكل الشائعة ===');
[['نضيفة','Afaqy@202520#'],['مسافة في الآخر','Afaqy@202520# '],['مسافة في الأول',' Afaqy@202520#'],
 ['حروف عربية','Afaqy@٢٠٢٥'],['أرقام بس','12345678']].forEach(([label,pw])=>{
  const f=A.pwFingerprint(pw);
  console.log('  '+label.padEnd(16)+' → '+f.n+' حرف · '+f.cls.join('+')+(f.notes.length?'  ⚠ '+f.notes.join('، '):'  ✓'));
});
