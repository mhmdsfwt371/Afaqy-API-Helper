/* أي زرار الكود بينده عليه لازم يكون موجود في الصفحة.
   الاختبار ده اتكتب بعد ما اتحطت أزرار في الجافاسكريبت من غير HTML،
   واللوحة كانت هتقع على أي حد يضغط نتيجة بحث. */
const fs = require('fs');
const tpl = fs.readFileSync('app_template.html','utf8');

const defined = new Set();
for(const m of tpl.matchAll(/id="([A-Za-z][A-Za-z0-9_]*)"/g)) defined.add(m[1]);

const referenced = new Set();
for(const m of tpl.matchAll(/\$\('([A-Za-z][A-Za-z0-9_]*)'\)/g)) referenced.add(m[1]);

const missing = [...referenced].filter(id => !defined.has(id));
if(missing.length){
  console.error('فشل: الكود بينده على عناصر مش موجودة في الصفحة:');
  missing.forEach(id => console.error('   $(\'' + id + '\')'));
  process.exit(1);
}
console.log('ربط العناصر: ' + referenced.size + ' مرجع، كلهم موجودين');
