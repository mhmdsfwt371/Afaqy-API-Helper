/* اختبارات v6.39 — إندبوينتس التقارير بتسأل عن الاسم، والإنشاء بيسأل عن العربيات */
const fs=require('fs'); const {JSDOM}=require('jsdom');
let F=0; const pass=m=>console.log('  \u2713 '+m); const fail=m=>{console.log('  \u2717 '+m);F++;};
const ok=(m,c,x)=>c?pass(m):fail(m+(x?'  \u2014 '+String(x).slice(0,110):''));
const build=()=>fs.readFileSync(process.argv[2]||'app_template.html','utf8')
  .replace('/*__KB__*/',()=>fs.readFileSync('kb_slim.json','utf8'))
  .replace('/*__DOCS__*/',()=>fs.readFileSync('docs.json','utf8'))
  .replace('/*__KBIN__*/',()=>fs.readFileSync('kb_in.json','utf8'));
function boot(conn){
  const w=new JSDOM(build(),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://localhost/'}).window;
  w.alert=()=>{};w.scrollTo=()=>{};w.confirm=()=>true;
  if(conn) w.eval("SESSION.token='TOK'; SESSION.user='Opp'; SESSION.userId='U0';");
  return w;
}
const deps = (w,p)=>JSON.parse(w.eval(
  `JSON.stringify(missingDeps(EPS.find(x=>x.p===${JSON.stringify(p)})).map(r=>r.key))`));

/* ═════ ١) إندبوينتس التقارير بقت تطلب اسم التقرير ═════ */
console.log('\n\u0661) قراءة تقرير بتطلب اسمه');
{
  const w=boot(true);
  ['/user_reports/data','/user_reports/data-summary','/user_reports/data-new',
   '/user_reports/export','/user_reports/delete'].forEach(p=>{
    const ep = w.eval(`!!EPS.find(x=>x.p===${JSON.stringify(p)})`);
    if(!ep){ pass(p+' مش في القاعدة — تخطّي'); return; }
    ok(p+' بتطلب التقرير', deps(w,p).indexOf('report')>-1, deps(w,p).join(','));
  });
  ok('والسؤال عن الاسم مش الرقم',
     /اسم التقرير/.test(w.eval(`JSON.stringify(RESOLVERS.find(r=>r.key==='report').ask)`)));
  ok('وبتجيبه من user_reports/lists',
     /user_reports\/lists/.test(w.eval(`RESOLVERS.find(r=>r.key==='report').list.path`)));
  w.close();
}

/* ═════ ٢) اللستة والإنشاء ما بيطلبوش رقم تقرير ═════ */
console.log('\n\u0662) اللستة والإنشاء مستثنيين');
{
  const w=boot(true);
  ok('/user_reports/lists ما بتطلبش تقرير', deps(w,'/user_reports/lists').indexOf('report')<0, deps(w,'/user_reports/lists').join(','));
  ok('/user_reports/add ما بتطلبش تقرير', deps(w,'/user_reports/add').indexOf('report')<0, deps(w,'/user_reports/add').join(','));
  w.close();
}

/* ═════ ٣) الإنشاء بيفتح صندوق العربيات ═════ */
console.log('\n\u0663) الإنشاء بيسأل على العربيات');
{
  const w=boot(true);
  const ran = w.eval(`(function(){ let called=false;
     const e = EPS.find(x=>x.p==='/user_reports/add');
     const r = ensureDeps(e, ()=>{called=true;});
     return JSON.stringify({r, title:($('mtitle')||{}).textContent||'', hasBox: !!$('depImeis')}); })()`);
  const o = JSON.parse(ran);
  ok('ما نفّذش على طول', o.r === false, 'ensureDeps رجّع '+o.r);
  ok('وفتح النافذة', /عربيات|vehicles/i.test(o.title), o.title);
  ok('وفيها صندوق الـ IMEIs', o.hasBox);
  ok('والشرح بيقول البودي كامل',
     /البودي كامل|body is complete/.test(w.document.getElementById('mbody').textContent));
  w.close();
}

/* ═════ ٤) الـ IMEIs المحلولة بتتحط في بودي الإنشاء ═════ */
console.log('\n\u0664) الأرقام بتوصل للبودي');
{
  const w=boot(true);
  w.eval("RSCOPE.mode='imeis'; RSCOPE.uids=['UID_A','UID_B']; RSCOPE.names=['car-1','car-2'];");
  const body = w.eval(`(function(){ const e=EPS.find(x=>x.p==='/user_reports/add'); return prepBody(e).text; })()`);
  ok('بودي الإنشاء فيه أرقام العربيات', /UID_A/.test(body) && /UID_B/.test(body), body.slice(0,160));
  ok('وما بعتش الـ IMEIs نفسها', !/8601\d{11}/.test(body));
  w.close();
}

/* ═════ ٥) لما العربيات اتحددت، ما بيسألش تاني ═════ */
console.log('\n\u0665) ما بيسألش مرتين');
{
  const w=boot(true);
  w.eval("RSCOPE.mode='imeis'; RSCOPE.uids=['UID_A'];");
  const r = w.eval(`ensureDeps(EPS.find(x=>x.p==='/user_reports/add'), ()=>{})`);
  ok('عدّى على طول بعد ما اتحددت', r === true, 'رجّع '+r);
  w.close();
}

/* ═════ ٦) من غير اتصال بيقول اتصل ═════ */
console.log('\n\u0666) من غير اتصال');
{
  const w=boot(false);
  const r = w.eval(`ensureDeps(EPS.find(x=>x.p==='/user_reports/add'), ()=>{})`);
  ok('ما فتحش النافذة قبل الاتصال', r === false);
  w.close();
}

console.log('\n'+(F?'\u2717 فشل: '+F:'\u2713 كله عدّى'));
process.exit(F?1:0);
