#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v6.47 — صورة الإيميل بتتحوّل لتذكرة، والتذكرة بتتحل.

المحك: إيميل حقيقي (١١ أكتوبر) — كلام العميل وتحته لقطة بوستمان: اللينك
وبودي الريكوست، والرد معروض بوضع Preview (جدول «message  not_allowed» مش JSON).
v6.46 طلّعت «{}» لأنها بتدوّر على JSON بس.

اللي بيتعمل:
- القراءة الأولى بتقسم الصورة: كلام العميل (فوق اللينك)، واللينك والميثود،
  وبودي الريكوست (بين اللينك وشريط Body/Cookies/Test Results)، والرد (تحت الشريط).
  كل جزء بيتقص ويتكبّر ويتقرا لوحده.
- الرد بوضع Preview (جدول مفتاح/قيمة) بيتحوّل JSON.
- النتيجة تذكرة: كلام العميل + Request + Response. في «حلّل رسالة عميل» التذكرة
  بتتحط وتتحلّل. في «افحص رد» الرد بيتفحص، وزرار بيحوّل الصورة لتذكرة.
- المحلّل: بودي فيه unit_id بقى يتعرف كريكوست، و not_allowed/401 بقت دليل
  على قاعدة IMEI مكان رقم العربية، والخطوة التانية في الحل بقت ببودي
  الإندبوينت الحقيقي من الكولكشن، والرد بيرد على سؤال «في رول ناقص؟»،
  وكولكشن Postman بيتولّد فعلًا بدل ما الرد يوعد بيه وهو مش موجود.
"""
import sys, io, os

HERE = os.path.dirname(os.path.abspath(__file__))
PATH = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, 'app_template.html')
src = io.open(PATH, encoding='utf-8').read()
orig = len(src)

def rep(old, new, n=1, tag=''):
    global src
    c = src.count(old)
    if c != n: raise SystemExit('MISMATCH [%s]: expected %d found %d\n---\n%s' % (tag, n, c, old[:240]))
    src = src.replace(old, new, n); print('  ok  %s' % tag)

SECTIONS_JS = r"""/* ============ لقطة إيميل فيها بوستمان → تذكرة ============
   القراءة الأولى بترجّع السطور بمواضعها. لو فيها لينك وتحته شريط الرد
   (Body · Cookies · Test Results / 200 OK)، الصورة بتتقسم أربع حتت:
   كلام العميل فوق اللينك، واللينك، وبودي الريكوست، والرد. */
function ocrSections(lines, scale, W, H){
  const L = lines.map(l => ({text:l.text.trim(), x0:l.bbox.x0/scale, y0:l.bbox.y0/scale, x1:l.bbox.x1/scale, y1:l.bbox.y1/scale}))
                 .sort((a,b) => a.y0 - b.y0 || a.x0 - b.x0);
  const url = L.find(l => /https?:\/\/[^\s]+\/[a-z_]+/i.test(l.text));
  if(!url) return null;
  const mk = L.find(l => l.y0 > url.y1 && /Body\s+Cookies|Test\s*Results|\b[0-9OoBb]{3}\s*[O0]K\b/i.test(l.text));
  if(!mk) return null;
  const hs = L.map(l => l.y1 - l.y0).sort((a,b) => a-b), lh = hs[Math.floor(hs.length/2)] || 12;
  const box = (arr, top, bottom) => {
    if(!arr.length) return null;
    const pad = Math.max(10, lh * 2);
    const x0 = Math.max(0, Math.min(...arr.map(l=>l.x0)) - pad), x1 = Math.min(W, Math.max(...arr.map(l=>l.x1)) + pad);
    const y0 = Math.max(top, Math.min(...arr.map(l=>l.y0)) - pad), y1 = Math.min(bottom, Math.max(...arr.map(l=>l.y1)) + pad * 1.5);
    return (x1 - x0 > 30 && y1 - y0 > 10) ? {x:x0, y:y0, w:x1 - x0, h:y1 - y0} : null;
  };
  /* بودي الريكوست: سطور فيها علامة تنصيص بين اللينك والشريط، في الجنب الشمال (مش Cookies/Beautify) */
  const reqL = L.filter(l => l.y0 > url.y1 && l.y1 < mk.y0 && /["“”]/.test(l.text) && l.x0 < W * 0.7);
  /* الرد: تحت الشريط، من غير سطر أوضاع العرض */
  const respL = L.filter(l => l.y0 > mk.y1 + 2 && !/Preview|Visualize|Pretty|\bRaw\b/i.test(l.text) && l.x0 < W * 0.8);
  /* كلام العميل: فوق اللينك، من غير هيدر الإيميل (To/Cc/الأزرار/التاريخ) */
  const head = /^(To|Cc|From|Sent|Subject)\b|<[^>\s]+@[^>\s]+>|Reply|Forward|\b\d{1,2}\/\d{1,2}\/\d{4}\b|^[^A-Za-z\u0600-\u06FF]{0,4}$/;
  let prose = L.filter(l => l.y1 <= url.y0 + 2 && l.x0 < W * 0.62 && !head.test(l.text));
  const g = prose.findIndex(l => /^(Dear|Hi|Hello|Good\s|السادة|عزيز|مرحب|السلام)/i.test(l.text));
  if(g > 0) prose = prose.slice(g);
  const paras = []; let last = null;
  prose.forEach(l => {
    if(last && l.y0 - last.y1 < lh * 1.2) paras[paras.length - 1] += ' ' + l.text; else paras.push(l.text);
    last = l;
  });
  const m = url.text.match(/\b(GET|POST|PUT|PATCH|DELETE)\b/i);
  const u = url.text.match(/https?:\/\/[^\s?]+/i);
  return { prose: paras.join('\n\n'), method: m ? m[1].toUpperCase() : 'POST', url: u ? u[0] : '',
           reqRegion: box(reqL, url.y1, mk.y0), respRegion: box(respL, mk.y1, H), lineH: lh,
           respIsTable: respL.length > 0 && !respL.some(l => /[{"“]/.test(l.text)) };
}
/* رد بوستمان بوضع Preview: جدول «مفتاح   قيمة» → كائن */
function ocrTable(txt){
  const o = {}; let n = 0;
  String(txt || '').split('\n').forEach(line => {
    const mm = line.trim().match(/^([a-z_][a-z0-9_]{1,40})\s+(.+)$/i);
    if(!mm) return;
    const k = mm[1], v = mm[2].trim(); let val;
    if(/^-?\d+(\.\d+)?$/.test(v)) val = Number(v);
    else if(/^(true|false|null)$/i.test(v)) val = JSON.parse(v.toLowerCase());
    /* المربع الصغير بتاع [] و{} بيتقرى «8)» أو «[]» أو «0» — في الحقول اللي دايمًا مصفوفة/كائن */
    else if(/^(data|extra|errors|items)$/i.test(k) && /^[\[\(\{]?\s*[8B0O\]\)\}|]{0,3}\s*[\]\)\}]?$/.test(v)) val = /^\{/.test(v) ? {} : [];
    else val = v.replace(/\s+/g, '_').replace(/^"|"$/g, '');
    o[k] = val; n++;
  });
  return n ? o : null;
}
"""

# ── ١) تقسيم اللقطة قبل التجهيز ───────────────────────────────
rep("/* السطور بمواضعها من رد المحرك — بلوك ← فقرة ← سطر */",
    SECTIONS_JS + "/* السطور بمواضعها من رد المحرك — بلوك ← فقرة ← سطر */", tag='تقسيم اللقطة لتذكرة')

# ── ٢) ocrImage: لو اللقطة فيها بوستمان، بتطلّع تذكرة ──────────
rep("""    const r1 = await w.recognize(p1.canvas);
    const loc = ocrLocate(ocrLines(r1.data), p1.scale, W, H);""",
"""    const r1 = await w.recognize(p1.canvas);
    const lines1 = ocrLines(r1.data);
    /* v6.47: إيميل فيه لقطة بوستمان كاملة → تذكرة بأجزائها */
    const sec = ocrSections(lines1, p1.scale, W, H);
    if(sec && (sec.reqRegion || sec.respRegion)) return await ocrTicket(img, w, sec, progress, p1.dark);
    const loc = ocrLocate(lines1, p1.scale, W, H);""", tag='ocrImage بيطلّع تذكرة')

rep("""/* صندوق الصورة تحت الخانة: الصورة نفسها + الحالة + اللي اتصلّح */""",
r"""/* كل جزء بيتقص ويتكبّر ويتقرا لوحده؛ النتيجة: الرد (للفحص) + التذكرة كاملة (للتحليل) */
async function ocrTicket(img, w, sec, progress, dark){
  const fixes = [t('الصورة فيها تذكرة كاملة: كلام العميل والريكوست والرد — اتقسمت واتقرت كل حتة لوحدها','The image holds a full ticket — the customer text, the request and the response were split and read one by one')];
  const sc = ocrScaleFor(sec.lineH);
  const readRegion = async region => {
    if(!region) return '';
    const p = ocrPrepare(img, region, sc);
    await w.setParameters({ tessedit_pageseg_mode: '6' });
    return (await w.recognize(p.canvas)).data.text || '';
  };
  progress && progress(t('بنقرا الريكوست','Reading the request'));
  let body = '';
  if(sec.reqRegion){
    const c = ocrClean(await readRegion(sec.reqRegion));
    try{ body = JSON.stringify(JSON.parse(c.text), null, 2); }
    catch(_){ const rp = repairJson(c.text); body = rp.json ? JSON.stringify(rp.json, null, 2) : c.text; }
  }
  progress && progress(t('بنقرا الرد','Reading the response'));
  let resp = '';
  if(sec.respRegion){
    const raw = await readRegion(sec.respRegion);
    const tbl = sec.respIsTable ? ocrTable(raw) : null;
    if(tbl){ resp = JSON.stringify(tbl, null, 2); fixes.push(t('الرد كان معروض جدول (Preview) واتحوّل JSON','The response was shown as a Preview table and was converted to JSON')); }
    else {
      const c = ocrClean(raw); c.fixes.forEach(f => fixes.push(f));
      try{ resp = JSON.stringify(JSON.parse(c.text), null, 2); }
      catch(_){ const rp = repairJson(c.text); resp = rp.json ? JSON.stringify(rp.json, null, 2) : c.text; }
    }
  }
  const path = String(sec.url || '').replace(/^https?:\/\/[^/]+/i, '');
  const tech = [ sec.url ? 'Request:\n' + sec.method + ' ' + sec.url + '?token=<TOKEN>' + (body ? '\n' + body : '') : '',
                 resp ? 'Response:\n' + resp : '' ].filter(Boolean).join('\n\n');
  return { text: resp || body, ticket: [sec.prose, tech].filter(Boolean).join('\n\n'), tech,
           prose: sec.prose, method: sec.method, url: sec.url, path, body, response: resp,
           fixes, dark, confidence: 0, isTicket: true };
}
/* صندوق الصورة تحت الخانة: الصورة نفسها + الحالة + اللي اتصلّح */""", tag='قراءة أجزاء التذكرة')

# ── ٣) ocrAttach: الخانة بتاخد الرد أو التذكرة حسب مكانها ──────
rep("""function ocrAttach(textId, boxId, fileId, after){""",
    """function ocrAttach(textId, boxId, fileId, after, mode){""", tag='ocrAttach بوضع')
rep("""      const cur = ta.value.trim();
      ta.value = cur ? cur + '\\n\\n' + r.text : r.text;""",
"""      const cur = ta.value.trim();
      if(r.isTicket && mode === 'case'){
        /* لو الموظف لصق كلام العميل قبلها، بنزوّد الريكوست والرد بس */
        ta.value = cur ? cur + '\\n\\n' + r.tech : r.ticket;
      } else {
        ta.value = cur ? cur + '\\n\\n' + r.text : r.text;
      }""", tag='التذكرة في خانة الرسالة')
rep("""          ${r.fixes.length ? `<ul style="margin:6px 0 0; padding-inline-start:20px">${r.fixes.map(f=>`<li>${esc(f)}</li>`).join('')}</ul>` : ''}</div>`, thumb);
      after && after(r);""",
"""          ${r.fixes.length ? `<ul style="margin:6px 0 0; padding-inline-start:20px">${r.fixes.map(f=>`<li>${esc(f)}</li>`).join('')}</ul>` : ''}
           ${r.isTicket && mode !== 'case' ? `<div class="row" style="margin-top:8px"><button class="btn sig" id="${boxId}Tk">${t('حوّلها لتذكرة وحلّلها','Turn it into a ticket and analyse it')}</button>
             <span style="font-size:12.5px; color:var(--muted); align-self:center">${t('الصورة فيها كلام العميل والريكوست — التحليل بيقول الغلطة والرد الجاهز.','The image carries the customer text and the request — the analysis gives the mistake and a ready reply.')}</span></div>` : ''}</div>`, thumb);
      const tk = $(boxId + 'Tk');
      if(tk) tk.onclick = ()=>{ INSPVIEW = 'case'; paintInspect(); $('caseText').value = r.ticket; renderCase(r.ticket); };
      after && after(r);""", tag='زرار حوّلها لتذكرة')
rep("""ocrAttach('inText', 'inImgBox', 'inFile', ()=>renderInspect());""",
    """ocrAttach('inText', 'inImgBox', 'inFile', ()=>renderInspect(), 'resp');""", tag='خانة الرد بوضع resp')
rep("""  ocrAttach('caseText', 'caseImgBox', 'caseImg', ()=>renderCase($('caseText').value));""",
    """  ocrAttach('caseText', 'caseImgBox', 'caseImg', ()=>renderCase($('caseText').value), 'case');""", tag='خانة الرسالة بوضع case')

# ── ٤) المحلّل: بودي فيه unit_id ريكوست ──────────────────────
rep("""  if(flat(j) && j.data && (j.data.id || j.data.username)) return 'request';""",
    """  if(flat(j) && j.data && (j.data.id || j.data.username || j.data.unit_id || j.data.resources || j.data.ids || j.data.unit_ids || j.data.filters)) return 'request';""",
    tag='بودي فيه unit_id = ريكوست')

# ── ٥) قاعدة IMEI مكان رقم العربية ───────────────────────────
rep("""    const err = (a.errs||[]).length || /not_found|not found|invalid|غير موجود/i.test(String(a.words||''));""",
    """    /* v6.47: not_allowed/401 مع IMEI في unit_id — شفناها في إيميل حقيقي على /units/locations */
    const err = (a.errs||[]).length || /not_found|not found|invalid|not_allowed|غير موجود/i.test(String(a.words||'') + ' ' + (a.blocks||[]).map(b=>b.raw).join(' '));""",
    tag='not_allowed دليل')
rep("""    if(err) ev.push(t('والرد رجع مش لاقي','and the response came back not-found'));
    return {score: needsUid && err ? 80 : 60, ev};
  },""",
"""    if(err) ev.push(t('والرد رجع خطأ (مش لاقي أو مش مسموح)','and the response came back as an error (not found or not allowed)'));
    return {score: needsUid && err ? 80 : 60, ev};
  },
  /* العميل بيسأل «في رول ناقص؟» — الإجابة الأمينة: صلّح المعرّف الأول، ولو فضل not_allowed يبقى الصلاحيات */
  extra(a){
    const all = String(a.words||'') + ' ' + (a.blocks||[]).map(b=>b.raw).join(' ');
    if(!/not_allowed|unauthori[sz]ed|"status_code"\\s*:\\s*40[13]|\\brole\\b|permission|صلاحي/i.test(all)) return null;
    return {ar:'لو بعد ما تبعت الـ id الرد فضل not_allowed، يبقى الرول بتاع الحساب ده مش عليه صلاحية الإندبوينت ده — ابعتلنا اسم المستخدم وإحنا نراجع صلاحياته.',
            en:'If the call still returns not_allowed once the id is used, the role on this user does not include permission for this endpoint — reply with the username and we will review its permissions on our side.'};
  },""", tag='الرد على سؤال الرول')
rep("""      {m:'POST', p:(_paths(a)[0] || '/units/view'), body:{data:{id:'{{unit_id}}'}},
       note:{ar:'وبعدين نفس الريكوست بس بالـ id.', en:'Then the same request, this time with the id.'}}
    ];
  } },""",
"""      /* البودي الحقيقي للإندبوينت من الكولكشن — /units/locations بياخد unit_id وفترة، مش id */
      (()=>{ const p = _paths(a)[0] || '/units/view', e = _ep(p);
        let body = {data:{id:'{{unit_id}}'}};
        if(e){ const b = reqPmBody(e); if(b && typeof b === 'object') body = b; }
        return {m:'POST', p, body, note:{ar:'وبعدين نفس الريكوست بس بالـ id في مكان الـ IMEI.', en:'Then the same request, with that id in place of the IMEI.'}}; })()
    ];
  } },""", tag='بودي الإندبوينت الحقيقي في الحل')

# ── ٦) الرد الجاهز: extra كدالة، والكولكشن حقيقي ───────────────
rep("""  if(r.extra){ L.push(''); L.push((r.extra.en)); }""",
    """  const ex = typeof r.extra === 'function' ? r.extra(a) : r.extra;
  if(ex){ L.push(''); L.push(ex.en); }""", tag='extra بتتحسب من الحالة')
rep("""    L.push('A Postman collection with these requests is attached; the identifiers move between the steps on their own.');""",
    """    L.push('A Postman collection with these requests is attached: run Login first, then copy the id of your vehicle into the unit_id variable.');""",
    tag='جملة الكولكشن صادقة')
rep("""function pmFromCase(a){
  if(!a || !a.reportCase) return null;""",
"""/* حالة اتشخّصت بقاعدة → كولكشن بنفس خطوات الحل اللي في الرد بالظبط */
function pmFromRule(a){
  const m = caseMatch(a);
  if(!m || m.h.score < CASE_SURE || typeof m.r.chain !== 'function') return null;
  const ch = m.r.chain(a) || [];
  if(!ch.length) return null;
  const items = [pmLogin()].concat(ch.map((s, i) => pmReq({ name: String(i + 1) + '. ' + s.m + ' ' + s.p, path: s.p, method: s.m || 'POST',
                                                          body: s.body, desc: (s.note && (s.note.en || s.note.ar)) || '' })));
  return pmWrap('AFAQY — ' + m.r.name.en, m.r.mistake.en + '\\n\\n' + m.r.why.en, items, []);
}
function pmFromCase(a){
  if(a && !a.reportCase){ return pmFromRule(a); }
  if(!a || !a.reportCase) return null;""", tag='كولكشن للحالة المشخّصة')
rep("""        ${a.reportCase ? `<button class="btn ghost" id="casePm">${t('نزّل كولكشن Postman','Download Postman collection')}</button>` : ''}</div>""",
    """        ${(a.reportCase || pmFromRule(a)) ? `<button class="btn ghost" id="casePm">${t('نزّل كولكشن Postman','Download Postman collection')}</button>` : ''}</div>""",
    tag='زرار الكولكشن للحالة المشخّصة')
rep("""    pmSave(col, 'AFAQY_Report_Data_Full_Chain.postman_collection.json');""",
    """    pmSave(col, a.reportCase ? 'AFAQY_Report_Data_Full_Chain.postman_collection.json' : 'AFAQY_Fix.postman_collection.json');""",
    tag='اسم ملف الكولكشن')


# ── ٧) من اختبار الإيميل الحقيقي: أغلاط قراءة متبقية، وقص الرد تحت شريط الأوضاع ──
rep('  /* علامة تنصيص اتقرت نجمة أو فاصلة في أول المفتاح: *message" → "message" */',
    '  /* علامة تنصيص اتقرت نجمة أو ® بعد المفتاح: "from*: → "from": */\n  s = s.replace(/"([A-Za-z_][A-Za-z0-9_]*)[*®°\'`´]\\s*:/g, \'"$1":\');\n  /* الصفر اتقرى © أو ® جوه رقم أو وقت: ©0:00 → 00:00 */\n  s = s.replace(/(^|[\\d:\\s"\\-])[©®](?=\\d)/g, \'$1\' + \'0\').replace(/(?<=\\d)[©®]/g, \'0\');\n  /* علامة تنصيص اتقرت نجمة أو فاصلة في أول المفتاح: *message" → "message" */', tag='إيميل حقيقي 1')
rep('  /* بودي الريكوست فوق والرد تحت في نفس اللقطة: الفحص بياخد أول بلوك، فالرد لازم يبقى الأول */',
    '  /* قوس الفتح الأول بيتقرى «i» أو بيضيع: لو أقواس القفل أكتر من الفتح بره النصوص، نكمّل من الأول */\n  {\n    let q = false, open = 0, close = 0, so = 0, sc = 0;\n    for(const ch of s){ if(ch === \'"\'){ q = !q; continue; } if(q) continue;\n      if(ch === \'{\') open++; else if(ch === \'}\') close++; else if(ch === \'[\') so++; else if(ch === \']\') sc++; }\n    if(close > open && /^\\s*(?:[il|!]\\s*\\n)?\\s*"/.test(s)){\n      s = \'{\\n\'.repeat(close - open) + s.replace(/^\\s*[il|!]\\s*\\n/, \'\');\n      fixes.push(t(\'قوس الفتح الأول ضاع في القراءة واترجّع\',\'The opening brace was lost in reading and restored\'));\n    }\n  }\n  /* بودي الريكوست فوق والرد تحت في نفس اللقطة: الفحص بياخد أول بلوك، فالرد لازم يبقى الأول */', tag='إيميل حقيقي 2')
rep('    const mm = line.trim().match(/^([a-z_][a-z0-9_]{1,40})\\s+(.+)$/i);',
    '    const mm = line.trim().match(/^([a-z][a-z0-9_]{2,40})\\s+(.+)$/);', tag='إيميل حقيقي 3')
rep('    if(/^-?\\d+(\\.\\d+)?$/.test(v)) val = Number(v);\n    else if(/^(true|false|null)$/i.test(v)) val = JSON.parse(v.toLowerCase());\n    /* المربع الصغير بتاع [] و{} بيتقرى «8)» أو «[]» أو «0» — في الحقول اللي دايمًا مصفوفة/كائن */\n    else if(/^(data|extra|errors|items)$/i.test(k) && /^[\\[\\(\\{]?\\s*[8B0O\\]\\)\\}|]{0,3}\\s*[\\]\\)\\}]?$/.test(v)) val = /^\\{/.test(v) ? {} : [];',
    '    /* المربع الصغير بتاع [] و{} بيتقرى «8)» أو «[]» أو «0» — في الحقول اللي دايمًا مصفوفة/كائن. قبل الأرقام. */\n    if(/^(data|extra|errors|items)$/i.test(k) && /^[\\[\\(\\{]?\\s*[8B0O\\]\\)\\}|]{0,3}\\s*[\\]\\)\\}]?$/.test(v)) val = /^\\{/.test(v) ? {} : [];\n    else if(/^-?\\d+(\\.\\d+)?$/.test(v)) val = Number(v);\n    else if(/^(true|false|null)$/i.test(v)) val = JSON.parse(v.toLowerCase());', tag='إيميل حقيقي 4')
rep('  /* الرد: تحت الشريط، من غير سطر أوضاع العرض */\n  const respL = L.filter(l => l.y0 > mk.y1 + 2 && !/Preview|Visualize|Pretty|\\bRaw\\b/i.test(l.text) && l.x0 < W * 0.8);',
    '  /* الرد: تحت الشريط وتحت سطر أوضاع العرض (JSON · Preview · Visualize) — القص بيبدأ بعده عشان ما يدخلش في الجدول */\n  const modeL = L.filter(l => l.y0 > mk.y1 - 2 && l.y0 < mk.y1 + lh * 4 && /Preview|Visualize|Pretty|\\bRaw\\b/i.test(l.text));\n  const respTop = Math.max(mk.y1, ...modeL.map(l => l.y1));\n  const respL = L.filter(l => l.y0 > respTop + 1 && l.x0 < W * 0.8);', tag='إيميل حقيقي 5')
rep('           reqRegion: box(reqL, url.y1, mk.y0), respRegion: box(respL, mk.y1, H), lineH: lh,',
    '           reqRegion: box(reqL, url.y1, mk.y0), respRegion: box(respL, respTop + 1, H), lineH: lh,', tag='إيميل حقيقي 6')
rep("function _imeis(a){\n  const all = String(a.words||'') + ' ' + (a.blocks||[]).map(b=>b.raw).join(' ');",
    "function _imeis(a){\n  /* v6.47: النص كله كمان — بودي مقروء من صورة ناقص قوس كان بيتشال من words وبياخد الـ IMEI معاه */\n  const all = String(a.words||'') + ' ' + (a.blocks||[]).map(b=>b.raw).join(' ') + ' ' + String(a._raw||'');", tag='إيميل حقيقي 7')


# ── ٨) القوس الخارجي بره القص، وجملة الرد، وملاحظة الفاضي تحت الخطأ ──
rep('    if(close > open && /^\\s*(?:[il|!]\\s*\\n)?\\s*"/.test(s)){\n      s = \'{\\n\'.repeat(close - open) + s.replace(/^\\s*[il|!]\\s*\\n/, \'\');\n      fixes.push(t(\'قوس الفتح الأول ضاع في القراءة واترجّع\',\'The opening brace was lost in reading and restored\'));\n    }',
    '    const bare = /^\\s*(?:[il|!]\\s*\\n)?\\s*"[^"\\n]+"\\s*:/.test(s);\n    if(bare && close > open){\n      s = \'{\\n\'.repeat(close - open) + s.replace(/^\\s*[il|!]\\s*\\n/, \'\');\n      fixes.push(t(\'قوس الفتح الأول ضاع في القراءة واترجّع\',\'The opening brace was lost in reading and restored\'));\n    } else if(bare && close === open){\n      /* القص بدأ بعد القوس الخارجي (عمود أرقام السطور في بوستمان): الكائن الخارجي كله ناقص */\n      s = \'{\\n\' + s.replace(/^\\s*[il|!]\\s*\\n/, \'\') + \'\\n}\';\n      fixes.push(t(\'القوس الخارجي كان بره القص واترجّع\',\'The outer braces fell outside the crop and were restored\'));\n    }', tag='تذكرة 1')
rep("  mistake:{ar:'بعت رقم الجهاز (IMEI) في خانة بتاخد رقم العربية (UID).',\n           en:'Sent the device number (IMEI) where the unit id (UID) belongs.'},",
    "  mistake:{ar:'بعت رقم الجهاز (IMEI) في خانة بتاخد رقم العربية (UID).',\n           en:'The request sends the device number (IMEI) where the vehicle id belongs.'},", tag='تذكرة 2')
rep('    if(!/not_allowed|unauthori[sz]ed|"status_code"\\s*:\\s*40[13]|\\brole\\b|permission|صلاحي/i.test(all)) return null;\n    return {ar:\'لو بعد ما تبعت الـ id الرد فضل not_allowed، يبقى الرول بتاع الحساب ده مش عليه صلاحية الإندبوينت ده — ابعتلنا اسم المستخدم وإحنا نراجع صلاحياته.\',\n            en:\'If the call still returns not_allowed once the id is used, the role on this user does not include permission for this endpoint — reply with the username and we will review its permissions on our side.\'};',
    '    const im = _imeis(a)[0];\n    const lead = im ? {ar:`في الريكوست، unit_id قيمته ${im} — ده الـ IMEI. السيرفر محتاج id العربية: حقل id بتاعها في رد /units/lists اللي بيوصلك أصلًا.`,\n                       en:`In your request, unit_id carries ${im}, which is the IMEI. The API expects the vehicle id instead: the id field of that vehicle in the /units/lists response you already receive.`} : null;\n    const role = /not_allowed|unauthori[sz]ed|"status_code"\\s*:\\s*40[13]|\\brole\\b|permission|صلاحي/i.test(all)\n      ? {ar:\'لو بعد ما تبعت الـ id الرد فضل not_allowed، يبقى الرول بتاع الحساب ده مش عليه صلاحية الإندبوينت ده — ابعتلنا اسم المستخدم وإحنا نراجع صلاحياته.\',\n         en:\'If the call still returns not_allowed once the id is used, the role on this user does not include permission for this endpoint — reply with the username and we will review its permissions on our side.\'} : null;\n    if(!lead && !role) return null;\n    return {ar:[lead, role].filter(Boolean).map(x=>x.ar).join(\'\\n\\n\'), en:[lead, role].filter(Boolean).map(x=>x.en).join(\'\\n\\n\')};', tag='تذكرة 3')
rep('      <div class="note" style="margin-top:8px">${PK2.empty ? t(\'الرد سليم والاتصال شغال',
    '      <div class="note" style="margin-top:8px">${(PK2.empty && !bad) ? t(\'الرد سليم والاتصال شغال', tag='تذكرة 4')

io.open(PATH, 'w', encoding='utf-8').write(src)
print('القالب: %d → %d بايت' % (orig, len(src)))

bp = os.path.join(HERE, 'build.py')
bb = io.open(bp, encoding='utf-8').read()
old = "    ('function ocrImage',            'قراءة صورة الرد على الجهاز'),\n]"
new = "    ('function ocrImage',            'قراءة صورة الرد على الجهاز'),\n    ('function ocrTicket',           'لقطة الإيميل بتتحوّل لتذكرة'),\n]"
if 'function ocrTicket' in bb: print('  --  علامة البناء موجودة')
elif bb.count(old) != 1: raise SystemExit('MISMATCH build.py markers')
else: io.open(bp, 'w', encoding='utf-8').write(bb.replace(old, new)); print('  ok  علامة البناء')
print('تمام — شغّل الاختبارات وبعدين build.py')
