#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v6.48 — رد الـ IMEI بكلام صفوت، والتوكن في الهيدر مسموح.

١) قاعدة «IMEI مكان رقم العربية»: صفوت متأكد إن الـ API شغّالة على الـ UID
   بس، وإن not_allowed في الحالة دي سببها الـ IMEI. الرد بقى يقول ده صريح:
   الـ API بتعرّف العربية بالـ UID، هات الـ UID الأول من /units/lists للعربية
   اللي الـ IMEI بتاعها كذا، وبعدين اطلب الداتا — ومفيش رول ناقص. جملة
   «لو فضلت not_allowed يبقى صلاحيات» اتشالت.
٢) التوثيق الرسمي (1- AVL Integration documentation) بيقول إن التوكن ينفع
   Bearer في الهيدر أو token في اللينك. الأداة كانت بتقول في ١٢ مكان —
   منهم ردود بتروح للعميل وتعليقات في الكود المتولّد — «مش في الهيدر».
   اتصلّحت كلها: اللينك هو اللي الكولكشن بيستخدمه، والهيدر مقبول كمان.
   سجل النسخ القديم (٤.٩) فاضل زي ما هو — ده تاريخ.
"""
import sys, io, os

HERE = os.path.dirname(os.path.abspath(__file__))
PATH = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, 'app_template.html')
src = io.open(PATH, encoding='utf-8').read()
orig = len(src)

def rep(old, new, n=1, tag=''):
    global src
    c = src.count(old)
    if c != n: raise SystemExit('MISMATCH [%s]: expected %d found %d\n---\n%s' % (tag, n, c, old[:240]))
    src = src.replace(old, new, n); print('  ok  %s' % tag)

# ── ١) رد الـ IMEI ─────────────────────────────────────────────
rep("""    const lead = im ? {ar:`في الريكوست، unit_id قيمته ${im} — ده الـ IMEI. السيرفر محتاج id العربية: حقل id بتاعها في رد /units/lists اللي بيوصلك أصلًا.`,
                       en:`In your request, unit_id carries ${im}, which is the IMEI. The API expects the vehicle id instead: the id field of that vehicle in the /units/lists response you already receive.`} : null;
    const role = /not_allowed|unauthori[sz]ed|"status_code"\\s*:\\s*40[13]|\\brole\\b|permission|صلاحي/i.test(all)
      ? {ar:'لو بعد ما تبعت الـ id الرد فضل not_allowed، يبقى الرول بتاع الحساب ده مش عليه صلاحية الإندبوينت ده — ابعتلنا اسم المستخدم وإحنا نراجع صلاحياته.',
         en:'If the call still returns not_allowed once the id is used, the role on this user does not include permission for this endpoint — reply with the username and we will review its permissions on our side.'} : null;""",
"""    /* v6.48 (صفوت): الـ API بتعرّف العربية بالـ UID بس. not_allowed هنا سببها الـ IMEI — مفيش رول ناقص. */
    const lead = im ? {ar:`الـ API بتعرّف العربية بالـ UID مش بالـ IMEI. في الريكوست، unit_id قيمته ${im} — ده IMEI الجهاز. هات الـ UID الأول: حقل id بتاع العربية دي في رد /units/lists، واستخدمه في أي ريكوست بياخد unit_id — وممكن يتخزّن مرة واحدة لكل عربية جنب الـ IMEI.`,
                       en:`The AFAQY API identifies vehicles by their unit ID (UID), not by the device IMEI. In your request, unit_id carries ${im}, which is the IMEI of the device. Get the UID first — the id field of that vehicle in the /units/lists response — then use it in every call that takes unit_id; you can store it once per vehicle next to the IMEI.`} : null;
    const role = /not_allowed|unauthori[sz]ed|"status_code"\\s*:\\s*40[13]|\\brole\\b|permission|صلاحي/i.test(all)
      ? {ar:'رد not_allowed سببه الـ IMEI اللي في unit_id — مفيش رول ولا صلاحية محتاجة تتغيّر.',
         en:'The not_allowed response comes from the IMEI in unit_id — no role or permission change is needed.'} : null;""",
    tag='رد الـ IMEI بكلام صفوت')
rep("""  chain(a){
    return [
      {m:'POST', p:'/units/lists', body:{data:{offset:0, limit:1000, projection:['basic']}},
       note:{ar:'دوّر على العربية اللي imei بتاعها = بتاعك، وخد id بتاعها.', en:'Find the unit whose imei matches yours and take its id.'}},""",
"""  chain(a){
    const im = _imeis(a)[0];
    return [
      {m:'POST', p:'/units/lists', body:{data:{offset:0, limit:1000, projection:['basic']}},
       note: im ? {ar:`دوّر على العربية اللي imei بتاعها ${im}، وخد قيمة id بتاعها — ده الـ UID.`, en:`Find the vehicle whose imei is ${im} and take the value of its id field — this is the UID.`}
                : {ar:'دوّر على العربية اللي imei بتاعها = بتاعك، وخد قيمة id بتاعها — ده الـ UID.', en:'Find the vehicle whose imei matches yours and take the value of its id field — this is the UID.'}},""",
    tag='خطوة ١ بالـ IMEI نفسه')
rep("""        return {m:'POST', p, body, note:{ar:'وبعدين نفس الريكوست بس بالـ id في مكان الـ IMEI.', en:'Then the same request, with that id in place of the IMEI.'}}; })()""",
    """        return {m:'POST', p, body, note:{ar:'وبعدين نفس الريكوست بالـ UID في unit_id مكان الـ IMEI.', en:'Then the same request, with the UID in unit_id in place of the IMEI.'}}; })()""",
    tag='خطوة ٢ بالـ UID')

# ── ٢) التوكن: اللينك أو هيدر Bearer ───────────────────────────
rep('The token is passed as a "token" query parameter, not in an Authorization header.',
    'The token is passed as a "token" query parameter; the official documentation also accepts it as an Authorization: Bearer header.',
    n=2, tag='تعليمات الكود المتولّد')
rep("""${t('في الرابط، مش في هيدر.','in the URL, not in a header.')}""",
    """${t('في الرابط — أو هيدر Authorization: Bearer.','in the URL — or as an Authorization: Bearer header.')}""", tag='تفاصيل الريكوست')
rep("""h:{ar:`<p>كـ باراميتر في اللينك، مش هيدر:</p>""",
    """h:{ar:`<p>كـ باراميتر في اللينك — وده اللي الكولكشن كله ماشي بيه. التوثيق الرسمي بيقبله كمان هيدر <code>Authorization: Bearer</code>:</p>""", tag='سؤال التوكن بالعربي')
rep("""en:`<p>As a query parameter, not a header:</p>""",
    """en:`<p>As a query parameter — the way the whole collection does it. The official documentation also accepts an <code>Authorization: Bearer</code> header:</p>""", tag='سؤال التوكن بالإنجليزي')
rep("2. The token goes in the URL, not a header",
    "2. The token goes in the URL (an Authorization: Bearer header also works)", tag='رد الأربع نقط')
rep('and is passed as a "token" query parameter rather than a header.',
    'and is passed as a "token" query parameter; an Authorization: Bearer header also works.', tag='وصف الكولكشن')
rep("L.push('   - The token goes in the URL as ?token=, not in an Authorization header.');",
    "L.push('   - The token goes in the URL as ?token= (an Authorization: Bearer header also works).');", tag='تعليق الكود')
rep("التوكن بيتبعت كباراميتر في اللينك ?token= مش هيدر (504 ريكوست من 534).",
    "التوكن بيتبعت كباراميتر في اللينك ?token= (504 ريكوست من 534)، والتوثيق الرسمي بيقبله كمان هيدر Authorization: Bearer.", tag='ملاحظة المصادقة بالعربي')
rep("It is sent as a URL parameter ?token=, not a header (504 of 534 requests).",
    "It is sent as a URL parameter ?token= (504 of 534 requests); the official documentation also accepts an Authorization: Bearer header.", tag='ملاحظة المصادقة بالإنجليزي')
rep("""'  - The token goes in the URL as ?token=..., not in a header.\\n'""",
    """'  - The token goes in the URL as ?token=... (an Authorization: Bearer header also works).\\n'""", tag='كولكشن طلب الإنتجريشن')

io.open(PATH, 'w', encoding='utf-8').write(src)
print('القالب: %d → %d بايت' % (orig, len(src)))
print('تمام — شغّل الاختبارات وبعدين build.py')
