#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v6.49 — الـ UID جنب اللوحة.

طلب صفوت (١٢ أكتوبر): بعد «حدّد الجهاز» الشريط بيعرض اللوحة بس، والـ UID
— اللي العميل محتاجه في كل ريكوست — مستخبي في SESSION.unit.uid.
بقى جنب اللوحة شريحة «UID ‹القيمة›» بخط ثابت العرض، وضغطة عليها بتنسخه.
"""
import sys, io, os
HERE = os.path.dirname(os.path.abspath(__file__))
PATH = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, 'app_template.html')
src = io.open(PATH, encoding='utf-8').read(); orig = len(src)
def rep(old, new, n=1, tag=''):
    global src
    c = src.count(old)
    if c != n: raise SystemExit('MISMATCH [%s]: expected %d found %d' % (tag, n, c))
    src = src.replace(old, new, n); print('  ok  %s' % tag)

rep("""      <span id="unitState" class="pill" hidden>—</span>""",
    """      <span id="unitState" class="pill" hidden>—</span>
      <button id="unitUid" class="pill on" hidden type="button" style="cursor:pointer; font-family:var(--mono, monospace); font-size:12px; letter-spacing:.2px"
              data-ar-title="الـ UID — اضغط للنسخ" data-en-title="The UID — click to copy"></button>""", tag='شريحة الـ UID')
rep("""  el.textContent = msg;
  el.className = 'pill' + (SESSION.unit ? ' on' : (bad ? ' bad' : ''));
}""",
"""  el.textContent = msg;
  el.className = 'pill' + (SESSION.unit ? ' on' : (bad ? ' bad' : ''));
  /* v6.49: الـ UID جنب اللوحة — ده اللي العميل محتاجه في unit_id، وضغطة بتنسخه */
  const u = $('unitUid');
  if(u){
    const uid = on && SESSION.unit && SESSION.unit.uid ? String(SESSION.unit.uid) : '';
    u.hidden = !uid;
    u.textContent = uid ? 'UID ' + uid : '';
    u.title = t('الـ UID — اضغط للنسخ','The UID — click to copy');
  }
}
/* نسخ الـ UID من الشريط */
document.addEventListener('click', ev => {
  const b = ev.target && ev.target.closest && ev.target.closest('#unitUid');
  if(!b || !SESSION.unit || !SESSION.unit.uid) return;
  copy(String(SESSION.unit.uid), t('الـ UID اتنسخ','UID copied'));
});""", tag='بتتعرض وبتتنسخ')
io.open(PATH, 'w', encoding='utf-8').write(src)
print('القالب: %d → %d بايت' % (orig, len(src)))
