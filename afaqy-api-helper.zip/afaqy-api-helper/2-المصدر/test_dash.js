/* لوحة الأجهزة: التقسيم بالنوع، والفلتر، والتصدير، وحالة إن الحقل مش راجع */
const fs=require('fs');
const R={}; let DOWNLOADED=null;
function el(id){return{id,hidden:false,innerHTML:'',value:'',textContent:'',className:'',dataset:{},style:{},files:[],disabled:false,
 href:'',download:'',classList:{toggle(){},add(){},remove(){}},
 querySelectorAll(sel){ const out=[]; const re=/data-slice="([^"]*)"/g; let m;
   while((m=re.exec(this.innerHTML))) out.push({dataset:{slice:m[1]},onclick:null});
   return out; },
 addEventListener(){},focus(){},select(){},click(){DOWNLOADED=this.download;},setAttribute(){},getAttribute(){return null},
 dispatchEvent(){},appendChild(){},remove(){},scrollIntoView(){},onclick:null}}
global.document={documentElement:el(),body:el(),addEventListener(){},querySelectorAll(){return[]},
 querySelector(){return null},createElement(){return el()},getElementById(i){return R[i]||(R[i]=el(i))}};
global.history={pushState(){},replaceState(){}};global.location={hash:'',pathname:'/',replace(){},reload(){}};
global.setInterval=()=>0;global.navigator={clipboard:{writeText(){return Promise.resolve()}}};
global.window={scrollTo(){},addEventListener(){}};
global.AbortController=function(){this.signal={};this.abort=()=>{}};
let CSV=null;
global.TextEncoder=require('util').TextEncoder;
let XLSX=null;
global.Blob=function(parts){XLSX=parts};
global.URL={createObjectURL(){return 'blob:x'}};global.FileReader=function(){};
global.fetch=()=>Promise.reject(0);
let js=fs.readFileSync('app_template.html','utf8').split('<script>')[1].split('</script>')[0]
 .replace('/*__KB__*/',fs.readFileSync('kb_slim.json','utf8'))
 .replace('/*__DOCS__*/',fs.readFileSync('docs.json','utf8'));
const m={};new Function('module',js+
 "\nmodule.exports={DASH,WASL,dashRender,dashExport,dashColumns,typeOf,pieSVG,dashInsights,dashRows,unitLastSeen,xlsxBlob};")(m);
const A=m.exports;
const fail=s=>{console.error('فشل: '+s);process.exit(1)};
const strip=h=>String(h||'').replace(/<[^>]+>/g,' ').replace(/\s+/g,' ').trim();

// عربيات بأنواع مختلفة
A.DASH.units=[
 {name:'V1',imei:'111',device_type:'gps',device:'bce',active:true},
 {name:'V2',imei:'222',device_type:'gps',device:'bce',active:true},
 {name:'V3',imei:'333',device_type:'gps',device:'teltonika',active:false},
 {name:'S1',imei:'444',device_type:'stationary',device:'bce',active:true},
 {name:'M1',imei:'555',device_type:'mdvr',device:'hikvision',active:true},
 {name:'M2',imei:'666',device_type:'mdvr',device:'hikvision',active:true},
];
A.DASH.at=new Date(); A.DASH.filter=null;
A.dashRender();
let out=strip(R['dashOut'].innerHTML);
if(out.indexOf('GPS')<0) fail('GPS مش ظاهر');
if(out.indexOf('MDVR')<0) fail('MDVR مش ظاهر');
if(out.indexOf('وحدة ثابتة')<0) fail('الوحدة الثابتة مش ظاهرة');
if(R['dashOut'].innerHTML.indexOf('<svg')<0) fail('الرسم مش موجود');
console.log('التقسيم بالنوع : GPS ٣ · وحدة ثابتة ١ · MDVR ٢  ✓');
console.log('الرسم          : موجود ✓');

// الفلتر
A.DASH.filter='mdvr'; A.dashRender();
out=strip(R['dashOut'].innerHTML);
if(out.indexOf('2 من 6')<0 && out.indexOf('2 of 6')<0) fail('الفلتر ما اشتغلش: '+out.slice(0,80));
if(out.indexOf('V1')>=0) fail('الفلتر سايب صفوف من نوع تاني');
console.log('الفلتر         : MDVR → ٢ من ٦، ومفيش صفوف غريبة ✓');

// التصدير إكسل، والمفلتر بس
A.dashExport();
if(!XLSX) fail('ما صدّرش');
const buf=Buffer.concat(XLSX.map(p=>Buffer.from(p)));
require('fs').writeFileSync('/tmp/dash.xlsx', buf);
const zip=buf.slice(0,2).toString();
if(zip!=='PK') fail('مش ملف إكسل — أول بايتين '+zip);
if(buf.indexOf(Buffer.from('V1'))>=0) fail('صدّر صفوف مش مفلترة');
console.log('التصدير        : ملف xlsx سليم، مفلتر بس ✓');

// الحقل مش راجع
A.DASH.units=[{name:'X',imei:'1'},{name:'Y',imei:'2'}]; A.DASH.filter=null;
A.dashRender();
out=strip(R['dashOut'].innerHTML);
if(out.indexOf('نوع الجهاز مش راجع')<0) fail('ما نبّهش إن الحقل ناقص');
if(out.indexOf('غير محدد')<0) fail('ما صنّفش الناقص');
console.log('الحقل مش راجع  : اتنبّه عليه بدل ما يفضل صامت ✓');

// الأعمدة بتتاخد من الداتا
const cols=A.dashColumns([{name:'a',imei:'1',device:'bce',foo:'x'}]);
if(cols.indexOf('name')!==0) fail('الاسم مش أول عمود');
if(cols.indexOf('foo')<0) fail('ما لقطش عمود جديد من الداتا');
console.log('الأعمدة        : '+cols.join(', ')+' ✓');


// ============ اللي محتاج تصرّف ============
const H=36e5, now=Date.now();
const at=h=>new Date(now-h*H).toISOString().slice(0,19).replace('T',' ');
A.DASH.units=[
 {name:'A',imei:'1',device_type:'gps',last_update:{time:at(2)}},
 {name:'B',imei:'2',device_type:'gps',last_update:{time:at(40)}},
 {name:'C',imei:'3',device_type:'gps',last_update:{time:at(300)}},
 {name:'D',device_type:'gps',last_update:{time:at(1)}},
 {name:'E',imei:'5',device_type:'mdvr'},
 {name:'F',imei:'6',device_type:'gps',active:false,last_update:{time:at(1)}},
];
A.DASH.filter=null; A.DASH.flag=null; A.WASL.rows=[];
const ins=A.dashInsights();
const get=k=>(ins.find(x=>x.k===k)||{n:0}).n;
if(get('silent7')!==1) fail('ساكتة أسبوع: '+get('silent7')+' بدل ١');
if(get('silent1')!==2) fail('ساكتة يوم: '+get('silent1')+' بدل ٢');
if(get('noImei')!==1) fail('من غير IMEI: '+get('noImei')+' بدل ١');
if(get('noTime')!==1) fail('ما رسلتش: '+get('noTime')+' بدل ١');
if(get('inactive')!==1) fail('موقوفة: '+get('inactive')+' بدل ١');
console.log('محتاج تصرّف    : ساكتة أسبوع ١ · ساكتة يوم ٢ · بلا IMEI ١ · ما رسلتش ١ · موقوفة ١ ✓');

// تقاطع مع وصل
A.WASL.rows=[{imei:'1'},{imei:'2'}];
if((A.dashInsights().find(x=>x.k==='notWasl')||{n:0}).n!==3) fail('مش مسجّلة في وصل: العدد غلط');
console.log('تقاطع وصل      : ٣ عربيات ليها IMEI ومش مسجّلة ✓');

// الضغط على بطاقة بيفلتر
A.DASH.flag='silent7';
if(A.dashRows().length!==1 || A.dashRows()[0].name!=='C') fail('فلتر البطاقة ما اشتغلش');
console.log('فلتر البطاقة   : ساكتة أسبوع → عربية واحدة ✓');

// كله سليم = مفيش بطاقات
A.DASH.units=[{name:'ok',imei:'9',device_type:'gps',last_update:{time:at(1)}}];
A.WASL.rows=[{imei:'9'}]; A.DASH.flag=null;
if(A.dashInsights().length!==0) fail('طلّع بطاقات وكله سليم');
console.log('كله سليم       : مفيش بطاقات ✓');

// ============ مؤشرات الأنواع ============
const nowT = h => new Date(Date.now()-h*36e5).toISOString().slice(0,19).replace('T',' ');
A.DASH.units=[
 // GPS بالحالات الأربعة
 {name:'G1',imei:'1',device_type:'gps',last_update:{time:nowT(0.2),pos:{speed:80},ignition:true}},
 {name:'G2',imei:'2',device_type:'gps',last_update:{time:nowT(0.2),pos:{speed:0},ignition:true}},
 {name:'G3',imei:'3',device_type:'gps',last_update:{time:nowT(0.2),pos:{speed:0},ignition:false}},
 {name:'G4',imei:'4',device_type:'gps',last_update:{time:nowT(0.2),pos:{speed:45},ignition:false}},
 {name:'G5',imei:'5',device_type:'gps',last_update:{time:nowT(30),pos:{speed:0},ignition:false}},
 // وحدة ثابتة بحساسات
 {name:'L1',imei:'6',device_type:'stationary',last_update:{time:nowT(0.1)},
  sensors:[{name:'Temperature',value:'4.2'},{name:'Humidity',value:'61'},{name:'Battery',value:'88%'}]},
 // MDVR
 {name:'M1',imei:'7',device_type:'mdvr',last_update:{time:nowT(0.1),pos:{speed:12},acc:1},
  sensors:[{name:'Recording',value:'ON'},{name:'Storage',value:'72%'}]},
];
A.DASH.filter=null; A.DASH.flag=null; A.WASL.rows=[];

A.DASH.filter='gps'; A.DASH.scope=null; A.DASH.state=null; A.dashRender();
let o=strip(R['dashOut'].innerHTML);
['أونلاين','أوفلاين'].forEach(lbl=>{ if(o.indexOf(lbl)<0) fail('ناقص مؤشر: '+lbl); });
A.DASH.scope='on'; A.dashRender();
o=strip(R['dashOut'].innerHTML);
['متحركة وشغّالة','واقفة وشغّالة','واقفة ومطفية','متحركة ومطفية'].forEach(lbl=>{
  if(o.indexOf(lbl)<0) fail('ناقص مؤشر: '+lbl); });
if(o.indexOf('حالات الأونلاين: 4 من 4')<0) fail('مجموع الأونلاين غلط');
A.DASH.scope=null;
console.log('مؤشرات GPS     : طبقة ١ ثم ٤ حالات مجموعها ٤ من ٤ ✓');

A.DASH.filter='stationary'; A.DASH.scope=null; A.dashRender();
o=strip(R['dashOut'].innerHTML);
['حرارة','رطوبة','بطارية'].forEach(k=>{ if(o.indexOf(k)<0) fail('ناقص في الوحدة الثابتة: '+k); });
console.log('الوحدة الثابتة  : حرارة · رطوبة · بطارية ✓');

A.DASH.filter='mdvr'; A.DASH.scope='on'; A.dashRender();
o=strip(R['dashOut'].innerHTML);
if(o.indexOf('التسجيل والتخزين')<0) fail('ناقص قسم التسجيل');
if(o.indexOf('ON')<0 || o.indexOf('72%')<0) fail('حالة التسجيل مش ظاهرة');
if(o.indexOf('متحركة وشغّالة')<0) fail('MDVR ناقصها حالة الحركة');
A.DASH.scope=null;
console.log('MDVR           : حركة ومحرك + تسجيل ON وتخزين 72% ✓');

// حقول ناقصة = تنبيه مش صفر
A.DASH.units=[{name:'X',imei:'9',device_type:'gps',last_update:{time:nowT(0.1)}}];
A.DASH.filter='gps'; A.DASH.scope='on'; A.dashRender();
o=strip(R['dashOut'].innerHTML);
if(o.indexOf('حالتها مش واضحة')<0) fail('ما صنّفش اللي ناقصها حقول');
A.DASH.scope=null;
console.log('حقول ناقصة     : اتنبّه عليها بدل ما يعرض أصفار ✓');

// ============ MDVR: تسجيل وتخزين ============
A.DASH.units=[
 {name:'M1',imei:'1',device_type:'mdvr',last_update:{time:nowT(0.1),pos:{speed:0},acc:1},
  sensors:[{name:'Recording',value:'ON'},{name:'Storage',value:'40%'}]},
 {name:'M2',imei:'2',device_type:'mdvr',last_update:{time:nowT(0.1),pos:{speed:0},acc:1},
  sensors:[{name:'Recording',value:'OFF'},{name:'Storage',value:'55%'}]},
 {name:'M3',imei:'3',device_type:'mdvr',last_update:{time:nowT(0.1),pos:{speed:0},acc:1},
  sensors:[{name:'Recording',value:'ON'},{name:'Storage',value:'96%'}]},
 {name:'M4',imei:'4',device_type:'mdvr',last_update:{time:nowT(0.1),pos:{speed:0},acc:1}},
 {name:'G1',imei:'5',device_type:'gps',last_update:{time:nowT(0.1),pos:{speed:0},ignition:false}},
];
A.DASH.filter=null; A.DASH.flag=null; A.WASL.rows=[];
const ins2=A.dashInsights(); const g2=k=>(ins2.find(x=>x.k===k)||{n:0}).n;
if(g2('mdvrOff')!==1)     fail('مش بتسجّل: '+g2('mdvrOff')+' بدل ١');
if(g2('mdvrFull')!==1)    fail('تخزين ممتلئ: '+g2('mdvrFull')+' بدل ١');
if(g2('mdvrNoData')!==1)  fail('حالة مش راجعة: '+g2('mdvrNoData')+' بدل ١');
console.log('MDVR تسجيل     : مش بتسجّل ١ · تخزين ٩٦٪ ١ · مش راجعة ١ ✓');

// كل واحدة تتفلتر وتتصدّر لوحدها
[['mdvrOff','M2'],['mdvrFull','M3'],['mdvrNoData','M4']].forEach(([k,nm])=>{
  A.DASH.flag=k;
  const r=A.dashRows();
  if(r.length!==1 || r[0].name!==nm) fail('فلتر '+k+' غلط');
  DOWNLOADED=null; XLSX=null; A.dashExport();
  if(!XLSX) fail('ما صدّرش '+k);
});
console.log('فلتر وتصدير    : الثلاثة بيتفلتروا ويتصدّروا لوحدهم ✓');

// لو مفيش MDVR خالص، البطاقات ما تظهرش
A.DASH.units=[{name:'G',imei:'9',device_type:'gps',last_update:{time:nowT(0.1),pos:{speed:0},ignition:false}}];
A.DASH.flag=null;
if(A.dashInsights().some(x=>x.k.indexOf('mdvr')===0)) fail('بطاقات MDVR ظهرت وما فيش MDVR');
console.log('بلا MDVR       : البطاقات ما ظهرتش ✓');

// ============ الطبقتين ============
A.DASH.units=[
 {name:'A',imei:'1',device_type:'gps',last_update:{time:nowT(0.1),pos:{speed:60},ignition:true}},
 {name:'B',imei:'2',device_type:'gps',last_update:{time:nowT(0.1),pos:{speed:0},ignition:true}},
 {name:'C',imei:'3',device_type:'gps',last_update:{time:nowT(0.1),pos:{speed:0},ignition:false}},
 {name:'D',imei:'4',device_type:'gps',last_update:{time:nowT(0.1),pos:{speed:30},ignition:false}},
 {name:'E',imei:'5',device_type:'gps',last_update:{time:nowT(0.1)}},
 {name:'F',imei:'6',device_type:'gps',last_update:{time:nowT(50),pos:{speed:0},ignition:false}},
 {name:'G',imei:'7',device_type:'gps',last_update:{time:nowT(60),pos:{speed:20},ignition:true}},
];
A.DASH.filter='gps'; A.DASH.flag=null; A.DASH.scope=null; A.DASH.state=null; A.WASL.rows=[];

// طبقة ١: أونلاين/أوفلاين بس
A.dashRender();
let o2=strip(R['dashOut'].innerHTML);
if(o2.indexOf('أونلاين')<0 || o2.indexOf('أوفلاين')<0) fail('الطبقة الأولى ناقصة');
if(o2.indexOf('متحركة وشغّالة')>=0) fail('الحالات ظهرت من غير ما ادوس');
console.log('طبقة ١         : أونلاين وأوفلاين بس ✓');

// طبقة ٢: أونلاين → المجموع لازم يساوي عدد الأونلاين
A.DASH.scope='on'; A.dashRender();
o2=strip(R['dashOut'].innerHTML);
if(o2.indexOf('متحركة وشغّالة')<0) fail('حالات الأونلاين ما ظهرتش');
if(o2.indexOf('حالات الأونلاين: 5 من 5')<0) fail('المجموع مش مظبوط: '+(o2.match(/حالات الأونلاين: \d+ من \d+/)||['?'])[0]);
if(o2.indexOf('في فرق')>=0) fail('قال في فرق وهو مظبوط');
console.log('طبقة ٢ أونلاين : ٥ من ٥ — المجموع مظبوط ✓');

// أوفلاين
A.DASH.scope='off'; A.DASH.state=null; A.dashRender();
o2=strip(R['dashOut'].innerHTML);
if(o2.indexOf('حالات الأوفلاين: 2 من 2')<0) fail('مجموع الأوفلاين غلط');
if(o2.indexOf('آخر حالة اتسجّلت')<0) fail('ما وضّحش إن دي آخر حالة');
console.log('طبقة ٢ أوفلاين : ٢ من ٢ + توضيح إنها آخر حالة ✓');

// الضغط على بطاقة صغيرة بيفلتر
A.DASH.scope='on'; A.DASH.state='idling';
let r2=A.dashRows();
if(r2.length!==1 || r2[0].name!=='B') fail('فلتر «واقفة شغّالة» غلط');
A.DASH.state='towed'; r2=A.dashRows();
if(r2.length!==1 || r2[0].name!=='D') fail('فلتر «متحركة مطفية» غلط');
A.DASH.state='unknown'; r2=A.dashRows();
if(r2.length!==1 || r2[0].name!=='E') fail('فلتر «مش واضحة» غلط');
console.log('فلتر البطاقات  : واقفة شغّالة · متحركة مطفية · مش واضحة ✓');

// التصدير بياخد الحالة في الاسم
A.SESSION=A.SESSION||{}; 
DOWNLOADED=null; A.DASH.state='idling'; A.dashExport();
if(!DOWNLOADED || DOWNLOADED.indexOf('idling')<0) fail('اسم التصدير مفيهوش الحالة: '+DOWNLOADED);
console.log('اسم التصدير    : '+DOWNLOADED+' ✓');

// الضغط تاني بيقفل
A.DASH.scope=null; A.DASH.state=null; A.dashRender();
if(strip(R['dashOut'].innerHTML).indexOf('متحركة وشغّالة')>=0) fail('الحالات ما اتقفلتش');
console.log('الضغط تاني     : الحالات اتقفلت ✓');
