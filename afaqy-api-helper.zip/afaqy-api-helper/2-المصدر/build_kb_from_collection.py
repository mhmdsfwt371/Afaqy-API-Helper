#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""بيبني kb_slim.json من كولكشن Postman (v2.1) — المصدر الرسمي للأداة.

من v6.50 المصدر هو التوثيق الرسمي «1- AVL Integration documentation»
(documenter.getpostman.com/view/50854881/2sBYB2qnL3). السكريبت ده كان ناقص
من الريبو — من غيره أي تحديث للكولكشن كان محتاج شغل يدوي.

الاستخدام:
    python3 build_kb_from_collection.py avl_integration_documentation.postman_collection.json kb_slim.json kb_slim.json

التالت هو الـ KB الحالي — منه بيتجاب نص الريكوستات المحفوظة اللي مش في التوثيق
(القايمة KEEP_UNDOCUMENTED). لو التوثيق اتحدّث: صدّر الكولكشن (v2.1)، حطه مكان
الملف، وشغّل الأمر ده — واختبار test_kb_source.js بيقفل إن الـ KB = ناتج الأمر ده بالظبط.

لكل ريكوست: الموديول (g) والفولدر الفرعي (s) والاسم (n) والميثود (m) والمسار
(p) وهل بياخد توكن (t) والبودي (b) أو form-data (bm/fd) والباراميترات غير
التوكن (q) والوصف (d). الوصف في التوثيق الرسمي بيقول الغرض والاستخدام
والنجاح والخطأ — والأداة بتعرضه.
"""
import json, sys, io, re

def strip_comments(raw):
    """// و /* */ بره النصوص المقتبسة — عينات التوثيق فيها تعليقات، ودي مش JSON صالح."""
    out, i, n, q = [], 0, len(raw), False
    while i < n:
        ch = raw[i]
        if q:
            out.append(ch)
            if ch == '\\' and i + 1 < n: out.append(raw[i+1]); i += 2; continue
            if ch == '"': q = False
            i += 1; continue
        if ch == '"': q = True; out.append(ch); i += 1; continue
        if raw.startswith('/*', i):
            j = raw.find('*/', i + 2); i = n if j < 0 else j + 2; continue
        if raw.startswith('//', i):
            j = raw.find('\n', i); i = n if j < 0 else j; continue
        out.append(ch); i += 1
    # سطور فضيت بعد الشيل
    txt = ''.join(out).replace('\r\n', '\n').replace('\u00a0', ' ')   # مسافات غير قابلة للكسر بتبوّظ الـ JSON
    return '\n'.join(l for l in txt.split('\n') if l.strip())

# تصليحات عينات بتتعمل بعد الاستيراد — كل واحدة بسبب مكتوب. التوثيق نفسه مش بيتلمس.
def _units_lists(b):
    d = b.get('data', {})
    d.pop('filters', None)                      # فلتر بـ IMEI وهمي: لو اتشغّل من الأداة بيرجّع صفر عربيات
    pr = d.get('projection') or []
    if 'created_at' not in pr: pr.append('created_at')   # كارت العربية بيعرض تاريخ الإضافة (v6.x)
    d['projection'] = pr
    return b
SAMPLE_FIXES = {
    ('POST', '/units/lists'): (_units_lists, 'العينة الرسمية فلترها بـ IMEI وهمي (بترجّع صفر) — اتشال، واتضاف created_at لكارت العربية'),
}

def text_of(desc):
    if isinstance(desc, dict): desc = desc.get('content', '')
    return (desc or '').strip()

def path_of(url):
    if isinstance(url, str):
        raw = url
    else:
        raw = url.get('raw') or ''
        if url.get('path'):
            return '/' + '/'.join(str(x) for x in url['path'] if x != '')
    raw = re.sub(r'^\{\{[^}]+\}\}', '', raw)
    raw = re.sub(r'^https?://[^/]+', '', raw)
    return '/' + raw.split('?')[0].lstrip('/')

def convert(col):
    out = []
    coll_auth = bool(col.get('auth'))
    def walk(items, path):
        for it in items:
            if 'item' in it:
                walk(it['item'], path + [it['name']]); continue
            r = it.get('request') or {}
            if isinstance(r, str): r = {'url': r, 'method': 'GET'}
            url = r.get('url') or {}
            qs = [] if isinstance(url, str) else (url.get('query') or [])
            has_tok = any((q.get('key') == 'token') for q in qs)
            auth = r.get('auth')
            noauth = isinstance(auth, dict) and auth.get('type') == 'noauth'
            e = {'i': len(out), 'g': path[0] if path else 'General', 'n': it.get('name', ''),
                 'm': (r.get('method') or 'GET').upper(), 'p': path_of(url),
                 't': 1 if (has_tok or (coll_auth and not noauth)) and not re.match(r'^/auth/(login|send_login_otp|verify_login_otp|forget|reset)', path_of(url)) else 0}
            if len(path) > 1: e['s'] = ' / '.join(path[1:])
            body = r.get('body') or {}
            if body.get('mode') == 'raw' and body.get('raw'):
                # التعليقات (// و /* */) مش JSON صالح — وواحد منها في التوثيق كان فيه اسم حساب عميل
                raw = strip_comments(body['raw'])
                fx = SAMPLE_FIXES.get((e['m'], e['p']))
                if fx:
                    try: raw = json.dumps(fx[0](json.loads(raw)), ensure_ascii=False, indent=4); e['fx'] = fx[1]
                    except ValueError: pass
                e['b'] = raw
            elif body.get('mode') == 'formdata':
                e['bm'] = 'formdata'
                e['fd'] = [{'k': f.get('key', ''), 't': f.get('type', 'text'), 'v': f.get('value', '') if f.get('type') != 'file' else ''}
                           for f in (body.get('formdata') or []) if not f.get('disabled')]
            extra = [{'k': q.get('key', ''), 'v': q.get('value', ''), 'd': text_of(q.get('description')), 'off': bool(q.get('disabled'))}
                     for q in qs if q.get('key') and q.get('key') != 'token']
            if extra: e['q'] = extra
            d = text_of(r.get('description')) or text_of(it.get('description'))
            if d: e['d'] = d
            out.append(e)
    walk(col.get('item', []), [])
    return out

# ريكوستات في التوثيق الرسمي بس الأداة بتستبعدها عمدًا — الموظف بيشغّل ريكوستات لايف على حسابات
# العملاء، وإضافة أو حذف عربيات من أداة دعم خطر (القرار ده من قبل v6.50، واختبار المختبر بيقفله).
EXCLUDE_DOCUMENTED = {
    ('POST', '/units/add'):         'إضافة عربية على حساب عميل من أداة الدعم',
    ('POST', '/units/delete'):      'حذف عربية من حساب عميل من أداة الدعم',
    ('POST', '/units/bulk-delete'): 'حذف عربيات بالجملة من حساب عميل من أداة الدعم',
}

# ريكوستات مش في التوثيق الرسمي بس الأداة نفسها بتستخدمها أو بتشرحها في التشخيص.
# بتفضل في الأداة بعلامة x=1 («مش في التوثيق الرسمي») — ما بتتبعتش للعميل كحل من غير تأكيد.
# أي ريكوست تاني مش في التوثيق بيتشال. لو حاجة هنا اتأكد إنها اتلغت: امسحها من هنا.
KEEP_UNDOCUMENTED = {
    ('POST', '/units/locations'):                     'نقط التراك اللي بتترسم خلال فترة زمنية — العملاء بيستخدموه؛ آخر موقع بييجي من /units/lists (last_update)، وللفترة في ردود العملاء /units/signals الموثّق',
    ('POST', '/user_report_templates/lists'):         'أول خطوة في سيناريو التقرير: كود القالب',
    ('POST', '/user_report_templates/add'):           'مصدر كود تقرير «summary» وحقوله — التوثيق الرسمي فيه summary_by_driver بس، والفريق بيشغّل summary لايف',
    ('POST', '/reports/add'):                         'شرح الفرق بين تعريف التقرير ونتيجته',
    ('POST', '/customers/lists'):                     'اسم العميل في لوحة الأجهزة',
    ('POST', '/units/getAddress'):                    'شرح العنوان في الدليل',
    ('POST', '/auth/login_as'):                       'سؤال «ادخل بحساب العميل» في الأساسيات',
    ('POST', '/auth/reset_expired_password'):         'تشخيص كلمة السر المنتهية',
    ('POST', '/auth/send_login_otp'):                 'تشخيص التحقق بخطوتين',
    ('POST', '/auth/verify_login_otp'):               'تشخيص التحقق بخطوتين',
    ('POST', '/wasl_integration/vehicles/lists'):     'لوحة وصل',
    ('POST', '/wasl_integration/vehicles/inquiry'):   'لوحة وصل: الاستعلام اللايف',
    ('POST', '/wasl_integration/vehicles/update_imei'): 'شرح تعديل IMEI في وصل',
}

def merge_kept(eps, previous):
    have = {(e['m'], e['p']) for e in eps}
    for e in previous:
        k = (e['m'], e['p'])
        if k in KEEP_UNDOCUMENTED and k not in have:
            x = {kk: v for kk, v in e.items() if kk in ('g','s','n','m','p','t','b','bm','fd','q','d','h')}
            x['i'] = len(eps); x['x'] = 1; x['xr'] = KEEP_UNDOCUMENTED[k]
            eps.append(x); have.add(k)
    missing = [k for k in KEEP_UNDOCUMENTED if k not in have]
    if missing: raise SystemExit('ريكوستات في KEEP_UNDOCUMENTED مش لاقيينها في الـ KB القديم: %s' % missing)
    return eps

if __name__ == '__main__':
    src = sys.argv[1]; dst = sys.argv[2] if len(sys.argv) > 2 else 'kb_slim.json'
    col = json.load(io.open(src, encoding='utf-8'))
    eps = convert(col)
    documented = len(eps)
    eps = [e for e in eps if (e['m'], e['p']) not in EXCLUDE_DOCUMENTED]
    for k, e in enumerate(eps): e['i'] = k
    official = len(eps)
    if len(sys.argv) > 3:   # الـ KB القديم — عشان نجيب منه الريكوستات اللي الأداة لسه محتاجاها
        eps = merge_kept(eps, json.load(io.open(sys.argv[3], encoding='utf-8'))['endpoints'])
    json.dump({'endpoints': eps, 'source': {'name': col.get('info', {}).get('name', ''),
               'url': 'https://documenter.getpostman.com/view/50854881/2sBYB2qnL3', 'documented': documented, 'official': official, 'excluded': documented - official, 'kept': len(eps) - official}},
              io.open(dst, 'w', encoding='utf-8'), ensure_ascii=False, separators=(',', ':'))
    print('%s ← %s: %d في التوثيق، %d مستبعدة عمدًا، %d محفوظة مش في التوثيق = %d' % (dst, col.get('info', {}).get('name', ''), documented, documented - official, len(eps) - official, len(eps)))
