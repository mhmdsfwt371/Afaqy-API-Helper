global.setInterval=()=>0;global.clearInterval=()=>{};
const fs = require('fs');
function el(){ const e={hidden:false,innerHTML:'',value:'',textContent:'',placeholder:'',dataset:{},style:{},files:[],
  classList:{toggle(){},add(){},remove(){}}, querySelectorAll(){return[]}, addEventListener(){}, focus(){},
  setAttribute(){}, dispatchEvent(){}, onclick:null, onchange:null, appendChild(){}, remove(){}, select(){}, click(){} }; return e; }
global.document = { documentElement:el(), body:el(), addEventListener(){}, querySelectorAll(){return[]},
  querySelector(){return null}, createElement(){return el()}, getElementById(){return el()} };
global.history={pushState(){},replaceState(){}};
global.location={hash:''};
global.navigator={clipboard:{writeText(){return Promise.resolve();}}};
global.window={scrollTo(){},addEventListener(){}}; global.fetch=()=>Promise.reject(new Error('stub'));
global.Blob=function(){}; global.URL={createObjectURL(){return'';}}; global.FileReader=function(){};

let js = fs.readFileSync('app_template.html','utf8').split('<script>')[1].split('</script>')[0];
js = js.replace('/*__KB__*/', fs.readFileSync('kb_slim.json','utf8')).replace('/*__KBIN__*/', fs.readFileSync('kb_in.json','utf8')).replace('/*__DOCS__*/', fs.readFileSync('docs.json','utf8'));
const m={};
new Function('module', js + `
module.exports={ TRIAGE, EVIDENCE, LEARNED, LOG, logCall, dual, t, setL:(l)=>{LANG=l}, RECIPES };`)(m);
const A=m.exports;

['ar','en'].forEach(L=>{
  A.setL(L);
  console.log('\n=========== ' + L.toUpperCase() + ' ===========');
  A.TRIAGE.forEach(x=>{
    console.log('▸ ' + A.dual(x.sym));
    console.log('   ' + (L==='ar'?'ما تعملهوش':'do not') + ': ' + A.dual(x.dont).slice(0,72) + '…');
    console.log('   ' + A.dual(x.steps).length + (L==='ar'?' خطوات':' steps') + ' | ' +
      (A.dual(x.reply) ? (L==='ar'?'فيه رد جاهز':'has ready reply') : (L==='ar'?'من غير رد':'no reply')) +
      ' | → ' + (x.go ? x.go.tab + (x.go.rec?':'+x.go.rec:'') : '—'));
  });
  console.log('evidence: ' + A.EVIDENCE.map(e=>L==='en'?e.en:e.ar).join(' / '));
});

// الروابط بين الفرز والسيناريوهات لازم تكون صحيحة
const ids = A.RECIPES.map(r=>r.id);
const bad = A.TRIAGE.filter(x=>x.go && x.go.rec && !ids.includes(x.go.rec));
console.log('\nbroken links to scenarios: ' + (bad.length ? bad.map(b=>b.go.rec).join(',') : 'none ✓'));
const tabs=['search','faq','browse','recipes','lab','triage'];
const badTab = A.TRIAGE.filter(x=>x.go && !tabs.includes(x.go.tab));
console.log('broken tab targets   : ' + (badTab.length ? badTab.map(b=>b.go.tab).join(',') : 'none ✓'));

// سجل الجلسة
A.logCall('POST /units/lists', 200, true);
A.logCall('POST /auth/login', 401, false);
console.log('session log entries  : ' + A.LOG.length + ' → ' + A.LOG.map(l=>l.label+' '+l.code).join(' | '));

// إضافة معرفة وقت التشغيل
const before = A.LEARNED.length;
A.LEARNED.push({sev:'ok', t:{ar:'اختبار',en:'test'}, src:{ar:'x',en:'x'}, body:{ar:'<p>y</p>',en:'<p>y</p>'}});
console.log('knowledge growable   : ' + before + ' → ' + A.LEARNED.length + ' ✓');
