#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v7.7 — إثبات التأليف: الأداة بتقول مين عملها، في كل مكان.

طلب صفوت (٤ نوفمبر). قبل النسخة دي مكانش فيه أي ذكر للمؤلف — لا في الصفحة
ولا الـ README ولا ملف النسخة ولا الـ PDF، والكوميتات كانت باسم وهمي.

القرار: نسبة التأليف (تصميم وتطوير: محمد صفوت) — مش ادعاء ملكية. الأداة
اتعملت لفريق أفاقي وجواها توثيق أفاقي ومعرفة من تذاكرها؛ الملكية قرار صفوت
بعد مراجعة عقده أو اتفاق مع الإدارة.

- سطر ثابت تحت كل الصفحات: «تصميم وتطوير: محمد صفوت»، عربي وإنجليزي.
- <meta name="author">، والمؤلف في version.json وCHANGELOG وغلاف الـ PDF والـ README.
- قسم «عن الأداة» في الدليل: المؤلف، أول نشر (٤ أغسطس ٢٠٢٦ — تاريخ إنشاء الريبو
  على حسابه)، والريبو.
- البناء بيوقف لو اسم المؤلف اختفى من أي واحد فيهم.
- الكوميتات من النسخة دي باسم Mohamed Safwat وإيميل GitHub المربوط بحسابه،
  وكل نسخة ليها تاج على GitHub فيه بصمة SHA-256 للأداة.
"""
import sys, io, os
HERE = os.path.dirname(os.path.abspath(__file__))
PATH = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, 'app_template.html')
src = io.open(PATH, encoding='utf-8').read(); orig = len(src)
def rep(old, new, n=1, tag=''):
    global src
    c = src.count(old)
    if c != n: raise SystemExit('MISMATCH [%s]: expected %d found %d\n---\n%s' % (tag, n, c, old[:200]))
    src = src.replace(old, new, n); print('  ok  %s' % tag)

rep("""<meta name="viewport" content="width=device-width, initial-scale=1">
<title>مساعد الإنتجريشن — دعم أفاقي</title>""",
"""<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="author" content="Mohamed Safwat (محمد صفوت)">
<meta name="description" content="AFAQY Integration Helper — designed and developed by Mohamed Safwat for the AFAQY Jeddah integration-support team.">
<title>مساعد الإنتجريشن — دعم أفاقي</title>""", tag='بيانات المؤلف في الصفحة')
rep("""</main>

<div id="printArea"></div>""",
"""</main>

<footer id="credit" style="text-align:center; padding:18px 12px 26px; font-size:12.5px; color:var(--muted); border-top:1px solid var(--line); margin-top:24px">
  <span data-ar="تصميم وتطوير: محمد صفوت" data-en="Designed &amp; developed by Mohamed Safwat">تصميم وتطوير: محمد صفوت</span>
  <span aria-hidden="true"> · </span>
  <span data-ar="أداة داخلية لفريق دعم الإنتجريشن — أفاقي جدة · منذ أغسطس 2026" data-en="Internal tool for the AFAQY Jeddah integration-support team · since August 2026">أداة داخلية لفريق دعم الإنتجريشن — أفاقي جدة · منذ أغسطس 2026</span>
</footer>

<div id="printArea"></div>""", tag='سطر المؤلف تحت الصفحات')

io.open(PATH, 'w', encoding='utf-8').write(src)
print('القالب: %d → %d بايت' % (orig, len(src)))

# ── البناء: المؤلف في version.json وCHANGELOG وغلاف الـ PDF، وفحص إنه موجود ──
bp = os.path.join(HERE, 'build.py'); bb = io.open(bp, encoding='utf-8').read()
edits = [
 ("""<div class="sub">دليل الاستخدام — فريق الدعم الفني، أفاقي</div>""",
  """<div class="sub">دليل الاستخدام — فريق الدعم الفني، أفاقي</div>
<div class="sub">تصميم وتطوير: محمد صفوت</div>"""),
 ("""    out = ['# سجل التغييرات', '',
           'الملف ده بيتولّد من `docs.json` مع كل بناء. ما تعدّلهوش بالإيد — التعديل هيضيع.', '']""",
  """    out = ['# سجل التغييرات', '',
           'تصميم وتطوير: محمد صفوت (Mohamed Safwat) — أول نشر ٤ أغسطس ٢٠٢٦.', '',
           'الملف ده بيتولّد من `docs.json` مع كل بناء. ما تعدّلهوش بالإيد — التعديل هيضيع.', '']"""),
 ("""        'version': d['version'],
        'date': d['date'],""",
  """        'version': d['version'],
        'date': d['date'],
        'author': 'Mohamed Safwat',"""),
 ("""    if re.search(r'https://<[^>]+>', rd):
        bad.append('README.md لسه فيه لينك مؤقت')""",
  """    if re.search(r'https://<[^>]+>', rd):
        bad.append('README.md لسه فيه لينك مؤقت')
    # v7.7: اسم المؤلف ما يختفيش من أي مكان
    if 'محمد صفوت' not in rd or 'Mohamed Safwat' not in rd:
        bad.append('README.md من غير اسم المؤلف')
    idx = open(os.path.join(REPO, 'index.html'), encoding='utf-8').read()
    if 'name="author" content="Mohamed Safwat' not in idx or 'تصميم وتطوير: محمد صفوت' not in idx:
        bad.append('index.html من غير اسم المؤلف')
    vj = json.load(open(os.path.join(REPO, 'version.json'), encoding='utf-8'))
    if vj.get('author') != 'Mohamed Safwat':
        bad.append('version.json من غير المؤلف')"""),
 ("""    ('function statsReport',         'تقرير الاستخدام — اتحلّت/اتصعّدت من غير بيانات عملاء'),\n""",
  """    ('function statsReport',         'تقرير الاستخدام — اتحلّت/اتصعّدت من غير بيانات عملاء'),\n    ('<meta name="author" content="Mohamed Safwat', 'اسم المؤلف في الصفحة'),\n"""),
]
for o, n in edits:
    if n in bb: continue
    if bb.count(o) != 1: raise SystemExit('MISMATCH build.py: ' + o[:70])
    bb = bb.replace(o, n)
io.open(bp, 'w', encoding='utf-8').write(bb); print('  ok  البناء')
