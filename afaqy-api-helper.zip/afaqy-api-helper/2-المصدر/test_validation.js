/* v6.42 — التحقق من المدخلات.
   الاختبارات دي بتقفل على تلات حالات لقيناهم في المراجعة، وأخطرهم
   إن فترة مقلوبة كانت بتطلّع رد غلط للعميل. */
const fs=require('fs'); const {JSDOM}=require('jsdom');
let F=0; const pass=m=>console.log('  \u2713 '+m); const fail=m=>{console.log('  \u2717 '+m);F++;};
const ok=(m,c,x)=>c?pass(m):fail(m+(x?'  \u2014 '+String(x).slice(0,130):''));
const build=()=>fs.readFileSync(process.argv[2]||'app_template.html','utf8')
  .replace('/*__KB__*/',()=>fs.readFileSync('kb_slim.json','utf8'))
  .replace('/*__DOCS__*/',()=>fs.readFileSync('docs.json','utf8'))
  .replace('/*__KBIN__*/',()=>fs.readFileSync('kb_in.json','utf8'));
const IM='860123456789012';
const AR='\u0668\u0666\u0660\u0661\u0662\u0663\u0664\u0665\u0666\u0667\u0668\u0669\u0660\u0661\u0662'; /* ٨٦٠١٢٣٤٥٦٧٨٩٠١٢ */

function boot(){
  const w=new JSDOM(build(),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://localhost/'}).window;
  w.alert=()=>{}; w.confirm=()=>true; w.scrollTo=()=>{};
  w.eval("SESSION.token='T';SESSION.user='O';SESSION.userId='U';");
  const calls=[]; let pct=0;
  w.fetch=async(u,o)=>{ const p=String(u).split('?')[0].replace(/^https?:\/\/[^/]+/,''); calls.push(p);
    const J=x=>({ok:true,status:200,text:async()=>JSON.stringify(x)});
    if(p==='/unit_groups/lists')return J({data:{items:[{id:'G1',name:'R'}]}});
    if(p==='/units/lists')return J({data:{items:[{id:'U_B',name:'Truck B',imei:IM}]}});
    if(p==='/user_report_templates/lists')return J({data:{items:[{id:'T1',name:'S',code:'summary',fields:[]}]}});
    if(p==='/user_reports/add')return J({data:{id:'R7'}});
    if(p==='/user_reports/percentage'){pct+=50;return J({data:[{reportId:'R7',percentage:Math.min(100,pct)}]});}
    if(p==='/user_reports/data-summary')return J({data:[{resource_id:'U_B',name:'Truck B',route_length:9}]});
    return J({data:[]}); };
  return {w, calls};
}
async function run(w,imei,from,to){
  w.showView('recipes'); w.startRecipe('summary-report');
  w.eval(`RC.vars.imei=${JSON.stringify(imei)};RC.vars.from=${JSON.stringify(from)};RC.vars.to=${JSON.stringify(to)};`);
  w.document.getElementById('rcAll').click();
  for(let i=0;i<90 && w.eval("RC.auto")!==false;i++) await new Promise(r=>setTimeout(r,60));
  await new Promise(r=>setTimeout(r,250));
}

(async()=>{

/* ═════ ١) التطبيع نفسه ═════ */
console.log('\n\u0661) تطبيع الأرقام');
{
  const {w}=boot();
  const D=v=>w.eval('digitsOnly('+JSON.stringify(v)+')');
  ok('أرقام عربية → إنجليزي', D(AR)===IM, D(AR));
  ok('أرقام فارسية → إنجليزي', D('\u06F8\u06F6\u06F0')==='860', D('\u06F8\u06F6\u06F0'));
  ok('علامة اتجاه مخفية بتتشال', D(IM+'\u200F')===IM, D(IM+'\u200F'));
  ok('مسافة غير قابلة للكسر بتتشال', D('\u00A0'+IM+'\u00A0')===IM);
  ok('الشرطة ما بتفرقش', D('860-123-456789012')===IM);
  ok('الفاضي بيفضل فاضي', D('')==='' && D(null)==='' && D(undefined)==='');
  w.close();
}

/* ═════ ٢) الفترة المقلوبة بتتمسك قبل السيرفر ═════ */
console.log('\n\u0662) الفترة المقلوبة');
{
  const {w,calls}=boot();
  await run(w, IM, '2026-12-31', '2026-01-01');
  ok('ما ضربش السيرفر خالص', calls.length===0, calls.join(','));
  ok('وما طلّعش رد للعميل', !w.document.getElementById('rcReplyTxt'));
  const md=w.document.body.textContent;
  ok('وقال إن الفترة مقلوبة', /مقلوبة|reversed/.test(md));
  ok('وحذّر إن الرد كان هيبقى غلط', /رد غلط|wrong answer/.test(md));
  w.close();
}

/* ═════ ٣) IMEI بشكل غلط بيتمسك قبل السيرفر ═════ */
console.log('\n\u0663) شكل الـ IMEI');
{
  for(const [v,lbl] of [['12345','١٤ رقم ناقص'],['abcdefghijklmno','حروف'],['86012345678901X','رقم فيه حرف']]){
    const {w,calls}=boot();
    await run(w, v, '2026-08-01','2026-08-05');
    ok(lbl+': ما ضربش السيرفر', calls.length===0, calls.join(','));
    w.close();
  }
  const {w}=boot();
  await run(w,'12345','2026-08-01','2026-08-05');
  ok('وقال إنه ١٥ رقم', /١٥ رقم|15 digits/.test(w.document.body.textContent));
  w.close();
}

/* ═════ ٤) الأرقام العربية بتلاقي العربية ═════ */
console.log('\n\u0664) IMEI بأرقام عربية بيلاقي');
{
  const {w,calls}=boot();
  await run(w, AR, '2026-08-01','2026-08-05');
  ok('مشى لآخر السلسلة', calls.includes('/user_reports/data-summary'), calls.join(' → '));
  /* نفحص شاشة السيناريو بس — الجملة دي موجودة في نص الدليل كمان */
  const _sc = w.document.getElementById('rcRun').textContent;
  ok('وما قالش «مش في الحساب»', !/مش في الحساب|not on the connected/.test(_sc), _sc.slice(0,90));
  const rep=w.document.getElementById('rcReplyTxt');
  ok('وطلّع رد للعميل', !!rep);
  w.close();
}

/* ═════ ٥) علامة الاتجاه المخفية ═════ */
console.log('\n\u0665) IMEI منسوخ من إيميل عربي');
{
  const {w,calls}=boot();
  await run(w, IM+'\u200F', '2026-08-01','2026-08-05');
  ok('لاقى العربية', calls.includes('/user_reports/data-summary'), calls.join(' → '));
  w.close();
}

/* ═════ ٦) اللي كان شغال لسه شغال ═════ */
console.log('\n\u0666) ما كسرناش اللي كان ماشي');
{
  const {w,calls}=boot();
  await run(w, IM, '2026-08-01','2026-08-05');
  ok('الرقم العادي لسه بيشتغل', calls.includes('/user_reports/data-summary'));
  ok('والرد بيطلع', !!w.document.getElementById('rcReplyTxt'));
  w.close();
}
{
  const {w,calls}=boot();
  await run(w, '', '2026-08-01','2026-08-05');   /* فاضي = الحساب كله */
  ok('الخانة الفاضية لسه بتشتغل على الحساب كله', calls.includes('/user_reports/data-summary'), calls.join(' → '));
  w.close();
}

/* ═════ ٧) فترة طويلة: تحذير مش منع أعمى ═════ */
console.log('\n\u0667) الفترة الطويلة');
{
  const {w,calls}=boot();
  await run(w, IM, '2020-01-01','2026-08-05');
  ok('وقف وحذّر', calls.length===0);
  ok('وقال كام يوم', /يوم|days/.test(w.document.body.textContent));
  w.close();
}


/* ═════ ٨) المسار اليدوي: نفس الباج كان فيه ═════ */
console.log('\n\u0668) المطابقة اليدوية (نافذة الاعتماديات)');
{
  const {w}=boot();
  const resp={data:{items:[{id:'U_B',name:'Truck B',imei:IM}]}};
  const M=(needle)=>w.eval('JSON.stringify(matchByName('+JSON.stringify(resp)+','+JSON.stringify(needle)+'))');
  ok('الرقم العادي بيلاقي', JSON.parse(M(IM)).hit!==null);
  ok('الأرقام العربية بتلاقي', JSON.parse(M(AR)).hit!==null, M(AR).slice(0,80));
  ok('علامة الاتجاه المخفية بتلاقي', JSON.parse(M(IM+'\u200F')).hit!==null);
  ok('وبيقول لاقاه بالـ IMEI', JSON.parse(M(AR)).by==='IMEI', JSON.parse(M(AR)).by);
  ok('ورقم غلط لسه ما بيلاقيش', JSON.parse(M('999999999999999')).hit===null);
  ok('والاسم لسه شغال', JSON.parse(M('Truck B')).hit!==null);
  w.close();
}

console.log('\n'+(F?'\u2717 فشل: '+F:'\u2713 كله عدّى'));
process.exit(F?1:0);
})();
