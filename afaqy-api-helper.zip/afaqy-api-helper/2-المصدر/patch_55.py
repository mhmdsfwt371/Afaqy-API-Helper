#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ترقيعة v5.5 — أمان التنفيذ. بتشتغل على app_template.html بأنكورات حرفية،
   وأي أنكور مش موجود بيوقّفها ويطبع MISS بدل ما تكمل ناقصة.
   طبقة فوق الأساس: مفيش دالة قديمة اتشالت ولا سلوك قراءة اتغيّر."""
import sys

P = 'app_template.html'
s = open(P, encoding='utf-8').read()
misses = []
done = []

def rep(old, new, label, count=1):
    global s
    c = s.count(old)
    if c != count:
        misses.append(f'{label} (لقيت {c} بدل {count})')
        return
    s = s.replace(old, new)
    done.append(label)

def rep_all(old, new, label):
    global s
    c = s.count(old)
    if c == 0:
        misses.append(f'{label} (مش موجود)')
        return
    s = s.replace(old, new)
    done.append(f'{label} ×{c}')

# ============ ١) التصنيف والشارة — بعد NO_RETRY ============
anchor = "const NO_RETRY = /^\\/auth\\/(login|send_login_otp|verify_login_otp|login_as|forgot|reset)/i;"
block = anchor + """

/* ============ v5.5 — تصنيف التنفيذ ============
   كل ريكوست: قراءة، أو كتابة (بيغيّر داتا العميل)، أو حساس (بيلمس حساب العميل نفسه).
   الكتابة محتاجة تأكيد مكتوب، والحساس مقفول من الأداة خالص.
   القايمة القديمة DESTRUCTIVE كانت سايبة التعيين والتحديث والحفظ — دي بتغطّيهم. */
const FORBIDDEN = /^\\/auth\\/(login_as|forgot|reset(_expired_password)?|delete|send_login_otp)(\\/|\\?|$)/i;
const WRITE_WORDS = new Set('add,create,store,save,edit,update,modify,delete,destroy,remove,erase,assign,unassign,attach,detach,unlink,import,upload,activate,deactivate,enable,disable,suspend,resume,change,cancel,approve,reject,copy,duplicate,clone,restore,clear,reset,merge,move,transfer,sync,send,register,renew,extend,reorder,mark,close,reopen,toggle,logout,revoke,terminate,restart,bulk,forever'.split(','));
const READ_TAIL = new Set('list,lists,view,search,get,show,count,export,history,details,detail,signals,report,reports,log,logs,status,check,inquire,find,filter,summary,info,stats,last,download,print,types,options'.split(','));
function epKind(e){
  const p = String((e && e.p) || e || '').toLowerCase();
  if(FORBIDDEN.test(p)) return 'danger';
  const segs = p.split(/[^a-z]+/).filter(Boolean);
  if(segs.length && READ_TAIL.has(segs[segs.length-1])) return 'read';
  if(segs.some(w => WRITE_WORDS.has(w))) return 'write';
  const name = String((e && e.n) || '').toLowerCase().split(/[^a-z]+/).filter(Boolean);
  if(name.some(w => WRITE_WORDS.has(w))) return 'write';
  return 'read';
}
function kindChip(e){
  const k = epKind(e);
  if(k === 'danger') return `<span class="pill" style="background:#F6D9DC; color:#8E2430; border:1px solid #E5B4BA">${t('حساس — مقفول','Sensitive — locked')}</span>`;
  if(k === 'write')  return `<span class="pill" style="background:#F9E9D2; color:#8A5A16; border:1px solid #EAD2A8">${t('كتابة','Writes')}</span>`;
  return '';
}"""
rep(anchor, block, '١) التصنيف epKind + الشارة')

# ============ ٢) KIND جوه صفحة الريكوست + توسيع noFix ============
old = "const noFix = isLogin || DESTRUCTIVE.test(e.n) || DESTRUCTIVE.test(e.p);"
new = "const KIND = epKind(e);\n  const noFix = isLogin || KIND !== 'read' || DESTRUCTIVE.test(e.n) || DESTRUCTIVE.test(e.p);"
rep(old, new, '٢) noFix بقى يغطي كل الكتابة')

# ============ ٣) الشارة جنب المسار ============
old = "<span class=\"m m-${esc(e.m||'POST')}\">${esc(e.m||'POST')}</span> ${esc(e.p)}</div>"
new = "<span class=\"m m-${esc(e.m||'POST')}\">${esc(e.m||'POST')}</span> ${esc(e.p)} ${kindChip(e)}</div>"
rep(old, new, '٣) شارة جنب المسار')

# ============ ٤) الشارة في نتايج البحث ============
old = "<span class=\"rp\">${esc(r.e.p)}</span>"
new = "<span class=\"rp\">${esc(r.e.p)}</span> ${kindChip(r.e)}"
rep_all(old, new, '٤) شارة في النتايج')

# ============ ٥) نوت الخطر/الكتابة بدل نوت SAFE القديم ============
i0 = s.find("${dangerous ? `")
end_mark = "بس.</div>` : ''}"
i1 = s.find(end_mark, i0)
if i0 < 0 or i1 < 0:
    misses.append('٥) بلوك نوت الخطر (مش لاقي البداية/النهاية)')
else:
    newnote = ("${KIND==='danger' ? `<div class=\"note warn\" style=\"margin-top:10px\"><b>${t('ريكوست حساس على حساب العميل — التنفيذ من هنا مقفول.','Sensitive account request — running it from here is locked.')}</b><br>"
               "${t('الدخول بحساب العميل أو تصفير الباسورد أو مسح الحساب بيتعمل من المنصة وبإجراء رسمي، مش من أداة الدعم.','Impersonation, password resets and account deletion go through the platform with a formal procedure, not the support tool.')}</div>`\n"
               "         : KIND==='write' ? `<div class=\"note warn\" style=\"margin-top:10px\"><b>${t('ريكوست كتابة — بيغيّر داتا العميل فعليًا.','A write request — it changes real customer data.')}</b> "
               "${t('التجربة هتطلب تأكيد مكتوب قبل الإرسال.','Running it asks for a typed confirmation first.')}</div>`\n"
               "         : dangerous ? `<div class=\"note warn\" style=\"margin-top:10px\">${t('ريكوست خطر — ما يتبعتش للعميل كمثال إلا بموافقة. جرّبه على البيئة التجريبية بس.','A risky request — do not send it to a customer as an example without approval. Try it on staging only.')}</div>` : ''}")
    s = s[:i0] + newnote + s[i1+len(end_mark):]
    done.append('٥) نوت الخطر بقى تلاتي: حساس/كتابة/القديم')

# ============ ٦) تعطيل زراير التجربة على الحساس ============
rep("<button class=\"btn ghost\" id=\"tryIt\">", "<button class=\"btn ghost\" id=\"tryIt\" ${KIND==='danger'?'disabled':''}>", '٦أ) تعطيل جرّب على الحساس')
rep("<button class=\"btn sig\" id=\"topTry\">", "<button class=\"btn sig\" id=\"topTry\" ${KIND==='danger'?'disabled':''}>", '٦ب) تعطيل جرّب-فوق على الحساس')

# ============ ٧) فرع الحساس في رسالة الزراير ============
old = "${isLogin ? t('التصحيح التلقائي مقفول هنا"
new = ("${KIND==='danger' ? t('التنفيذ مقفول على الريكوست ده — حساس على حساب العميل نفسه.','Running this request is locked — it touches the customer account itself.')\n"
       "             : isLogin ? t('التصحيح التلقائي مقفول هنا")
rep(old, new, '٧) رسالة الحساس جنب الزراير')

# ============ ٨) البوابة: tryItRun بقى حارس + tryItSend هو الإرسال ============
old = "async function tryItRun(e, out){"
new = """async function tryItRun(e, out, armed){
  const k = epKind(e);
  if(k === 'danger'){
    out.innerHTML = `<div class="note warn" style="margin-top:12px"><b>${t('مقفول.','Locked.')}</b> ${t('الريكوست ده بيلمس حساب العميل نفسه (دخول بحسابه / باسورد / مسح) — ما يتنفذش من أداة الدعم.','This request touches the customer account itself — impersonation / password / deletion — and it does not run from the support tool.')}</div>`;
    return;
  }
  if(k === 'write' && !armed){
    out.innerHTML = `<div class="note warn" style="margin-top:12px">
      <b>${t('ريكوست كتابة — هيغيّر داتا العميل فعليًا.','A write request — it changes real customer data.')}</b><br>
      ${t('لو قاصدها فعلًا: اكتب','If you really mean it: type')} <b>نفّذ</b> ${t('في الخانة ودوس تأكيد.','in the box, then press confirm.')}
      <div class="row" style="margin-top:8px">
        <input class="wgIn" style="width:110px" autocomplete="off">
        <button class="btn warn wgGo">${t('تأكيد التنفيذ','Confirm the run')}</button>
        <button class="btn ghost wgNo">${t('إلغاء','Cancel')}</button>
      </div>
    </div>`;
    const gi = out.querySelector('.wgIn'), gg = out.querySelector('.wgGo'), gn = out.querySelector('.wgNo');
    if(gg) gg.onclick = ()=>{
      const v = ((gi && gi.value) || '').trim();
      if(v === 'نفّذ' || v === 'نفذ') tryItRun(e, out, true);
      else if(gi) gi.style.borderColor = '#B4232F';
    };
    if(gn) gn.onclick = ()=>{ out.innerHTML = ''; };
    return;
  }
  return tryItSend(e, out);
}
async function tryItSend(e, out){"""
rep(old, new, '٨) بوابة التأكيد قبل الإرسال')

# ============ ٩) حارس المسار السريع ============
old = "const imei=($('qkImei').value||'').trim(), e=QUICK.ep;"
new = old + """
  if(e && epKind(e)!=='read'){ out.innerHTML=`<div class="note warn" style="margin-top:12px">${t('المسار السريع للقراءة بس — الريكوست ده بيكتب في داتا العميل. افتحه من تبويب الريكوستات وجرّبه بالتأكيد المكتوب.','The quick path is read-only — this request writes customer data. Open it in the requests tab and run it with the typed confirmation.')}</div>`; return; }"""
rep(old, new, '٩) حارس المسار السريع')

# ============ ١٠) سقف التزامن ============
i0 = s.find('async function apiFetch(')
if i0 < 0:
    misses.append('١٠) مكان apiFetch')
else:
    ln = s.rfind('\n', 0, i0) + 1
    polite = """/* v5.5 — سقف تزامن: أربع ريكوستات في نفس اللحظة كحد أقصى.
   الداشبوردات بتضرب عشرات النداءات — من غير سقف بنداهم كلهم على حساب العميل مرة واحدة. */
let POLITE_N = 0; const POLITE_Q = [];
async function polite(fn){
  if(POLITE_N >= 4) await new Promise(res => POLITE_Q.push(res));
  POLITE_N++;
  try{ return await fn(); }
  finally{ POLITE_N--; const nx = POLITE_Q.shift(); if(nx) nx(); }
}
"""
    s = s[:ln] + polite + s[ln:]
    done.append('١٠) سقف التزامن polite')
rep("let r = await send();", "let r = await polite(send);", '١٠أ) لف الإرسال الأول')
rep("if(re){ r = await send(); r.relogged = true; }", "if(re){ r = await polite(send); r.relogged = true; }", '١٠ب) لف إعادة الإرسال')

# ============ ١١) خانة عميل التذكرة في الشريط ============
old = "<span id=\"sesState\" class=\"pill\">غير متصل</span>"
new = old + """
      <input id="tickCust" autocomplete="off" style="width:150px; font-family:var(--ar); text-align:right; direction:rtl" data-arph="عميل التذكرة (اختياري)" data-enph="Ticket customer (optional)" placeholder="عميل التذكرة (اختياري)">
      <span id="tickWarn" class="pill" style="background:#F6D9DC; color:#8E2430; border:1px solid #E5B4BA" hidden data-ar="⚠ حساب مختلف عن عميل التذكرة" data-en="⚠ Different account from the ticket customer">⚠ حساب مختلف عن عميل التذكرة</span>"""
rep(old, new, '١١) خانة عميل التذكرة')

# ============ ١٢) منطق الخانة قبل ربط زرار الاتصال ============
i0 = s.find("$('sesGo').onclick")
if i0 < 0:
    misses.append('١٢) مكان ربط sesGo')
else:
    ln = s.rfind('\n', 0, i0) + 1
    tick = """/* v5.5 — خانة عميل التذكرة: تحذير لو الحساب المتصل مختلف عن العميل اللي بترد عليه */
function checkTick(){
  const w = $('tickWarn'); if(!w) return;
  const c = (($('tickCust') && $('tickCust').value) || '').trim().toLowerCase();
  const u = String(SESSION.user || '').toLowerCase();
  w.hidden = !(c && u && c !== u && u.indexOf(c) < 0 && c.indexOf(u) < 0);
}
try{ $('tickCust').value = sessionStorage.getItem('tickCust') || ''; }catch(_){}
$('tickCust').oninput = ()=>{ try{ sessionStorage.setItem('tickCust', $('tickCust').value); }catch(_){} checkTick(); };
"""
    s = s[:ln] + tick + s[ln:]
    done.append('١٢) منطق خانة التذكرة')

# ============ ١٣) فحص بعد الاتصال وبعد القطع ============
old = "SESSION.user=u; SESSION.pass=pw; SESSION.token=tok; SESSION.at=Date.now();"
rep(old, old + " checkTick();", '١٣أ) فحص بعد الاتصال')
old = "SESSION.at=null; SESSION.unit=null;"
rep(old, old + " checkTick();", '١٣ب) فحص بعد القطع')

# ============ النتيجة ============
for d in done: print('تمام:', d)
if misses:
    print('\n!! أنكورات ضايعة — الترقيعة وقفت من غير كتابة:')
    for x in misses: print('  MISS:', x)
    sys.exit(1)
open(P, 'w', encoding='utf-8').write(s)
print(f'\nاتكتب — {len(done)} تعديل، صفر MISS')
