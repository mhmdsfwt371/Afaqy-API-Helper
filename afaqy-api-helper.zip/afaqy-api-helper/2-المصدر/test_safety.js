/* v5.5 — بوابة الأمان: التصنيف والتأكيد والقفل.
   اتكتب مع النسخة اللي منعت تنفيذ الكتابة بضغطة واحدة —
   قبلها «جرّب مرة واحدة» كان بيبعت أي حاجة، حتى الدخول بحساب العميل. */
global.setInterval=()=>0;global.clearInterval=()=>{};
const fs = require('fs');
function el(id){return{id,hidden:false,innerHTML:'',value:'',textContent:'',className:'',dataset:{},style:{},files:[],disabled:false,
 classList:{toggle(){},add(){},remove(){}},querySelectorAll(){return[]},addEventListener(){},focus(){},select(){},click(){},
 setAttribute(){},getAttribute(){return null},dispatchEvent(){},appendChild(){},remove(){},scrollIntoView(){}}}
const R={};global.document={documentElement:el(),body:el(),addEventListener(){},querySelectorAll(){return[]},
 querySelector(){return null},createElement(){return el()},getElementById(i){return R[i]||(R[i]=el(i))}};
global.history={pushState(){},replaceState(){}};global.location={hash:'',pathname:'/',replace(){}};
global.navigator={userAgent:'node',clipboard:{writeText(){return Promise.resolve()}}};
global.window={scrollTo(){},addEventListener(){},matchMedia:()=>({matches:false}),navigator:{}};
global.fetch=()=>Promise.reject(0);global.Blob=function(){};global.URL={createObjectURL(){return''}};global.FileReader=function(){};

let js = fs.readFileSync('app_template.html','utf8').split('<script>')[1].split('</script>')[0]
  .replace('/*__KB__*/', fs.readFileSync('kb_slim.json','utf8')).replace('/*__KBIN__*/', fs.readFileSync('kb_in.json','utf8'))
  .replace('/*__DOCS__*/', fs.readFileSync('docs.json','utf8'));
const m={};
new Function('module', js + "\nmodule.exports={EPS,epKind,FORBIDDEN,DESTRUCTIVE,SESSION,tryItRun};")(m);
const A = m.exports;
const fail = msg => { console.error('فشل: ' + msg); process.exit(1); };

/* ١) جدول حقيقة التصنيف */
const truth = [
  ['/units/lists','read'], ['/units/view','read'], ['/units/signals','read'],
  ['/auth/login','read'], ['/settings/list','read'], ['/import_logs/list','read'],
  ['/reports/export','read'],
  ['/units/edit','write'], ['/drivers/assign','write'], ['/x/store','write'],
  ['/x/update','write'], ['/x/save','write'], ['/x/create','write'],
  ['/x/restore','write'], ['/auth/logout','write'],
  ['/auth/login_as','danger'], ['/auth/reset','danger'], ['/auth/delete','danger'],
  ['/auth/send_login_otp','danger'], ['/auth/forgot','danger'], ['/auth/reset_expired_password','danger'],
];
for(const [p,k] of truth){
  const got = A.epKind({p, n:''});
  if(got !== k) fail(`تصنيف ${p}: المفروض ${k} طلع ${got}`);
}
console.log('جدول التصنيف       : ' + truth.length + ' حالة تمام');

/* ٢) إحصاء على الكولكشن الحقيقي — الحدود المعقولة */
const kinds = {read:0, write:0, danger:0};
for(const e of A.EPS) kinds[A.epKind(e)]++;
if(kinds.write < 150 || kinds.write > 340) fail('عدد الكتابة خارج المعقول: ' + kinds.write);
if(kinds.danger < 5) fail('الحساس أقل من المتوقع: ' + kinds.danger);
for(const e of A.EPS){
  if(A.epKind(e) === 'danger' && e.p.indexOf('/auth/') !== 0) fail('حساس خارج auth: ' + e.p);
  if(/\/(delete|destroy)(\/|$|_)/.test(e.p) && A.epKind(e) === 'read') fail('مسح متصنّف قراءة: ' + e.p);
}
console.log(`إحصاء الكولكشن     : قراءة ${kinds.read} · كتابة ${kinds.write} · حساس ${kinds.danger}`);

/* ٣) البوابة بتمنع فعليًا — عدّاد نداءات الشبكة لازم يفضل صفر */
function elq(){ const b = el('out'); b._q = {}; b.querySelector = s => b._q[s] || (b._q[s] = el(s)); return b; }
let calls = 0;

(async () => {
  /* نداءات التحميل المؤجلة (زي فحص وجود docs.pdf جنب الصفحة) لازم تخلص قبل ما نبدأ نعد */
  await new Promise(r => setTimeout(r, 120));
  global.fetch = () => { calls++; return Promise.resolve({ok:true, status:200, text:()=>Promise.resolve('{}')}); };
  A.SESSION.user='support'; A.SESSION.pass='x'; A.SESSION.token='tok'; A.SESSION.at=Date.now();
  const we = A.EPS.find(e => A.epKind(e) === 'write' && e.t);
  if(!we) fail('مفيش ريكوست كتابة بتوكن في الكولكشن؟');
  let out = elq();
  await A.tryItRun(we, out);
  if(calls !== 0) fail('كتابة من غير تأكيد بعتت نداء شبكة!');
  if(out.innerHTML.indexOf('نفّذ') < 0) fail('نافذة التأكيد ما ظهرتش');

  out = elq();
  await A.tryItRun({p:'/auth/login_as', n:'Login as user', t:true, m:'POST', i:99999}, out);
  if(calls !== 0) fail('ريكوست حساس اتبعت!');
  if(out.innerHTML.indexOf('مقفول') < 0) fail('رسالة القفل ما ظهرتش');
  console.log('البوابة الحية      : الكتابة اتوقفت والحساس اتقفل — صفر نداءات ✓');

  /* ٤) أسلاك القالب — الترتيب والوجود */
  const tpl = fs.readFileSync('app_template.html','utf8');
  const iRun = tpl.indexOf('async function tryItRun');
  const iSend = tpl.indexOf('async function tryItSend');
  if(iRun < 0 || iSend < 0 || iRun > iSend) fail('ترتيب البوابة قبل الإرسال غلط');
  if((tpl.match(/polite\(send\)/g) || []).length !== 2) fail('سقف التزامن مش لافف الإرسالين');
  if(tpl.indexOf("epKind(e)!=='read'") < 0) fail('حارس المسار السريع ناقص');
  if(tpl.indexOf('id="tickCust"') < 0) fail('خانة رقم التاسك ناقصة');
  // v6.5: الخانة بقت رقم تاسك، فتحذير «حساب مختلف عن العميل» اتشال —
  // مقارنة رقم بإيميل كانت هتدّي تحذير كاذب على طول.
  if(tpl.indexOf('id="tickWarn"') >= 0) fail('تحذير اختلاف الحساب رجع — بيقارن رقم بإيميل');
  if(tpl.indexOf('data-arph="رقم التاسك (اختياري)"') < 0) fail('عنوان الخانة مش رقم التاسك');
  console.log('أسلاك القالب       : تمام');
})().catch(e => { console.error('فشل: ' + (e && e.message || e)); process.exit(1); });
