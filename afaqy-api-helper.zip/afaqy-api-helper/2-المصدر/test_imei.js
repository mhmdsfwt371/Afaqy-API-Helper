global.setInterval=()=>0;global.clearInterval=()=>{};
const fs=require('fs');
function el(id){return{id,hidden:false,innerHTML:'',value:'',textContent:'',dataset:{},style:{},files:[],disabled:false,
 classList:{toggle(){},add(){},remove(){}},querySelectorAll(){return[]},addEventListener(){},focus(){},select(){},click(){},
 setAttribute(){},getAttribute(){return null},dispatchEvent(){},appendChild(){},remove(){},scrollIntoView(){}}}
const R={};global.document={documentElement:el(),body:el(),addEventListener(){},querySelectorAll(){return[]},
 querySelector(){return null},createElement(){return el()},getElementById(i){return R[i]||(R[i]=el(i))}};
global.history={pushState(){},replaceState(){}};
global.location={hash:''};
global.navigator={clipboard:{writeText(){return Promise.resolve()}}};global.window={scrollTo(){},addEventListener(){}};
global.fetch=()=>Promise.reject(0);global.Blob=function(){};global.URL={createObjectURL(){return''}};global.FileReader=function(){};
let js=fs.readFileSync('app_template.html','utf8').split('<script>')[1].split('</script>')[0]
  .replace('/*__KB__*/',fs.readFileSync('kb_slim.json','utf8')).replace('/*__KBIN__*/', fs.readFileSync('kb_in.json','utf8')).replace('/*__DOCS__*/',fs.readFileSync('docs.json','utf8'));
const m={};new Function('module',js+'\nmodule.exports={matchByName,deepItems,EXAMPLES,GLOSSARY,LEARNED,RECIPES,dual,setL:(l)=>{LANG=l}};')(m);
const A=m.exports;

// رد فيه العربية بكل أرقامها
const resp={status:true,data:{items:[
 {_id:'5fb0e2e703ed529bb30f9af3', name:'NB YD - TH - 1129', imei:'357454075086551',
  device_serial:'861230048816917', plate_number:'ABC 1234'},
 {_id:'6009324fd77b9f0552247855', name:'DP 18181', imei:'352094083043288', device_serial:'111222333'}]}};

console.log('المطابقة بأي رقم:');
[['رقم النظام','5fb0e2e703ed529bb30f9af3'],
 ['IMEI','357454075086551'],
 ['سيريال الجهاز','861230048816917'],
 ['اللوحة','ABC 1234'],
 ['الاسم','NB YD - TH - 1129'],
 ['IMEI التانية','352094083043288']].forEach(([label,v])=>{
  const r=A.matchByName(resp,v);
  console.log('  '+label.padEnd(16)+' → '+(r.hit?r.hit.name+'   (اتطابق على '+r.by+')':'ما لقاش'));
});

// رقم مش موجود
const miss=A.matchByName(resp,'999999999999999');
console.log('  رقم غير موجود   → '+(miss.hit?'لقى!':'ما لقاش ✓')+'  | الرد فيه IMEI؟ '+(miss.hasImei?'أيوه':'لأ'));

// رد من غير IMEI: لازم يقول للموظف
const noImei={data:{items:[{_id:'aaa',name:'Truck 1'}]}};
const r2=A.matchByName(noImei,'357454075086551');
console.log('  رد من غير IMEI  → hit='+(r2.hit?'لقى':'ما لقاش')+' | hasImei='+r2.hasImei+' (المفروض يحذّر الموظف)');

console.log('\nالمدخلات في السيناريوهات:');
A.setL('ar');
A.RECIPES.filter(r=>r.inputs.length).forEach(r=>console.log('  '+A.dual(r.title)+'  →  '+r.inputs.map(f=>A.dual(f.l)).join(' , ')));

console.log('\nأمثلة الشغل: '+A.EXAMPLES.length+' | مصطلحات: '+A.GLOSSARY.length+' | معرفة: '+A.LEARNED.length);
A.setL('en'); console.log('EN example 1: '+A.dual(A.EXAMPLES[0].tag));
