#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v7.0 — Claude جوه الأداة: فهم أي رسالة، مؤسس على التوثيق، ومتفحوص قبل ما يظهر.

ليه: كل حالة الشهر ده احتاجت قاعدة جديدة بإيد (الـ IMEI، لستة الإنتجريشن، لقطة
بوستمان، كارت المنصة). العميل الجاي هيبعت حاجة مفيش قاعدة ليها. اللي بيغيّر
ده نموذج لغة جوه الأداة — بشرط إنه ما يجاوبش من دماغه.

إزاي:
- الأداة بتنادي Anthropic API من المتصفح مباشرة (الـ API بيقبل ده بهيدر
  anthropic-dangerous-direct-browser-access — اتأكدنا منه) بمفتاح الموظف
  المتخزّن على جهازه زي كلمات السر. مفيش سيرفر، ومفيش مفتاح في الصفحة.
- كل نداء معاه: فهرس كل ريكوستات التوثيق الرسمي، وتفاصيل المرشّحين (البودي
  والوصف) من بحث الأداة، والريكوستات المحفوظة من غير توثيق متعلّمة «ما
  تتبعتش للعميل»، والمعرفة المؤكدة (الأساسيات، الأخطاء، دروس التذاكر،
  القواعد)، وتعليمات صارمة: ما تخترعش، ما توعدش، التوكن وكلمة السر مش بتتبعت.
- الرد بييجي منظّم (tool use): النوع، الفهم، التشخيص، الخطوات بالإندبوينتس
  والبودي، الرد للعميل عربي وإنجليزي، اللي مش مؤكد، اللي محتاجه من العميل.
- قبل ما يظهر: الأداة بتفحص كل مسار اتذكر — مش في الكولكشن = مخترع (بيتعلّم
  أحمر ومش بيتبعت)، محفوظ من غير توثيق = تحذير. البودي لازم JSON.
- الصورة: لو فيه مفتاح، الصورة نفسها بتتبعت لـ Claude (رؤية) بدل قراءة
  Tesseract — أدق بكتير على الإيميلات وكروت المنصة.
- التكلفة بتتعرض بعد كل نداء. والرسالة (والصورة) بتروح لـ Anthropic API على
  حساب المفتاح — قرار بيزنس، والأداة بتقوله في الإعدادات.
"""
import sys, io, os
HERE = os.path.dirname(os.path.abspath(__file__))
PATH = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, 'app_template.html')
src = io.open(PATH, encoding='utf-8').read(); orig = len(src)
def rep(old, new, n=1, tag=''):
    global src
    c = src.count(old)
    if c != n: raise SystemExit('MISMATCH [%s]: expected %d found %d\n---\n%s' % (tag, n, c, old[:200]))
    src = src.replace(old, new, n); print('  ok  %s' % tag)

AI_JS = r"""
/* ============ Claude جوه الأداة — فهم مؤسس على التوثيق ============
   النموذج عمره ما بيجاوب من دماغه: كل نداء معاه التوثيق الرسمي والمعرفة
   المؤكدة، والرد بيتفحص مسار مسار قبل ما يظهر. */
const AI_STORE = 'afaqy.ai.v1';
const AI = { key:'', model:'claude-sonnet-5', vision:true, remember:true, lastImage:null, busy:false, usage:{inp:0, out:0, calls:0}, last:null };
const AI_MODELS = [['claude-sonnet-5','Sonnet 5 — الافتراضي'], ['claude-haiku-4-5-20251001','Haiku 4.5 — أرخص وأسرع'], ['claude-opus-5-5','Opus 5.5 — أقوى وأغلى']];
/* تقريبي بالدولار لكل مليون توكن — للعرض بس */
const AI_PRICE = {'claude-sonnet-5':[3,15], 'claude-haiku-4-5-20251001':[1,5], 'claude-opus-5-5':[15,75]};
function aiLoad(){
  try{ const s = JSON.parse(localStorage.getItem(AI_STORE) || '{}');
    if(s.k) AI.key = acctUnmask(s.k, AI_STORE);
    if(s.model) AI.model = s.model;
    if(typeof s.vision === 'boolean') AI.vision = s.vision;
  }catch(_){}
}
function aiStore(){
  try{
    if(AI.remember && AI.key) localStorage.setItem(AI_STORE, JSON.stringify({k:acctMask(AI.key, AI_STORE), model:AI.model, vision:AI.vision}));
    else localStorage.removeItem(AI_STORE);
  }catch(_){}
}
function aiReady(){ return !!(AI.key && AI.key.length > 20); }
/* اللي بيتبعت: التوكن وكلمة السر بيتشالوا — الـ IMEI والمعرّفات لازم يفضلوا عشان الفهم */
function aiRedact(txt){
  let s = String(txt || '');
  try{ if(SESSION.token) s = s.split(SESSION.token).join('<TOKEN>'); if(SESSION.pass) s = s.split(SESSION.pass).join('<PASSWORD>'); }catch(_){}
  s = s.replace(/([?&]token=)[^&\s"'<>]+/gi, '$1<TOKEN>').replace(/(Bearer\s+)[A-Za-z0-9\-._~+/]+=*/g, '$1<TOKEN>')
       .replace(/("password"\s*:\s*")[^"]*(")/gi, '$1<PASSWORD>$2').replace(/\beyJ[A-Za-z0-9\-_]{20,}\.[A-Za-z0-9\-_]{10,}\.[A-Za-z0-9\-_]{10,}\b/g, '<TOKEN>');
  return s;
}
/* فهرس كل ريكوستات التوثيق الرسمي — سطر لكل ريكوست */
function aiIndex(){
  return EPS.filter(e => sysOf(e) === 'avl').map(e => `${e.m} ${e.p} — ${e.n}` + (e.x ? ' [NOT IN OFFICIAL DOCUMENTATION — never recommend to a customer]' : (e.d ? ': ' + String(e.d).split('\n')[0].slice(0, 110) : ''))).join('\n');
}
/* تفاصيل المرشّحين: بحث الأداة + المسارات المذكورة في الرسالة */
function aiDetail(text){
  const seen = new Set(), picked = [];
  const add = e => { if(e && !seen.has(e.p + e.m)){ seen.add(e.p + e.m); picked.push(e); } };
  (mentionedPaths(text) || []).forEach(p => add(EPS.find(e => e.p === p && sysOf(e) === 'avl')));
  try{ search(text).slice(0, 10).forEach(r => add(r.e)); }catch(_){}
  ['/auth/login', '/units/lists'].forEach(p => add(EPS.find(e => e.p === p && sysOf(e) === 'avl' && !e.x)));
  return picked.slice(0, 14).map(e => `### ${e.m} ${e.p} — ${e.n}${e.x ? '\n[NOT IN OFFICIAL DOCUMENTATION — the tool keeps it because: ' + (e.xr || '') + '. Never recommend it to a customer.]' : ''}\n${e.d ? String(e.d).slice(0, 1200) : '(no description)'}\nSample body:\n${e.b ? String(e.b).slice(0, 1500) : '(none)'}`).join('\n\n');
}
const _aiStrip = h => String(h || '').replace(/<[^>]+>/g, ' ').replace(/&[a-z]+;/g, ' ').replace(/\s+/g, ' ').trim();
/* المعرفة المؤكدة: الأساسيات، الأخطاء، دروس التذاكر، قواعد التشخيص */
function aiFacts(){
  const L = [];
  try{ FAQ.forEach(f => L.push('- ' + _aiStrip(f.t.en) + ': ' + _aiStrip(f.h.en).slice(0, 700))); }catch(_){}
  try{ LEARNED.forEach(k => L.push('- ' + _aiStrip(k.t.en) + ': ' + _aiStrip(k.body.en).slice(0, 500))); }catch(_){}
  try{ CASE_RULES.forEach(r => L.push('- Known mistake "' + r.name.en + '": ' + r.mistake.en + ' ' + r.why.en)); }catch(_){}
  try{ ERRORS.forEach(x => L.push('- Error ' + (x.code || '') + ' (' + (x.http || '') + '): ' + _aiStrip(x.meaning && x.meaning.en))); }catch(_){}
  return L.join('\n').slice(0, 40000);
}
const AI_RULES = `You are the AFAQY integration support assistant inside an internal tool used by AFAQY support engineers in Saudi Arabia. You help an engineer answer a customer's API question or diagnose an API problem.

HARD RULES — violating any of them is a failure:
1. Only use endpoints, fields and behaviours from the OFFICIAL DOCUMENTATION and VERIFIED KNOWLEDGE given below. Never invent an endpoint, a field name, a parameter, a limit, a retention period or a feature. If something is not in the material, say it is unverified and put it in "unverified".
2. Endpoints marked "NOT IN OFFICIAL DOCUMENTATION" must never appear in a reply to a customer; use the documented alternative if one exists, otherwise say the capability is unverified.
3. Vehicles are identified by their UID (the "id" field of the vehicle in /units/lists), never by the IMEI. A 15-digit number in unit_id is the IMEI — that is a known customer mistake.
4. The platform returns HTTP 200 even on failure: read status_code and message in the body.
5. Almost every endpoint is POST with the body wrapped in a "data" object. The token goes in the URL as ?token= or as an Authorization: Bearer header.
6. Never promise follow-ups, timelines, pricing, roles or permissions on AFAQY's behalf. Never claim the platform can do something the material does not show.
7. Write the customer reply in a professional tone, in English (reply_en) and in formal Arabic (reply_ar) — each language pure, no mixing. Address the customer as "Dear team," in English and "السادة المحترمين،" in Arabic. No placeholders like [TO CONFIRM]; use "unverified" instead.
8. Write summary_ar and diagnosis_ar in Egyptian Arabic for the engineer, short and concrete.
9. Each step: method, path, a complete JSON body as a string using the customer's own values when known (IMEI, dates, codes); otherwise clear placeholders like <UID> or <YOUR_TOKEN>.
10. Answer by calling the "answer" tool exactly once. If an image is attached, read it carefully — it is the customer's screenshot (email, Postman, or the platform panel).`;
const AI_TOOL = { name:'answer', description:'Return the structured answer for the engineer and the customer.',
  input_schema:{ type:'object', properties:{
    kind:{type:'string', enum:['troubleshoot','integration_request','fields_request','question','other']},
    summary_ar:{type:'string'}, diagnosis_ar:{type:'string'}, diagnosis_en:{type:'string'},
    steps:{type:'array', items:{type:'object', properties:{method:{type:'string'}, path:{type:'string'}, body:{type:'string'}, why_en:{type:'string'}, why_ar:{type:'string'}}, required:['method','path']}},
    reply_en:{type:'string'}, reply_ar:{type:'string'},
    unverified:{type:'array', items:{type:'string'}}, needs_from_customer:{type:'array', items:{type:'string'}},
    confidence:{type:'number'} },
    required:['kind','summary_ar','steps','reply_en','reply_ar','unverified','confidence'] } };
/* الفحص: كل مسار اتذكر لازم يكون في الكولكشن؛ المحفوظ من غير توثيق تحذير؛ البودي JSON */
function aiValidate(ans){
  const avl = EPS.filter(e => sysOf(e) === 'avl');
  const docs = new Set(avl.map(e => e.p)), undoc = new Set(avl.filter(e => e.x).map(e => e.p));
  const norm = p => String(p || '').replace(/^https?:\/\/[^/]+/i, '').replace(/\?.*$/, '').replace(/\/+$/, '');
  ans.steps = (ans.steps || []).map(s => {
    const p = norm(s.path); let body = s.body;
    if(typeof body === 'string'){ try{ body = JSON.parse(body); }catch(_){ body = {_raw: String(s.body)}; } }
    return Object.assign({}, s, {path:p, body, st: !docs.has(p) ? 'invented' : (undoc.has(p) ? 'undocumented' : 'ok')});
  });
  const mention = txt => (String(txt || '').match(/\/(?:[a-z_][a-z0-9_\-]*)(?:\/[a-z_][a-z0-9_\-]*)+/gi) || []).map(norm);
  const issues = {};
  ['reply_en', 'reply_ar'].forEach(k => mention(ans[k]).forEach(p => {
    if(/^\/(auth|units|unit_|user|drivers|events|zones|reports|tracking|share|trailers|warehouses|rooms|inventory|wasl|customers|unit_report)/i.test(p) || docs.has(p)){
      if(!docs.has(p)) issues[p] = 'invented'; else if(undoc.has(p)) issues[p] = 'undocumented';
    }
  }));
  ans.replyIssues = Object.keys(issues).map(p => ({path:p, st:issues[p]}));
  ans.blocked = ans.steps.some(s => s.st === 'invented') || ans.replyIssues.some(x => x.st === 'invented');
  ans.warn = ans.steps.some(s => s.st === 'undocumented') || ans.replyIssues.some(x => x.st === 'undocumented');
  return ans;
}
function _aiB64(file){
  return new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(String(r.result).split(',')[1]); r.onerror = rej; r.readAsDataURL(file); });
}
/* النداء نفسه */
async function aiAsk(text, image){
  if(!aiReady()) throw new Error('nokey');
  const pack = 'OFFICIAL DOCUMENTATION — index of every request (method path — name: purpose):\n' + aiIndex()
    + '\n\nVERIFIED KNOWLEDGE (facts confirmed from real responses and tickets):\n' + aiFacts();
  const detail = 'CANDIDATE REQUESTS — full description and sample body:\n\n' + aiDetail(text);
  const content = [];
  if(image){ content.push({type:'image', source:{type:'base64', media_type: image.type || 'image/png', data: await _aiB64(image)}}); }
  content.push({type:'text', text: detail + '\n\n=====\nENGINEER CONTEXT: ' + (SESSION.token ? 'connected to a customer account' : 'not connected') + (SESSION.unit && SESSION.unit.uid ? `; device set in the tool: IMEI ${SESSION.unit.imei || '?'} = UID ${SESSION.unit.uid} (${SESSION.unit.name || ''})` : '')
    + '\n\nMESSAGE FROM THE CUSTOMER OR QUESTION FROM THE ENGINEER:\n' + aiRedact(text)});
  const body = { model: AI.model, max_tokens: 4000,
    system: [{type:'text', text: AI_RULES}, {type:'text', text: pack, cache_control:{type:'ephemeral'}}],
    tools: [AI_TOOL], messages: [{role:'user', content}] };
  const r = await fetch('https://api.anthropic.com/v1/messages', { method:'POST',
    headers: {'content-type':'application/json', 'x-api-key': AI.key, 'anthropic-version':'2023-06-01', 'anthropic-dangerous-direct-browser-access':'true'},
    body: JSON.stringify(body) });
  const j = await r.json().catch(() => ({}));
  if(!r.ok){ const err = new Error((j && j.error && j.error.message) || ('HTTP ' + r.status)); err.status = r.status; throw err; }
  const tu = (j.content || []).find(c => c.type === 'tool_use' && c.name === 'answer');
  let ans = tu ? tu.input : null;
  if(!ans){ const txt = (j.content || []).filter(c => c.type === 'text').map(c => c.text).join('\n'); const m = txt.match(/\{[\s\S]*\}/); if(m){ try{ ans = JSON.parse(m[0]); }catch(_){} } }
  if(!ans) throw new Error('no-answer');
  const u = j.usage || {};
  AI.usage.calls++; AI.usage.inp += (u.input_tokens || 0) + (u.cache_read_input_tokens || 0) + (u.cache_creation_input_tokens || 0); AI.usage.out += (u.output_tokens || 0);
  ans._usage = u; ans._model = j.model || AI.model;
  return aiValidate(ans);
}
function aiCost(u, model){
  const p = AI_PRICE[model] || AI_PRICE['claude-sonnet-5'];
  const inp = ((u.input_tokens || 0) + (u.cache_creation_input_tokens || 0) * 1.25 + (u.cache_read_input_tokens || 0) * 0.1) * p[0] / 1e6 + (u.output_tokens || 0) * p[1] / 1e6;
  return '$' + inp.toFixed(3);
}
/* إعدادات المفتاح — جوه خانة الرسالة */
function aiSettingsHtml(){
  return `<div id="aiSet" class="panel" style="margin-top:10px" ${aiReady() ? 'hidden' : ''}><div class="sec" style="border-top:0">
    <h3>${t('Claude جوه الأداة','Claude inside the tool')}</h3>
    <div class="note" style="margin-bottom:8px">${t(
      'بتفهم أي رسالة عميل أو سؤال منك، وبتجاوب من التوثيق الرسمي بس — وكل مسار بتذكره بيتفحص قبل ما يظهر. الرسالة (والصورة) بتتبعت لـ Anthropic API على حساب المفتاح ده؛ التوكن وكلمة السر بيتشالوا قبل الإرسال. المفتاح بيتحفظ على الجهاز ده بس زي الحسابات.',
      'Understands any customer message or question from you and answers from the official documentation only — every path it cites is checked before it is shown. The message (and image) is sent to the Anthropic API under this key; tokens and passwords are stripped first. The key is kept on this device only, like saved accounts.')}</div>
    <div class="row">
      <input id="aiKey" type="password" placeholder="sk-ant-…" value="${esc(AI.key)}" style="flex:1 1 260px; font-family:var(--mono, monospace)" autocomplete="off">
      <select id="aiModel">${AI_MODELS.map(([v,l]) => `<option value="${v}" ${AI.model===v?'selected':''}>${esc(l)}</option>`).join('')}</select>
    </div>
    <div class="row" style="margin-top:8px; font-size:13px; gap:14px">
      <label><input type="checkbox" id="aiVision" ${AI.vision?'checked':''}> ${t('ابعت الصورة نفسها لـ Claude (أدق من القراءة المحلية)','Send the image itself to Claude (more accurate than local reading)')}</label>
      <label><input type="checkbox" id="aiRemember" ${AI.remember?'checked':''}> ${t('افتكر المفتاح على الجهاز ده','Remember the key on this device')}</label>
      <button class="btn sig" id="aiSave" style="margin-inline-start:auto">${t('احفظ','Save')}</button>
    </div>
    <div style="font-size:12px; color:var(--muted); margin-top:6px">${t('المفتاح من console.anthropic.com — مفتاح الفريق أو مفتاحك. التكلفة التقريبية للنداء بتظهر بعد كل مرة.','Get the key from console.anthropic.com — the team key or your own. The approximate cost shows after each call.')}</div>
  </div></div>`;
}
function aiWireSettings(){
  const s = $('aiSave'); if(!s) return;
  s.onclick = ()=>{ AI.key = ($('aiKey').value || '').trim(); AI.model = $('aiModel').value; AI.vision = $('aiVision').checked; AI.remember = $('aiRemember').checked; aiStore();
    toast(aiReady() ? t('اتحفظ — زرار «افهمها بـ Claude» شغّال','Saved — the Claude button is live') : t('المفتاح مش شكله مفتاح','That does not look like a key'));
    const box = $('aiSet'); if(box) box.hidden = aiReady(); const b = $('aiGo'); if(b) b.disabled = !aiReady(); };
}
/* زرار الفهم في خانة الرسالة */
async function aiRun(text){
  const out = $('caseOut'); if(!out) return;
  if(!aiReady()){ const box = $('aiSet'); if(box){ box.hidden = false; $('aiKey').focus(); } return; }
  if(AI.busy) return; AI.busy = true;
  const img = (AI.vision && AI.lastImage) ? AI.lastImage : null;
  out.innerHTML = `<div class="panel"><div class="sec" style="border-top:0"><div class="note">${t('Claude بيقرا الرسالة والتوثيق…','Claude is reading the message and the documentation…')}${img ? ' ' + t('(مع الصورة)','(with the image)') : ''}</div></div></div>`;
  try{
    const ans = await aiAsk(text, img); AI.last = ans; AI.busy = false;
    renderAi(ans, out, text);
  }catch(err){
    AI.busy = false;
    const m = String(err && err.message || err);
    out.innerHTML = `<div class="panel"><div class="sec" style="border-top:0"><div class="note warn"><b>${t('ما قدرناش ننده Claude.','Could not reach Claude.')}</b> ${
      m === 'nokey' ? t('مفيش مفتاح.','No key.') : /invalid x-api-key|authentication/i.test(m) ? t('المفتاح مرفوض — راجعه في الإعدادات.','The key was rejected — check it in the settings.')
      : /credit|billing|quota/i.test(m) ? t('رصيد المفتاح خلص.','The key has no credit.') : /Failed to fetch|NetworkError|network/i.test(m) ? t('مفيش نت.','No internet connection.') : esc(m.slice(0, 160))}</div></div></div>`;
    const box = $('aiSet'); if(box && /invalid x-api-key|authentication|nokey/i.test(m)) box.hidden = false;
  }
}
let AI_LANG = null;
function renderAi(ans, out, text){
  const lang = AI_LANG || (ans.reply_ar && /[\u0600-\u06FF]/.test(text || '') ? 'ar' : 'en');
  const reply = lang === 'ar' ? (ans.reply_ar || ans.reply_en || '') : (ans.reply_en || ans.reply_ar || '');
  const kindT = {troubleshoot:['تذكرة عطل','Troubleshooting'], integration_request:['طلب إنتجريشن','Integration request'], fields_request:['حقول من المنصة','Platform fields'], question:['سؤال','Question'], other:['حاجة تانية','Other']};
  const chip = st => st === 'invented' ? `<span class="pill" style="background:var(--alert-soft); color:var(--alert-ink)">${t('مش في الكولكشن — مخترع','not in the collection — invented')}</span>`
    : st === 'undocumented' ? `<span class="pill" style="background:var(--signal-soft); color:var(--signal-deep)">${t('مش في التوثيق الرسمي','not in the official documentation')}</span>` : `<span class="pill" style="background:var(--ok-soft); color:var(--ok)">${t('موثّق','documented')}</span>`;
  const epBtn = p => { const e = EPS.find(x => x.p === p && sysOf(x) === 'avl'); return e ? `<button class="chip" data-goep="${e.i}" style="padding:1px 8px"><code>${esc(p)}</code></button>` : `<code>${esc(p)}</code>`; };
  const steps = (ans.steps || []).map((s, i) => `<tr><td style="width:34%"><b>${i + 1}.</b> ${esc(s.method || 'POST')} ${epBtn(s.path)}<br>${chip(s.st)}</td>
      <td><pre class="pre" style="white-space:pre-wrap; font-size:12px; margin:0">${esc(typeof s.body === 'object' && !s.body._raw ? JSON.stringify(s.body) : String((s.body && s.body._raw) || ''))}</pre>
      <div style="font-size:12.5px; color:var(--ink-2); margin-top:4px">${esc(dual({ar:s.why_ar || s.why_en || '', en:s.why_en || s.why_ar || ''}))}</div></td></tr>`).join('');
  const issues = ans.replyIssues.length ? `<div class="note warn" style="margin-top:8px">${t('الرد بيذكر مسارات:','The reply mentions paths:')} ${ans.replyIssues.map(x => `<code>${esc(x.path)}</code> ${chip(x.st)}`).join(' ')}</div>` : '';
  const u = ans._usage || {};
  out.innerHTML = `
    <div class="panel"><div class="sec" style="border-top:0"><div class="caseVerdict">
      <div style="flex:1 1 300px; min-width:0"><div class="crumb">${t('الفهم — بـ Claude','Understanding — by Claude')} · ${esc((kindT[ans.kind] || kindT.other)[LANG === 'en' ? 1 : 0])} · ${t('ثقة','confidence')} ${Math.round((ans.confidence || 0) * 100)}%</div>
        <div style="font-size:15px; font-weight:600; margin-top:5px; line-height:1.6">${esc(ans.summary_ar || '')}</div>
        ${ans.diagnosis_ar ? `<div style="margin-top:6px; line-height:1.6">${esc(ans.diagnosis_ar)}</div>` : ''}</div>
      <span class="chip ${ans.blocked ? 'bad' : 'sig'}" style="pointer-events:none; flex:0 0 auto">${ans.blocked ? t('فيه مسار مخترع — ما تبعتش','Invented path — do not send') : ans.warn ? t('راجع التحذيرات','Check the warnings') : t('اتفحص: كل المسارات موثّقة','Checked: every path is documented')}</span></div>
      <div class="note" style="margin-top:8px">${t('اتولّد بالذكاء الاصطناعي من التوثيق الرسمي والمعرفة المؤكدة. الأداة فحصت كل مسار اتذكر — بس اقرا الرد قبل ما تبعته.','Generated by AI from the official documentation and verified knowledge. The tool checked every path mentioned — still read the reply before sending.')}
        <span style="color:var(--muted)"> · ${esc(ans._model || '')} · ${t('التكلفة التقريبية','approx. cost')} ${aiCost(u, ans._model)}</span></div>
    </div></div>
    ${steps ? `<div class="panel" style="margin-top:12px"><div class="sec" style="border-top:0"><h3>${t('الخطوات بالإندبوينتس','Steps with endpoints')}</h3><table class="kv" style="font-size:13px">${steps}</table></div></div>` : ''}
    <div class="panel" style="margin-top:12px"><div class="sec" style="border-top:0">
      <h3>${t('رد جاهز للعميل','A reply ready to send')}</h3>
      <div class="row" style="margin-bottom:8px">
        <button class="ct" id="aiAr" aria-selected="${lang==='ar'}">${t('عربي','Arabic')}</button>
        <button class="ct" id="aiEn" aria-selected="${lang==='en'}">${t('إنجليزي','English')}</button></div>
      ${issues}
      <pre id="caseReplyTxt" class="pre" style="white-space:pre-wrap; font-family:var(--ar); font-size:13.5px; background:var(--panel-2); padding:14px; border-radius:var(--r); border:1px solid var(--line); direction:${lang==='ar'?'rtl':'ltr'}; text-align:${lang==='ar'?'right':'left'}; color:var(--ink)">${esc(reply)}</pre>
      <div class="row" style="margin-top:10px"><button class="btn ${ans.blocked ? 'ghost' : 'sig'}" id="caseCopy">${ans.blocked ? t('انسخ (فيه مسار مخترع!)','Copy (contains an invented path!)') : t('انسخ الرد','Copy the reply')}</button></div>
    </div></div>
    ${(ans.unverified || []).length || (ans.needs_from_customer || []).length ? `<div class="panel" style="margin-top:12px"><div class="sec" style="border-top:0">
      ${(ans.unverified || []).length ? `<h3>${t('مش مؤكد — ما يتقالش للعميل كمؤكد','Unverified — never state it as certain')}</h3><ul>${ans.unverified.map(x => `<li>${esc(x)}</li>`).join('')}</ul>` : ''}
      ${(ans.needs_from_customer || []).length ? `<h3 style="margin-top:10px">${t('محتاج من العميل','Needed from the customer')}</h3><ul>${ans.needs_from_customer.map(x => `<li>${esc(x)}</li>`).join('')}</ul>` : ''}
    </div></div>` : ''}`;
  out.querySelectorAll('[data-goep]').forEach(b => b.onclick = ()=>{ const e = EPS.find(x => String(x.i) === b.dataset.goep); if(e){ showView('search'); select(e, []); pushRecent(e); } });
  $('caseCopy').onclick = ()=>{ copy(reply, t('الرد اتنسخ','Reply copied')); };
  $('aiAr').onclick = ()=>{ AI_LANG = 'ar'; renderAi(ans, out, text); };
  $('aiEn').onclick = ()=>{ AI_LANG = 'en'; renderAi(ans, out, text); };
}
/* القواعد ما عرفتش → اقتراح Claude فوق النتيجة */
function aiHint(text){
  const out = $('caseOut'); if(!out || !out.innerHTML) return;
  const a = analyzeCase(text); const m = caseMatch(a);
  const unknown = !a.reqCase && !a.fieldsCase && !a.reportCase && (!m || m.h.score < CASE_SURE);
  if(!unknown) return;
  out.insertAdjacentHTML('afterbegin', `<div class="note sig" style="margin-bottom:10px"><b>${t('القواعد ما عرفتش الحالة دي.','The rules did not recognise this case.')}</b> ${aiReady()
    ? t('اضغط «افهمها بـ Claude» وهتاخد الفهم والتشخيص والرد من التوثيق الرسمي.','Press "Understand with Claude" for the understanding, the diagnosis and the reply from the official documentation.')
    : t('حط مفتاح Anthropic في الإعدادات تحت و«افهمها بـ Claude» هتفهمها من التوثيق الرسمي.','Add an Anthropic key in the settings below and "Understand with Claude" will handle it from the official documentation.')}</div>`);
}
"""

rep("\nfunction renderCase(text){\n  const out = $('caseOut');",
    AI_JS + "\nfunction renderCase(text){\n  const out = $('caseOut');", tag='طبقة Claude')

rep("""      <div class="row" style="margin-top:10px">
        <button class="btn sig" id="caseGo">${t('حلّل','Analyse')}</button>
        <label class="btn ghost" style="cursor:pointer">${t('أو ارفع صورة الرد','or upload the response image')}
          <input type="file" id="caseImg" accept="image/*" hidden></label>
        <button class="btn ghost" id="caseClear">${t('مسح','Clear')}</button>
      </div>
      <div id="caseImgBox" style="margin-top:10px" hidden></div>
    </div></div>
    <div id="caseOut"></div>`;
  $('caseGo').onclick = ()=>renderCase($('caseText').value);""",
"""      <div class="row" style="margin-top:10px">
        <button class="btn sig" id="caseGo">${t('حلّل','Analyse')}</button>
        <button class="btn" id="aiGo" ${aiReady() ? '' : 'disabled'} title="${esc(t('فهم أي رسالة أو سؤال من التوثيق الرسمي','Understand any message or question from the official documentation'))}">${t('افهمها بـ Claude','Understand with Claude')}</button>
        <label class="btn ghost" style="cursor:pointer">${t('أو ارفع صورة الرد','or upload the response image')}
          <input type="file" id="caseImg" accept="image/*" hidden></label>
        <button class="btn ghost" id="caseClear">${t('مسح','Clear')}</button>
        <button class="chip" id="aiCfg" style="margin-inline-start:auto">${t('إعدادات Claude','Claude settings')}</button>
      </div>
      <div id="caseImgBox" style="margin-top:10px" hidden></div>
      ${aiSettingsHtml()}
    </div></div>
    <div id="caseOut"></div>`;
  $('caseGo').onclick = ()=>{ const v = $('caseText').value; renderCase(v); aiHint(v); };
  $('aiGo').onclick = ()=>aiRun($('caseText').value);
  $('aiCfg').onclick = ()=>{ const b = $('aiSet'); if(b){ b.hidden = !b.hidden; } };
  aiWireSettings();""", tag='زراير Claude في الخانة')

rep("""  const run = async file => {
    if(!file || !/^image\\//.test(file.type || '')){ toast(t('ده مش ملف صورة','That is not an image file')); return; }""",
"""  const run = async file => {
    if(!file || !/^image\\//.test(file.type || '')){ toast(t('ده مش ملف صورة','That is not an image file')); return; }
    if(mode === 'case') AI.lastImage = file;   /* v7.0: الصورة نفسها بتتبعت لـ Claude لو فيه مفتاح */""", tag='الصورة الأخيرة للرؤية')
rep("""  $('caseClear').onclick = ()=>{ $('caseText').value=''; $('caseOut').innerHTML=''; CASE_LIVE = null;""",
    """  $('caseClear').onclick = ()=>{ $('caseText').value=''; $('caseOut').innerHTML=''; CASE_LIVE = null; AI.lastImage = null;""", tag='المسح بيمسح الصورة')
rep("""\naddedRestore();\n""", """\naddedRestore();\naiLoad();   /* v7.0: مفتاح Claude المحفوظ على الجهاز */\n""", tag='تحميل الإعدادات')

io.open(PATH, 'w', encoding='utf-8').write(src)
print('القالب: %d → %d بايت' % (orig, len(src)))

bp = os.path.join(HERE, 'build.py'); bb = io.open(bp, encoding='utf-8').read()
old = "    ('const FIELD_MAP',              'حقول كارت المنصة ← مكانها في الرد'),\n]"
new = "    ('const FIELD_MAP',              'حقول كارت المنصة ← مكانها في الرد'),\n    ('function aiValidate',          'Claude جوه الأداة — وكل مسار بيتفحص'),\n]"
if 'function aiValidate' in bb: print('  --  علامة البناء موجودة')
elif bb.count(old) != 1: raise SystemExit('MISMATCH build.py markers')
else: io.open(bp, 'w', encoding='utf-8').write(bb.replace(old, new)); print('  ok  علامة البناء')
