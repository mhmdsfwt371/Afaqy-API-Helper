/* v6.40 — نسختين من الكولكشن.
   الحاجة الخطيرة: النسخة اللي للعميل لازم تفضل صفر تسريب مهما حصل. */
const fs=require('fs'); const {JSDOM}=require('jsdom');
let F=0; const pass=m=>console.log('  \u2713 '+m); const fail=m=>{console.log('  \u2717 '+m);F++;};
const ok=(m,c,x)=>c?pass(m):fail(m+(x?'  \u2014 '+String(x).slice(0,120):''));
const build=()=>fs.readFileSync(process.argv[2]||'app_template.html','utf8')
  .replace('/*__KB__*/',()=>fs.readFileSync('kb_slim.json','utf8'))
  .replace('/*__DOCS__*/',()=>fs.readFileSync('docs.json','utf8'))
  .replace('/*__KBIN__*/',()=>fs.readFileSync('kb_in.json','utf8'));

const SECRETS = ['eyJLIVE_TOKEN_SECRET','P@ssw0rd!','UID_PRIVATE_9','CustomerAcctX'];
function boot(){
  const w=new JSDOM(build(),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://localhost/'}).window;
  w.alert=()=>{}; w.confirm=()=>true; w.scrollTo=()=>{};
  w.eval(`SESSION.token='${SECRETS[0]}'; SESSION.user='${SECRETS[3]}';
          SESSION.pass='${SECRETS[1]}'; SESSION.userId='${SECRETS[2]}';`);
  return w;
}
const col = (w, mine) => JSON.parse(w.eval(
  `JSON.stringify(pmFromRecipe(RECIPES.find(r=>r.id==='summary-report'), ${mine?'true':'false'}))`));

/* ═════ ١) نسخة العميل: صفر تسريب ═════ */
console.log('\n\u0661) نسخة العميل لسه نظيفة');
{
  const w=boot(); const c=col(w,false); const s=JSON.stringify(c);
  SECRETS.forEach(x=>ok('مفيش '+x.slice(0,18), s.indexOf(x)<0));
  const V={}; c.variable.forEach(v=>V[v.key]=v.value);
  ok('التوكن فاضي', V.token==='', V.token);
  ok('اسم المستخدم فاضي', V.username==='', V.username);
  ok('رقم المستخدم فاضي', (V.user_id||'')==='', V.user_id);
  ok('مفيش تحذير في الاسم', c.info.name.indexOf('DO NOT SHARE')<0, c.info.name);
  w.close();
}

/* ═════ ٢) نسختي: معبّاة وشغالة على طول ═════ */
console.log('\n\u0662) نسختي معبّاة');
{
  const w=boot(); const c=col(w,true);
  const V={}; c.variable.forEach(v=>V[v.key]=v.value);
  ok('التوكن اتحط', V.token===SECRETS[0], V.token);
  ok('اسم المستخدم اتحط', V.username===SECRETS[3], V.username);
  ok('رقم المستخدم اتحط', V.user_id===SECRETS[2], V.user_id);
  ok('الباسورد ما اتكتبش أبدًا', V.password==='', V.password);
  ok('ومفيش الباسورد في أي مكان في الملف', JSON.stringify(c).indexOf(SECRETS[1])<0);
  w.close();
}

/* ═════ ٣) التحذير صريح في الملف نفسه ═════ */
console.log('\n\u0663) التحذير مكتوب في الملف');
{
  const w=boot(); const c=col(w,true);
  ok('الاسم فيه تحذير', /DO NOT SHARE/.test(c.info.name), c.info.name);
  ok('الوصف بيقول إن فيه توكن', /LIVE ACCESS TOKEN/.test(c.info.description));
  ok('وبيقول ما تبعتوش لعميل', /Do not send it to a\s*\ncustomer/.test(c.info.description) ||
     /do not send/i.test(c.info.description));
  w.close();
}

/* ═════ ٤) الترتيب — أهم حاجة في السلسلة دي ═════ */
console.log('\n\u0664) الترتيب محفوظ في النسختين');
{
  const w=boot();
  [['العميل',false],['أنا',true]].forEach(([lbl,mine])=>{
    const c=col(w,mine);
    const paths=c.item.map(i=>'/'+i.request.url.path.join('/'));
    const iAdd=paths.indexOf('/user_reports/add');
    const iPct=paths.indexOf('/user_reports/percentage');
    const iSum=paths.indexOf('/user_reports/data-summary');
    ok(lbl+': الدخول أول حاجة', paths[0]==='/auth/login', paths[0]);
    ok(lbl+': إنشاء ← انتظار ← قراءة',
       iAdd>-1 && iPct>iAdd && iSum>iPct, paths.join(' → '));
  });
  w.close();
}

/* ═════ ٥) الزرار مقفول لو مش متصل ═════ */
console.log('\n\u0665) الزرار مقفول من غير اتصال');
{
  const w=new JSDOM(build(),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://localhost/'}).window;
  w.alert=()=>{}; w.scrollTo=()=>{};
  w.showView('recipes'); w.startRecipe('summary-report');
  const b=w.document.getElementById('rcPmMine');
  ok('زرار «ليّا» موجود', !!b);
  ok('ومقفول وإحنا مش متصلين', b && b.hasAttribute('disabled'));
  ok('وزرار العميل مفتوح', !w.document.getElementById('rcPm').hasAttribute('disabled'));
  w.close();
}

console.log('\n'+(F?'\u2717 فشل: '+F:'\u2713 كله عدّى'));
process.exit(F?1:0);
